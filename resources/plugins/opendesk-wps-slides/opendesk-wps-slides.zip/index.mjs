// integrations/opendesk-plugin/plugin-entry.mjs
import fs4 from "node:fs";
import path4 from "node:path";
import { execFileSync } from "node:child_process";

// integrations/opendesk-plugin/recovery-command.mjs
import { randomBytes } from "node:crypto";

// integrations/opendesk-plugin/recovery-endpoint.mjs
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
function createRecoveryEndpoint(platform = process.platform, temporaryRoot = os.tmpdir()) {
  if (platform === "win32") return { endpoint: `\\\\.\\pipe\\wps-recovery-${randomUUID()}`, dispose() {
  } };
  if (!path.isAbsolute(temporaryRoot)) throw new Error("wps_recovery_temporary_root_invalid");
  const directory = fs.mkdtempSync(path.join(temporaryRoot, "wps-r-"));
  const endpoint = path.join(directory, "r.sock");
  try {
    fs.chmodSync(directory, 448);
    if (Buffer.byteLength(endpoint, "utf8") > 103) throw new Error("wps_recovery_socket_path_too_long");
    return { endpoint, dispose() {
      fs.rmSync(directory, { recursive: true, force: true });
    } };
  } catch (error) {
    fs.rmSync(directory, { recursive: true, force: true });
    throw error;
  }
}

// integrations/opendesk-plugin/recovery-command.mjs
function createRecoveryEnvironment(allocation = createRecoveryEndpoint()) {
  const { endpoint } = allocation;
  const secret = randomBytes(32).toString("hex");
  return { WPS_RECOVERY_COMMAND_PIPE: endpoint, WPS_RECOVERY_COMMAND_SECRET: secret };
}

// integrations/opendesk-plugin/js-bridge-config.mjs
import fs2 from "node:fs/promises";
import path2 from "node:path";
import { randomBytes as randomBytes2 } from "node:crypto";
function validateJsBridgeConfig(value) {
  const port = (number) => Number.isInteger(number) && number >= 1024 && number <= 65535;
  if (!value || value.schemaVersion !== 1 || !/^[a-f0-9]{64}$/.test(value.secret || "") || !/^[a-f0-9]{64}$/.test(value.resourceToken || "") || !port(value.bridgePort) || !port(value.addinPort) || value.bridgePort === value.addinPort) {
    throw new Error("wps_js_installation_config_invalid");
  }
  return value;
}
async function prepareJsBridgeConfig(stateRoot) {
  if (!path2.isAbsolute(stateRoot)) throw new Error("wps_js_state_root_invalid");
  const directory = path2.join(stateRoot, "js-bridge");
  await fs2.mkdir(directory, { recursive: true, mode: 448 });
  const file = path2.join(directory, "installation.json");
  const lock = path2.join(directory, "initializing");
  const read = async () => validateJsBridgeConfig(JSON.parse(await fs2.readFile(file, "utf8")));
  const deadline = Date.now() + 3e3;
  while (true) {
    try {
      return { file, config: await read() };
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    try {
      await fs2.mkdir(lock, { mode: 448 });
      break;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      if (Date.now() >= deadline) throw new Error("wps_js_installation_initializing");
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  }
  const temporary = path2.join(lock, "installation.json");
  try {
    try {
      return { file, config: await read() };
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const config = {
      schemaVersion: 1,
      secret: randomBytes2(32).toString("hex"),
      resourceToken: randomBytes2(32).toString("hex"),
      bridgePort: 58912,
      addinPort: 58913
    };
    await fs2.writeFile(temporary, JSON.stringify(config), { flag: "wx", mode: 384 });
    await fs2.rename(temporary, file);
    return { file, config: await read() };
  } finally {
    await fs2.rm(lock, { recursive: true, force: true });
  }
}

// integrations/opendesk-plugin/addin-host.mjs
import fs3 from "node:fs/promises";
import path3 from "node:path";
import { createServer } from "node:http";
import { createHash, timingSafeEqual } from "node:crypto";
async function startAddinHost({ resourceRoot, config, platform, openExternal }) {
  const metadata = JSON.parse(await fs3.readFile(path3.join(resourceRoot, "resource-manifest.json"), "utf8"));
  const main = await fs3.readFile(path3.join(resourceRoot, "main.js"), "utf8");
  if (metadata.schemaVersion !== 1 || createHash("sha256").update(main).digest("hex") !== metadata.mainSha256) {
    throw new Error("wps_js_addin_resource_integrity_invalid");
  }
  const origin = `http://127.0.0.1:${config.addinPort}`;
  const prefix = `/${config.resourceToken}/${metadata.mainSha256}/`;
  const name = "opendesk-wps-ppt-js-bridge";
  const runtimeConfig = {
    serverUrl: `http://127.0.0.1:${config.bridgePort}`,
    secret: config.secret,
    platform: platform === "openharmony" ? "harmonyos" : platform,
    addinVersion: metadata.addinVersion,
    sourceSha256: metadata.mainSha256,
    capabilities: metadata.capabilities,
    capabilityReport: metadata.capabilityReport,
    capabilityHash: metadata.capabilityHash
  };
  const resources = /* @__PURE__ */ new Map([
    ["main.js", { type: "application/javascript", body: `var WpsJsBridgeBuildConfig = ${JSON.stringify(runtimeConfig)};
${main}` }],
    ["jsplugins.xml", { type: "application/xml", body: `<?xml version="1.0" encoding="UTF-8"?><jsplugins><jspluginonline name="${name}" type="wpp" url="${origin}${prefix}" install="true" version="${metadata.addinVersion}" enable="enable_dev"/></jsplugins>` }]
  ]);
  for (const file of ["index.html", "manifest.xml", "ribbon.xml"]) resources.set(file, {
    type: file.endsWith(".html") ? "text/html" : "application/xml",
    body: await fs3.readFile(path3.join(resourceRoot, file))
  });
  let launching;
  const server = createServer((request, response) => {
    void (async () => {
      response.setHeader("Cache-Control", "no-store");
      response.setHeader("X-Content-Type-Options", "nosniff");
      const url = request.url || "";
      if (request.method === "POST" && url === "/launch-relay") {
        const supplied = Buffer.from(String(request.headers.authorization || ""));
        const expected = Buffer.from(`Bearer ${config.secret}`);
        if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
          response.writeHead(403);
          response.end();
          return;
        }
        launching ??= Promise.resolve().then(() => openExternal("ksoWPSCloudSvr://start=RelayHttpServer")).finally(() => {
          launching = void 0;
        });
        await launching;
        response.writeHead(204);
        response.end();
        return;
      }
      const resource = request.method === "GET" && url.startsWith(prefix) ? resources.get(url.slice(prefix.length)) : void 0;
      if (!resource) {
        response.writeHead(404);
        response.end();
        return;
      }
      response.writeHead(200, { "Content-Type": `${resource.type}; charset=utf-8` });
      response.end(resource.body);
    })().catch(() => {
      if (!response.headersSent) response.writeHead(503);
      response.end("wps_js_addin_host_unavailable");
    });
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(config.addinPort, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  return {
    origin,
    url: `${origin}${prefix}`,
    name,
    version: metadata.addinVersion,
    sourceSha256: metadata.mainSha256,
    async dispose() {
      server.closeAllConnections();
      await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }
  };
}

// integrations/opendesk-plugin/plugin-entry.mjs
function resolveNodeExecutable(runtime = process, verify) {
  const windows = (runtime.platform || process.platform) === "win32";
  const basename = windows ? "node.exe" : "node";
  const pathKey = Object.keys(runtime.env).find((key) => key.toLowerCase() === "path");
  const directories = String(runtime.env[pathKey] || "").split(windows ? ";" : ":").map((entry) => entry.trim().replace(/^"(.*)"$/, "$1")).filter(Boolean);
  const candidates = [
    ...path4.basename(runtime.execPath).toLowerCase() === basename ? [runtime.execPath] : [],
    ...directories.map((directory) => path4.join(directory, basename))
  ];
  const seen = /* @__PURE__ */ new Set();
  let verificationError;
  for (const candidate of candidates) {
    try {
      const real = fs4.realpathSync(candidate);
      const key = windows ? real.toLowerCase() : real;
      if (seen.has(key)) continue;
      seen.add(key);
      if (fs4.statSync(real).isFile()) {
        if (!windows) fs4.accessSync(real, fs4.constants.X_OK);
        if (verify) {
          try {
            verify(real);
          } catch (error) {
            verificationError = error;
            continue;
          }
        }
        return real;
      }
    } catch {
    }
  }
  throw verificationError || new Error("wps_slides_node_runtime_unavailable");
}
function verifyNodeExecutable(executable, run = execFileSync) {
  let version;
  try {
    version = run(executable, ["--version"], {
      encoding: "utf8",
      timeout: 5e3,
      windowsHide: true,
      maxBuffer: 4096
    }).trim();
  } catch {
    throw new Error("wps_slides_node_runtime_invalid");
  }
  const match = /^v(\d+)\.\d+\.\d+$/.exec(version);
  if (!match) throw new Error("wps_slides_node_runtime_invalid");
  if (Number(match[1]) < 18) throw new Error("wps_slides_node_runtime_unsupported");
}
function containedFile(root, relative) {
  if (typeof relative !== "string" || !relative || path4.isAbsolute(relative)) {
    throw new Error("wps_slides_runtime_path_invalid");
  }
  const full = fs4.realpathSync(path4.resolve(root, relative));
  const within = path4.relative(root, full);
  if (within === ".." || within.startsWith(`..${path4.sep}`) || path4.isAbsolute(within) || !fs4.statSync(full).isFile()) {
    throw new Error("wps_slides_runtime_path_invalid");
  }
  return full;
}
function companionWindowEnvironment(runtime = process) {
  const createdAt = runtime.versions.electron && runtime.type === "browser" ? runtime.getCreationTime?.() : null;
  return {
    OPENDESK_WPS_COMPANION_WINDOW: Number.isFinite(createdAt) && createdAt > 0 ? JSON.stringify({ pid: runtime.pid, executable: runtime.execPath, createdAt }) : ""
  };
}
var plugin_entry_default = {
  id: "opendesk-wps-slides",
  apiVersion: 1,
  capabilities: ["skill", "mcp", "command"],
  async setup(ctx) {
    if (process.platform === "openharmony") return setupHarmony(ctx);
    if (process.platform !== "win32") return;
    const useElectronNode = Boolean(process.versions.electron);
    const nodeExecutable = useElectronNode ? process.execPath : resolveNodeExecutable();
    if (!useElectronNode) verifyNodeExecutable(nodeExecutable);
    const root = fs4.realpathSync(ctx.pluginDir);
    const descriptor = JSON.parse(fs4.readFileSync(containedFile(root, "wps-slides.runtime.json"), "utf8"));
    const filter = containedFile(root, descriptor.filterEntry);
    const mcp = containedFile(root, descriptor.mcpEntry);
    const gateway = containedFile(root, descriptor.gatewayContract);
    const com = containedFile(root, descriptor.wpsComScript);
    const windowScript = containedFile(root, descriptor.wpsWindowScript);
    const localAppData = String(process.env.LOCALAPPDATA || "").trim();
    if (!localAppData || !path4.isAbsolute(localAppData)) throw new Error("wps_slides_local_app_data_unavailable");
    const runtimeCwd = path4.join(localAppData, "OpenDesk", "wps-slides", "runtime-workdir");
    fs4.mkdirSync(runtimeCwd, { recursive: true });
    const state = Object.fromEntries(["scenes", "scene-resources", "artifacts", "assets", "lifecycle-authorizations"].map((name) => {
      const directory = path4.join(localAppData, "OpenDesk", "wps-slides", name);
      fs4.mkdirSync(directory, { recursive: true });
      return [name, directory];
    }));
    const mode = String(process.env.WPS_NATIVE_EXECUTOR || "wps-js-bridge").trim().toLowerCase();
    if (!["wps-js-bridge", "windows-com"].includes(mode)) throw new Error(`unsupported_wps_native_executor:${mode}`);
    let addin;
    let bridgeEnv = {};
    const allocation = createRecoveryEndpoint();
    const recoveryEnvironment = createRecoveryEnvironment(allocation);
    try {
      if (mode === "wps-js-bridge") {
        const { config } = await prepareJsBridgeConfig(path4.dirname(runtimeCwd));
        addin = await startAddinHost({
          resourceRoot: path4.dirname(containedFile(root, "./addin/resource-manifest.json")),
          config,
          platform: process.platform,
          openExternal: async (uri) => {
            const { shell } = await import("electron");
            return shell.openExternal(uri);
          }
        });
        bridgeEnv = {
          WPS_JS_BRIDGE_SECRET: config.secret,
          WPS_JS_BRIDGE_PORT: String(config.bridgePort),
          WPS_JS_ADDIN_URL: addin.url,
          WPS_JS_ADDIN_NAME: addin.name,
          WPS_JS_ADDIN_VERSION: addin.version,
          WPS_JS_ADDIN_SOURCE_SHA256: addin.sourceSha256
        };
      }
      ctx.mcps.registerServer({
        name: "wps-office",
        transport: "stdio",
        command: nodeExecutable,
        args: [filter],
        cwd: runtimeCwd,
        env: {
          ...recoveryEnvironment,
          ...companionWindowEnvironment(),
          ...bridgeEnv,
          WPS_NATIVE_EXECUTOR: mode,
          ...useElectronNode ? { ELECTRON_RUN_AS_NODE: "1" } : {},
          OPENDESK_WPS_RUNTIME_MODE: "builtin-plugin-v1",
          OPENDESK_WPS_MCP_COMMAND: nodeExecutable,
          OPENDESK_WPS_MCP_SERVER_PATH: mcp,
          OPENDESK_WPS_MCP_SERVER_CWD: runtimeCwd,
          OPENDESK_WPS_GATEWAY_CONTRACT_PATH: gateway,
          OPENDESK_WPS_TOOL_EXPOSURE_MODE: "scene-v2",
          WPS_COM_SCRIPT_PATH: com,
          WPS_WINDOW_SCRIPT_PATH: windowScript,
          WPS_PPT_SCENE_DIR: state.scenes,
          WPS_PPT_SCENE_RESOURCE_DIR: state["scene-resources"],
          WPS_PPT_ARTIFACT_DIR: state.artifacts,
          WPS_ASSET_DIR: state.assets,
          WPS_PPT_LIFECYCLE_AUTH_DIR: state["lifecycle-authorizations"]
        }
      });
      if (addin) return async () => {
        await addin.dispose();
        allocation.dispose();
      };
    } catch (error) {
      if (addin) await addin.dispose();
      allocation.dispose();
      throw error;
    }
  }
};
async function setupHarmony(ctx) {
  const root = fs4.realpathSync(ctx.pluginDir);
  if (!path4.isAbsolute(ctx.configDir)) throw new Error("wps_slides_config_dir_invalid");
  const descriptor = JSON.parse(fs4.readFileSync(containedFile(root, "wps-slides.runtime.json"), "utf8"));
  const filter = containedFile(root, descriptor.filterEntry);
  const mcp = containedFile(root, descriptor.mcpEntry);
  const gateway = containedFile(root, descriptor.gatewayContract);
  let executable = process.execPath;
  let electronNode = false;
  if (process.versions.electron) {
    try {
      verifyNodeExecutable(executable, (command, args, options) => execFileSync(command, args, {
        ...options,
        env: { ...process.env, ELECTRON_RUN_AS_NODE: "1" }
      }));
      electronNode = true;
    } catch {
    }
  }
  if (!electronNode) executable = resolveNodeExecutable(process, verifyNodeExecutable);
  const stateRoot = path4.join(ctx.configDir, "wps-slides");
  const state = Object.fromEntries(["scenes", "scene-resources", "artifacts", "assets", "lifecycle-authorizations", "runtime-workdir"].map((name) => {
    const directory = path4.join(stateRoot, name);
    fs4.mkdirSync(directory, { recursive: true, mode: 448 });
    return [name, directory];
  }));
  const { config } = await prepareJsBridgeConfig(stateRoot);
  const { shell, app } = await import("electron");
  const documents = app.getPath("documents");
  if (!path4.isAbsolute(documents)) throw new Error("wps_shared_documents_path_invalid");
  const sharedRoot = path4.join(documents, "OpenDesk", "wps-slides", "resources");
  for (const name of ["assets", "screenshots", "template-work"]) fs4.mkdirSync(path4.join(sharedRoot, name), { recursive: true });
  const resources = path4.dirname(containedFile(root, "./addin/resource-manifest.json"));
  const allocation = createRecoveryEndpoint();
  const recoveryEnvironment = createRecoveryEnvironment(allocation);
  let addin;
  try {
    addin = await startAddinHost({
      resourceRoot: resources,
      config,
      platform: process.platform,
      openExternal: (uri) => shell.openExternal(uri)
    });
    ctx.mcps.registerServer({
      name: "wps-office",
      transport: "stdio",
      command: executable,
      args: [filter],
      cwd: state["runtime-workdir"],
      env: {
        ...recoveryEnvironment,
        ...electronNode ? { ELECTRON_RUN_AS_NODE: "1" } : {},
        ...!electronNode ? { NODE_OPTIONS: `${process.env.NODE_OPTIONS || ""} --jitless`.trim() } : {},
        OPENDESK_WPS_RUNTIME_MODE: "builtin-plugin-v1",
        OPENDESK_WPS_MCP_COMMAND: executable,
        OPENDESK_WPS_MCP_SERVER_PATH: mcp,
        OPENDESK_WPS_MCP_SERVER_CWD: state["runtime-workdir"],
        OPENDESK_WPS_GATEWAY_CONTRACT_PATH: gateway,
        OPENDESK_WPS_TOOL_EXPOSURE_MODE: "scene-v2",
        WPS_NATIVE_EXECUTOR: "wps-js-bridge",
        WPS_JS_BRIDGE_SECRET: config.secret,
        WPS_JS_BRIDGE_PORT: String(config.bridgePort),
        WPS_JS_ADDIN_URL: addin.url,
        WPS_JS_ADDIN_NAME: addin.name,
        WPS_JS_ADDIN_VERSION: addin.version,
        WPS_JS_ADDIN_SOURCE_SHA256: addin.sourceSha256,
        WPS_PPT_SCENE_DIR: state.scenes,
        WPS_PPT_SCENE_RESOURCE_DIR: state["scene-resources"],
        WPS_PPT_ARTIFACT_DIR: state.artifacts,
        WPS_ASSET_DIR: path4.join(sharedRoot, "assets"),
        WPS_PPT_SCREENSHOT_DIR: path4.join(sharedRoot, "screenshots"),
        WPS_PPT_TEMPLATE_WORK_DIR: path4.join(sharedRoot, "template-work"),
        WPS_PPT_LIFECYCLE_AUTH_DIR: state["lifecycle-authorizations"]
      }
    });
    return async () => {
      await addin.dispose();
      allocation.dispose();
    };
  } catch (error) {
    if (addin) await addin.dispose();
    allocation.dispose();
    throw error;
  }
}
export {
  companionWindowEnvironment,
  plugin_entry_default as default,
  resolveNodeExecutable,
  verifyNodeExecutable
};
