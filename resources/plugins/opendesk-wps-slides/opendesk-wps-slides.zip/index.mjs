import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

export function resolveNodeExecutable(runtime = process) {
  const pathKey = Object.keys(runtime.env).find((key) => key.toLowerCase() === 'path');
  const directories = String(runtime.env[pathKey] || '').split(';')
    .map((entry) => entry.trim().replace(/^"(.*)"$/, '$1')).filter(Boolean);
  const candidates = [
    ...(path.basename(runtime.execPath).toLowerCase() === 'node.exe' ? [runtime.execPath] : []),
    ...directories.map((directory) => path.join(directory, 'node.exe')),
  ];
  const seen = new Set();
  for (const candidate of candidates) {
    try {
      const real = fs.realpathSync(candidate);
      const key = real.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      if (fs.statSync(real).isFile()) return real;
    } catch { /* Missing PATH candidates are normal. */ }
  }
  throw new Error('wps_slides_node_runtime_unavailable');
}

export function verifyNodeExecutable(executable, run = execFileSync) {
  let version;
  try {
    version = run(executable, ['--version'], {
      encoding: 'utf8', timeout: 5000, windowsHide: true, maxBuffer: 4096,
    }).trim();
  } catch {
    throw new Error('wps_slides_node_runtime_invalid');
  }
  const match = /^v(\d+)\.\d+\.\d+$/.exec(version);
  if (!match) throw new Error('wps_slides_node_runtime_invalid');
  if (Number(match[1]) < 18) throw new Error('wps_slides_node_runtime_unsupported');
}

function containedFile(root, relative) {
  if (typeof relative !== 'string' || !relative || path.isAbsolute(relative)) {
    throw new Error('wps_slides_runtime_path_invalid');
  }
  const full = fs.realpathSync(path.resolve(root, relative));
  const within = path.relative(root, full);
  if (within === '..' || within.startsWith(`..${path.sep}`) || path.isAbsolute(within) || !fs.statSync(full).isFile()) {
    throw new Error('wps_slides_runtime_path_invalid');
  }
  return full;
}

export default {
  id: 'opendesk-wps-slides',
  apiVersion: 1,
  capabilities: ['skill', 'mcp'],
  setup(ctx) {
    if (process.platform !== 'win32') return;
    const useElectronNode = Boolean(process.versions.electron);
    const nodeExecutable = useElectronNode ? process.execPath : resolveNodeExecutable();
    if (!useElectronNode) verifyNodeExecutable(nodeExecutable);
    const root = fs.realpathSync(ctx.pluginDir);
    const descriptor = JSON.parse(fs.readFileSync(containedFile(root, 'wps-slides.runtime.json'), 'utf8'));
    const filter = containedFile(root, descriptor.filterEntry);
    const mcp = containedFile(root, descriptor.mcpEntry);
    const gateway = containedFile(root, descriptor.gatewayContract);
    const com = containedFile(root, descriptor.wpsComScript);
    const localAppData = String(process.env.LOCALAPPDATA || '').trim();
    if (!localAppData || !path.isAbsolute(localAppData)) throw new Error('wps_slides_local_app_data_unavailable');
    const runtimeCwd = path.join(localAppData, 'OpenDesk', 'wps-slides', 'runtime-workdir');
    fs.mkdirSync(runtimeCwd, { recursive: true });
    const state = Object.fromEntries(['scenes', 'scene-resources', 'artifacts', 'assets', 'lifecycle-authorizations'].map((name) => {
      const directory = path.join(localAppData, 'OpenDesk', 'wps-slides', name);
      fs.mkdirSync(directory, { recursive: true });
      return [name, directory];
    }));
    ctx.mcps.registerServer({
      name: 'wps-office', transport: 'stdio', command: nodeExecutable,
      args: [filter], cwd: runtimeCwd,
      env: {
        ...(useElectronNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}),
        OPENDESK_WPS_RUNTIME_MODE: 'builtin-plugin-v1',
        OPENDESK_WPS_MCP_COMMAND: nodeExecutable,
        OPENDESK_WPS_MCP_SERVER_PATH: mcp,
        OPENDESK_WPS_MCP_SERVER_CWD: runtimeCwd,
        OPENDESK_WPS_GATEWAY_CONTRACT_PATH: gateway,
        OPENDESK_WPS_TOOL_EXPOSURE_MODE: 'scene-v2',
        WPS_COM_SCRIPT_PATH: com,
        WPS_PPT_SCENE_DIR: state.scenes,
        WPS_PPT_SCENE_RESOURCE_DIR: state['scene-resources'],
        WPS_PPT_ARTIFACT_DIR: state.artifacts,
        WPS_ASSET_DIR: state.assets,
        WPS_PPT_LIFECYCLE_AUTH_DIR: state['lifecycle-authorizations'],
      },
    });
  },
};
