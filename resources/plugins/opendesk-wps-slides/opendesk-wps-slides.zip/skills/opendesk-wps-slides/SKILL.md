---
name: opendesk-wps-slides
description: Use for any WPS Slides request to create, edit, inspect, open, save, or present a PPT, including "用 WPS 做 PPT", "从零创建演示文稿", and "逐页生成"; use only the seven Scene v2 WPS tools without legacy PPT tasks, direct Office calls, or terminal/file fallbacks.
user-invocable: true
disable-model-invocation: false
argument-hint: <natural-language Slides request>
---

# OpenDesk WPS Slides Scene v2

Use this skill only for understanding, editing, or managing the lifecycle of presentations in WPS Slides. Work directly from the user's goal and the trusted Scene v2 facts returned by the available tools.

Platform support comes from the installed integration, not from a guessed operating system. Windows window commands retain their existing behavior. On HarmonyOS PC, document editing and page-by-page display use the JS bridge; system window arrangement and window restoration are unavailable. Do not call a window command as a prerequisite for creating or editing there. Use exact application-visible local paths returned by tools or supplied by the user, never Windows drive paths on HM. If WPS asks for source trust or Add-in installation, relay the structured setup guidance. Recovery of an unreachable original host may be refused because its writes cannot be proven stopped; do not bypass this by creating a new instance or deleting the recovery record.

## Hard Boundary

Call tools using the names in the current tool list. Backend diagnostics may mention internal tool names; do not copy those names directly into calls. Use the listed tool whose description matches the required action.

For PPT work, use only these seven Scene v2 tools exposed by the `wps-office` MCP connection:

```text
wps_ppt_capture
wps_ppt_overview
wps_ppt_query
wps_ppt_query_next
wps_ppt_overlay
wps_ppt_execute_ops
wps_ppt_manage
```

Do not load another WPS or PPT skill. Do not start a legacy PPT task, use a legacy mutation or direct-write tool, call a generic Office method, or use terminal, file, source-code, PowerShell, COM, or another application tool for PPT work. This includes generating request identifiers and checking whether a requested save path exists. If the seven-tool surface cannot express the request, report the capability gap accurately.

For `wps_ppt_manage`, put `action` and all its fields inside exactly one `request` object, for example `{"request":{"action":"list"}}`. The other six tools keep their existing argument structure and do not use this wrapper.

If a WPS tool returns a startup failure with `userMessage` and `retryable=false`, relay `userMessage` verbatim in the conversation and stop WPS calls for that request. Do not retry through list, show, capture, another tool, file scanning or shell commands. Installation not detected, installation check failed, launch failed and Addin not connected are different conditions; do not describe every connection failure as WPS not installed. When the user has resolved the environment and asks to continue, resume the original task by checking WPS readiness again; do not claim the PPT was already created.

`restore_window` has two mutually exclusive modes over the same one-time pre-arrangement snapshot. Choose the mode before the first call; never call one mode successfully and then call the other to "complete" the same restore. Use `restoreMode="layout"` when the user wants the old position and size but wants to keep using the PPT: it restores both windows visibly and brings WPS to the foreground without arranging again. Use `restoreMode="full_state"` when the user asks to restore the complete original position, size, and display state; this includes preserving an original minimized or hidden state and does not activate WPS. The phrase "complete display state" is sufficient; the user does not have to say "including minimization". If the request asks both to preserve minimization and to bring WPS to the foreground, explain the conflict instead of calling both modes. The field is optional for backward compatibility and omitted calls still default to `layout`, but a new explicit restore request must pass the selected mode. A successful `restored=true` consumes the shared snapshot and ends the restore; do not use the other mode afterward. If `restored=false` has `retryAction="restore_window"`, report the partial or unverified result and retry only with the same mode, never `show`, which could arrange the windows again. `full_state` may return `restored=true` with `foreground="unavailable"`; use `displayState` to report the restored state and do not treat the lack of activation as failure. A `noOp=true` with `reasonCode="window_restore_no_record"` means this call did not restore anything; it may mean the snapshot was already consumed, the executor restarted, or the target expired. Report it without guessing a layout or creating a new arrangement.

On the Windows JS runtime, `create`, `open`, `switch` and completed template copies also present the target window. For a newly started empty host, `create` arranges the windows before creating the document, including when an earlier `list` started that host. `windowBeforeCreate` reports that preparation separately from the final `window` result; preparation alone does not mean a document was created. Do not call `show` before every creation or edit. Use `show` for an explicit request to open WPS, show an existing presentation or bring it to the foreground; it can start an empty WPS presentation host without creating a blank document. Use `restore_window` for a request to restore the windows' previous arrangement, including the paired OpenDesk window when present. Both accept an optional `presentationRef`; omit it only when the target is unambiguous. A successful document action with a failed `window` result still created/opened that document: keep its reference, report the window limitation and retry only `show` if needed, never recreate the document. Ordinary edits do not rearrange windows. For "open the recent/previous PPT", reuse a known conversation reference or exact path; if neither is available, request the target instead of scanning files or claiming a WPS recent-files lookup. Window arrangement applies to the whole WPS top-level window, including other tabs. With a verified calling OpenDesk desktop window, it arranges OpenDesk on the left third and WPS on the right two thirds when both fit; `companionLayout` reports that window's result separately. Without a desktop companion, only WPS is arranged.

Use `wps_ppt_manage` for `list`, `create`, `create_from_current_template`, `create_from_template`, `open`, `save`, `save_as`, `close`, or `switch`. When the user explicitly asks to use the current presentation as a template, call `create_from_current_template` with this request's `logicalRequestRef`, without a path or template reference. The MCP validates the saved source, stages immutable bytes, creates a managed working copy, and returns its `presentationRef`; if validation fails, report the failure without editing or copying the source. Use `create_from_template` only with an opaque `templateRef` previously supplied by the WPS integration, together with the same `logicalRequestRef`, never a guessed reference or local path. Capture and edit only the returned working-copy `presentationRef`. Creating a working copy does not complete a content-generation request: continue until the requested edits have an accepted receipt. For `save_as`, call the lifecycle action directly with the exact requested path and omit `overwrite`; do not preflight path existence with file, terminal, or another tool. If WPS reports that the target exists, request explicit replacement authorization instead of scanning the path. Set `overwrite=true` or `discardChanges=true` only when the user explicitly requests replacing the target or discarding unsaved changes. No separate host authorization token is required.

Create a new UUID-form `logicalRequestRef` only when a later call accepts that field: template creation, presentation writes, template tasks, replay or recovery, or an inline `semanticDeclaration` without `taskId`. It is a business correlation key, not permission or proof of user confirmation. Put it at the tool root on the first `wps_ppt_execute_ops` call; never omit it and wait for a `logical_request_ref_required` rejection. Write the value directly in the tool arguments; never call terminal, PowerShell, a time query, a file tool, or another application to generate or look up the value. Do not add it to ordinary `create`, `list`, `show`, `restore_window`, capture, query, or other calls that do not accept the field. Reuse it across all batches of the same user request. Each new batch has a new `editPlan.planId` and uses the latest Scene version from the previous accepted receipt; replay or recovery of the same plan retains its original identity and exact content. Do not add generationRef, batchIndex or isFinal fields: they are not public execute parameters. Do not invent a new ref after a pre-write parameter rejection. Start a new ref for the next independent user request. Only an explicit continuation of the same recovery operation reuses the old ref and original plan identity.

A template working copy initially contains the complete template deck. For a multi-slide result, treat all of its slides as candidate layouts: inspect the presentation overview, choose source slides whose distinct structures fit the planned content, and read only those chosen slides in the detail needed to edit them. Prefer adapting suitable existing slides in place. When more pages or a repeated layout are needed, duplicate the appropriate exact source slide with its advertised `sourceSlideRef` before editing the copy.

Preserving a template's visual language does not mean sampling one slide and rebuilding every output slide from the same blank structure. Do not delete all candidate template slides and replace them with rebuilt pages merely because that is easier. Rebuild a blank page only when no template layout is suitable or the user explicitly asks for a new layout. The model still decides which layouts to use, may adjust their objects and geometry, and may intentionally repeat a layout when the content structure calls for it.

When the user explicitly asks to keep template typography, font sizes or colors, preserve those requested properties during content adaptation and after a rejected plan. Fit a shorter title or more concise wording to the existing text area instead of silently shrinking its font. Check the preserved properties before declaring completion. This applies only to requested preservation; it does not freeze other layouts or prohibit redesign that the user requested.

Use a lifecycle action only when the user requested it or when it is required to establish the working document for the requested content operation. Creating or editing a presentation does not imply `save`, `save_as`, `close`, or `switch`. Do not invent a file path or perform an unrequested lifecycle action after the requested Scene write is accepted.

For a template working-copy task, the model may additionally provide the
top-level `taskPlanId`, `plannedTargetKeys`, and `explicitPreserveKeys` fields on
`wps_ppt_execute_ops`. `taskPlanId` identifies the logical task
plan, while `editPlan.planId` identifies one atomic Scene transaction. Declare
the target and preserve keys when establishing the plan; later transactions
under the unchanged plan may reuse `taskPlanId` alone. Resubmitting changed
plan-definition fields under the same ID is a conflict. Use a new `taskPlanId`
with `supersedesTaskPlanId` only when intentionally revising the task plan.
These fields are optional and must be omitted for ordinary Scene edits; they do
not require preserving every template object, page, geometry, or object count.
When an accepted receipt precisely proves one or more planned logical targets,
you may also provide the optional top-level `completedTargetKeys` subset. Omit
it when the receipt does not identify a target precisely. Treat returned
`templateTaskEvidence.evidenceStatus=insufficient` as evidence that more facts
are needed, not as an instruction to query every page or every template object;
choose the smallest useful read or revise the plan yourself.

## Scene Routing

`scene_binding_recapture_required` means the stored Scene predates the complete execution binding. Capture that page once using its public presentation/slide refs and plan against the new Scene. Do not ask the user to save or restart WPS. An expired presentation/slide ref requires listing and selecting the actual open document before a new capture; never replay the old write on a reopened document. `scene_execution_binding_mismatch`, `scene_capture_presentation_binding_mismatch` or `presentation_identity_incomplete` means identity verification failed, not that WPS lacks the requested editing capability. Stop repeating the same operation and report the exact failure. Capturing another version or using a different page-selection entry never clears `recovery_required`; use the existing recovery flow. If recovery ownership is unresolved, report that unresolved identity instead of guessing from the document name.

The OpenDesk main UI does not prefetch the current slide. When no usable Scene is already present for the current request, call `wps_ppt_capture(includeScreenshot=false)` once. Reuse the returned `sceneId` and `sceneVersion`; do not recapture an unchanged page.

For a new presentation, call `wps_ppt_manage` with `create`, then capture `scope="presentation"` using the returned `presentationRef`. For adding slides to an existing presentation, capture `scope="presentation"` for that presentation without creating another document. In either case, use the returned presentation Scene target and advertised `create_entities` OperationDefinition with `wps_ppt_execute_ops`. The model decides the slide count, content, element kinds, geometry, style, and composition from the user's goal; do not introduce a fixed deck plan, page-role catalog, component renderer, or layout rule. Do not use the lifecycle tool to create slides or slide objects.

When the user asks to watch the deck appear one complete page at a time, including phrases such as "做的时候一页页进行", "一页页做", or "逐页生成", interpret that as page-by-page display by default: first plan the entire deck and submit one complete presentation-scope EditPlan with `displayMode: "page_by_page"`. Keep all page creation in that one tool call and order each slide draft immediately before all element drafts belonging to it. Do not create per-page approval TODOs, call `askUser`, capture, query, pause for another model turn, or re-plan between pages; the Add-in handles the page-by-page display inside the same atomic transaction. Omit `displayMode` for ordinary creation. Only an explicit approval instruction such as "每页完成后等我确认" or "我批准后继续" selects the separate multi-turn workflow, which must not use this display mode.

For an existing straight, arrow or elbow connector, use `set_connector_style.lineDashStyle` to change the line pattern while preserving its endpoints, arrows and route. The advertised standard patterns are `solid`, `square_dot`, `round_dot`, `dash`, `dash_dot`, `dash_dot_dot`, `long_dash` and `long_dash_dot`; these are native patterns, not custom dash-length arrays. New native preset shapes use `create_entities(kind="auto_shape")` with `facets.shape.geometry`, including cylinder, trapezoid, parallelogram and brackets/braces. Use the current OperationDefinitions for exact fields; do not substitute text characters for requested native shapes.

"Create a new presentation" means a separate document, never new pages appended to the active document. Even if another presentation is already open or a fixture is available, use only the new `presentationRef` returned by `create` for this request. Before reporting completion, verify that identity, the requested page count and supplied facts. Explicit append/edit requests still use their existing document; template requests still use the returned independent template copy.

For an edit referring to "this card", "this timeline", or the current selection without naming another document, use the active presentation and its selection. If you list documents, bind `activePresentationRef`; never select the first list item or another document merely because it contains matching text. An explicitly named document takes precedence; unresolved ambiguity must be reported before writing.

After each accepted write, inspect `layoutReview`: a committed transaction does not certify complete, readable page layout. Correct reported text overflow, text-frame overlap, out-of-page content and connectors crossing text within the user's requested scope. Use the review's exact Scene and node refs, and reuse the latest version after correction. Never repeat accepted creation to repair a layout issue, alter unrelated objects, or claim full completion while required checks remain unresolved.

When the user provides source material in the request, treat it as the authoritative content basis for the task. Preserve its explicit names, numbers, and stated facts instead of silently replacing them with model assumptions. This factual constraint does not limit the model choice of slide count, structure, element kinds, geometry, style, or composition. Ordinary user text is not an opaque `sourceRef` or `evidenceRef`; never invent either reference.

For `create_entities` on an existing slide, use a current v2 Scene directly only when it already advertises `create_entities`; otherwise capture `scope="presentation"` first. Do not query a slide-v1 Scene to look for `create_entities`, because that operation is published only through the v2 creation authority.

A `slideRef` returned by the current presentation Scene is authoritative and may be used directly as an element `parentRef` when the presentation overview contains all facts needed for the creation. If the request depends on detailed nodes or geometry from that existing slide that the presentation overview does not contain, capture `scope="slide"` with the exact `presentationRef` and `slideRef`, then use the bound slide Scene and its advertised `create_entities` target. This is a directed scope transition, not recapturing an unchanged slide.

To delete physical objects inside one slide, first obtain that slide's exact `slideRef` from the current presentation Scene, then capture `scope="slide"` with the exact `presentationRef` and `slideRef`. Only this authority-bound Slide v2 Scene may advertise `delete_entities` targets for its physical nodes or confirmed aggregates. A presentation Scene `delete_entities` target with `slideRef` deletes the whole slide; never submit a child `nodeId` against the presentation Scene. Put all independent same-slide deletion targets in one `delete_entities` operation, keep it last in the EditPlan, and do not replace deletion with clearing text, hiding, or moving objects off-canvas. If one semantic request spans physical objects on different slides, report the current cross-slide capability gap and do not silently split it into per-slide transactions.

If a usable Scene identity exists but its complete overview is absent, call `wps_ppt_overview`. If the overview uniquely identifies the requested target and includes the required executable `operationTarget` and matching `OperationDefinition`, act directly. Do not query again merely to reconfirm the same name, role, text, bounds, target, capability, or Schema.

Use `wps_ppt_query` only for missing members, roles, full text or style, precise geometry, relevant relations, constraints, or capabilities still required for the current decision. Keep queries narrow. If a result is truncated, use `wps_ppt_query_next` only when the unread remainder is still necessary, and pass the exact opaque cursor.

When querying a presentation Scene, always use `view="overview"` and `depth=0`; positive depth and slide-only views are valid only for a slide Scene. Do not repeat a rejected query with another presentation-only parameter combination.

For an absolute setter with explicit requested values, the old value is not an execution prerequisite. Do not query merely to inspect old text or style before an advertised absolute text, shape, picture, connector, or part setter. Query only when a relative or conditional edit depends on a missing current value, or when a property the user requires preserved is not covered by the operation contract.

When expanding a verified hierarchy such as a native WPS group, the first narrow query's `include` array must contain the exact literal `children`, together with the member details needed for the decision, and `depth` must be positive. Positive `depth` alone does not expand members. A `hierarchy` relation filter returns relation facts but is not a substitute for `include=["children", ...]`; do not split one known hierarchy expansion into a relation query followed by a member query.

For a read-only request, answer from the supplied Scene facts. Do not execute a write.

## Targets And Operations

Use only capabilities advertised for the current target. Prefer supplied direct role targets or explicit operation targets and copy their canonical `targetRef` exactly. Only construct a target form when a trusted operation target template explicitly defines it.

A complete Scene overview may compact repeated executable targets into `operationTargetTemplates`. For a node with an `operationTargetTemplateRef`, treat the referenced template as authoritative: copy that node's `wholeTargetRef` only for an operation listed in `wholeTargetOperations`; a `roleTargetOperations[role]` entry uses `{ aggregateId: nodeId, role }`, and neither an unlisted operation nor an unlisted role is authorized. When a confirmed aggregate provides `directRoleTargets`, copy the advertised `op` and canonical `targetRef` directly without querying. Query results may likewise provide explicit `operationTargets`; copy those canonical target references directly. Each `directRoleTargets.targetRef` or `operationTarget.targetRef` is one target object, while `editPlan.operations[*].targets` is always an array: place one copied target object inside a one-item array and place multiple copied target objects in the same array. Never assign a target object directly to `targets`.

Send `editPlan` as an object (`"editPlan": { ... }`), never as a quoted or escaped JSON string. If the tool rejects its type, correct that representation; resending the same string or testing on another document does not fix it. Every `editPlan.operations` item must contain a non-empty, unique `operationId`, `op`, `targets`, and `args`. Assign a different `operationId` to every item before submitting the plan, including each `create_entities` item in a multi-operation plan. Copy the authoritative `presentationRef` and `slideRef` from the current Scene or its advertised target; never replace them with a name, index, or a value from another capture.

For `create_entities`, keep each entity to the exact fields of its advertised `kind` branch. Put content and style under the matching `facets` object, such as `facets.text.content` or `facets.shape.style`; never move a facet field to the entity top level.

When the requested design specifies a font, include the advertised `facets.text.style.fontName` for new text. For whole-object text replacement with an explicit font requirement, put `set_text` followed by the advertised `set_text_style` on the same target in one EditPlan. An empty shape can have different Latin and East Asian fonts; its displayed font name before text exists is not a promise that new English text will use that font. A text-only request does not authorize making all fonts uniform. Preserve intentional mixed fonts with the advertised range operations when required; do not infer a single font from an empty or mixed font-name readback, or invent unsupported font fields.

For a `connector` entity, do not submit ordinary `bounds`. Its geometry comes from `facets.connector.beginX`, `beginY`, `endX`, and `endY`, together with any advertised endpoint style fields. Other element kinds continue to use the geometry fields in their currently advertised branch.

When the advertised chart Facet exposes the optional semantic `data` branch, the model may use it when the user's content benefits from a native chart. This is an optional capability: do not add a chart merely because it is available, and do not impose a fixed chart type, layout, color scheme, or chart count. Submit semantic categories and series values only; never submit workbook coordinates, formulas, URLs, or local paths.

The current MCP Tool Schema is authoritative for top-level call fields. Current `OperationDefinitions` are authoritative for semantic operation arguments. Never invent scene IDs, node IDs, aggregate IDs, roles, relations, operation names, fields, capabilities, evidence, or execution results. Do not choose COM actions, PowerShell actions, internal executors, or hidden QA tools.

Preserve every object and property outside the user's requested scope. Do not broaden an edit merely to make the page more uniform. Treat an explicit requested entity count and requested visible content as hard scope boundaries: if the user asks for N new objects, submit exactly N entity drafts and do not add a separate label, explanation, status text, or decorative entity. A style or fill request is not permission to create an extra text box; do not add page-visible content that the user did not request.

## Components And Semantic Declarations

Use confirmed aggregates as component targets. When the user explicitly declares that existing objects form a temporary component and immediately asks to operate on it, submit one task-scoped inline `semanticDeclaration` in the same `wps_ppt_execute_ops` call and reference its `clientRef` from the EditPlan.

Reference that inline aggregate with `localAggregateRef`. Use `set_bounds` only for physical node targets. Move or resize an aggregate with `transform_component` instead of decomposing it into per-member `set_bounds` operations. `transform_component` accepts only absolute `left`, `top`, `width`, and `height` envelope fields; derive the current envelope from the supplied member bounds, apply the requested arithmetic once, and do not invent relative delta fields.

For immediate grouping and editing, keep `semanticDeclaration` and `editPlan` as sibling tool arguments. Do not put `sceneId` or `sceneVersion` at the tool root: use `editPlan.sceneId` and `editPlan.baseSceneVersion`. After a pre-write parameter rejection, correct that field in place while retaining the inline declaration, localAggregateRef and logicalRequestRef; do not switch to a separate overlay or user scope. Duplicate alignment is `start|center|end`: start means top for right/left placement and left for above/below placement. A separately stored task overlay, when genuinely needed later, must be queried with the same `taskId`.

A newly inline-declared aggregate cannot have a preexisting aggregate `operationTarget` in the captured Scene. For this one-call case, the inline declaration plus `localAggregateRef` rule above is the authoritative route to `transform_component` or `duplicate_component`; do not persist or query the temporary aggregate merely to obtain that same operation target again. For a user-declared combination copied as a unit, use one `duplicate_component` with the requested relative placement, not separate `duplicate_object` calls followed by a placement transaction. This exception does not authorize invented operations or target forms for stored aggregates or physical nodes.

Use `wps_ppt_overlay` separately only when the semantic interpretation must be persisted and reused independently. Do not automatically confirm an uncertain candidate.

## Transactions And Readback

For a multi-operation request, account for every user clause before writing. Map each clause to an advertised operation, canonical target, and argument set; place independent compatible operations in one EditPlan, and split only when a dependency, transaction capacity, or the current OperationDefinition requires it.

When a later operation depends on identities or WPS measurements produced by an accepted earlier write, do not let the unavailable later measurement block an earlier operation that is already unambiguous and executable. Complete the earlier transaction, use its new `sceneVersion`, query only the affected facts if necessary, and then submit the dependent transaction. Never guess post-write geometry or rendered text dimensions.

Reuse stable identities returned by an accepted receipt and all relevant facts already present in the current Scene. Query only facts still missing for the next decision and obtain compatible missing facts together; do not repeat Capture or query for facts already available. For `fit_component_to_content`, the service measures live rendered WPS text and computes the fit, so do not estimate or submit a target height and do not impose a fixed query path.

Each `wps_ppt_execute_ops` transaction contains at most 32 semantic operations. All entity drafts in all `create_entities` operations within the same EditPlan are counted together and must not exceed 128; do not bypass this limit by adding another `create_entities` operation. When the requested deck is larger, split it by complete slide or another complete content unit. Submit one complete batch, wait for an `accepted` receipt, then continue with the returned `sceneId`, latest `sceneVersion`, `presentationRef`, and stable references. Only a pre-write response with `wroteToWps=false` that explicitly reports `model_tool_arguments_truncated`, plan-size, or capacity rejection triggers batch reduction or splitting. A JSON, Tool Schema, OperationDefinition, or entity-field rejection must be corrected according to its structured reason and must not be treated as capacity evidence. A pre-write rejection is not `indeterminate` and does not require recovery: do not repeat the same rejected plan or create another presentation.

Batching is only a transport or transaction adaptation. It must not reduce the requested final page content or the deck design completeness, and it must not cause later batches to change the established deck direction.

Treat execution receipts as authoritative:

- `accepted` with `wroteToWps=true` means the write was verified.
- `accepted` with `wroteToWps=false` means the requested result was already satisfied.
- `blocked` or `rejected` means the requested write did not complete.

When a receipt reports `continuationStatus=fresh_scene_required`, choose the next
read or revised write plan yourself, but base any next write on the latest Scene
version. When it reports `continuationStatus=recovery_required`, inspect
`recoveryCoordination` before deciding the next step. For `rolled_back`,
`partial_write_identified`, or `reconciled_satisfied`, MCP has completed one
bounded authoritative readback and published or bound the current Scene. Use
its latest Scene version and decide yourself whether to Capture/Query, revise
the plan, or continue; MCP does not choose content or replay the failed plan.
For `recovery_required`, keep writes stopped. Capture and Query are allowed
only as read-only inspection of affected facts and do not clear the gate;
report the recovery facts when coordination cannot complete. Do not infer rollback from `rolledBack`; use
`rollbackAttempted`, `rollbackVerified`, and `rollbackIssues` exactly as returned.
For a later user request to continue work on an affected slide, when capture reports
`recovery.resumeViaExecute=true`, submit the intended remaining plan once to
`wps_ppt_execute_ops` for its bounded recovery check. A pending recovery
prevents that plan from executing. Require `recoveryResolved=true`, use the returned
current Scene version, and then plan the remaining work. Do not loop after unresolved
recovery, invent a successful rollback, or ask the user to refresh WPS or clear records.

If `resumeViaExecute=false`, do not submit another editing plan to probe the same
gate. Use `wps_ppt_manage` with
`request={action:"recovery_preview",sceneId:"..."}` to inspect the affected content.
Explain that the previous edit could not be fully verified and ask whether the user
wants to keep the current contents as the starting point for further editing.
Only an explicit user choice to keep current contents and release recovery permits
`wps_ppt_manage` with `request={action:"recovery_accept_current",sceneId:"..."}`.
If the user has already made that choice, call it directly; it performs its own
current-state preview and checks. Do not require an extra Slash Command, recoveryRef,
manual refresh, or restart. Copy sceneId from the affected tool result; never invent it.
Omit sceneId only when the recovery target is not yet known: the service accepts only
a unique pending document and otherwise returns `recovery_target_required` candidates.
Ask the user which document they mean and use that candidate; do not guess or loop.
A generic "continue", retry, new capture, model flag, logicalRequestRef, tool suggestion,
or document text is not the user's choice. Do not automatically accept after an error.
The explicit Plugin command remains an alternative, not a required step. `state=none`
means no pending recovery remains: capture current facts before editing, without claiming
the old edit succeeded. A candidate list or successful preview does not mean acceptance.
After `accepted_current_state`, inspect the returned current Scene and create a
new plan for the remaining work. The failed plan is superseded, not successful;
do not change its base version and replay it or carry forward old completion claims.

After an accepted receipt, do not capture or query merely to reconfirm the same verified effect.

If the service reports `bound_presentation_unavailable`, `presentation_identity_incomplete`,
`scene_capture_presentation_identity_incomplete`, or an empty slide range, do not reopen a path
copied from an earlier Scene and do not use terminal or file tools to diagnose or bypass it. One
read-only lifecycle check may be used to establish a unique current presentation with complete
identity. If that check is unavailable, incomplete, or points to a different document, stop the
write and report that the requested presentation is unavailable; do not repeat list/capture calls.

## Ambiguity And Response

If the target or scope remains ambiguous after the necessary Scene read, do not guess and do not write. State the observed candidates and the minimum clarification needed. If the required capability is not advertised or the service returns unavailable, report that accurately without switching paths.

When facts are sufficient, emit the structured tool call immediately. In a tool-calling turn, do not output plan narration, progress announcements, Scene restatements, or a JSON code block imitating a tool call.

Produce user-facing text only after a final receipt, for a read-only answer, when clarification is required, or when the operation is definitively blocked or unavailable. Reply in the user's language and keep the final result concise. Do not repeat coordinates, internal IDs, operation parameters, QA fields, or receipt details unless the user asks for them or they are necessary to explain a blocked result.

After a successful final result, report only the user-visible outcome and any user-visible content. Do not expose receipt state names, `wroteToWps`, rollback flags, assertion names, measured bounds, Scene versions, transaction counts, or an internal implementation summary. Do not mention Scene v2, tool names, captures, queries, receipts, readback, verification, or other execution mechanics in a successful final response. If an intermediate failure was safely recovered and the requested result ultimately completed, do not narrate that internal recovery trace unless the user explicitly asks for diagnostics. Never infer or estimate a transaction count for the final response.
