---
name: opendesk-wps-slides
description: Use the seven Scene v2 WPS Slides tools to understand, edit, or manage the lifecycle of a presentation without legacy PPT tasks, direct Office calls, or terminal/file fallbacks.
user-invocable: true
disable-model-invocation: false
argument-hint: <natural-language Slides request>
---

# OpenDesk WPS Slides Scene v2

Use this skill only for understanding, editing, or managing the lifecycle of presentations in WPS Slides. Work directly from the user's goal and the trusted Scene v2 facts returned by the available tools.

## Hard Boundary

Call tools using the names in the current tool list. Backend diagnostics may mention internal tool names; do not copy those names directly into calls. Use the listed tool whose description matches the required action.

For PPT work, use only these seven Scene v2 tools exposed by the `wps-office` MCP connection:

```text
wps_ppt_capture
wps_ppt_overview
wps_ppt_query
wps_ppt_query_next
wps_ppt_overlay
wps_ppt_execute_ops
wps_ppt_manage
```

Do not load another WPS or PPT skill. Do not start a legacy PPT task, use a legacy mutation or direct-write tool, call a generic Office method, or use terminal, file, source-code, PowerShell, COM, or another application tool to bypass Scene v2. If the seven-tool surface cannot express the request, report the capability gap accurately.

For `wps_ppt_manage`, put `action` and all its fields inside exactly one `request` object, for example `{"request":{"action":"list"}}`. The other six tools keep their existing argument structure and do not use this wrapper.

Use `wps_ppt_manage` for `list`, `create`, `create_from_current_template`, `create_from_template`, `open`, `save`, `save_as`, `close`, or `switch`. When the user explicitly asks to use the current presentation as a template, call `create_from_current_template` with this request's `logicalRequestRef`, without a path or template reference. The MCP validates the saved source, stages immutable bytes, creates a managed working copy, and returns its `presentationRef`; if validation fails, report the failure without editing or copying the source. Use `create_from_template` only with an opaque `templateRef` previously supplied by the WPS integration, together with the same `logicalRequestRef`, never a guessed reference or local path. Capture and edit only the returned working-copy `presentationRef`. Creating a working copy does not complete a content-generation request: continue until the requested edits have an accepted receipt. Set `overwrite=true` or `discardChanges=true` only when the user explicitly requests replacing the target or discarding unsaved changes. No separate host authorization token is required.

For each new independent WPS user request, generate one UUID-form `logicalRequestRef`. It is a business correlation key, not permission or proof of user confirmation. Pass it to both template-creation actions and to `wps_ppt_execute_ops` for presentation writes, template tasks, replay and recovery. Also supply it for inline `semanticDeclaration` when no `taskId` is present. Reuse it across all batches of the same request. Each new batch has a new `editPlan.planId` and uses the latest Scene version from the previous accepted receipt; replay or recovery of the same plan retains its original identity and exact content. Do not add generationRef, batchIndex or isFinal fields: they are not public execute parameters. Do not invent a new ref after a pre-write parameter rejection. Start a new ref for the next independent user request. Only an explicit continuation of the same recovery operation reuses the old ref and original plan identity. Do not put this field on the other five tools or on non-template lifecycle actions.

A template working copy initially contains the complete template deck. For a multi-slide result, treat all of its slides as candidate layouts: inspect the presentation overview, choose source slides whose distinct structures fit the planned content, and read only those chosen slides in the detail needed to edit them. Prefer adapting suitable existing slides in place. When more pages or a repeated layout are needed, duplicate the appropriate exact source slide with its advertised `sourceSlideRef` before editing the copy.

Preserving a template's visual language does not mean sampling one slide and rebuilding every output slide from the same blank structure. Do not delete all candidate template slides and replace them with rebuilt pages merely because that is easier. Rebuild a blank page only when no template layout is suitable or the user explicitly asks for a new layout. The model still decides which layouts to use, may adjust their objects and geometry, and may intentionally repeat a layout when the content structure calls for it.

Use a lifecycle action only when the user requested it or when it is required to establish the working document for the requested content operation. Creating or editing a presentation does not imply `save`, `save_as`, `close`, or `switch`. Do not invent a file path or perform an unrequested lifecycle action after the requested Scene write is accepted.

For a template working-copy task, the model may additionally provide the
top-level `taskPlanId`, `plannedTargetKeys`, and `explicitPreserveKeys` fields on
`wps_ppt_execute_ops`. `taskPlanId` identifies the logical task
plan, while `editPlan.planId` identifies one atomic Scene transaction. Declare
the target and preserve keys when establishing the plan; later transactions
under the unchanged plan may reuse `taskPlanId` alone. Resubmitting changed
plan-definition fields under the same ID is a conflict. Use a new `taskPlanId`
with `supersedesTaskPlanId` only when intentionally revising the task plan.
These fields are optional and must be omitted for ordinary Scene edits; they do
not require preserving every template object, page, geometry, or object count.
When an accepted receipt precisely proves one or more planned logical targets,
you may also provide the optional top-level `completedTargetKeys` subset. Omit
it when the receipt does not identify a target precisely. Treat returned
`templateTaskEvidence.evidenceStatus=insufficient` as evidence that more facts
are needed, not as an instruction to query every page or every template object;
choose the smallest useful read or revise the plan yourself.

## Scene Routing

The OpenDesk main UI does not prefetch the current slide. When no usable Scene is already present for the current request, call `wps_ppt_capture(includeScreenshot=false)` once. Reuse the returned `sceneId` and `sceneVersion`; do not recapture an unchanged page.

For a new presentation, call `wps_ppt_manage` with `create`, then capture `scope="presentation"` using the returned `presentationRef`. For adding slides to an existing presentation, capture `scope="presentation"` for that presentation without creating another document. In either case, use the returned presentation Scene target and advertised `create_entities` OperationDefinition with `wps_ppt_execute_ops`. The model decides the slide count, content, element kinds, geometry, style, and composition from the user's goal; do not introduce a fixed deck plan, page-role catalog, component renderer, or layout rule. Do not use the lifecycle tool to create slides or slide objects.

When the user provides source material in the request, treat it as the authoritative content basis for the task. Preserve its explicit names, numbers, and stated facts instead of silently replacing them with model assumptions. This factual constraint does not limit the model choice of slide count, structure, element kinds, geometry, style, or composition. Ordinary user text is not an opaque `sourceRef` or `evidenceRef`; never invent either reference.

For `create_entities` on an existing slide, use a current v2 Scene directly only when it already advertises `create_entities`; otherwise capture `scope="presentation"` first. Do not query a slide-v1 Scene to look for `create_entities`, because that operation is published only through the v2 creation authority.

A `slideRef` returned by the current presentation Scene is authoritative and may be used directly as an element `parentRef` when the presentation overview contains all facts needed for the creation. If the request depends on detailed nodes or geometry from that existing slide that the presentation overview does not contain, capture `scope="slide"` with the exact `presentationRef` and `slideRef`, then use the bound slide Scene and its advertised `create_entities` target. This is a directed scope transition, not recapturing an unchanged slide.

To delete physical objects inside one slide, first obtain that slide's exact `slideRef` from the current presentation Scene, then capture `scope="slide"` with the exact `presentationRef` and `slideRef`. Only this authority-bound Slide v2 Scene may advertise `delete_entities` targets for its physical nodes or confirmed aggregates. A presentation Scene `delete_entities` target with `slideRef` deletes the whole slide; never submit a child `nodeId` against the presentation Scene. Put all independent same-slide deletion targets in one `delete_entities` operation, keep it last in the EditPlan, and do not replace deletion with clearing text, hiding, or moving objects off-canvas. If one semantic request spans physical objects on different slides, report the current cross-slide capability gap and do not silently split it into per-slide transactions.

If a usable Scene identity exists but its complete overview is absent, call `wps_ppt_overview`. If the overview uniquely identifies the requested target and includes the required executable `operationTarget` and matching `OperationDefinition`, act directly. Do not query again merely to reconfirm the same name, role, text, bounds, target, capability, or Schema.

Use `wps_ppt_query` only for missing members, roles, full text or style, precise geometry, relevant relations, constraints, or capabilities still required for the current decision. Keep queries narrow. If a result is truncated, use `wps_ppt_query_next` only when the unread remainder is still necessary, and pass the exact opaque cursor.

When querying a presentation Scene, always use `view="overview"` and `depth=0`; positive depth and slide-only views are valid only for a slide Scene. Do not repeat a rejected query with another presentation-only parameter combination.

For an absolute setter with explicit requested values, the old value is not an execution prerequisite. Do not query merely to inspect old text or style before an advertised absolute text, shape, picture, connector, or part setter. Query only when a relative or conditional edit depends on a missing current value, or when a property the user requires preserved is not covered by the operation contract.

When expanding a verified hierarchy such as a native WPS group, the first narrow query's `include` array must contain the exact literal `children`, together with the member details needed for the decision, and `depth` must be positive. Positive `depth` alone does not expand members. A `hierarchy` relation filter returns relation facts but is not a substitute for `include=["children", ...]`; do not split one known hierarchy expansion into a relation query followed by a member query.

For a read-only request, answer from the supplied Scene facts. Do not execute a write.

## Targets And Operations

Use only capabilities advertised for the current target. Prefer supplied direct role targets or explicit operation targets and copy their canonical `targetRef` exactly. Only construct a target form when a trusted operation target template explicitly defines it.

A complete Scene overview may compact repeated executable targets into `operationTargetTemplates`. For a node with an `operationTargetTemplateRef`, treat the referenced template as authoritative: copy that node's `wholeTargetRef` only for an operation listed in `wholeTargetOperations`; a `roleTargetOperations[role]` entry uses `{ aggregateId: nodeId, role }`, and neither an unlisted operation nor an unlisted role is authorized. When a confirmed aggregate provides `directRoleTargets`, copy the advertised `op` and canonical `targetRef` directly without querying. Query results may likewise provide explicit `operationTargets`; copy those canonical target references directly. Each `directRoleTargets.targetRef` or `operationTarget.targetRef` is one target object, while `editPlan.operations[*].targets` is always an array: place one copied target object inside a one-item array and place multiple copied target objects in the same array. Never assign a target object directly to `targets`.

Every `editPlan.operations` item must contain a non-empty, unique `operationId`, `op`, `targets`, and `args`. Assign a different `operationId` to every item before submitting the plan, including each `create_entities` item in a multi-operation plan. Copy the authoritative `presentationRef` and `slideRef` from the current Scene or its advertised target; never replace them with a name, index, or a value from another capture.

For `create_entities`, keep each entity to the exact fields of its advertised `kind` branch. Put content and style under the matching `facets` object, such as `facets.text.content` or `facets.shape.style`; never move a facet field to the entity top level.

For a `connector` entity, do not submit ordinary `bounds`. Its geometry comes from `facets.connector.beginX`, `beginY`, `endX`, and `endY`, together with any advertised endpoint style fields. Other element kinds continue to use the geometry fields in their currently advertised branch.

When the advertised chart Facet exposes the optional semantic `data` branch, the model may use it when the user's content benefits from a native chart. This is an optional capability: do not add a chart merely because it is available, and do not impose a fixed chart type, layout, color scheme, or chart count. Submit semantic categories and series values only; never submit workbook coordinates, formulas, URLs, or local paths.

The current MCP Tool Schema is authoritative for top-level call fields. Current `OperationDefinitions` are authoritative for semantic operation arguments. Never invent scene IDs, node IDs, aggregate IDs, roles, relations, operation names, fields, capabilities, evidence, or execution results. Do not choose COM actions, PowerShell actions, internal executors, or hidden QA tools.

Preserve every object and property outside the user's requested scope. Do not broaden an edit merely to make the page more uniform. Treat an explicit requested entity count and requested visible content as hard scope boundaries: if the user asks for N new objects, submit exactly N entity drafts and do not add a separate label, explanation, status text, or decorative entity. A style or fill request is not permission to create an extra text box; do not add page-visible content that the user did not request.

## Components And Semantic Declarations

Use confirmed aggregates as component targets. When the user explicitly declares that existing objects form a temporary component and immediately asks to operate on it, submit one task-scoped inline `semanticDeclaration` in the same `wps_ppt_execute_ops` call and reference its `clientRef` from the EditPlan.

Reference that inline aggregate with `localAggregateRef`. Use `set_bounds` only for physical node targets. Move or resize an aggregate with `transform_component` instead of decomposing it into per-member `set_bounds` operations. `transform_component` accepts only absolute `left`, `top`, `width`, and `height` envelope fields; derive the current envelope from the supplied member bounds, apply the requested arithmetic once, and do not invent relative delta fields.

A newly inline-declared aggregate cannot have a preexisting aggregate `operationTarget` in the captured Scene. For this one-call case, the inline declaration plus `localAggregateRef` rule above is the authoritative route to `transform_component`; do not persist or query the temporary aggregate merely to obtain that same operation target again. This exception does not authorize invented operations or target forms for stored aggregates or physical nodes.

Use `wps_ppt_overlay` separately only when the semantic interpretation must be persisted and reused independently. Do not automatically confirm an uncertain candidate.

## Transactions And Readback

For a multi-operation request, account for every user clause before writing. Map each clause to an advertised operation, canonical target, and argument set; place independent compatible operations in one EditPlan, and split only when a dependency, transaction capacity, or the current OperationDefinition requires it.

When a later operation depends on identities or WPS measurements produced by an accepted earlier write, do not let the unavailable later measurement block an earlier operation that is already unambiguous and executable. Complete the earlier transaction, use its new `sceneVersion`, query only the affected facts if necessary, and then submit the dependent transaction. Never guess post-write geometry or rendered text dimensions.

Reuse stable identities returned by an accepted receipt and all relevant facts already present in the current Scene. Query only facts still missing for the next decision and obtain compatible missing facts together; do not repeat Capture or query for facts already available. For `fit_component_to_content`, the service measures live rendered WPS text and computes the fit, so do not estimate or submit a target height and do not impose a fixed query path.

Each `wps_ppt_execute_ops` transaction contains at most 32 semantic operations. All entity drafts in all `create_entities` operations within the same EditPlan are counted together and must not exceed 128; do not bypass this limit by adding another `create_entities` operation. When the requested deck is larger, split it by complete slide or another complete content unit. Submit one complete batch, wait for an `accepted` receipt, then continue with the returned `sceneId`, latest `sceneVersion`, `presentationRef`, and stable references. Only a pre-write response with `wroteToWps=false` that explicitly reports `model_tool_arguments_truncated`, plan-size, or capacity rejection triggers batch reduction or splitting. A JSON, Tool Schema, OperationDefinition, or entity-field rejection must be corrected according to its structured reason and must not be treated as capacity evidence. A pre-write rejection is not `indeterminate` and does not require recovery: do not repeat the same rejected plan or create another presentation.

Batching is only a transport or transaction adaptation. It must not reduce the requested final page content or the deck design completeness, and it must not cause later batches to change the established deck direction.

Treat execution receipts as authoritative:

- `accepted` with `wroteToWps=true` means the write was verified.
- `accepted` with `wroteToWps=false` means the requested result was already satisfied.
- `blocked` or `rejected` means the requested write did not complete.

When a receipt reports `continuationStatus=fresh_scene_required`, choose the next
read or revised write plan yourself, but base any next write on the latest Scene
version. When it reports `continuationStatus=recovery_required`, inspect
`recoveryCoordination` before deciding the next step. For `rolled_back`,
`partial_write_identified`, or `reconciled_satisfied`, MCP has completed one
bounded authoritative readback and published or bound the current Scene. Use
its latest Scene version and decide yourself whether to Capture/Query, revise
the plan, or continue; MCP does not choose content or replay the failed plan.
For `recovery_required`, keep writes stopped. Capture and Query are allowed
only as read-only inspection of affected facts and do not clear the gate;
report the recovery facts when coordination cannot complete. Do not infer rollback from `rolledBack`; use
`rollbackAttempted`, `rollbackVerified`, and `rollbackIssues` exactly as returned.

After an accepted receipt, do not capture or query merely to reconfirm the same verified effect.

If the service reports `bound_presentation_unavailable`, `presentation_identity_incomplete`,
`scene_capture_presentation_identity_incomplete`, or an empty slide range, do not reopen a path
copied from an earlier Scene and do not use terminal or file tools to diagnose or bypass it. One
read-only lifecycle check may be used to establish a unique current presentation with complete
identity. If that check is unavailable, incomplete, or points to a different document, stop the
write and report that the requested presentation is unavailable; do not repeat list/capture calls.

## Ambiguity And Response

If the target or scope remains ambiguous after the necessary Scene read, do not guess and do not write. State the observed candidates and the minimum clarification needed. If the required capability is not advertised or the service returns unavailable, report that accurately without switching paths.

When facts are sufficient, emit the structured tool call immediately. In a tool-calling turn, do not output plan narration, progress announcements, Scene restatements, or a JSON code block imitating a tool call.

Produce user-facing text only after a final receipt, for a read-only answer, when clarification is required, or when the operation is definitively blocked or unavailable. Reply in the user's language and keep the final result concise. Do not repeat coordinates, internal IDs, operation parameters, QA fields, or receipt details unless the user asks for them or they are necessary to explain a blocked result.

After a successful final result, report only the user-visible outcome and any user-visible content. Do not expose receipt state names, `wroteToWps`, rollback flags, assertion names, measured bounds, Scene versions, transaction counts, or an internal implementation summary. Do not mention Scene v2, tool names, captures, queries, receipts, readback, verification, or other execution mechanics in a successful final response. If an intermediate failure was safely recovered and the requested result ultimately completed, do not narrate that internal recovery trace unless the user explicitly asks for diagnostics. Never infer or estimate a transaction count for the final response.
