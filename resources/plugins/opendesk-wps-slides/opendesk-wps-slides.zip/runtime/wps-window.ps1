$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)

# This short-lived helper accepts only host facts from the authenticated JS executor.
# It does not discover presentations, launch WPS, or use COM.
try {
    $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($request.action -notin @('inspect', 'present', 'restore')) { throw 'wps_window_action_invalid' }
    $restoreMode = 'layout'
    if ($request.action -eq 'restore' -and $null -ne $request.restoreMode) {
        if ($request.restoreMode -notin @('layout', 'full_state')) { throw 'wps_window_restore_mode_invalid' }
        $restoreMode = $request.restoreMode
    }
    Add-Type @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
public static class WpsWindow {
    public delegate bool EnumProc(IntPtr h, IntPtr p);
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int left, top, right, bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct Point { public int x, y; }
    [StructLayout(LayoutKind.Sequential)] public struct MinMax { public Point reserved, maxSize, maxPosition, minTrack, maxTrack; }
    [StructLayout(LayoutKind.Sequential)] public struct Placement {
        public int length, flags, showCmd; public Point min, max; public Rect normal;
    }
    [StructLayout(LayoutKind.Sequential)] public struct Monitor {
        public int size; public Rect monitor, work; public int flags;
    }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc p, IntPtr d);
    [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h, EnumProc p, IntPtr d);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint flag);
    [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint flag);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int index);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] static extern bool AttachThreadInput(uint from, uint to, bool attach);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int command);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out Rect r);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int z, uint flags);
    [DllImport("user32.dll")] static extern bool GetWindowPlacement(IntPtr h, ref Placement p);
    [DllImport("user32.dll")] public static extern bool SetWindowPlacement(IntPtr h, ref Placement p);
    [DllImport("user32.dll", SetLastError=true)] static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, ref MinMax info, uint flags, uint timeout, out IntPtr result);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, System.Text.StringBuilder name, int length);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint flags);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromRect(ref Rect r, uint flags);
    [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr h, ref Monitor m);
    [DllImport("user32.dll")] static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attribute, out Rect r, int length);
    public static void Dpi() { try { SetThreadDpiAwarenessContext(new IntPtr(-4)); } catch (EntryPointNotFoundException) { } }
    public static int Pid(IntPtr h) { uint p; GetWindowThreadProcessId(h, out p); return (int)p; }
    static bool WaitForForeground(IntPtr target) {
        var clock=Stopwatch.StartNew();
        while(GetForegroundWindow()!=target && IsWindow(target) && clock.ElapsedMilliseconds<250)
            System.Threading.Thread.Sleep(10);
        return GetForegroundWindow()==target;
    }
    public static void PresentForeground(IntPtr target) {
        if (GetForegroundWindow()==target) return;
        if (SetForegroundWindow(target) && WaitForForeground(target)) return;
        if (GetForegroundWindow()==target) return;
        uint p;
        var foreground=GetForegroundWindow();
        var foregroundThread=GetWindowThreadProcessId(foreground,out p);
        var targetThread=GetWindowThreadProcessId(target,out p);
        var current=GetCurrentThreadId();
        if(foregroundThread==0 || targetThread==0) return;
        bool foregroundAttached=false, targetAttached=false;
        try {
            // A background helper needs both input queues for one explicit activation.
            if(foregroundThread!=current)
                foregroundAttached=AttachThreadInput(current,foregroundThread,true);
            if(targetThread!=current && targetThread!=foregroundThread)
                targetAttached=AttachThreadInput(current,targetThread,true);
            if((foregroundThread!=current && !foregroundAttached) ||
               (targetThread!=current && targetThread!=foregroundThread && !targetAttached)) return;
            if(GetForegroundWindow()!=foreground) return;
            SetForegroundWindow(target);
            // Cross-thread activation can complete after SetForegroundWindow returns.
            WaitForForeground(target);
        } finally {
            if(targetAttached) AttachThreadInput(current,targetThread,false);
            if(foregroundAttached) AttachThreadInput(current,foregroundThread,false);
        }
    }
    public static IntPtr[] Tops() { var r = new List<IntPtr>(); EnumWindows((h,d)=>{r.Add(h);return true;}, IntPtr.Zero); return r.ToArray(); }
    public static IntPtr[] Roots(int pid) {
        var r = new HashSet<IntPtr>();
        foreach (var top in Tops()) {
            if (Pid(top)==pid) r.Add(top);
            EnumChildWindows(top,(h,d)=>{if(Pid(h)==pid) r.Add(GetAncestor(h,2)); return true;},IntPtr.Zero);
        }
        return new List<IntPtr>(r).ToArray();
    }
    public static Rect Bounds(IntPtr h, bool frame) {
        Rect r;
        if (frame && DwmGetWindowAttribute(h,9,out r,Marshal.SizeOf(typeof(Rect)))==0) return r;
        if (!GetWindowRect(h,out r)) throw new Exception("wps_window_read_failed"); return r;
    }
    public static Placement Place(IntPtr h) {
        var p=new Placement(); p.length=Marshal.SizeOf(typeof(Placement));
        if(!GetWindowPlacement(h,ref p)) throw new Exception("wps_window_read_failed"); return p;
    }
    public static Monitor Screen(IntPtr h) {
        var m=new Monitor(); m.size=Marshal.SizeOf(typeof(Monitor));
        if(!GetMonitorInfo(MonitorFromWindow(h,2),ref m)) throw new Exception("wps_window_monitor_unavailable"); return m;
    }
    public static bool HasScreen(Rect r) { return MonitorFromRect(ref r,0)!=IntPtr.Zero; }
    public static Point Minimum(IntPtr h) {
        var info=new MinMax(); IntPtr result;
        if(SendMessageTimeout(h,0x24,IntPtr.Zero,ref info,2,500,out result)==IntPtr.Zero)
            throw new Exception("window_minimum_unavailable");
        return info.minTrack;
    }
    public static string Class(IntPtr h) { var s=new System.Text.StringBuilder(256); GetClassName(h,s,256); return s.ToString(); }
}
'@
    [WpsWindow]::Dpi()

    function Process-Facts([int]$processId) {
        try {
            $process = Get-Process -Id $processId -ErrorAction Stop
            @{ pid=$processId; birth=$process.StartTime.ToUniversalTime().Ticks.ToString(); path=$process.Path; name=$process.ProcessName
                createdAt=([DateTimeOffset]$process.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds() }
        } catch { throw 'wps_window_process_unavailable' }
    }
    function Snapshot([IntPtr]$handle) {
        if (-not [WpsWindow]::IsWindow($handle)) { throw 'wps_window_target_invalid' }
        $facts = Process-Facts ([WpsWindow]::Pid($handle))
        $place = [WpsWindow]::Place($handle)
        $screen = [WpsWindow]::Screen($handle)
        @{
            hwnd=$handle.ToInt64(); pid=$facts.pid; birth=$facts.birth
            rect=[WpsWindow]::Bounds($handle,$true); work=$screen.work
            placement=@{ flags=$place.flags; showCmd=$place.showCmd
                left=$place.normal.left; top=$place.normal.top; right=$place.normal.right; bottom=$place.normal.bottom }
            visible=[WpsWindow]::IsWindowVisible($handle); iconic=[WpsWindow]::IsIconic($handle)
            enabled=[WpsWindow]::IsWindowEnabled($handle)
        }
    }
    function Eligible([IntPtr]$handle) {
        [WpsWindow]::IsWindow($handle) -and [WpsWindow]::GetWindow($handle,4) -eq [IntPtr]::Zero -and
            ([WpsWindow]::GetWindowLong($handle,-20) -band 0x08000080) -eq 0 -and
            ([WpsWindow]::IsWindowVisible($handle) -or [WpsWindow]::IsIconic($handle))
    }
    function Resolve-Target($identity, $expected) {
        if (-not $identity.pid -or $identity.pid -le 0) { throw 'wps_window_identity_unavailable' }
        $native = Process-Facts $identity.pid
        if ($native.name -ne 'wpp') { throw 'wps_window_identity_mismatch' }
        if ($expected -and ($expected.nativePid -ne $native.pid -or $expected.nativeBirth -ne $native.birth)) {
            throw 'wps_window_target_invalid'
        }
        $roots = @([WpsWindow]::Roots($native.pid) | Where-Object { Eligible $_ })
        if ($identity.hwnd) {
            $handle = [IntPtr][long]$identity.hwnd
            if (-not [WpsWindow]::IsWindow($handle)) { throw 'wps_window_target_invalid' }
            $root = [WpsWindow]::GetAncestor($handle,2)
            if ([WpsWindow]::Pid($handle) -ne $native.pid -and $roots -notcontains $root) {
                throw 'wps_window_identity_mismatch'
            }
            $roots = @($root | Where-Object { Eligible $_ })
        } elseif ($roots.Count -eq 0 -and $identity.documentCount -eq 0 -and $identity.mainWindowCount -eq 1) {
            # Empty WPP is embedded in its direct, same-installation WPS shell.
            $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId = $($native.pid)"
            $parent = Process-Facts $processInfo.ParentProcessId
            if ($parent.name -ne 'wpsoffice' -or [long]$parent.birth -gt [long]$native.birth -or
                [IO.Path]::GetDirectoryName($parent.path) -ne [IO.Path]::GetDirectoryName($native.path)) {
                throw 'wps_window_identity_mismatch'
            }
            $roots = @([WpsWindow]::Tops() | Where-Object { [WpsWindow]::Pid($_) -eq $parent.pid -and (Eligible $_) })
        }
        if ($roots.Count -eq 0) { throw 'wps_window_identity_unavailable' }
        if ($roots.Count -ne 1) { throw 'wps_window_target_ambiguous' }
        $result = Snapshot $roots[0]
        $owner = Process-Facts $result.pid
        if ($owner.name -notin @('wpp','wpsoffice') -or
            [IO.Path]::GetDirectoryName($owner.path) -ne [IO.Path]::GetDirectoryName($native.path)) {
            throw 'wps_window_identity_mismatch'
        }
        if ($expected -and ($expected.hwnd -ne $result.hwnd -or $expected.birth -ne $result.birth -or $expected.pid -ne $result.pid)) {
            throw 'wps_window_target_invalid'
        }
        $result.nativePid=$native.pid
        $result.nativeBirth=$native.birth
        $result
    }
    function Outcome($foreground, $layout, $reason) {
        $value = @{ foreground=$foreground; layout=$layout }
        if ($reason) { $value.reasonCode=$reason }
        if ($foreground -eq 'denied') { $value.retryAction='show' }
        $value
    }
    function Foreground([IntPtr]$handle) {
        if ([WpsWindow]::GetForegroundWindow() -eq $handle -and -not [WpsWindow]::IsIconic($handle)) { 'shown' } else { 'denied' }
    }
    function Display-State($snapshot) {
        if (-not $snapshot.visible) { 'hidden' }
        elseif ($snapshot.iconic) { 'minimized' }
        elseif ($snapshot.placement.showCmd -eq 3) { 'maximized' }
        else { 'normal' }
    }
    function Resolve-Companion($identity, $expected) {
        $facts=Process-Facts $identity.pid
        if ($facts.path -ne $identity.executable -or [Math]::Abs($facts.createdAt-$identity.createdAt) -gt 2) {
            throw 'companion_process_mismatch'
        }
        $roots=@([WpsWindow]::Tops() | Where-Object {
            [WpsWindow]::Pid($_) -eq $identity.pid -and (Eligible $_) -and [WpsWindow]::Class($_) -eq 'Chrome_WidgetWin_1' -and
                ([WpsWindow]::GetWindowLong($_,-16) -band 0x00040000) -ne 0
        })
        # Fixed-size task/status widgets are not desktop companions. Once bound, retain the exact main window.
        if ($expected) { $roots=@($roots | Where-Object { $_.ToInt64() -eq $expected.hwnd }) }
        if ($roots.Count -ne 1) { throw 'companion_window_unavailable_or_ambiguous' }
        $snapshot=Snapshot $roots[0]
        if ($expected -and ($expected.hwnd -ne $snapshot.hwnd -or $expected.birth -ne $snapshot.birth -or $expected.pid -ne $snapshot.pid)) {
            throw 'companion_window_changed'
        }
        if (-not $snapshot.enabled) { throw 'companion_modal_blocked' }
        $snapshot
    }
    function Fits([IntPtr]$handle, $desired) {
        $minimum=[WpsWindow]::Minimum($handle)
        $outer=[WpsWindow]::Bounds($handle,$false)
        $frame=[WpsWindow]::Bounds($handle,$true)
        ($minimum.x -le $desired.right-$desired.left+($outer.right-$outer.left)-($frame.right-$frame.left)) -and
            ($minimum.y -le $desired.bottom-$desired.top+($outer.bottom-$outer.top)-($frame.bottom-$frame.top))
    }
    function Arrange([IntPtr]$handle, $desired) {
        if ([WpsWindow]::Place($handle).showCmd -ne 1) { $null=[WpsWindow]::ShowWindow($handle,4) }
        $frame=[WpsWindow]::Bounds($handle,$true)
        $outer=[WpsWindow]::Bounds($handle,$false)
        $x=$desired.left+$outer.left-$frame.left
        $y=$desired.top+$outer.top-$frame.top
        $width=$desired.right-$desired.left+($outer.right-$outer.left)-($frame.right-$frame.left)
        $height=$desired.bottom-$desired.top+($outer.bottom-$outer.top)-($frame.bottom-$frame.top)
        # Preserve z-order and do not activate the companion.
        $matched=[WpsWindow]::SetWindowPos($handle,[IntPtr]::Zero,$x,$y,$width,$height,0x14)
        $actual=[WpsWindow]::Bounds($handle,$true)
        foreach ($field in @('left','top','right','bottom')) {
            if ([Math]::Abs($actual.$field-$desired.$field) -gt 2) { $matched=$false }
        }
        $matched
    }
    function Restore-Snapshot($target, $original) {
        $handle=[IntPtr][long]$target.hwnd
        if (-not $original -or $original.hwnd -ne $target.hwnd -or $original.birth -ne $target.birth) { throw 'wps_window_restore_invalid' }
        $place=[WpsWindow]::Place($handle)
        $place.flags=$original.placement.flags
        $place.showCmd=$original.placement.showCmd
        $expectedVisible=[bool]$original.visible
        $expectedIconic=[bool]$original.iconic
        if ($restoreMode -eq 'layout') {
            # Restore usable geometry, not an old minimized/hidden state.
            $place.showCmd=$(if($original.placement.showCmd -eq 3){3}else{1})
            $place.flags=$place.flags -band (-bnot 2)
            $expectedVisible=$true
            $expectedIconic=$false
        }
        $normal=[WpsWindow+Rect]::new()
        foreach ($field in @('left','top','right','bottom')) { $normal.$field=$original.placement.$field }
        $originalWork=[WpsWindow+Rect]::new()
        foreach ($field in @('left','top','right','bottom')) { $originalWork.$field=$original.work.$field }
        $adjusted=-not [WpsWindow]::HasScreen($originalWork)
        if ($adjusted) {
            $screen=[WpsWindow]::Screen($handle)
            $work=$screen.work
            $width=[Math]::Min($normal.right-$normal.left,$work.right-$work.left)
            $height=[Math]::Min($normal.bottom-$normal.top,$work.bottom-$work.top)
            # WINDOWPLACEMENT uses workspace coordinates.
            $normal.left=$screen.monitor.left; $normal.top=$screen.monitor.top
            $normal.right=$normal.left+$width; $normal.bottom=$normal.top+$height
        }
        $place.normal=$normal
        # Electron may accept placement while retaining its minimized/maximized state.
        if ($expectedVisible -and -not $expectedIconic -and
            ([WpsWindow]::IsIconic($handle) -or ($place.showCmd -eq 1 -and [WpsWindow]::Place($handle).showCmd -eq 3))) {
            $null=[WpsWindow]::ShowWindow($handle,9)
        }
        $restored=[WpsWindow]::SetWindowPlacement($handle,[ref]$place)
        # Chromium can apply placement while leaving the HWND hidden. Visibility is a separate saved fact.
        if ($restored -and $expectedVisible -and -not [WpsWindow]::IsWindowVisible($handle)) {
            $null=[WpsWindow]::ShowWindow($handle,8)
        } elseif ($restored -and -not $expectedVisible -and [WpsWindow]::IsWindowVisible($handle)) {
            $null=[WpsWindow]::ShowWindow($handle,0)
        }
        $actual=[WpsWindow]::Place($handle)
        $restored=$restored -and $actual.showCmd -eq $place.showCmd -and
            [WpsWindow]::IsWindowVisible($handle) -eq $expectedVisible -and
            [WpsWindow]::IsIconic($handle) -eq $expectedIconic
        foreach ($field in @('left','top','right','bottom')) {
            if ([Math]::Abs($actual.normal.$field-$normal.$field) -gt 2) { $restored=$false }
        }
        $outcome=Outcome $(if((Foreground $handle) -eq 'shown'){'shown'}else{'unavailable'}) $(if($restored){'applied'}else{'failed'}) $(if($adjusted){'adjusted_for_display_change'}elseif(-not $restored){'window_restore_mismatch'})
        $outcome.restored=$restored
        $outcome
    }
    $result = @{ ok=$true; foreground=[WpsWindow]::GetForegroundWindow().ToInt64(); windows=@(); hostRunning=$false }
    if ($request.companionIdentity) {
        try { $result.companion=Resolve-Companion $request.companionIdentity $request.companionTarget }
        catch { $result.companionReasonCode=$_.Exception.Message }
    }
    if ($request.identity) {
        $target = Resolve-Target $request.identity $request.target
        $result.target=$target
        $handle=[IntPtr][long]$target.hwnd
    } elseif ($request.action -ne 'inspect') { throw 'wps_window_identity_unavailable' }
    if ($request.action -eq 'inspect') {
        $hostProcesses = @(Get-Process -Name wpp -ErrorAction SilentlyContinue)
        $result.hostRunning=$hostProcesses.Count -gt 0
        $result.hostPids=@($hostProcesses | ForEach-Object { $_.Id })
        if (-not $request.identity) {
            $wpsIds = @(Get-Process -Name wpp,wpsoffice -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
            $result.windows=@(foreach ($window in [WpsWindow]::Tops()) {
                if ($wpsIds -contains [WpsWindow]::Pid($window) -and (Eligible $window)) { Snapshot $window }
            })
        }
    } elseif (-not $target.enabled) {
        $result.outcome=Outcome 'unavailable' 'skipped' 'wps_window_modal_blocked'
    } elseif ($request.action -eq 'present') {
        $foregroundClock=[Diagnostics.Stopwatch]::StartNew()
        if ($target.iconic) { $null=[WpsWindow]::ShowWindow($handle,9) }
        [WpsWindow]::PresentForeground($handle)
        $foreground=Foreground $handle
        $result.timings=@{ foregroundMs=$foregroundClock.ElapsedMilliseconds; layoutMs=0 }
        $result.outcome=Outcome $foreground 'skipped' $(if ($foreground -ne 'shown') { 'foreground_not_acquired' })
        if ($foreground -eq 'shown' -and $request.allowLayout -eq $true -and
            $null -ne $result.companion -and $null -ne $request.companionTarget) {
            $layoutClock=[Diagnostics.Stopwatch]::StartNew()
            $screen=[WpsWindow]::Screen($handle)
            $paired=$null -ne $result.companion -and $null -ne $request.companionTarget
            $desired=$screen.work
            $companionDesired=$screen.work
            if ($paired) {
                $split=$desired.right-[int][Math]::Round(($desired.right-$desired.left)*2.0/3)
                $desired.left=$split
                $companionDesired.right=$split
            }
            $fits=Fits $handle $desired
            if ($paired) { $fits=$fits -and (Fits ([IntPtr][long]$result.companion.hwnd) $companionDesired) }
            if (-not $fits) {
                $result.outcome=Outcome (Foreground $handle) 'failed' 'window_minimum_exceeds_layout'
                if ($paired) { $result.outcome.companionLayout='skipped'; $result.outcome.companionReasonCode='window_minimum_exceeds_layout' }
            } else {
                $matched=Arrange $handle $desired
                $result.outcome=Outcome (Foreground $handle) $(if($matched){'applied'}else{'failed'}) $(if(-not $matched){'window_geometry_mismatch'})
                if ($paired -and $matched) {
                    # Recheck identity immediately before moving the calling host.
                    try {
                    $companion=Resolve-Companion $request.companionIdentity $request.companionTarget
                    $companionMatched=Arrange ([IntPtr][long]$companion.hwnd) $companionDesired
                    $result.outcome.companionLayout=$(if($companionMatched){'applied'}else{'failed'})
                    if (-not $companionMatched) {
                        $result.outcome.companionReasonCode='companion_geometry_mismatch'
                    }
                    $result.companion=Resolve-Companion $request.companionIdentity $companion
                    $wpsFrame=[WpsWindow]::Bounds($handle,$true)
                    if ([Math]::Abs($result.companion.rect.right-$wpsFrame.left) -gt 2) {
                        $result.outcome.companionLayout='failed'
                        $result.outcome.companionReasonCode='companion_boundary_mismatch'
                    }
                    } catch {
                        $result.outcome.companionLayout='failed'
                        $result.outcome.companionReasonCode=$_.Exception.Message
                    }
                }
            }
            if ($request.companionIdentity -and -not $paired) {
                $result.outcome.companionLayout='skipped'
                $result.outcome.companionReasonCode=$(if($result.companionReasonCode){$result.companionReasonCode}else{'companion_pre_state_unavailable'})
            }
            $result.timings.layoutMs=$layoutClock.ElapsedMilliseconds
        }
        $result.target=Resolve-Target $request.identity $target
    } else {
        $result.outcome=Restore-Snapshot $target $request.original
        if ($request.companionOriginal) {
            try {
                $companion=Resolve-Companion $request.companionIdentity $request.companionOriginal
                $companionOutcome=Restore-Snapshot $companion $request.companionOriginal
                $result.outcome.companionLayout=$companionOutcome.layout
                $result.outcome.companionReasonCode=$companionOutcome.reasonCode
                $result.outcome.restored=$result.outcome.restored -and $companionOutcome.restored
                $result.companion=Resolve-Companion $request.companionIdentity $companion
            } catch {
                $result.outcome.companionLayout='failed'
                $result.outcome.companionReasonCode=$_.Exception.Message
                $result.outcome.restored=$false
            }
        }
        $result.target=Resolve-Target $request.identity $target
        if ($restoreMode -eq 'layout' -and $result.outcome.restored) {
            # Activate only after both layouts are restored; do not run Arrange again.
            [WpsWindow]::PresentForeground($handle)
        }
        $finalForeground=Foreground $handle
        $result.outcome.foreground=$(if($finalForeground -eq 'shown'){'shown'}elseif($restoreMode -eq 'layout'){'denied'}else{'unavailable'})
        if ($restoreMode -eq 'layout' -and $result.outcome.restored -and $finalForeground -ne 'shown') {
            $result.outcome.restored=$false
            $result.outcome.reasonCode='foreground_not_acquired'
        }
    }
    if ($request.action -eq 'restore') {
        $result.outcome.restoreMode=$restoreMode
        $result.outcome.displayState=Display-State (Resolve-Target $request.identity $target)
        if ($result.companion) { $result.outcome.companionDisplayState=Display-State $result.companion }
        if (-not $result.outcome.restored) { $result.outcome.retryAction='restore_window' }
    }
    $result.foreground=[WpsWindow]::GetForegroundWindow().ToInt64()
    $result | ConvertTo-Json -Compress -Depth 10
} catch {
    @{ ok=$false; reasonCode=$_.Exception.Message } | ConvertTo-Json -Compress
}
