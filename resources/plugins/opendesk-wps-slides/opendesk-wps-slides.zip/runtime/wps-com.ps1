﻿# Input: Action 名称与 JSON 参数
# Output: WPS COM 调用结果 JSON
# Pos: Windows COM 桥接脚本。一旦我被修改，请更新我的头部注释（Updated: 2026-08-26 20:10:00 CST），以及所属文件夹的md。
# WPS COM Bridge - PowerShell script for WPS COM operations
# Full implementation for Excel, Word, PPT, and common conversions
# Usage: powershell -File wps-com.ps1 -Action <action> -Params <json>

param(
    [string]$Action,
    [string]$Params = "{}",
    [switch]$ParamsFromStdin,
    [string]$ParamsFromFile = ""
)

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$script:BoundPptApplication = $null
$script:BoundPptPresentation = $null

# ==================== COM Object Getters ====================

function Get-WpsExcel {
    try { return [System.Runtime.InteropServices.Marshal]::GetActiveObject('Ket.Application') }
    catch { return $null }
}

function Get-WpsWord {
    try { return [System.Runtime.InteropServices.Marshal]::GetActiveObject('Kwps.Application') }
    catch { return $null }
}

function Get-WpsPpt {
    if ($null -ne $script:BoundPptApplication) { return $script:BoundPptApplication }
    $rotApplication = $null
    try { $rotApplication = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Kwpp.Application') } catch {}
    if (Test-WpsPptApplicationUsable $rotApplication) { return $rotApplication }
    $windowApplication = @(Get-WpsPptWindowApplications | Where-Object { Test-WpsPptApplicationUsable $_ } | Select-Object -First 1)
    if ($windowApplication.Count -gt 0) { return $windowApplication[0] }
    return $rotApplication
}

function Test-WpsPptApplicationUsable($application) {
    if ($null -eq $application) { return $false }
    try {
        $presentation = $application.ActivePresentation
        if ($null -eq $presentation -or $null -eq $presentation.Slides) { return $false }
        $name = [string]$presentation.Name
        $fullName = ""
        try { $fullName = [string]$presentation.FullName } catch {}
        return -not [string]::IsNullOrWhiteSpace($name) -or -not [string]::IsNullOrWhiteSpace($fullName)
    } catch {
        return $false
    }
}

function Get-WpsPptWindowApplications {
    try {
        if ($null -eq ("WpsPptNativeWindow" -as [type])) {
            Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class WpsPptNativeWindow {
    public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);
    [DllImport("user32.dll")]
    public static extern bool EnumChildWindows(IntPtr parent, EnumWindowsProc callback, IntPtr lParam);
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetClassName(IntPtr hwnd, StringBuilder className, int maxCount);
    [DllImport("oleacc.dll")]
    public static extern int AccessibleObjectFromWindow(
        IntPtr hwnd,
        uint objectId,
        ref Guid iid,
        [MarshalAs(UnmanagedType.Interface)] out object nativeObject);
}
"@
        }
        $foregroundWindow = [WpsPptNativeWindow]::GetForegroundWindow()
        $processes = @(Get-Process wps,wpp -ErrorAction SilentlyContinue |
            Where-Object { $_.MainWindowHandle -ne 0 } |
            Sort-Object @{ Expression = { if ($_.MainWindowHandle -eq $foregroundWindow) { 0 } else { 1 } } }, StartTime)
        $iid = [Guid]"00020400-0000-0000-C000-000000000046"
        $nativeObjectId = [uint32]4294967280
        $applications = @()
        $seenPresentations = @{}
        foreach ($process in $processes) {
            $handles = [Collections.Generic.List[IntPtr]]::new()
            $callback = [WpsPptNativeWindow+EnumWindowsProc]{
                param([IntPtr]$hwnd, [IntPtr]$lParam)
                $handles.Add($hwnd)
                return $true
            }
            $null = [WpsPptNativeWindow]::EnumChildWindows($process.MainWindowHandle, $callback, [IntPtr]::Zero)
            foreach ($handle in $handles) {
                $className = [Text.StringBuilder]::new(256)
                $null = [WpsPptNativeWindow]::GetClassName($handle, $className, $className.Capacity)
                if ($className.ToString() -ne "mdiClass") { continue }
                $native = $null
                $result = [WpsPptNativeWindow]::AccessibleObjectFromWindow(
                    $handle,
                    $nativeObjectId,
                    [ref]$iid,
                    [ref]$native
                )
                if ($result -ne 0 -or $null -eq $native) { continue }
                $application = $null
                try { $application = $native.Application } catch {}
                if ($null -eq $application) { continue }
                $identity = ""
                try {
                    $presentation = $application.ActivePresentation
                    $identity = [string]$presentation.FullName
                    if ([string]::IsNullOrWhiteSpace($identity)) { $identity = [string]$presentation.Name }
                } catch {}
                if ([string]::IsNullOrWhiteSpace($identity)) { $identity = "window:$handle" }
                if (-not $seenPresentations.ContainsKey($identity)) {
                    $seenPresentations[$identity] = $true
                    $applications += $application
                }
            }
        }
        return $applications
    } catch {
        return @()
    }
}

function Output-Json($obj) {
    $obj | ConvertTo-Json -Depth 20 -Compress
}

function Convert-ColumnLetterToNumber([string]$letters) {
    if (-not $letters) { return $null }
    $letters = $letters.ToUpper().Trim()
    $sum = 0
    foreach ($ch in $letters.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { continue }
        $sum = ($sum * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $sum
}

function Convert-ColumnNumberToLetter([int]$col) {
    if ($col -le 0) { return $null }
    $letter = ""
    while ($col -gt 0) {
        $mod = ($col - 1) % 26
        $letter = [char](65 + $mod) + $letter
        $col = [Math]::Floor(($col - 1) / 26)
    }
    return $letter
}

function Convert-HexColorToRgbInt([string]$hex) {
    if (-not $hex) { return $null }
    $hex = $hex.Trim()
    if ($hex.StartsWith('#')) { $hex = $hex.Substring(1) }
    if ($hex.Length -eq 3) {
        $hex = ($hex[0] + $hex[0] + $hex[1] + $hex[1] + $hex[2] + $hex[2])
    }
    if ($hex.Length -ne 6) { return $null }
    $r = [Convert]::ToInt32($hex.Substring(0, 2), 16)
    $g = [Convert]::ToInt32($hex.Substring(2, 2), 16)
    $b = [Convert]::ToInt32($hex.Substring(4, 2), 16)
    return $r + ($g * 256) + ($b * 65536)
}

function Get-WpsPptPresentation($ppt) {
    if ($null -ne $script:BoundPptPresentation) {
        return $script:BoundPptPresentation
    }
    try { return $ppt.ActivePresentation } catch { return $null }
}

function Get-PptPresentationProtectionState($presentation) {
    $readOnly = $false
    $protectMode = $false
    try { $readOnly = [bool]$presentation.ReadOnly } catch {}
    try { $protectMode = [bool]$presentation.ProtectMode } catch {}
    return @{
        readOnly = $readOnly
        protectMode = $protectMode
    }
}

function Get-PptRuntimePresentationLocator($presentation, [bool]$allowWindowFallback = $false) {
    if ($null -eq $presentation) { return "" }
    $name = ""
    try { $name = [string]$presentation.Name } catch {}
    $fullPath = ""
    try { $fullPath = [string]$presentation.FullName } catch {}
    if (-not [string]::IsNullOrWhiteSpace($fullPath) -and $fullPath -ne $name) {
        return "wps-path:$fullPath"
    }
    # WPS 12 may block for seconds when reading the native window handle. A
    # name-only locator is sufficient until an unsaved same-name ambiguity or an
    # explicit runtime locator requires disambiguation.
    if (-not $allowWindowFallback) { return "wps-name:$name" }
    $windowHwnd = ""
    try { $windowHwnd = [string]$presentation.Windows.Item(1).HWND } catch {}
    if (-not [string]::IsNullOrWhiteSpace($windowHwnd)) {
        return "wps-runtime::$windowHwnd`:$name"
    }
    return "wps-name:$name"
}

function Get-PptCompactHash([string]$value) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($value)
        return ([System.BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "").ToLowerInvariant().Substring(0, 32)
    } finally {
        $sha.Dispose()
    }
}

function Get-PptSlideSummaryResult($slide, [int]$slideIndex) {
    $nativeSlideId = $slideIndex
    try { $nativeSlideId = [int]$slide.SlideID } catch {}
    $title = ""
    $textExcerpts = @()
    $objectCounts = @{}
    $fingerprintParts = @([string]$nativeSlideId, [string]$slideIndex)
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
        $shape = $slide.Shapes.Item($shapeIndex)
        $typeCode = -1
        try { $typeCode = [int]$shape.Type } catch {}
        $typeKey = "type-$typeCode"
        if ($objectCounts.ContainsKey($typeKey)) {
            $objectCounts[$typeKey] = [int]$objectCounts[$typeKey] + 1
        } else {
            $objectCounts[$typeKey] = 1
        }
        $shapeId = ""
        $shapeName = ""
        try { $shapeId = [string]$shape.Id } catch {}
        try { $shapeName = [string]$shape.Name } catch {}
        $text = ""
        try {
            if ([int]$shape.HasTextFrame -ne 0 -and [int]$shape.TextFrame.HasText -ne 0) {
                $text = [string]$shape.TextFrame.TextRange.Text
            }
        } catch {}
        $normalizedText = ($text -replace "[\r\n]+", " " -replace "\s+", " ").Trim()
        if (-not [string]::IsNullOrWhiteSpace($normalizedText)) {
            if ($normalizedText.Length -gt 160) { $normalizedText = $normalizedText.Substring(0, 160) }
            if ($textExcerpts.Count -lt 4) { $textExcerpts += $normalizedText }
            if ([string]::IsNullOrWhiteSpace($title)) {
                try {
                    $placeholderType = [int]$shape.PlaceholderFormat.Type
                    if (@(1, 3) -contains $placeholderType) { $title = $normalizedText }
                } catch {}
            }
        }
        $fingerprintParts += @($shapeId, $shapeName, [string]$typeCode, $normalizedText)
        try {
            $fingerprintParts += @(
                [string][double]$shape.Left,
                [string][double]$shape.Top,
                [string][double]$shape.Width,
                [string][double]$shape.Height,
                [string][double]$shape.Rotation
            )
        } catch {}
    }
    if ([string]::IsNullOrWhiteSpace($title) -and $textExcerpts.Count -gt 0) {
        $title = [string]$textExcerpts[0]
    }
    $hidden = $false
    try { $hidden = ([int]$slide.SlideShowTransition.Hidden -ne 0) } catch {}
    $nativeLayoutName = ""
    try { $nativeLayoutName = [string]$slide.CustomLayout.Name } catch {}
    $background = @{}
    try {
        $background = @{
            followMasterBackground = ([int]$slide.FollowMasterBackground -ne 0)
            fillType = [int]$slide.Background.Fill.Type
            fillForeColor = $(try { [int]$slide.Background.Fill.ForeColor.RGB } catch { $null })
        }
    } catch {}
    return @{
        nativeSlideId = $nativeSlideId
        index = $slideIndex
        title = $title
        textExcerpts = @($textExcerpts)
        objectCount = [int]$slide.Shapes.Count
        objectCounts = $objectCounts
        hidden = $hidden
        nativeLayoutName = $nativeLayoutName
        directBackground = $background
        fingerprint = Get-PptCompactHash ($fingerprintParts -join "|")
    }
}

function Get-PptPresentationTemplateIdentityResult($pres) {
    if ($null -eq $pres) {
        return @{ success = $false; error = "No active presentation" }
    }
    $name = [string]$pres.Name
    $fullPath = ""
    try { $fullPath = [string]$pres.FullName } catch {}
    $hasFilePath = -not [string]::IsNullOrWhiteSpace($fullPath) -and $fullPath -ne $name
    $saved = $false
    try { $saved = $hasFilePath -and [bool]$pres.Saved } catch {}
    return @{
        success = $true
        data = @{
            name = $name
            fullPath = $(if ($hasFilePath) { $fullPath } else { $null })
            runtimeLocator = Get-PptRuntimePresentationLocator $pres $false
            saved = $saved
        }
    }
}

function Get-PptPresentationIdentityResult(
    $pres,
    $nameAmbiguousOverride = $null,
    $activeRuntimeLocatorOverride = $null
) {
    if ($null -eq $pres) {
        return @{ success = $false; error = "No active presentation" }
    }
    $protection = Get-PptPresentationProtectionState $pres
    $name = [string]$pres.Name
    $fullPath = ""
    try { $fullPath = [string]$pres.FullName } catch {}
    $hasFilePath = -not [string]::IsNullOrWhiteSpace($fullPath) -and $fullPath -ne $name
    $saved = $false
    try { $saved = $hasFilePath -and [bool]$pres.Saved } catch {}
    $slideWidth = 0.0
    $slideHeight = 0.0
    try { $slideWidth = [double]$pres.PageSetup.SlideWidth } catch {}
    try { $slideHeight = [double]$pres.PageSetup.SlideHeight } catch {}
    $nameAmbiguous = if ($null -ne $nameAmbiguousOverride) {
        [bool]$nameAmbiguousOverride
    } else {
        Test-PptPresentationNameAmbiguous $pres
    }
    $runtimeLocator = Get-PptRuntimePresentationLocator $pres $nameAmbiguous
    $active = $false
    if ($null -ne $activeRuntimeLocatorOverride) {
        $active = (
            -not [string]::IsNullOrWhiteSpace([string]$activeRuntimeLocatorOverride) -and
            ([string]$activeRuntimeLocatorOverride -eq $runtimeLocator)
        )
    } else {
        try {
            $activePresentation = $pres.Application.ActivePresentation
            if ($null -ne $activePresentation) {
                $activeRuntimeLocator = Get-PptRuntimePresentationLocator $activePresentation (
                    (Test-PptPresentationNameAmbiguous $activePresentation)
                )
                $active = ($activeRuntimeLocator -eq $runtimeLocator)
            }
        } catch {}
    }
    return @{
        success = $true
        data = @{
            name = $name
            fullPath = $(if ([string]::IsNullOrWhiteSpace($fullPath) -or $fullPath -eq $name) { $null } else { $fullPath })
            runtimeLocator = $runtimeLocator
            saved = $saved
            readOnly = [bool]$protection.readOnly
            protectMode = [bool]$protection.protectMode
            active = $active
            slideCount = [int]$pres.Slides.Count
            pageSize = @{ width = $slideWidth; height = $slideHeight }
        }
    }
}

function Test-PptPresentationNameAmbiguous($presentation) {
    if ($null -eq $presentation) { return $false }
    $name = ""
    try { $name = [string]$presentation.Name } catch {}
    if ([string]::IsNullOrWhiteSpace($name)) { return $false }
    try {
        $application = $presentation.Application
        $matches = 0
        for ($index = 1; $index -le $application.Presentations.Count; $index++) {
            try {
                if ([string]$application.Presentations.Item($index).Name -eq $name) {
                    $matches++
                    if ($matches -gt 1) { return $true }
                }
            } catch {}
        }
    } catch {}
    return $false
}

function Get-PptPresentationSceneResult($pres) {
    $identityResult = Get-PptPresentationIdentityResult $pres
    if (-not $identityResult.success) { return $identityResult }
    $identity = $identityResult.data
    $slideWidth = [double]$identity.pageSize.width
    $slideHeight = [double]$identity.pageSize.height
    $slides = @()
    # File identity is carried by presentationRef/runtimeLocator. Saving under a
    # different path must not be reported as a content change.
    $presentationFingerprintParts = @([string]$slideWidth, [string]$slideHeight)
    for ($slideIndex = 1; $slideIndex -le $pres.Slides.Count; $slideIndex++) {
        $slide = $pres.Slides.Item($slideIndex)
        $summary = Get-PptSlideSummaryResult $slide $slideIndex
        $slides += $summary
        $presentationFingerprintParts += @(
            [string]$summary.nativeSlideId,
            [string]$slideIndex,
            [string]$summary.fingerprint
        )
    }
    return @{
        success = $true
        data = @{
            presentation = @{
                name = $identity.name
                fullPath = $identity.fullPath
                runtimeLocator = $identity.runtimeLocator
                saved = $identity.saved
                readOnly = $identity.readOnly
                protectMode = $identity.protectMode
                active = $identity.active
                slideCount = $identity.slideCount
                pageSize = $identity.pageSize
            }
            slides = @($slides)
            fingerprint = Get-PptCompactHash ($presentationFingerprintParts -join "|")
        }
    }
}

function Find-WpsPptPresentationInApplication($application, [string]$presentationId) {
    if ($null -eq $application -or [string]::IsNullOrWhiteSpace($presentationId)) { return $null }
    $matches = @()
    $requiresRuntimeLocator = ([string]$presentationId).StartsWith("wps-runtime::", [System.StringComparison]::OrdinalIgnoreCase)
    $requestedPath = if (([string]$presentationId).StartsWith("wps-path:", [System.StringComparison]::OrdinalIgnoreCase)) {
        ([string]$presentationId).Substring("wps-path:".Length)
    } else { "" }
    $requestedName = if (([string]$presentationId).StartsWith("wps-name:", [System.StringComparison]::OrdinalIgnoreCase)) {
        ([string]$presentationId).Substring("wps-name:".Length)
    } else { "" }
    for ($index = 1; $index -le $application.Presentations.Count; $index++) {
        try {
            $candidate = $application.Presentations.Item($index)
            $name = [string]$candidate.Name
            $fullName = ""
            try { $fullName = [string]$candidate.FullName } catch {}
            if (
                $name -eq $presentationId -or
                $fullName -eq $presentationId -or
                (-not [string]::IsNullOrWhiteSpace($requestedPath) -and $fullName -eq $requestedPath) -or
                (-not [string]::IsNullOrWhiteSpace($requestedName) -and $name -eq $requestedName)
            ) {
                $matches += $candidate
            }
            elseif ($requiresRuntimeLocator) {
                $runtimeLocator = Get-PptRuntimePresentationLocator $candidate $true
                if ($runtimeLocator -eq $presentationId) { $matches += $candidate }
            }
        } catch {}
    }
    if ($matches.Count -eq 1) { return $matches[0] }
    return $null
}

function Get-WpsPptPresentationById($ppt, [string]$presentationId) {
    if ([string]::IsNullOrWhiteSpace($presentationId)) { return $null }
    $candidate = Find-WpsPptPresentationInApplication $ppt $presentationId
    if ($null -ne $candidate) {
        $script:BoundPptApplication = $ppt
        return $candidate
    }
    foreach ($application in @(Get-WpsPptWindowApplications)) {
        $candidate = Find-WpsPptPresentationInApplication $application $presentationId
        if ($null -ne $candidate) {
            $script:BoundPptApplication = $application
            return $candidate
        }
    }
    return $null
}

function Convert-RgbIntToHex($rgb) {
    if ($null -eq $rgb) { return $null }
    $value = [int]$rgb
    $r = $value -band 255
    $g = ($value -shr 8) -band 255
    $b = ($value -shr 16) -band 255
    return ("#{0:X2}{1:X2}{2:X2}" -f $r, $g, $b)
}

function Get-PptChartAxesSnapshot($chart) {
    $axes = @()
    foreach ($axisDefinition in @(
        @{ kind = "category"; type = 1 },
        @{ kind = "value"; type = 2 }
    )) {
        try {
            $axis = $chart.Axes([int]$axisDefinition.type, 1)
            $hasTitle = [bool]$axis.HasTitle
            $axes += @{
                kind = [string]$axisDefinition.kind
                hasTitle = $hasTitle
                title = $(if ($hasTitle) { [string]$axis.AxisTitle.Text } else { "" })
                hasMajorGridlines = $(try { [bool]$axis.HasMajorGridlines } catch { $false })
                minimumScale = $(try { [double]$axis.MinimumScale } catch { $null })
                maximumScale = $(try { [double]$axis.MaximumScale } catch { $null })
                minimumScaleIsAuto = $(try { [bool]$axis.MinimumScaleIsAuto } catch { $null })
                maximumScaleIsAuto = $(try { [bool]$axis.MaximumScaleIsAuto } catch { $null })
            }
        } catch {}
    }
    return $axes
}

function Get-PptTableCellBorders($cell) {
    $result = [ordered]@{}
    foreach ($definition in @(
        @{ name = "top"; value = 1 },
        @{ name = "left"; value = 2 },
        @{ name = "bottom"; value = 3 },
        @{ name = "right"; value = 4 }
    )) {
        try {
            $border = $cell.Borders.Item([int]$definition.value)
            $result[[string]$definition.name] = [ordered]@{
                color = Convert-RgbIntToHex ([int]$border.ForeColor.RGB)
                width = [double]$border.Weight
            }
        } catch {}
    }
    return $result
}

function Get-PptTableCellParagraph($cellShape) {
    $format = $cellShape.TextFrame.TextRange.ParagraphFormat
    return [ordered]@{
        alignment = $(try {
            $value = [int]$format.Alignment
            if ($value -eq 2) { "center" } elseif ($value -eq 3) { "right" } elseif ($value -eq 4) { "justify" } else { "left" }
        } catch { $null })
        spaceBefore = $(try { [double]$format.SpaceBefore } catch { $null })
        spaceAfter = $(try { [double]$format.SpaceAfter } catch { $null })
        lineSpacing = $(try { [double]$format.SpaceWithin } catch { $null })
    }
}

function Get-PptChartSeriesSnapshot($chart) {
    $series = @()
    try {
        $collection = $chart.SeriesCollection()
        for ($index = 1; $index -le $collection.Count; $index++) {
            $item = $collection.Item($index)
            $series += @{
                index = $index
                name = $(try { [string]$item.Name } catch { "" })
                fillColor = $(try { Convert-RgbIntToHex ([int]$item.Format.Fill.ForeColor.RGB) } catch { $null })
                hasDataLabels = $(try { [bool]$item.HasDataLabels } catch { $false })
            }
        }
    } catch {}
    return $series
}

function Get-ObjectPropertyValue($obj, [string]$name) {
    if ($null -eq $obj) { return $null }
    if ($obj -is [System.Collections.IDictionary]) {
        if ($obj.Contains($name)) { return $obj[$name] }
        return $null
    }
    $prop = $obj.PSObject.Properties | Where-Object { $_.Name -eq $name } | Select-Object -First 1
    if ($null -eq $prop) { return $null }
    return $prop.Value
}

function Convert-PptShapeTypeToName($shapeType) {
    if ($null -eq $shapeType) { return "unknown" }
    $typeMap = @{
        1 = "autoShape"
        2 = "callout"
        3 = "chart"
        4 = "comment"
        5 = "freeform"
        6 = "group"
        7 = "embeddedOleObject"
        8 = "formControl"
        9 = "line"
        10 = "linkedOleObject"
        11 = "linkedPicture"
        12 = "oleControlObject"
        13 = "picture"
        14 = "placeholder"
        15 = "textEffect"
        16 = "media"
        17 = "textBox"
        18 = "scriptAnchor"
        19 = "table"
        20 = "canvas"
        21 = "diagram"
        22 = "ink"
        23 = "inkComment"
        24 = "smartArt"
        25 = "slicer"
        26 = "webVideo"
        27 = "contentApp"
        28 = "graphic"
        29 = "linkedGraphic"
        30 = "model3D"
        31 = "linkedModel3D"
    }
    $name = $typeMap[[int]$shapeType]
    if ($null -ne $name) { return $name }
    return "shapeType:$shapeType"
}

function Convert-PptChartTypeToName($chartType) {
    if ($null -eq $chartType) { return $null }
    $chartTypeMap = @{
        1 = "area"
        4 = "line"
        5 = "pie"
        51 = "column_clustered"
        52 = "column_stacked"
        57 = "bar_clustered"
        65 = "line_markers"
        -4120 = "doughnut"
        -4169 = "scatter"
        -4151 = "radar"
    }
    $name = $chartTypeMap[[int]$chartType]
    if ($null -ne $name) { return $name }
    return "chartType:$chartType"
}

function Convert-PptAutoShapeTypeToName($autoShapeType) {
    if ($null -eq $autoShapeType) { return $null }
    $autoMap = @{
        1 = "rectangle"
        2 = "parallelogram"
        3 = "trapezoid"
        4 = "diamond"
        5 = "roundedRectangle"
        7 = "triangle"
        9 = "oval"
        10 = "hexagon"
        12 = "pentagon"
        13 = "can"
        21 = "heart"
        33 = "rightArrow"
        34 = "leftArrow"
        35 = "upArrow"
        36 = "downArrow"
        37 = "leftRightArrow"
        38 = "upDownArrow"
        39 = "quadArrow"
        92 = "star5"
        179 = "cloud"
    }
    $name = $autoMap[[int]$autoShapeType]
    if ($null -ne $name) { return $name }
    return "autoShapeType:$autoShapeType"
}

function Convert-PptPlaceholderTypeToName($placeholderType) {
    if ($null -eq $placeholderType) { return $null }
    $placeholderMap = @{
        1 = "title"
        2 = "body"
        3 = "centerTitle"
        4 = "subtitle"
        5 = "verticalTitle"
        6 = "verticalBody"
        7 = "object"
        8 = "chart"
        9 = "bitmap"
        10 = "mediaClip"
        11 = "orgChart"
        12 = "table"
        13 = "slideNumber"
        14 = "header"
        15 = "footer"
        16 = "date"
    }
    $name = $placeholderMap[[int]$placeholderType]
    if ($null -ne $name) { return $name }
    return "placeholderType:$placeholderType"
}

function Get-PptTextFormattingSnapshot($textRange, $shape = $null) {
    $runs = @()
    $runCount = 0
    try { $runCount = [int]$textRange.Runs().Count } catch {}
    for ($runIndex = 1; $runIndex -le $runCount; $runIndex++) {
        try {
            $run = $textRange.Runs($runIndex, 1)
            $run2 = $null
            if ($null -ne $shape) {
                try { $run2 = $shape.TextFrame2.TextRange.Characters([int]$run.Start, [int]$run.Length) } catch {}
            }
            $runs += [ordered]@{
                start = [int]$run.Start
                length = [int]$run.Length
                fontName = $(try { [string]$run.Font.Name } catch { $null })
                fontSize = $(try { [double]$run.Font.Size } catch { $null })
                fontBold = $(try { [int]$run.Font.Bold } catch { $null })
                fontItalic = $(try { [int]$run.Font.Italic } catch { $null })
                fontColor = $(try { [int]$run.Font.Color.RGB } catch { $null })
                fontUnderline = $(try { [int]$run.Font.Underline } catch { $null })
                fontSubscript = $(try { [int]$run.Font.Subscript } catch { $null })
                fontSuperscript = $(try { [int]$run.Font.Superscript } catch { $null })
                fontStrike = $(if ($null -ne $run2) { try { [int]$run2.Font.Strike } catch { $null } } else { $null })
                characterSpacing = $(if ($null -ne $run2) { try { [double]$run2.Font.Spacing } catch { $null } } else { $null })
                allCaps = $(if ($null -ne $run2) { try { [int]$run2.Font.Allcaps } catch { $null } } else { $null })
                smallCaps = $(if ($null -ne $run2) { try { [int]$run2.Font.Smallcaps } catch { $null } } else { $null })
                alignment = $(try { [int]$run.ParagraphFormat.Alignment } catch { $null })
            }
        } catch {}
    }
    $propertyStates = [ordered]@{}
    foreach ($property in @("fontName", "fontSize", "fontBold", "fontItalic", "fontColor", "fontUnderline", "fontSubscript", "fontSuperscript", "fontStrike", "characterSpacing", "allCaps", "smallCaps", "alignment")) {
        $propertyValues = @($runs | ForEach-Object { Get-ObjectPropertyValue $_ $property })
        $knownValues = @($propertyValues | Where-Object { $null -ne $_ })
        $values = @($knownValues | ForEach-Object {
            "{0}:{1}" -f $_.GetType().FullName, [string]$_
        } | Sort-Object -Unique)
        $propertyStates[$property] = if ($runs.Count -eq 0 -or $knownValues.Count -ne $runs.Count) {
            "unknown"
        } elseif ($values.Count -eq 1) {
            "uniform"
        } else {
            "mixed"
        }
    }
    $formatState = if (@($propertyStates.Values | Where-Object { $_ -eq "mixed" }).Count -gt 0) {
        "mixed"
    } elseif ($runs.Count -gt 0) {
        "uniform"
    } else {
        "unknown"
    }
    return [ordered]@{
        formatState = $formatState
        propertyStates = $propertyStates
        runs = $runs
    }
}

function Get-PptCanonicalTextRuns($shape) {
    $result = @()
    $textRange = $null
    try { $textRange = $shape.TextFrame.TextRange } catch { return $result }
    $runCount = 0
    try { $runCount = [int]$textRange.Runs().Count } catch {}
    for ($runIndex = 1; $runIndex -le $runCount; $runIndex++) {
        try {
            $run = $textRange.Runs($runIndex, 1)
            $run2 = $null
            try { $run2 = $shape.TextFrame2.TextRange.Characters([int]$run.Start, [int]$run.Length) } catch {}
            $fontColor = $(try { [int]$run.Font.Color.RGB } catch { $null })
            $subscript = $(try { [int]$run.Font.Subscript } catch { 0 })
            $superscript = $(try { [int]$run.Font.Superscript } catch { 0 })
            $result += [ordered]@{
                start = [int]$run.Start
                length = [int]$run.Length
                fontName = $(try { [string]$run.Font.Name } catch { $null })
                fontSize = $(try { [double]$run.Font.Size } catch { $null })
                bold = $(try { [bool]([int]$run.Font.Bold -ne 0) } catch { $null })
                italic = $(try { [bool]([int]$run.Font.Italic -ne 0) } catch { $null })
                fontColorHex = $(if ($null -ne $fontColor) { Convert-RgbIntToHex $fontColor } else { $null })
                underline = $(try { [bool]([int]$run.Font.Underline -ne 0) } catch { $null })
                strikethrough = $(if ($null -ne $run2) { try { [bool]([int]$run2.Font.Strike -ne 0) } catch { $null } } else { $null })
                baseline = $(if ($superscript -ne 0) { "superscript" } elseif ($subscript -ne 0) { "subscript" } else { "normal" })
                characterSpacing = $(if ($null -ne $run2) { try { [double]$run2.Font.Spacing } catch { $null } } else { $null })
                case = $(if ($null -ne $run2 -and $(try { [int]$run2.Font.Allcaps } catch { 0 }) -ne 0) { "all_caps" } elseif ($null -ne $run2 -and $(try { [int]$run2.Font.Smallcaps } catch { 0 }) -ne 0) { "small_caps" } else { "normal" })
            }
        } catch {}
    }
    return @($result)
}

function Convert-PptFormattingSnapshotToCanonicalTextRuns($formattingSnapshot) {
    $result = @()
    foreach ($run in @((Get-ObjectPropertyValue $formattingSnapshot "runs"))) {
        $fontColor = Get-ObjectPropertyValue $run "fontColor"
        $subscript = Get-ObjectPropertyValue $run "fontSubscript"
        $superscript = Get-ObjectPropertyValue $run "fontSuperscript"
        $allCaps = Get-ObjectPropertyValue $run "allCaps"
        $smallCaps = Get-ObjectPropertyValue $run "smallCaps"
        $result += [ordered]@{
            start = [int](Get-ObjectPropertyValue $run "start")
            length = [int](Get-ObjectPropertyValue $run "length")
            fontName = Get-ObjectPropertyValue $run "fontName"
            fontSize = Get-ObjectPropertyValue $run "fontSize"
            bold = $(if ($null -ne (Get-ObjectPropertyValue $run "fontBold")) { [bool]([int](Get-ObjectPropertyValue $run "fontBold") -ne 0) } else { $null })
            italic = $(if ($null -ne (Get-ObjectPropertyValue $run "fontItalic")) { [bool]([int](Get-ObjectPropertyValue $run "fontItalic") -ne 0) } else { $null })
            fontColorHex = $(if ($null -ne $fontColor) { Convert-RgbIntToHex ([int]$fontColor) } else { $null })
            underline = $(if ($null -ne (Get-ObjectPropertyValue $run "fontUnderline")) { [bool]([int](Get-ObjectPropertyValue $run "fontUnderline") -ne 0) } else { $null })
            strikethrough = $(if ($null -ne (Get-ObjectPropertyValue $run "fontStrike")) { [bool]([int](Get-ObjectPropertyValue $run "fontStrike") -ne 0) } else { $null })
            baseline = $(if ([int]$superscript -ne 0) { "superscript" } elseif ([int]$subscript -ne 0) { "subscript" } else { "normal" })
            characterSpacing = Get-ObjectPropertyValue $run "characterSpacing"
            case = $(if ([int]$allCaps -ne 0) { "all_caps" } elseif ([int]$smallCaps -ne 0) { "small_caps" } else { "normal" })
        }
    }
    return @($result)
}

function Get-PptCanonicalTextParagraphs($shape) {
    $result = @()
    $textRange = $null
    try { $textRange = $shape.TextFrame.TextRange } catch { return $result }
    $paragraphCount = 0
    try { $paragraphCount = [int]$textRange.Paragraphs().Count } catch {}
    for ($paragraphIndex = 1; $paragraphIndex -le $paragraphCount; $paragraphIndex++) {
        try {
            $paragraphRange = $textRange.Paragraphs($paragraphIndex, 1)
            $format = $paragraphRange.ParagraphFormat
            $format2 = $null
            try { $format2 = $shape.TextFrame2.TextRange.Paragraphs($paragraphIndex, 1).ParagraphFormat } catch {}
            $bulletVisible = $(try { [int]$format.Bullet.Visible } catch { 0 })
            $bulletType = $(try { [int]$format.Bullet.Type } catch { 0 })
            $result += [ordered]@{
                index = $paragraphIndex
                start = [int]$paragraphRange.Start
                length = [int]$paragraphRange.Length
                alignment = $(try { [int]$format.Alignment } catch { $null })
                leftIndent = $(if ($null -ne $format2) { try { [double]$format2.LeftIndent } catch { $null } } else { $null })
                rightIndent = $(if ($null -ne $format2) { try { [double]$format2.RightIndent } catch { $null } } else { $null })
                firstLineIndent = $(if ($null -ne $format2) { try { [double]$format2.FirstLineIndent } catch { $null } } else { $null })
                spaceBefore = $(try { [double]$format.SpaceBefore } catch { $null })
                spaceAfter = $(try { [double]$format.SpaceAfter } catch { $null })
                lineSpacing = $(try { [double]$format.SpaceWithin } catch { $null })
                bullet = [ordered]@{
                    kind = $(if ($bulletVisible -eq 0 -or $bulletType -eq 0) { "none" } elseif ($bulletType -eq 2) { "number" } else { "bullet" })
                    character = $(try { [string][char][int]$format.Bullet.Character } catch { $null })
                    startAt = $(try { [int]$format.Bullet.StartValue } catch { $null })
                }
            }
        } catch {}
    }
    return @($result)
}

function Get-PptCanonicalTextFrame($shape) {
    return [ordered]@{
        marginLeft = $(try { [double]$shape.TextFrame.MarginLeft } catch { $null })
        marginRight = $(try { [double]$shape.TextFrame.MarginRight } catch { $null })
        marginTop = $(try { [double]$shape.TextFrame.MarginTop } catch { $null })
        marginBottom = $(try { [double]$shape.TextFrame.MarginBottom } catch { $null })
        verticalAnchor = $(try { [int]$shape.TextFrame.VerticalAnchor } catch { $null })
        autoSize = $(try { [int]$shape.TextFrame.AutoSize } catch { $null })
        wordWrap = $(try { [int]$shape.TextFrame.WordWrap } catch { $null })
    }
}

function Restore-PptTextFormattingSnapshot($shape, $formattingSnapshot) {
    $errors = @()
    if ($null -eq $formattingSnapshot) { return $errors }
    foreach ($runSnapshot in @((Get-ObjectPropertyValue $formattingSnapshot "runs"))) {
        $start = [int](Get-ObjectPropertyValue $runSnapshot "start")
        $length = [int](Get-ObjectPropertyValue $runSnapshot "length")
        if ($start -lt 1 -or $length -lt 1) { continue }
        try {
            $run = $shape.TextFrame.TextRange.Characters($start, $length)
        } catch {
            $errors += "range:${start}:${length}:$($_.Exception.Message)"
            continue
        }
        foreach ($entry in @(
            @{ name = "fontName"; apply = { param($target, $value) $target.Font.Name = [string]$value } },
            @{ name = "fontSize"; apply = { param($target, $value) $target.Font.Size = [double]$value } },
            @{ name = "fontBold"; apply = { param($target, $value) $target.Font.Bold = [int]$value } },
            @{ name = "fontItalic"; apply = { param($target, $value) $target.Font.Italic = [int]$value } },
            @{ name = "fontColor"; apply = { param($target, $value) $target.Font.Color.RGB = [int]$value } },
            @{ name = "fontUnderline"; apply = { param($target, $value) $target.Font.Underline = [int]$value } },
            @{ name = "fontSubscript"; apply = { param($target, $value) $target.Font.Subscript = [int]$value } },
            @{ name = "fontSuperscript"; apply = { param($target, $value) $target.Font.Superscript = [int]$value } },
            @{ name = "alignment"; apply = { param($target, $value) $target.ParagraphFormat.Alignment = [int]$value } }
        )) {
            $value = Get-ObjectPropertyValue $runSnapshot $entry.name
            if ($null -eq $value) { continue }
            try { & $entry.apply $run $value } catch { $errors += "$($entry.name):${start}:$($_.Exception.Message)" }
        }
        try {
            $run2 = $shape.TextFrame2.TextRange.Characters($start, $length)
            $fontStrike = Get-ObjectPropertyValue $runSnapshot "fontStrike"
            if ($null -ne $fontStrike) { $run2.Font.Strike = [int]$fontStrike }
            $characterSpacing = Get-ObjectPropertyValue $runSnapshot "characterSpacing"
            if ($null -ne $characterSpacing) { $run2.Font.Spacing = [double]$characterSpacing }
            $allCaps = Get-ObjectPropertyValue $runSnapshot "allCaps"
            if ($null -ne $allCaps) { $run2.Font.Allcaps = [int]$allCaps }
            $smallCaps = Get-ObjectPropertyValue $runSnapshot "smallCaps"
            if ($null -ne $smallCaps) { $run2.Font.Smallcaps = [int]$smallCaps }
        } catch { $errors += "textFrame2:${start}:$($_.Exception.Message)" }
    }
    return $errors
}

function Restore-PptCanonicalTextParagraphs($shape, $paragraphSnapshots) {
    $errors = @()
    foreach ($snapshot in @($paragraphSnapshots)) {
        $index = [int](Get-ObjectPropertyValue $snapshot "index")
        if ($index -lt 1) { continue }
        try {
            $format = $shape.TextFrame.TextRange.Paragraphs($index, 1).ParagraphFormat
            $format2 = $shape.TextFrame2.TextRange.Paragraphs($index, 1).ParagraphFormat
            foreach ($field in @("alignment", "spaceBefore", "spaceAfter", "lineSpacing")) {
                $value = Get-ObjectPropertyValue $snapshot $field
                if ($null -eq $value) { continue }
                switch ($field) {
                    "alignment" { $format.Alignment = [int]$value }
                    "spaceBefore" { $format.SpaceBefore = [double]$value }
                    "spaceAfter" { $format.SpaceAfter = [double]$value }
                    "lineSpacing" { $format.SpaceWithin = [double]$value }
                }
            }
            $bullet = Get-ObjectPropertyValue $snapshot "bullet"
            if ($null -ne $bullet) {
                $kind = [string](Get-ObjectPropertyValue $bullet "kind")
                if ($kind -eq "none") {
                    $format.Bullet.Visible = 0
                } elseif ($kind -eq "number") {
                    $format.Bullet.Visible = -1
                    $format.Bullet.Type = 2
                    $startAt = Get-ObjectPropertyValue $bullet "startAt"
                    if ($null -ne $startAt) { $format.Bullet.StartValue = [int]$startAt }
                } else {
                    $format.Bullet.Visible = -1
                    $format.Bullet.Type = 1
                    $character = [string](Get-ObjectPropertyValue $bullet "character")
                    if (-not [string]::IsNullOrEmpty($character)) { $format.Bullet.Character = [int][char]$character[0] }
                }
            }
            # WPS may reset paragraph indents when bullet state changes, so restore indents last.
            foreach ($field in @("leftIndent", "rightIndent", "firstLineIndent")) {
                $value = Get-ObjectPropertyValue $snapshot $field
                if ($null -eq $value) { continue }
                $nativeField = $field.Substring(0, 1).ToUpperInvariant() + $field.Substring(1)
                $format2.$nativeField = [double]$value
            }
        } catch { $errors += "paragraph:${index}:$($_.Exception.Message)" }
    }
    return $errors
}

function Get-PptShapeTextInfo($shape, [int]$previewLimit = 120) {
    $text = ""
    $hasText = $false
    $textCapable = $false
    $fontSize = $null
    $fontName = $null
    $fontBold = $null
    $fontItalic = $null
    $fontColor = $null
    $fontColorHex = $null
    $alignment = $null
    $verticalAnchor = $null
    $marginLeft = $null
    $marginRight = $null
    $marginTop = $null
    $marginBottom = $null
    $canonicalFrame = @{}
    $textFormatting = [ordered]@{ formatState = "unknown"; propertyStates = [ordered]@{}; runs = @() }
    try {
        $textCapable = [bool]($shape.HasTextFrame -ne 0)
        if ($textCapable -and $shape.TextFrame.HasText) {
            $hasText = $true
            $textRange = $shape.TextFrame.TextRange
            $text = [string]$textRange.Text
            $textFormatting = Get-PptTextFormattingSnapshot $textRange $shape
            try { $fontSize = [double]$textRange.Font.Size } catch {}
            try { $fontName = [string]$textRange.Font.Name } catch {}
            try {
                $rawBold = [int]$textRange.Font.Bold
                if ($rawBold -ne -2) { $fontBold = [bool]($rawBold -ne 0) }
            } catch {}
            try {
                $rawItalic = [int]$textRange.Font.Italic
                if ($rawItalic -ne -2) { $fontItalic = [bool]($rawItalic -ne 0) }
            } catch {}
            try {
                $fontColor = [int]$textRange.Font.Color.RGB
                $fontColorHex = Convert-RgbIntToHex $fontColor
            } catch {}
            try { $alignment = [int]$textRange.ParagraphFormat.Alignment } catch {}
        }
    } catch {}
    if ($textCapable) {
        $canonicalFrame = Get-PptCanonicalTextFrame $shape
        if ($hasText) {
            $verticalAnchor = Get-ObjectPropertyValue $canonicalFrame "verticalAnchor"
            $marginLeft = Get-ObjectPropertyValue $canonicalFrame "marginLeft"
            $marginRight = Get-ObjectPropertyValue $canonicalFrame "marginRight"
            $marginTop = Get-ObjectPropertyValue $canonicalFrame "marginTop"
            $marginBottom = Get-ObjectPropertyValue $canonicalFrame "marginBottom"
        }
    }
    $propertyStates = Get-ObjectPropertyValue $textFormatting "propertyStates"
    if ((Get-ObjectPropertyValue $propertyStates "fontSize") -eq "mixed") { $fontSize = $null }
    if ((Get-ObjectPropertyValue $propertyStates "fontName") -eq "mixed") { $fontName = $null }
    if ((Get-ObjectPropertyValue $propertyStates "fontBold") -eq "mixed") { $fontBold = $null }
    if ((Get-ObjectPropertyValue $propertyStates "fontItalic") -eq "mixed") { $fontItalic = $null }
    if ((Get-ObjectPropertyValue $propertyStates "fontColor") -eq "mixed") { $fontColor = $null; $fontColorHex = $null }
    if ((Get-ObjectPropertyValue $propertyStates "alignment") -eq "mixed") { $alignment = $null }
    $textLength = $text.Length
    $preview = $text
    $truncated = $false
    if ($previewLimit -gt 0 -and $textLength -gt $previewLimit) {
        $preview = $text.Substring(0, $previewLimit)
        $truncated = $true
    }
    $textFit = if ($hasText) {
        Test-PptShapeTextOverflow $shape
    } else {
        @{ overflow = $false; boundHeight = 0; availableHeight = [double]$shape.Height }
    }
    return @{
        textCapable = $textCapable
        hasText = $hasText
        text = $text
        textLength = $textLength
        textPreview = $preview
        textPreviewTruncated = $truncated
        textTruncated = $truncated
        textOverflow = [bool]$textFit.overflow
        textFit = $textFit
        runs = [object[]]$(if ($hasText) { @(Convert-PptFormattingSnapshotToCanonicalTextRuns $textFormatting) } else { @(Get-PptCanonicalTextRuns $shape) })
        paragraphs = [object[]]$(if ($textCapable) { @(Get-PptCanonicalTextParagraphs $shape) } else { @() })
        frame = $canonicalFrame
        style = @{
            formatState = [string](Get-ObjectPropertyValue $textFormatting "formatState")
            propertyStates = $propertyStates
            fontSize = $fontSize
            fontName = $fontName
            bold = $fontBold
            italic = $fontItalic
            fontColor = $fontColor
            fontColorHex = $fontColorHex
            alignment = $alignment
            verticalAnchor = $verticalAnchor
            marginLeft = $marginLeft
            marginRight = $marginRight
            marginTop = $marginTop
            marginBottom = $marginBottom
        }
    }
}

function New-PptRecoverableError([string]$code, [string]$message, $details = @{}) {
    return @{
        success = $false
        error = $message
        data = @{
            code = $code
            recoverable = $true
            details = $details
        }
    }
}

function Resolve-PptSlide($pres, $slideIndex, [string]$actionName) {
    $count = 0
    try { $count = [int]$pres.Slides.Count } catch {}
    $index = if ($slideIndex) { [int]$slideIndex } else { 1 }
    if ($index -lt 1 -or $index -gt $count) {
        $range = if ($count -gt 0) { "1..$count" } else { "empty" }
        return @{
            ok = $false
            result = (New-PptRecoverableError `
                "PPT_SLIDE_INDEX_OUT_OF_RANGE" `
                "$actionName failed: slideIndex=$index is out of range. Current slide range: $range. Suggestion: call wps_ppt_get_slide_count or wps_ppt_get_open_presentations, then retry with a valid slideIndex." `
                @{ requestedSlideIndex = $index; slideCount = $count; validRange = $range; suggestedAction = "get_slide_count_then_retry" })
        }
    }
    return @{ ok = $true; slideIndex = $index; slide = $pres.Slides.Item($index) }
}

function Resolve-PptSlideBinding($pres, $slideIndex, $nativeSlideId, [string]$actionName) {
    $expectedNativeSlideId = [string]$nativeSlideId
    if (-not [string]::IsNullOrWhiteSpace($expectedNativeSlideId)) {
        for ($index = 1; $index -le $pres.Slides.Count; $index++) {
            $slide = $pres.Slides.Item($index)
            $actualNativeSlideId = ""
            try { $actualNativeSlideId = [string]$slide.SlideID } catch {}
            if ($actualNativeSlideId -eq $expectedNativeSlideId) {
                return @{ ok = $true; slideIndex = $index; slide = $slide; reboundByNativeSlideId = ($index -ne [int]$slideIndex) }
            }
        }
        return @{
            ok = $false
            result = (New-PptRecoverableError `
                "PPT_SLIDE_BINDING_STALE" `
                "$actionName failed: nativeSlideId=$expectedNativeSlideId no longer exists in the bound presentation." `
                @{ requestedSlideIndex = $slideIndex; nativeSlideId = $expectedNativeSlideId })
        }
    }
    return Resolve-PptSlide $pres $slideIndex $actionName
}

function Resolve-PptShape($slide, $target, [string]$actionName, [string]$targetKind = "shape") {
    $shapeCount = 0
    try { $shapeCount = [int]$slide.Shapes.Count } catch {}
    if ($null -eq $target -or [string]::IsNullOrWhiteSpace([string]$target)) {
        $range = if ($shapeCount -gt 0) { "1..$shapeCount" } else { "empty" }
        return @{
            ok = $false
            result = (New-PptRecoverableError `
                "PPT_SHAPE_TARGET_MISSING" `
                "$actionName failed: missing $targetKind target. Current shape range: $range. Suggestion: call wps_ppt_get_shapes or wps_ppt_get_textboxes, then retry with name/shapeName or shapeIndex." `
                @{ shapeCount = $shapeCount; validShapeIndexRange = $range; suggestedAction = "get_shapes_then_retry" })
        }
    }
    $nativeShapeId = Get-ObjectPropertyValue $target "nativeShapeId"
    $expectedShapeName = [string](Get-ObjectPropertyValue $target "expectedShapeName")
    $shapeIndexFallback = Get-ObjectPropertyValue $target "shapeIndexFallback"
    $groupPath = @(
        (Get-ObjectPropertyValue $target "groupPath") |
            Where-Object { $null -ne $_ }
    )
    if ($groupPath.Count -gt 0) {
        if ($groupPath.Count -lt 2) {
            return @{
                ok = $false
                result = (New-PptRecoverableError "PPT_GROUP_PATH_INVALID" "$actionName failed: a Group member path must include the top-level Group index and at least one member index." @{ groupPath = $groupPath })
            }
        }
        try {
            $rootIndex = [int]$groupPath[0]
            if ($rootIndex -lt 1 -or $rootIndex -gt $shapeCount) { throw "root index is out of range" }
            $shape = $slide.Shapes.Item($rootIndex)
            for ($pathIndex = 1; $pathIndex -lt $groupPath.Count; $pathIndex++) {
                $memberIndex = [int]$groupPath[$pathIndex]
                if ([int]$shape.Type -ne 6) { throw "path segment $pathIndex does not resolve through a Group" }
                if ($memberIndex -lt 1 -or $memberIndex -gt [int]$shape.GroupItems.Count) { throw "member index $memberIndex is out of range" }
                $shape = $shape.GroupItems.Item($memberIndex)
            }
            $actualNativeShapeId = $(try { [int]$shape.Id } catch { $null })
            if ($null -ne $nativeShapeId -and [string]$actualNativeShapeId -ne [string]$nativeShapeId) {
                throw "resolved member native shape id '$actualNativeShapeId' does not match '$nativeShapeId'"
            }
            if (-not [string]::IsNullOrWhiteSpace($expectedShapeName) -and [string]$shape.Name -ne $expectedShapeName) {
                throw "resolved member name '$([string]$shape.Name)' does not match '$expectedShapeName'"
            }
            return @{
                ok = $true
                shape = $shape
                target = $target
                nativeShapeId = $actualNativeShapeId
                shapeIndex = $rootIndex
                groupPath = @($groupPath | ForEach-Object { [int]$_ })
            }
        } catch {
            return @{
                ok = $false
                result = (New-PptRecoverableError "PPT_GROUP_MEMBER_BINDING_STALE" "$actionName failed: frozen Group member path no longer resolves to the captured object." @{ groupPath = $groupPath; nativeShapeId = $nativeShapeId; expectedShapeName = $expectedShapeName; cause = $_.Exception.Message })
            }
        }
    }
    $hasFrozenBinding = $null -ne $nativeShapeId -or -not [string]::IsNullOrWhiteSpace($expectedShapeName) -or $null -ne $shapeIndexFallback
    if ($hasFrozenBinding) {
        if ($null -ne $nativeShapeId) {
            $nativeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
            if ($null -eq $nativeIndex) {
                return @{
                    ok = $false
                    result = (New-PptRecoverableError "PPT_SHAPE_BINDING_STALE" "$actionName failed: native shape id '$nativeShapeId' no longer exists." @{ nativeShapeId = $nativeShapeId; expectedShapeName = $expectedShapeName })
                }
            }
            $shape = $slide.Shapes.Item([int]$nativeIndex)
            if (-not [string]::IsNullOrWhiteSpace($expectedShapeName) -and [string]$shape.Name -ne $expectedShapeName) {
                return @{
                    ok = $false
                    result = (New-PptRecoverableError "PPT_SHAPE_BINDING_STALE" "$actionName failed: native shape id '$nativeShapeId' resolved to an unexpected name." @{ nativeShapeId = $nativeShapeId; expectedShapeName = $expectedShapeName; actualShapeName = [string]$shape.Name })
                }
            }
            return @{ ok = $true; shape = $shape; target = $target; nativeShapeId = [int]$nativeShapeId; shapeIndex = [int]$nativeIndex }
        }
        if (-not [string]::IsNullOrWhiteSpace($expectedShapeName)) {
            $nameMatches = @()
            for ($i = 1; $i -le $shapeCount; $i++) {
                try {
                    if ([string]$slide.Shapes.Item($i).Name -eq $expectedShapeName) { $nameMatches += $i }
                } catch {}
            }
            if ($nameMatches.Count -ne 1) {
                return @{
                    ok = $false
                    result = (New-PptRecoverableError $(if ($nameMatches.Count -gt 1) { "PPT_SHAPE_NAME_AMBIGUOUS" } else { "PPT_SHAPE_BINDING_STALE" }) "$actionName failed: expected shape name '$expectedShapeName' resolved to $($nameMatches.Count) objects." @{ expectedShapeName = $expectedShapeName; matchCount = $nameMatches.Count })
                }
            }
            $shape = $slide.Shapes.Item([int]$nameMatches[0])
            return @{ ok = $true; shape = $shape; target = $target; nativeShapeId = $(try { [int]$shape.Id } catch { $null }); shapeIndex = [int]$nameMatches[0] }
        }
        if ($null -ne $shapeIndexFallback) {
            try {
                $shape = $slide.Shapes.Item([int]$shapeIndexFallback)
                return @{ ok = $true; shape = $shape; target = $target; nativeShapeId = $(try { [int]$shape.Id } catch { $null }); shapeIndex = [int]$shapeIndexFallback }
            } catch {}
        }
    }
    try {
        $shape = $slide.Shapes.Item($target)
        return @{ ok = $true; shape = $shape; target = $target; nativeShapeId = $(try { [int]$shape.Id } catch { $null }); shapeIndex = $(Get-PptShapeIndexByNativeId $slide $(try { [int]$shape.Id } catch { $null })) }
    } catch {
        $names = @()
        for ($i = 1; $i -le [Math]::Min($shapeCount, 20); $i++) {
            try { $names += $slide.Shapes.Item($i).Name } catch {}
        }
        $range = if ($shapeCount -gt 0) { "1..$shapeCount" } else { "empty" }
        return @{
            ok = $false
            result = (New-PptRecoverableError `
                "PPT_SHAPE_TARGET_NOT_FOUND" `
                "$actionName failed: $targetKind target '$target' was not found. Current shape range: $range. Suggestion: call wps_ppt_get_shapes or wps_ppt_get_textboxes and retry with an existing name/shapeName/shapeIndex." `
                @{ requestedTarget = $target; shapeCount = $shapeCount; validShapeIndexRange = $range; knownShapeNames = $names; suggestedAction = "get_shapes_then_retry" })
        }
    }
}

function Get-PptShapeSummary($shape, [int]$index, [int]$textPreviewLimit = 120) {
    $autoShapeType = $null
    $placeholderType = $null
    $fillColor = $null
    $fillColorHex = $null
    $fillVisible = $null
    $fillTransparency = $null
    $lineColor = $null
    $lineColorHex = $null
    $lineTransparency = $null
    $lineDashStyle = $null
    $lineVisible = $null
    $lineWeight = $null
    $visible = $null
    $locked = $null
    try { $autoShapeType = $shape.AutoShapeType } catch {}
    try { $placeholderType = $shape.PlaceholderFormat.Type } catch {}
    try {
        $fillColor = [int]$shape.Fill.ForeColor.RGB
        $fillColorHex = Convert-RgbIntToHex $fillColor
    } catch {}
    try { $fillVisible = [bool]($shape.Fill.Visible -ne 0) } catch {}
    try { $fillTransparency = [double]$shape.Fill.Transparency } catch {}
    try {
        $lineColor = [int]$shape.Line.ForeColor.RGB
        $lineColorHex = Convert-RgbIntToHex $lineColor
    } catch {}
    try { $lineTransparency = [double]$shape.Line.Transparency } catch {}
    try { $lineDashStyle = [int]$shape.Line.DashStyle } catch {}
    try { $lineVisible = [bool]($shape.Line.Visible -ne 0) } catch {}
    try { $lineWeight = [double]$shape.Line.Weight } catch {}
    try { $visible = [bool]($shape.Visible -ne 0) } catch {}
    try { $locked = [bool]($shape.Locked -ne 0) } catch {}
    $textInfo = Get-PptShapeTextInfo $shape $textPreviewLimit
    return @{
        name = $shape.Name
        index = $index
        type = Convert-PptShapeTypeToName $shape.Type
        typeCode = $shape.Type
        autoShapeType = $autoShapeType
        autoShapeTypeName = Convert-PptAutoShapeTypeToName $autoShapeType
        placeholderType = $placeholderType
        placeholderTypeName = Convert-PptPlaceholderTypeToName $placeholderType
        left = $shape.Left
        top = $shape.Top
        width = $shape.Width
        height = $shape.Height
        rotation = $(try { [double]$shape.Rotation } catch { 0 })
        visible = $visible
        locked = $locked
        fillColor = $fillColor
        fillColorHex = $fillColorHex
        textCapable = $textInfo.textCapable
        hasText = $textInfo.hasText
        text = $textInfo.text
        textLength = $textInfo.textLength
        textPreview = $textInfo.textPreview
        textPreviewTruncated = $textInfo.textPreviewTruncated
        textTruncated = $textInfo.textTruncated
        textOverflow = $textInfo.textOverflow
        textFit = $textInfo.textFit
        textRuns = $textInfo.runs
        textParagraphs = $textInfo.paragraphs
        textFrame = $textInfo.frame
        style = @{
            fill = @{
                visible = $fillVisible
                color = $fillColor
                colorHex = $fillColorHex
                transparency = $fillTransparency
            }
            line = @{
                visible = $lineVisible
                color = $lineColor
                colorHex = $lineColorHex
                transparency = $lineTransparency
                width = $lineWeight
                dashStyle = $(if ($lineDashStyle -eq 1) { "solid" } elseif ($lineDashStyle -eq 4) { "dash" } else { $lineDashStyle })
            }
            text = $textInfo.style
        }
    }
}

function Get-PptGroupMemberObjects(
    $groupShape,
    [int]$slideIndex,
    [bool]$presentationReadOnly = $false,
    [bool]$presentationProtectMode = $false,
    [bool]$includeLink = $false
) {
    $members = @()
    $memberCount = 0
    try { $memberCount = [int]$groupShape.GroupItems.Count } catch {}
    for ($memberIndex = 1; $memberIndex -le $memberCount; $memberIndex++) {
        try {
            $member = $groupShape.GroupItems.Item($memberIndex)
            $memberObject = Get-PptUnifiedObject `
                $member `
                $slideIndex `
                $memberIndex `
                $true `
                $presentationReadOnly `
                $presentationProtectMode `
                $includeLink
            $memberObject["isGroupMember"] = $true
            $members += $memberObject
        } catch {}
    }
    return @($members)
}

function Get-PptUnifiedObject(
    $shape,
    [int]$slideIndex,
    [int]$shapeIndex,
    [bool]$includeContent = $false,
    [bool]$presentationReadOnly = $false,
    [bool]$presentationProtectMode = $false,
    [bool]$includeLink = $false
) {
    $summary = Get-PptShapeSummary $shape $shapeIndex 160
    $shapeId = "slide:${slideIndex}:shape:${shapeIndex}"
    $typeName = [string]$summary.type
    $placeholderTypeName = $summary.placeholderTypeName
    $kind = $typeName
    $role = $typeName
    $zOrder = $null
    $isConnector = $false
    $hasTable = $false
    $tableInfo = $null
    $imageInfo = $null
    $chartInfo = $null
    $graphicInfo = $null
    $groupInfo = $null
    $connectorInfo = $null
    $linkInfo = $null

    try { $zOrder = [int]$shape.ZOrderPosition } catch {}
    try { $isConnector = [bool]($shape.Connector -ne 0) } catch {}
    try { $hasTable = [bool]$shape.HasTable } catch {}

    if ($hasTable) {
        $kind = "table"
        $role = "table"
        $rows = 0
        $columns = 0
        $cells = @()
        try { $rows = [int]$shape.Table.Rows.Count } catch {}
        try { $columns = [int]$shape.Table.Columns.Count } catch {}
        if ($includeContent) {
            for ($r = 1; $r -le $rows; $r++) {
                for ($c = 1; $c -le $columns; $c++) {
                    $cellText = ""
                    try { $cellText = [string]$shape.Table.Cell($r, $c).Shape.TextFrame.TextRange.Text } catch {}
                    $cellShape = $shape.Table.Cell($r, $c).Shape
                    $cells += @{
                        row = $r
                        col = $c
                        text = $cellText
                        left = $(try { [double]$cellShape.Left } catch { $null })
                        top = $(try { [double]$cellShape.Top } catch { $null })
                        width = $(try { [double]$cellShape.Width } catch { $null })
                        height = $(try { [double]$cellShape.Height } catch { $null })
                        style = @{
                            fillColor = $(try { Convert-RgbIntToHex ([int]$cellShape.Fill.ForeColor.RGB) } catch { $null })
                            fontColor = $(try { Convert-RgbIntToHex ([int]$cellShape.TextFrame.TextRange.Font.Color.RGB) } catch { $null })
                            fontName = $(try { [string]$cellShape.TextFrame.TextRange.Font.Name } catch { $null })
                            fontSize = $(try { [double]$cellShape.TextFrame.TextRange.Font.Size } catch { $null })
                            bold = $(try { [bool]([int]$cellShape.TextFrame.TextRange.Font.Bold -ne 0) } catch { $null })
                            alignment = $(try {
                                $alignment = [int]$cellShape.TextFrame.TextRange.ParagraphFormat.Alignment
                                if ($alignment -eq 2) { "center" } elseif ($alignment -eq 3) { "right" } else { "left" }
                            } catch { $null })
                            paragraph = Get-PptTableCellParagraph $cellShape
                            borders = Get-PptTableCellBorders $shape.Table.Cell($r, $c)
                        }
                    }
                }
            }
        }
        $tableInfo = @{
            tableShapeId = $shapeId
            tableName = $shape.Name
            rows = $rows
            columns = $columns
            cells = $cells
            rowHeights = @(1..$rows | ForEach-Object { [double]$shape.Table.Rows.Item($_).Height })
            columnWidths = @(1..$columns | ForEach-Object { [double]$shape.Table.Columns.Item($_).Width })
        }
    } elseif ($typeName -eq "placeholder") {
        if ($placeholderTypeName -eq "title" -or $placeholderTypeName -eq "centerTitle" -or $placeholderTypeName -eq "verticalTitle") {
            $kind = "title"
            $role = "title"
        } elseif ($placeholderTypeName -eq "subtitle") {
            $kind = "subtitle"
            $role = "subtitle"
        } else {
            $kind = "placeholder"
            $role = if ($placeholderTypeName) { $placeholderTypeName } else { "placeholder" }
        }
    } elseif ($typeName -eq "textBox") {
        $kind = "textbox"
        $role = "textbox"
    } elseif ($typeName -eq "picture" -or $typeName -eq "linkedPicture") {
        $kind = "picture"
        $role = "picture"
        $sourcePath = $null
        try { $sourcePath = [string]$shape.LinkFormat.SourceFullName } catch {}
        $imageInfo = @{
            sourcePath = $sourcePath
            linked = [bool]($typeName -eq "linkedPicture" -or $sourcePath)
            colorMode = $(try {
                $colorType = [int]$shape.PictureFormat.ColorType
                if ($colorType -eq 1) { "automatic" } elseif ($colorType -eq 2) { "grayscale" } else { $colorType }
            } catch { $null })
            crop = @{
                left = $(try { [double]$shape.PictureFormat.CropLeft } catch { $null })
                top = $(try { [double]$shape.PictureFormat.CropTop } catch { $null })
                right = $(try { [double]$shape.PictureFormat.CropRight } catch { $null })
                bottom = $(try { [double]$shape.PictureFormat.CropBottom } catch { $null })
            }
        }
    } elseif ($typeName -eq "chart") {
        $kind = "chart"
        $role = "chart"
        $chartType = $null
        $hasTitle = $false
        $title = ""
        $hasLegend = $false
        $seriesCount = $null
        try { $chartType = [int]$shape.Chart.ChartType } catch {}
        try { $hasTitle = [bool]$shape.Chart.HasTitle } catch {}
        if ($hasTitle) { try { $title = [string]$shape.Chart.ChartTitle.Text } catch {} }
        try { $hasLegend = [bool]$shape.Chart.HasLegend } catch {}
        try { $seriesCount = [int]$shape.Chart.SeriesCollection().Count } catch {}
        $chartInfo = @{
            hasChart = $true
            chartType = $chartType
            chartTypeName = Convert-PptChartTypeToName $chartType
            hasTitle = $hasTitle
            title = $title
            hasLegend = $hasLegend
            legendPosition = $(if ($hasLegend) {
                try {
                    $position = [int]$shape.Chart.Legend.Position
                    if ($position -eq -4160) { "top" } elseif ($position -eq -4152) { "right" } elseif ($position -eq -4107) { "bottom" } elseif ($position -eq -4131) { "left" } else { $position }
                } catch { $null }
            } else { $null })
            seriesCount = $seriesCount
            axes = @(Get-PptChartAxesSnapshot $shape.Chart)
            series = @(Get-PptChartSeriesSnapshot $shape.Chart)
        }
    } elseif ($typeName -eq "graphic" -or $typeName -eq "linkedGraphic") {
        $kind = if ($typeName -eq "linkedGraphic") { "linkedGraphic" } else { "graphic" }
        $role = "graphic"
        $sourcePath = $null
        try { $sourcePath = [string]$shape.LinkFormat.SourceFullName } catch {}
        $graphicInfo = @{
            embedded = [bool]($typeName -eq "graphic")
            linked = [bool]($typeName -eq "linkedGraphic")
            sourcePath = $sourcePath
        }
    } elseif ($typeName -eq "group") {
        $kind = "group"
        $role = "group"
        $groupMembers = @(
            Get-PptGroupMemberObjects `
                $shape `
                $slideIndex `
                $presentationReadOnly `
                $presentationProtectMode `
                $includeLink
        )
        $groupInfo = @{
            memberCount = $groupMembers.Count
            members = $groupMembers
        }
    } elseif ($typeName -eq "line" -or $isConnector) {
        $kind = "connector"
        $role = "connector"
        $beginConnectedShapeId = $null
        $endConnectedShapeId = $null
        $beginConnected = $false
        $endConnected = $false
        try { $beginConnected = [bool]($shape.ConnectorFormat.BeginConnected -ne 0) } catch {}
        try { $endConnected = [bool]($shape.ConnectorFormat.EndConnected -ne 0) } catch {}
        if ($beginConnected) {
            try { $beginConnectedShapeId = [int]$shape.ConnectorFormat.BeginConnectedShape.Id } catch {}
        }
        if ($endConnected) {
            try { $endConnectedShapeId = [int]$shape.ConnectorFormat.EndConnectedShape.Id } catch {}
        }
        $connectorInfo = @{
            connectorType = $(try { [int]$shape.ConnectorFormat.Type } catch { $null })
            routeType = $(try {
                $connectorType = [int]$shape.ConnectorFormat.Type
                if ($connectorType -eq 1) { "straight" } elseif ($connectorType -eq 2) { "elbow" } else { $connectorType }
            } catch { $null })
            beginConnected = $beginConnected
            endConnected = $endConnected
            beginConnectedShapeId = $beginConnectedShapeId
            endConnectedShapeId = $endConnectedShapeId
            beginConnectionSite = $(try { [int]$shape.ConnectorFormat.BeginConnectionSite } catch { $null })
            endConnectionSite = $(try { [int]$shape.ConnectorFormat.EndConnectionSite } catch { $null })
            beginArrow = $(try { [int]$shape.Line.BeginArrowheadStyle } catch { $null })
            endArrow = $(try { [int]$shape.Line.EndArrowheadStyle } catch { $null })
        }
    } elseif ($summary.hasText) {
        $kind = "textbox"
        $role = "text"
    }

    if ($includeLink) {
        try {
            $linkSetting = $shape.ActionSettings.Item(1)
            $linkAction = [int]$linkSetting.Action
            $linkAddress = $(try { [string]$linkSetting.Hyperlink.Address } catch { "" })
            $linkSubAddress = $(try { [string]$linkSetting.Hyperlink.SubAddress } catch { "" })
            if ($linkAction -eq 7 -or -not [string]::IsNullOrWhiteSpace($linkAddress) -or -not [string]::IsNullOrWhiteSpace($linkSubAddress)) {
                $linkInfo = @{
                    action = $linkAction
                    destinationKind = $(if (-not [string]::IsNullOrWhiteSpace($linkAddress)) { "externalUrl" } elseif (-not [string]::IsNullOrWhiteSpace($linkSubAddress)) { "internal" } else { "unknown" })
                    address = $linkAddress
                    subAddress = $linkSubAddress
                }
            }
        } catch {}
    }

    $obj = @{
        objectId = $shapeId
        shapeId = $shapeId
        nativeShapeId = $(try { [int]$shape.Id } catch { $null })
        shapeIndex = $shapeIndex
        zOrder = $zOrder
        visible = $summary.visible
        nativeLocked = $summary.locked
        locked = [bool]($presentationProtectMode -and $summary.locked)
        readOnly = [bool]$presentationReadOnly
        name = $shape.Name
        shapeName = $shape.Name
        kind = $kind
        role = $role
        type = $summary.type
        typeCode = $summary.typeCode
        autoShapeType = $summary.autoShapeType
        autoShapeTypeName = $summary.autoShapeTypeName
        placeholderType = $summary.placeholderType
        placeholderTypeName = $summary.placeholderTypeName
        bounds = @{
            left = $summary.left
            top = $summary.top
            width = $summary.width
            height = $summary.height
            rotation = $summary.rotation
        }
        fillColorHex = $summary.fillColorHex
        style = $summary.style
        hasText = $summary.hasText
        textCapable = $summary.textCapable
        textPreview = $summary.textPreview
        textLength = $summary.textLength
        textPreviewTruncated = $summary.textPreviewTruncated
        textTruncated = $summary.textTruncated
        textOverflow = $summary.textOverflow
        textFit = $summary.textFit
        textRuns = $summary.textRuns
        textParagraphs = $summary.textParagraphs
        textFrame = $summary.textFrame
    }
    if ($includeContent) { $obj["text"] = $summary.text }
    if ($null -ne $tableInfo) { $obj["table"] = $tableInfo; $obj["tableShapeId"] = $shapeId }
    if ($null -ne $imageInfo) { $obj["image"] = $imageInfo }
    if ($null -ne $chartInfo) { $obj["chart"] = $chartInfo }
    if ($null -ne $graphicInfo) { $obj["graphic"] = $graphicInfo }
    if ($null -ne $groupInfo) { $obj["group"] = $groupInfo }
    if ($null -ne $connectorInfo) { $obj["connector"] = $connectorInfo }
    if ($null -ne $linkInfo) { $obj["link"] = $linkInfo }
    $componentDescriptor = Get-PptComponentDescriptor ([string]$shape.Name)
    if ($null -ne $componentDescriptor) {
        $obj["component"] = @{
            componentId = [string]$componentDescriptor.componentId
            componentType = [string]$componentDescriptor.componentType
            part = [string]$componentDescriptor.part
            itemId = [string]$componentDescriptor.itemId
            contentBlockId = [string]$componentDescriptor.contentBlockId
        }
    }
    return $obj
}

function Get-PptShapeIndexByNativeId($slide, $nativeShapeId) {
    if ($null -eq $nativeShapeId) { return $null }
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        try {
            if ([int]$slide.Shapes.Item($i).Id -eq [int]$nativeShapeId) { return $i }
        } catch {}
    }
    return $null
}

function Find-PptShapeByNativeIdRecursive($shapes, $nativeShapeId) {
    if ($null -eq $shapes -or $null -eq $nativeShapeId) { return $null }
    $count = 0
    try { $count = [int]$shapes.Count } catch { return $null }
    for ($index = 1; $index -le $count; $index++) {
        $shape = $shapes.Item($index)
        $actualId = $(try { [int]$shape.Id } catch { $null })
        if ($null -ne $actualId -and [string]$actualId -eq [string]$nativeShapeId) {
            return $shape
        }
        try {
            if ([int]$shape.Type -eq 6) {
                $nested = Find-PptShapeByNativeIdRecursive $shape.GroupItems $nativeShapeId
                if ($null -ne $nested) { return $nested }
            }
        } catch {}
    }
    return $null
}

function Copy-PptShapeAndResolveClone($slide, $sourceShape) {
    $existingNativeIds = @{}
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
        $existingShape = $slide.Shapes.Item($shapeIndex)
        try { $existingNativeIds[[string][int]$existingShape.Id] = $true } catch {}
    }

    $sourceShape.Copy()
    $null = $slide.Shapes.Paste()

    $createdShapes = @()
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
        $candidate = $slide.Shapes.Item($shapeIndex)
        $candidateNativeId = $null
        try { $candidateNativeId = [int]$candidate.Id } catch {}
        if ($null -ne $candidateNativeId -and -not $existingNativeIds.ContainsKey([string]$candidateNativeId)) {
            $createdShapes += $candidate
        }
    }
    if ($createdShapes.Count -ne 1) {
        throw "PPT_DUPLICATE_PASTE_IDENTITY_AMBIGUOUS: expected=1, actual=$($createdShapes.Count)"
    }
    return $createdShapes[0]
}

function Get-PptComponentDescriptor([string]$shapeName) {
    $value = [string]$shapeName
    if ($value -match '^(R[0-9]+_(.+?)_([0-9]+))(__CB_[a-zA-Z0-9-]+)_(.+)$') {
        $layoutComponentId = [string]$Matches[1]
        $componentType = [string]$Matches[2]
        $componentIndex = [int]$Matches[3]
        $contentBlockSuffix = [string]$Matches[4]
        $rawPart = [string]$Matches[5]
        $itemId = ""
        if ($rawPart -match '^(.+)__ITEM_([a-zA-Z0-9-]+)$') { $rawPart = [string]$Matches[1]; $itemId = [string]$Matches[2] }
        return @{
            componentId = $layoutComponentId + $contentBlockSuffix
            layoutComponentId = $layoutComponentId
            contentBlockId = $contentBlockSuffix.Substring(5)
            componentType = $componentType
            componentIndex = $componentIndex
            part = $rawPart
            itemId = $itemId
        }
    }
    if ($value -match '^(R[0-9]+_(.+?)_([0-9]+))_(.+)$') {
        $layoutComponentId = [string]$Matches[1]
        $componentType = [string]$Matches[2]
        $componentIndex = [int]$Matches[3]
        $rawPart = [string]$Matches[4]
        $itemId = ""
        if ($rawPart -match '^(.+)__ITEM_([a-zA-Z0-9-]+)$') { $rawPart = [string]$Matches[1]; $itemId = [string]$Matches[2] }
        return @{
            componentId = $layoutComponentId
            layoutComponentId = $layoutComponentId
            componentType = $componentType
            componentIndex = $componentIndex
            part = $rawPart
            itemId = $itemId
        }
    }
    return $null
}

function Get-PptCanonicalComponentPart($obj) {
    $component = Get-ObjectPropertyValue $obj "component"
    $part = if ($null -ne $component) { [string](Get-ObjectPropertyValue $component "part") } else { "" }
    if ($part -match '(^|_)(bg|band|background)($|_)') { return "background" }
    if ($part -match '(^|_)(accent|rule|strip)($|_)') { return "decoration" }
    foreach ($candidate in @("subtitle", "caption", "title", "body", "label", "value", "note")) {
        if ($part -match "(^|_)$candidate($|_)") { return $candidate }
    }
    if ([bool](Get-ObjectPropertyValue $obj "hasText")) { return "text" }
    return $part
}

function Resolve-PptRuntimeComponentInstances($objects) {
    $rawGroups = @{}
    $diagnostics = @()
    foreach ($obj in @($objects)) {
        $component = Get-ObjectPropertyValue $obj "component"
        if ($null -eq $component) { continue }
        $rawId = [string](Get-ObjectPropertyValue $component "componentId")
        if ([string]::IsNullOrWhiteSpace($rawId)) { continue }
        if (-not $rawGroups.ContainsKey($rawId)) { $rawGroups[$rawId] = @() }
        $rawGroups[$rawId] += $obj
    }

    foreach ($rawId in @($rawGroups.Keys)) {
        $members = @($rawGroups[$rawId])
        $anchors = @($members | Where-Object { (Get-PptCanonicalComponentPart $_) -eq "background" } | Sort-Object { [int]$_.shapeIndex })
        if ($anchors.Count -le 1) {
            foreach ($member in $members) {
                $component = Get-ObjectPropertyValue $member "component"
                $component["rawComponentId"] = $rawId
                $component["componentInstanceId"] = $rawId
                $component["identitySource"] = "shape_name"
            }
            continue
        }

        $anchorRecords = @($anchors | ForEach-Object {
            $nativeId = Get-ObjectPropertyValue $_ "nativeShapeId"
            $identitySuffix = if ($null -ne $nativeId) { "native-$nativeId" } else { "shape-$([int]$_.shapeIndex)" }
            @{
                object = $_
                instanceId = "$rawId@$identitySuffix"
                left = Get-PptBoundsNumber $_.bounds "left"
                top = Get-PptBoundsNumber $_.bounds "top"
                width = Get-PptBoundsNumber $_.bounds "width"
                height = Get-PptBoundsNumber $_.bounds "height"
            }
        })

        foreach ($member in $members) {
            $memberObjectId = [string](Get-ObjectPropertyValue $member "objectId")
            $anchor = @($anchorRecords | Where-Object { [string](Get-ObjectPropertyValue $_.object "objectId") -eq $memberObjectId })[0]
            $ambiguous = $false
            if ($null -eq $anchor) {
                $memberLeft = Get-PptBoundsNumber $member.bounds "left"
                $memberTop = Get-PptBoundsNumber $member.bounds "top"
                $memberWidth = Get-PptBoundsNumber $member.bounds "width"
                $memberHeight = Get-PptBoundsNumber $member.bounds "height"
                $memberCenterX = $memberLeft + ($memberWidth / 2)
                $memberCenterY = $memberTop + ($memberHeight / 2)
                $ranked = @($anchorRecords | ForEach-Object {
                    $centerX = $_.left + ($_.width / 2)
                    $centerY = $_.top + ($_.height / 2)
                    $inside = $memberCenterX -ge ($_.left - 2) -and $memberCenterX -le ($_.left + $_.width + 2) -and
                        $memberCenterY -ge ($_.top - 2) -and $memberCenterY -le ($_.top + $_.height + 2)
                    $distance = [Math]::Pow($memberCenterX - $centerX, 2) + [Math]::Pow($memberCenterY - $centerY, 2)
                    @{
                        anchor = $_
                        score = $distance + $(if ($inside) { 0 } else { 1000000000 })
                    }
                } | Sort-Object @{ Expression = { [double](Get-ObjectPropertyValue $_ "score") } }, @{ Expression = { [int](Get-ObjectPropertyValue (Get-ObjectPropertyValue (Get-ObjectPropertyValue $_ "anchor") "object") "shapeIndex") } })
                if ($ranked.Count -gt 0) { $anchor = Get-ObjectPropertyValue $ranked[0] "anchor" }
                $firstScore = if ($ranked.Count -gt 0) { [double](Get-ObjectPropertyValue $ranked[0] "score") } else { 0 }
                $secondScore = if ($ranked.Count -gt 1) { [double](Get-ObjectPropertyValue $ranked[1] "score") } else { 0 }
                if ($ranked.Count -gt 1 -and [Math]::Abs($firstScore - $secondScore) -lt 0.01) {
                    $ambiguous = $true
                    $diagnostics += @{
                        code = "PPT_COMPONENT_INSTANCE_AMBIGUOUS"
                        rawComponentId = $rawId
                        objectId = $memberObjectId
                        shapeIndex = [int]$member.shapeIndex
                        candidateInstanceIds = @($ranked | Where-Object { [Math]::Abs([double](Get-ObjectPropertyValue $_ "score") - $firstScore) -lt 0.01 } | ForEach-Object { [string](Get-ObjectPropertyValue (Get-ObjectPropertyValue $_ "anchor") "instanceId") })
                    }
                }
            }
            if ($null -eq $anchor) { continue }
            $component = Get-ObjectPropertyValue $member "component"
            $component["rawComponentId"] = $rawId
            $component["componentId"] = [string]$anchor.instanceId
            $component["componentInstanceId"] = [string]$anchor.instanceId
            $component["identitySource"] = "background_native_shape"
            if ($ambiguous) { $component["identityAmbiguous"] = $true }
        }
    }
    return $diagnostics
}

function Get-PptCurrentSlideSelection($ppt, $pres) {
    $slideIndex = $null
    $source = ""
    $viewType = $null
    $viewTypeName = "unknown"
    $window = $null
    try { $window = $pres.Windows.Item(1) } catch {}
    if ($null -eq $window) {
        try { $window = $ppt.ActiveWindow } catch {}
    }
    try {
        $viewType = [int]$window.ViewType
        $viewTypeName = switch ($viewType) {
            1 { "slide" }
            2 { "slide_sorter" }
            3 { "notes_page" }
            5 { "slide_show" }
            6 { "normal" }
            7 { "print_preview" }
            9 { "reading" }
            default { "view_type:$viewType" }
        }
    } catch {}
    try {
        $viewSlide = $window.View.Slide
        if ($null -ne $viewSlide) {
            $slideIndex = [int]$viewSlide.SlideIndex
            $source = "active_window_view"
        }
    } catch {}
    if ($null -eq $slideIndex) {
        try {
            $slideIndex = [int]$window.Selection.SlideRange.SlideIndex
            $source = "selection_slide_range"
        } catch {}
    }
    if ($null -eq $slideIndex) {
        try {
            $slideIndex = [int]$window.View.GotoSlide
            $source = "active_window_goto_slide"
        } catch {}
    }
    if ($null -eq $slideIndex -or $slideIndex -lt 1 -or $slideIndex -gt $pres.Slides.Count) {
        return @{ success = $false; error = "Unable to resolve the current PPT slide from ActiveWindow.View or Selection.SlideRange." }
    }

    $selectionType = $null
    $selectionTypeName = "unknown"
    $selectedShapeIndexes = @()
    try {
        $selection = $window.Selection
        $selectionType = [int]$selection.Type
        $selectionTypeName = switch ($selectionType) {
            0 { "none" }
            1 { "slides" }
            2 { "shapes" }
            3 { "text" }
            default { "unknown" }
        }
        try {
            $shapeRange = $selection.ShapeRange
            for ($i = 1; $i -le $shapeRange.Count; $i++) {
                $nativeId = $null
                try { $nativeId = [int]$shapeRange.Item($i).Id } catch {}
                $shapeIndex = Get-PptShapeIndexByNativeId $pres.Slides.Item($slideIndex) $nativeId
                if ($null -ne $shapeIndex -and $selectedShapeIndexes -notcontains [int]$shapeIndex) {
                    $selectedShapeIndexes += [int]$shapeIndex
                }
            }
        } catch {}
        if ($selectedShapeIndexes.Count -eq 0 -and $selectionType -eq 3) {
            try {
                $candidate = $selection.TextRange.Parent
                for ($depth = 0; $depth -lt 3; $depth++) {
                    $nativeId = $null
                    try { $nativeId = [int]$candidate.Id } catch {}
                    if ($null -ne $nativeId) {
                        $shapeIndex = Get-PptShapeIndexByNativeId $pres.Slides.Item($slideIndex) $nativeId
                        if ($null -ne $shapeIndex) { $selectedShapeIndexes += [int]$shapeIndex }
                        break
                    }
                    try { $candidate = $candidate.Parent } catch { break }
                }
            } catch {}
        }
    } catch {}

    return @{
        success = $true
        slideIndex = [int]$slideIndex
        source = $source
        viewType = $viewType
        viewTypeName = $viewTypeName
        selectionType = $selectionType
        selectionTypeName = $selectionTypeName
        selectedShapeIndexes = $selectedShapeIndexes
    }
}

function Test-PptBoundsContains($outer, $inner, [double]$tolerance = 2) {
    $ol = Get-PptBoundsNumber $outer "left"
    $ot = Get-PptBoundsNumber $outer "top"
    $or = $ol + (Get-PptBoundsNumber $outer "width")
    $ob = $ot + (Get-PptBoundsNumber $outer "height")
    $il = Get-PptBoundsNumber $inner "left"
    $it = Get-PptBoundsNumber $inner "top"
    $ir = $il + (Get-PptBoundsNumber $inner "width")
    $ib = $it + (Get-PptBoundsNumber $inner "height")
    return ($il -ge ($ol - $tolerance) -and $it -ge ($ot - $tolerance) -and $ir -le ($or + $tolerance) -and $ib -le ($ob + $tolerance))
}

function Get-PptCurrentContextResult($ppt, $pres, $options) {
    $diagnosticsEnabled = [bool](Get-ObjectPropertyValue $options "__includeDiagnostics")
    $contextTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $contextTiming = @{}
    $phaseTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $selection = Get-PptCurrentSlideSelection $ppt $pres
    $contextTiming.selection = $phaseTimer.ElapsedMilliseconds
    if (-not $selection.success) {
        return New-PptRecoverableError "PPT_CURRENT_SLIDE_UNAVAILABLE" $selection.error @{ suggestedAction = "focus_a_slide_then_retry" }
    }

    $mode = if ($options.mode) { [string]$options.mode } else { "content" }
    $structureTiming = @{}
    $phaseTimer.Restart()
    $structure = Get-PptSlideStructureResult $pres ([int]$selection.slideIndex) $mode $false $structureTiming
    $contextTiming.slideStructure = $phaseTimer.ElapsedMilliseconds
    if (-not $structure.success) { return $structure }
    $objects = @($structure.data.objects)
    $selectedIndexes = @($selection.selectedShapeIndexes)
    $selectedObjects = @()
    $componentMap = @{}

    $phaseTimer.Restart()
    foreach ($obj in $objects) {
        $descriptor = Get-PptComponentDescriptor ([string]$obj.shapeName)
        if ($null -ne $descriptor) {
            $obj["component"] = $descriptor
        }
    }
    $contextTiming.componentDescriptor = $phaseTimer.ElapsedMilliseconds
    $phaseTimer.Restart()
    $componentIdentityDiagnostics = @(Resolve-PptRuntimeComponentInstances $objects)
    $contextTiming.componentIdentity = $phaseTimer.ElapsedMilliseconds

    $phaseTimer.Restart()
    foreach ($obj in $objects) {
        $descriptor = Get-ObjectPropertyValue $obj "component"
        if ($null -ne $descriptor) {
            $componentId = [string]$descriptor.componentId
            if (-not $componentMap.ContainsKey($componentId)) {
                $componentMap[$componentId] = @{
                    componentId = $componentId
                    componentType = [string]$descriptor.componentType
                    componentIndex = [int]$descriptor.componentIndex
                    objectIds = @()
                    shapeIndexes = @()
                    shapeNames = @()
                    parts = @()
                    texts = @()
                    left = [double]::PositiveInfinity
                    top = [double]::PositiveInfinity
                    right = [double]::NegativeInfinity
                    bottom = [double]::NegativeInfinity
                }
            }
            $group = $componentMap[$componentId]
            $group.objectIds += [string]$obj.objectId
            $group.shapeIndexes += [int]$obj.shapeIndex
            $group.shapeNames += [string]$obj.shapeName
            $group.parts += [string]$descriptor.part
            if ($obj.textPreview) { $group.texts += [string]$obj.textPreview }
            $bounds = $obj.bounds
            $left = Get-PptBoundsNumber $bounds "left"
            $top = Get-PptBoundsNumber $bounds "top"
            $right = $left + (Get-PptBoundsNumber $bounds "width")
            $bottom = $top + (Get-PptBoundsNumber $bounds "height")
            if ($left -lt $group.left) { $group.left = $left }
            if ($top -lt $group.top) { $group.top = $top }
            if ($right -gt $group.right) { $group.right = $right }
            if ($bottom -gt $group.bottom) { $group.bottom = $bottom }
        }
        if ($selectedIndexes -contains [int]$obj.shapeIndex) {
            $obj["selected"] = $true
            $selectedObjects += $obj
        }
    }
    $contextTiming.componentGrouping = $phaseTimer.ElapsedMilliseconds

    $componentGroups = @()
    foreach ($componentId in $componentMap.Keys) {
        $group = $componentMap[$componentId]
        $componentGroups += @{
            componentId = $group.componentId
            componentType = $group.componentType
            componentIndex = $group.componentIndex
            objectIds = $group.objectIds
            shapeIndexes = $group.shapeIndexes
            shapeNames = $group.shapeNames
            parts = $group.parts
            texts = $group.texts
            bounds = @{
                left = $group.left
                top = $group.top
                width = [Math]::Max(0, $group.right - $group.left)
                height = [Math]::Max(0, $group.bottom - $group.top)
            }
        }
    }

    $phaseTimer.Restart()
    $targetCandidates = @()
    foreach ($selectedObject in $selectedObjects) {
        $component = Get-ObjectPropertyValue $selectedObject "component"
        if ($null -ne $component) {
            $componentId = [string]$component.componentId
            $groupObjects = @($objects | Where-Object { $_.component -and [string]$_.component.componentId -eq $componentId })
            $backgrounds = @($groupObjects | Where-Object { [string]$_.component.part -match '(^|_)(bg|band|background)($|_)' })
            foreach ($background in $backgrounds) {
                $targetCandidates += @{
                    reason = "selected_object_component_background"
                    selectedObjectId = $selectedObject.objectId
                    objectId = $background.objectId
                    shapeIndex = $background.shapeIndex
                    shapeName = $background.shapeName
                    componentId = $componentId
                    confidence = 1.0
                    bounds = $background.bounds
                }
            }
        }

        if (@($targetCandidates | Where-Object { $_.selectedObjectId -eq $selectedObject.objectId }).Count -eq 0 -and [string]$selectedObject.kind -match 'textbox|title|subtitle|placeholder') {
            $containing = @($objects | Where-Object {
                [int]$_.zOrder -lt [int]$selectedObject.zOrder -and
                [string]$_.kind -match 'shape|autoShape' -and
                (Test-PptBoundsContains $_.bounds $selectedObject.bounds 3)
            } | Sort-Object { (Get-PptBoundsNumber $_.bounds "width") * (Get-PptBoundsNumber $_.bounds "height") })
            if ($containing.Count -gt 0) {
                $background = $containing[0]
                $targetCandidates += @{
                    reason = "selected_text_containing_background"
                    selectedObjectId = $selectedObject.objectId
                    objectId = $background.objectId
                    shapeIndex = $background.shapeIndex
                    shapeName = $background.shapeName
                    confidence = 0.85
                    bounds = $background.bounds
                }
            }
        }
    }
    $contextTiming.targetCandidates = $phaseTimer.ElapsedMilliseconds

    $phaseTimer.Restart()
    $title = ""
    foreach ($obj in $objects) {
        if (($obj.role -eq "title" -or [string]$obj.shapeName -match '(?i)_title$') -and $obj.textPreview) {
            $title = [string]$obj.textPreview
            break
        }
    }
    $contextTiming.title = $phaseTimer.ElapsedMilliseconds
    $includeSlideObjects = if ($null -ne $options.includeSlideObjects) { [bool]$options.includeSlideObjects } else { $true }
    $rollbackSnapshot = $null
    $phaseTimer.Restart()
    if ([bool](Get-ObjectPropertyValue $options "includeRollbackSnapshot")) {
        $requestedRollbackSlides = @()
        $rollbackSlideInput = Get-ObjectPropertyValue $options "rollbackSlideIndexes"
        if ($null -ne $rollbackSlideInput) {
            foreach ($candidate in @($rollbackSlideInput)) {
                $parsed = 0
                if ([int]::TryParse([string]$candidate, [ref]$parsed) -and $parsed -gt 0 -and $requestedRollbackSlides -notcontains $parsed) {
                    $requestedRollbackSlides += $parsed
                }
            }
        }
        if ($requestedRollbackSlides.Count -eq 0) { $requestedRollbackSlides = @([int]$selection.slideIndex) }
        $rollbackTargetsBySlide = @((Get-ObjectPropertyValue $options "rollbackTargetsBySlide"))
        $hasExplicitRollbackTarget = $false
        foreach ($target in $rollbackTargetsBySlide) {
            if (
                @((Get-ObjectPropertyValue $target "nativeShapeIds")).Count -gt 0 -or
                @((Get-ObjectPropertyValue $target "shapeIndexes")).Count -gt 0 -or
                @((Get-ObjectPropertyValue $target "shapeNames")).Count -gt 0 -or
                @((Get-ObjectPropertyValue $target "componentIds")).Count -gt 0
            ) {
                $hasExplicitRollbackTarget = $true
                break
            }
        }
        if (-not $hasExplicitRollbackTarget) {
            $selectedObjects = @((Get-ObjectPropertyValue $selection "selectedObjects"))
            if ($selectedObjects.Count -gt 0) {
                $rollbackTargetsBySlide = @(@{
                    slideIndex = [int]$selection.slideIndex
                    nativeShapeIds = @($selectedObjects | ForEach-Object { Get-ObjectPropertyValue $_ "nativeShapeId" } | Where-Object { $null -ne $_ })
                    shapeIndexes = @($selectedObjects | ForEach-Object { Get-ObjectPropertyValue $_ "shapeIndex" } | Where-Object { $null -ne $_ })
                    shapeNames = @($selectedObjects | ForEach-Object { Get-ObjectPropertyValue $_ "shapeName" } | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
                    componentIds = @($selectedObjects | ForEach-Object {
                        $component = Get-ObjectPropertyValue $_ "component"
                        if ($null -ne $component) { Get-ObjectPropertyValue $component "componentId" }
                    } | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
                })
            }
        }
        $rollbackSnapshot = Get-PptMutationRollbackSnapshot $pres $requestedRollbackSlides $rollbackTargetsBySlide
    }
    $contextTiming.rollbackSnapshot = $phaseTimer.ElapsedMilliseconds
    $contextTiming.totalBeforeOutput = $contextTimer.ElapsedMilliseconds
    $contextData = @{
        presentation = $structure.data.presentation
        currentSlide = @{
            slideIndex = [int]$selection.slideIndex
            nativeSlideId = $structure.data.slide.nativeSlideId
            title = $title
            layout = $structure.data.slide.layout
            width = $structure.data.slide.width
            height = $structure.data.slide.height
            objectCount = $structure.data.slide.objectCount
        }
        view = @{
            currentSlideSource = $selection.source
            viewType = $selection.viewType
            viewTypeName = $selection.viewTypeName
            selectionType = $selection.selectionType
            selectionTypeName = $selection.selectionTypeName
        }
        selection = @{
            selectedShapeIndexes = $selectedIndexes
            selectedObjects = $selectedObjects
            selectedObjectCount = $selectedObjects.Count
        }
        componentGroups = $componentGroups
        componentIdentityDiagnostics = $componentIdentityDiagnostics
        targetCandidates = $targetCandidates
        # Keep the collection shape stable when a slide has exactly one object.
        # PowerShell's subexpression operator unwraps a single-item array, which
        # makes downstream JSON consumers mistake the context for an empty list.
        objects = @(if ($includeSlideObjects) { $objects } else { @() })
        rollbackSnapshot = $rollbackSnapshot
    }
    if ($diagnosticsEnabled) {
        $contextData.diagnostics = @{
            actionInternalMs = $contextTimer.ElapsedMilliseconds
            timingMs = $contextTiming
            structureTimingMs = $structureTiming
            objectCount = $objects.Count
        }
    }
    return @{
        success = $true
        data = $contextData
    }
}

function Get-PptSlideStructureResult(
    $pres,
    [int]$slideIndex,
    [string]$mode = "structure",
    [bool]$includeLink = $false,
    $diagnostics = $null
) {
    $includeContent = ($mode -eq "content" -or $mode -eq "both")
    $structureTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $resolvedSlide = Resolve-PptSlide $pres $slideIndex "getSlideStructure"
    if ($null -ne $diagnostics) { $diagnostics.resolveSlide = $structureTimer.ElapsedMilliseconds }
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }

    $slide = $resolvedSlide.slide
    $protection = Get-PptPresentationProtectionState $pres
    $objects = @()
    $counts = @{ title = 0; subtitle = 0; textbox = 0; placeholder = 0; table = 0; picture = 0; chart = 0; shape = 0 }
    $textLengthTotal = 0
    $objectTiming = @()
    $objectLoopTimer = [System.Diagnostics.Stopwatch]::StartNew()
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $shape = $slide.Shapes.Item($i)
        $objectTimer = $null
        if ($null -ne $diagnostics) {
            $objectTimer = [System.Diagnostics.Stopwatch]::StartNew()
        }
        $obj = Get-PptUnifiedObject `
            $shape `
            $resolvedSlide.slideIndex `
            $i `
            $includeContent `
            ([bool]$protection.readOnly) `
            ([bool]$protection.protectMode) `
            $includeLink
        $objects += $obj
        if ($null -ne $objectTimer) {
            $objectTiming += @{
                shapeIndex = $i
                shapeName = [string]$obj.shapeName
                kind = [string]$obj.kind
                nativeType = [string]$obj.nativeType
                elapsedMs = $objectTimer.ElapsedMilliseconds
            }
        }
        $kind = [string]$obj.kind
        if ($counts.ContainsKey($kind)) { $counts[$kind] = [int]$counts[$kind] + 1 } else { $counts["shape"] = [int]$counts["shape"] + 1 }
        if ($obj.textLength) { $textLengthTotal += [int]$obj.textLength }
    }
    if ($null -ne $diagnostics) { $diagnostics.objectLoop = $objectLoopTimer.ElapsedMilliseconds }
    $metadataTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $slideWidth = $null
    $slideHeight = $null
    try { $slideWidth = [double]$pres.PageSetup.SlideWidth } catch {}
    try { $slideHeight = [double]$pres.PageSetup.SlideHeight } catch {}
    if ($null -ne $diagnostics) {
        $diagnostics.metadata = $metadataTimer.ElapsedMilliseconds
        $diagnostics.objectTiming = @($objectTiming)
        $diagnostics.total = $structureTimer.ElapsedMilliseconds
    }
    $summaryFingerprint = [string](Get-PptSlideSummaryResult $slide $resolvedSlide.slideIndex).fingerprint

    return @{
        success = $true
        data = @{
            mode = $mode
            presentation = @{
                name = $pres.Name
                path = $pres.FullName
                runtimeLocator = Get-PptRuntimePresentationLocator $pres
                slideCount = $pres.Slides.Count
                readOnly = [bool]$protection.readOnly
                protectMode = [bool]$protection.protectMode
            }
            slide = @{
                slideIndex = $resolvedSlide.slideIndex
                nativeSlideId = $(try { [int]$slide.SlideID } catch { [int]$resolvedSlide.slideIndex })
                layout = $slide.Layout
                width = $slideWidth
                height = $slideHeight
                objectCount = $objects.Count
                counts = $counts
                textLengthTotal = $textLengthTotal
                fingerprint = $summaryFingerprint
            }
            objects = $objects
        }
    }
}

function Get-PptTemplateCandidate($slideStructure) {
    $slide = $slideStructure.slide
    $objects = $slideStructure.objects
    $counts = $slide.counts
    $title = ""
    foreach ($obj in $objects) {
        if ($obj.role -eq "title" -and $obj.textPreview) {
            $title = [string]$obj.textPreview
            break
        }
    }

    $type = "content"
    $score = 0.55
    $reasons = @()
    if ([int]$slide.objectCount -eq 0) {
        $type = "blank"
        $score = 0.9
        $reasons += "no objects"
    } elseif ([int]$counts.table -gt 0) {
        $type = "table"
        $score = 0.86
        $reasons += "contains table"
    } elseif ([int]$counts.picture -gt 0 -and [int]$counts.textbox + [int]$counts.title -gt 0) {
        $type = "image_content"
        $score = 0.82
        $reasons += "contains image and text"
    } elseif ([int]$counts.chart -gt 0) {
        $type = "chart"
        $score = 0.8
        $reasons += "contains chart"
    } elseif ([int]$slide.slideIndex -eq 1 -and [int]$counts.title -gt 0) {
        $type = "cover"
        $score = 0.84
        $reasons += "first slide with title"
    } elseif ([int]$counts.title -gt 0 -and [int]$slide.objectCount -le 3 -and [int]$slide.textLengthTotal -le 80) {
        $type = "section_header"
        $score = 0.78
        $reasons += "low object count with short title"
    } else {
        $type = "content"
        $score = 0.62
        $reasons += "general content layout"
    }

    $slots = Get-PptTemplateSlots $slideStructure
    return @{
        slideIndex = $slide.slideIndex
        candidateType = $type
        score = $score
        title = $title
        objectCount = $slide.objectCount
        counts = $counts
        reasons = $reasons
        replaceableSlots = $slots
        slots = $slots
        preservationHints = @{
            strategy = "duplicate_then_replace_slots"
            preserve = @("background", "layout", "decorations", "positions", "z_order")
            editableSlotCount = $slots.Count
            warning = "Use slotId or shapeName when replacing template content; avoid adding unrelated shapes unless the user asks."
        }
    }
}

function Get-PptTemplateSlotType($obj) {
    $kind = [string]$obj.kind
    $role = [string]$obj.role
    $shapeName = [string]$obj.shapeName
    $placeholderTypeName = [string]$obj.placeholderTypeName

    if ($kind -eq "table") { return "table" }
    if ($kind -eq "picture") { return "image" }
    if ($kind -eq "title" -or $role -eq "title" -or $placeholderTypeName -match "title") { return "title" }
    if ($kind -eq "subtitle" -or $role -eq "subtitle" -or $placeholderTypeName -match "subtitle") { return "subtitle" }
    if ($role -eq "body" -or $placeholderTypeName -match "body") { return "body" }
    if ($shapeName -match "(?i)(^|_)(body|content|正文|内容)$") { return "body" }
    if ($shapeName -match "(?i)(^|_)(subtitle|sub_title|副标题)$") { return "subtitle" }
    if ($shapeName -match "(?i)(^|_)(title|标题)$") { return "title" }
    if ($kind -eq "textbox" -or $kind -eq "placeholder" -or $role -eq "text" -or $role -eq "textbox") { return "text" }
    return $null
}

function Get-PptTemplateSlots($slideStructure) {
    $slots = @()
    $tableIndex = 0
    $imageIndex = 0
    foreach ($obj in @($slideStructure.objects)) {
        $kind = [string]$obj.kind
        $role = [string]$obj.role
        $slotType = Get-PptTemplateSlotType $obj
        if (-not $slotType) { continue }
        $slotRole = if ($slotType -in @("title", "subtitle", "body")) { $slotType } else { $role }
        if ($kind -eq "table") {
            $tableIndex++
            $slots += @{
                slotId = $obj.objectId
                slotType = $slotType
                kind = $kind
                role = $slotRole
                shapeIndex = $obj.shapeIndex
                shapeName = $obj.shapeName
                tableIndex = $tableIndex
                rows = $obj.table.rows
                columns = $obj.table.columns
                bounds = $obj.bounds
                textPreview = $obj.textPreview
                replacement = @{ accepts = "data"; toolHint = "tableReplacements.data" }
            }
        } elseif ($kind -eq "picture") {
            $imageIndex++
            $slots += @{
                slotId = $obj.objectId
                slotType = $slotType
                kind = $kind
                role = $slotRole
                shapeIndex = $obj.shapeIndex
                shapeName = $obj.shapeName
                imageIndex = $imageIndex
                bounds = $obj.bounds
                replacement = @{ accepts = "localPath"; toolHint = "imageReplacements.path" }
            }
        } else {
            $slots += @{
                slotId = $obj.objectId
                slotType = $slotType
                kind = $kind
                role = $slotRole
                shapeIndex = $obj.shapeIndex
                shapeName = $obj.shapeName
                bounds = $obj.bounds
                textPreview = $obj.textPreview
                replacement = @{ accepts = "text"; toolHint = "textReplacements.text" }
            }
        }
    }
    return $slots
}

function Get-PptScreenshotMimeType([string]$format) {
    $f = if ($format) { $format.ToUpper() } else { "PNG" }
    if ($f -eq "JPG" -or $f -eq "JPEG") { return "image/jpeg" }
    if ($f -eq "GIF") { return "image/gif" }
    if ($f -eq "BMP") { return "image/bmp" }
    return "image/png"
}

function Get-PptVisibleShapeCount($slide) {
    $count = 0
    if ($null -eq $slide) { return $count }
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
        try {
            $shape = $slide.Shapes.Item($shapeIndex)
            if ([int]$shape.Visible -ne 0 -and [double]$shape.Width -gt 0 -and [double]$shape.Height -gt 0) {
                $count++
            }
        } catch {}
    }
    return $count
}

function Get-PptScreenshotPixelStats([string]$path, [int]$visibleShapeCount) {
    $bitmap = $null
    try {
        Add-Type -AssemblyName System.Drawing
        $bitmap = [System.Drawing.Bitmap]::FromFile($path)
        $step = [Math]::Max(1, [int][Math]::Floor([Math]::Min($bitmap.Width, $bitmap.Height) / 180.0))
        $sampled = 0
        $nonWhite = 0
        $minChannel = 255
        $maxChannel = 0
        for ($y = 0; $y -lt $bitmap.Height; $y += $step) {
            for ($x = 0; $x -lt $bitmap.Width; $x += $step) {
                $pixel = $bitmap.GetPixel($x, $y)
                $sampled++
                $minChannel = [Math]::Min($minChannel, [Math]::Min($pixel.R, [Math]::Min($pixel.G, $pixel.B)))
                $maxChannel = [Math]::Max($maxChannel, [Math]::Max($pixel.R, [Math]::Max($pixel.G, $pixel.B)))
                if ($pixel.R -lt 248 -or $pixel.G -lt 248 -or $pixel.B -lt 248) {
                    $nonWhite++
                }
            }
        }
        $minimumVisibleSamples = [Math]::Max(8, [int][Math]::Ceiling($sampled * 0.0005))
        $likelyBlank = $visibleShapeCount -gt 0 -and $nonWhite -lt $minimumVisibleSamples
        return @{
            status = if ($likelyBlank) { "invalid_blank" } else { "valid" }
            sampledPixelCount = $sampled
            nonWhiteSampleCount = $nonWhite
            nonWhiteRatio = if ($sampled -gt 0) { [Math]::Round($nonWhite / [double]$sampled, 6) } else { 0 }
            minimumVisibleSamples = $minimumVisibleSamples
            minChannel = $minChannel
            maxChannel = $maxChannel
            visibleShapeCount = $visibleShapeCount
        }
    } catch {
        return @{
            status = "unknown"
            visibleShapeCount = $visibleShapeCount
            error = $_.Exception.Message
        }
    } finally {
        if ($null -ne $bitmap) { $bitmap.Dispose() }
    }
}

function Export-PptSlideImageSafe($pres, [int]$slideIndex, $options, [string]$actionName) {
    $resolvedSlide = Resolve-PptSlide $pres $slideIndex $actionName
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }

    $slide = $resolvedSlide.slide
    $format = Get-ObjectPropertyValue $options "format"
    $rawFormat = if ($format) { [string]$format } else { "PNG" }
    $filterName = $rawFormat.ToUpper()
    if ($filterName -eq "JPEG") { $filterName = "JPG" }
    if (@("PNG", "JPG", "GIF", "BMP") -notcontains $filterName) {
        return (New-PptRecoverableError "PPT_INVALID_IMAGE_FORMAT" "$actionName failed: format must be PNG, JPG, GIF, or BMP." @{ format = $rawFormat; validFormats = @("PNG", "JPG", "GIF", "BMP") })
    }

    $width = Get-ObjectPropertyValue $options "width"
    if ($null -eq $width) { $width = 1280 }
    $height = Get-ObjectPropertyValue $options "height"
    if ($null -eq $height) { $height = 720 }

    $outputPath = Get-ObjectPropertyValue $options "outputPath"
    if (-not $outputPath) { $outputPath = Get-ObjectPropertyValue $options "path" }
    if (-not $outputPath) {
        $outputDir = Get-ObjectPropertyValue $options "outputDir"
        if (-not $outputDir) { $outputDir = Join-Path $env:TEMP "wps-ppt-screenshots" }
        if (-not (Test-Path $outputDir)) { New-Item -ItemType Directory -Path $outputDir -Force | Out-Null }
        $safeName = "presentation"
        try { $safeName = [IO.Path]::GetFileNameWithoutExtension([string]$pres.Name) } catch {}
        $safeName = ($safeName -replace '[^a-zA-Z0-9._-]', '_')
        $timestamp = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
        $extension = if ($filterName -eq "JPG") { "jpg" } else { $filterName.ToLower() }
        $outputPath = Join-Path $outputDir ("{0}-slide-{1}-{2}.{3}" -f $safeName, $resolvedSlide.slideIndex, $timestamp, $extension)
    } else {
        $parent = Split-Path -Parent $outputPath
        if ($parent -and -not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    }

    $visibleShapeCount = Get-PptVisibleShapeCount $slide
    $captureAttempts = @()
    $selectedPath = [string]$outputPath
    $selectedFilter = $filterName
    $selectedStats = $null
    $attemptFormats = @($filterName)
    if ($filterName -ne "JPG") { $attemptFormats += "JPG" }
    if ($filterName -ne "BMP") { $attemptFormats += "BMP" }
    for ($attemptIndex = 0; $attemptIndex -lt $attemptFormats.Count; $attemptIndex++) {
        $attemptFilter = [string]$attemptFormats[$attemptIndex]
        $attemptPath = if ($attemptIndex -eq 0) {
            [string]$outputPath
        } else {
            $attemptExtension = if ($attemptFilter -eq "JPG") { "jpg" } else { $attemptFilter.ToLower() }
            $directory = Split-Path -Parent ([string]$outputPath)
            if ([string]::IsNullOrWhiteSpace($directory)) { $directory = [string](Get-Location).Path }
            $baseName = [IO.Path]::GetFileNameWithoutExtension([string]$outputPath)
            Join-Path $directory ("{0}-fallback-{1}.{2}" -f $baseName, $attemptIndex, $attemptExtension)
        }
        Remove-Item -LiteralPath $attemptPath -ErrorAction SilentlyContinue
        $slide.Export($attemptPath, $attemptFilter, [int]$width, [int]$height)
        $attemptFile = Get-Item -LiteralPath $attemptPath
        $attemptStats = Get-PptScreenshotPixelStats $attemptPath $visibleShapeCount
        $captureAttempts += @{
            method = "original_slide"
            format = $attemptFilter
            outputPath = $attemptPath
            bytes = [int64]$attemptFile.Length
            pixelStats = $attemptStats
        }
        $selectedPath = $attemptPath
        $selectedFilter = $attemptFilter
        $selectedStats = $attemptStats
        if ([string]$attemptStats.status -eq "valid") { break }
        if ([string]$attemptStats.status -ne "invalid_blank") { break }
    }

    $renderCloneCleanupVerified = $true
    if ([string]$selectedStats.status -eq "invalid_blank") {
        $renderClone = $null
        $slideCountBeforeClone = [int]$pres.Slides.Count
        $renderCloneNativeId = $null
        try {
            $renderClone = $slide.Duplicate().Item(1)
            try { $renderCloneNativeId = [string]$renderClone.SlideID } catch {}
            $cloneExtension = if ($filterName -eq "JPG") { "jpg" } else { $filterName.ToLower() }
            $cloneDirectory = Split-Path -Parent ([string]$outputPath)
            if ([string]::IsNullOrWhiteSpace($cloneDirectory)) { $cloneDirectory = [string](Get-Location).Path }
            $cloneBaseName = [IO.Path]::GetFileNameWithoutExtension([string]$outputPath)
            $clonePath = Join-Path $cloneDirectory ("{0}-render-clone.{1}" -f $cloneBaseName, $cloneExtension)
            Remove-Item -LiteralPath $clonePath -ErrorAction SilentlyContinue
            $renderClone.Export($clonePath, $filterName, [int]$width, [int]$height)
            $cloneFile = Get-Item -LiteralPath $clonePath
            $cloneStats = Get-PptScreenshotPixelStats $clonePath $visibleShapeCount
            $captureAttempts += @{
                method = "temporary_slide_duplicate"
                format = $filterName
                outputPath = $clonePath
                bytes = [int64]$cloneFile.Length
                pixelStats = $cloneStats
            }
            $selectedPath = $clonePath
            $selectedFilter = $filterName
            $selectedStats = $cloneStats
        } catch {
            $captureAttempts += @{
                method = "temporary_slide_duplicate"
                format = $filterName
                error = $_.Exception.Message
            }
        } finally {
            if ($null -ne $renderClone) {
                try { $renderClone.Delete() } catch { $renderCloneCleanupVerified = $false }
            }
            try {
                if ([int]$pres.Slides.Count -ne $slideCountBeforeClone -and -not [string]::IsNullOrWhiteSpace([string]$renderCloneNativeId)) {
                    for ($cleanupIndex = 1; $cleanupIndex -le $pres.Slides.Count; $cleanupIndex++) {
                        $candidateSlide = $pres.Slides.Item($cleanupIndex)
                        if ([string]$candidateSlide.SlideID -eq [string]$renderCloneNativeId) {
                            $candidateSlide.Delete()
                            break
                        }
                    }
                }
                if ([int]$pres.Slides.Count -ne $slideCountBeforeClone) { $renderCloneCleanupVerified = $false }
            } catch {
                $renderCloneCleanupVerified = $false
            }
        }
        if (-not $renderCloneCleanupVerified) {
            $selectedStats = @{
                status = "unknown"
                visibleShapeCount = $visibleShapeCount
                error = "Temporary render clone cleanup was not verified."
            }
        }
    }

    if (-not $renderCloneCleanupVerified) {
        return (New-PptRecoverableError "PPT_RENDER_CLONE_CLEANUP_FAILED" "$actionName failed: the temporary slide used to refresh WPS rendering was not removed safely." @{
            slideIndex = $resolvedSlide.slideIndex
            slideCountBeforeClone = $slideCountBeforeClone
            slideCountAfterClone = $(try { [int]$pres.Slides.Count } catch { $null })
            renderCloneNativeId = $renderCloneNativeId
        })
    }

    $fileInfo = Get-Item -LiteralPath $selectedPath
    $mimeType = Get-PptScreenshotMimeType $selectedFilter
    $data = @{
        slideIndex = $resolvedSlide.slideIndex
        outputPath = [string]$selectedPath
        format = $selectedFilter
        mimeType = $mimeType
        width = [int]$width
        height = [int]$height
        bytes = [int64]$fileInfo.Length
        captureStatus = [string]$selectedStats.status
        capturePixelStats = $selectedStats
        captureAttempts = $captureAttempts
        renderCloneCleanupVerified = $renderCloneCleanupVerified
        visualQaPending = @{
            requiresMultimodal = $true
            status = if ([string]$selectedStats.status -eq "valid") { "not_implemented" } else { "capture_failed" }
            pendingChecks = @(
                "image_semantics",
                "visual_style_quality",
                "theme_relevance",
                "ocr_text_rendering",
                "contrast_by_rendered_pixels"
            )
        }
    }

    $includeBase64 = Get-ObjectPropertyValue $options "includeBase64"
    $includeDataUrl = Get-ObjectPropertyValue $options "includeDataUrl"
    if ([bool]$includeBase64 -or [bool]$includeDataUrl) {
        $base64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes([string]$selectedPath))
        if ([bool]$includeBase64) { $data["base64"] = $base64 }
        if ([bool]$includeDataUrl) { $data["dataUrl"] = "data:$mimeType;base64,$base64" }
    }

    return @{ success = $true; data = $data }
}

function Get-PptBoundsNumber($bounds, [string]$name) {
    $value = Get-ObjectPropertyValue $bounds $name
    if ($null -eq $value) { return 0 }
    return [double]$value
}

function Get-PptObjectArea($obj) {
    $bounds = $obj.bounds
    $width = Get-PptBoundsNumber $bounds "width"
    $height = Get-PptBoundsNumber $bounds "height"
    if ($width -le 0 -or $height -le 0) { return 0 }
    return $width * $height
}

function Test-PptBackgroundCandidate($obj, [double]$slideWidth, [double]$slideHeight, [double]$margin) {
    $kind = [string]$obj.kind
    $zOrder = 9999
    try { $zOrder = [int]$obj.zOrder } catch {}
    $bounds = $obj.bounds
    $left = Get-PptBoundsNumber $bounds "left"
    $top = Get-PptBoundsNumber $bounds "top"
    $width = Get-PptBoundsNumber $bounds "width"
    $height = Get-PptBoundsNumber $bounds "height"
    $covers = ($left -le $margin -and $top -le $margin -and ($left + $width) -ge ($slideWidth - $margin) -and ($top + $height) -ge ($slideHeight - $margin))
    return ($covers -and $zOrder -le 2 -and @("picture", "shape", "autoShape") -contains $kind)
}

function Test-PptTextOnShapeIntentional($a, $b) {
    $textObj = $null
    $shapeObj = $null
    if (@("textbox", "title", "subtitle", "text") -contains [string]$a.kind -and @("shape", "autoShape") -contains [string]$b.kind) {
        $textObj = $a; $shapeObj = $b
    } elseif (@("textbox", "title", "subtitle", "text") -contains [string]$b.kind -and @("shape", "autoShape") -contains [string]$a.kind) {
        $textObj = $b; $shapeObj = $a
    }
    if ($null -eq $textObj -or $null -eq $shapeObj) { return $false }

    $tb = $textObj.bounds
    $sb = $shapeObj.bounds
    $tl = Get-PptBoundsNumber $tb "left"
    $tt = Get-PptBoundsNumber $tb "top"
    $tr = $tl + (Get-PptBoundsNumber $tb "width")
    $tbm = $tt + (Get-PptBoundsNumber $tb "height")
    $sl = Get-PptBoundsNumber $sb "left"
    $st = Get-PptBoundsNumber $sb "top"
    $sr = $sl + (Get-PptBoundsNumber $sb "width")
    $sbm = $st + (Get-PptBoundsNumber $sb "height")
    return ($tl -ge ($sl - 2) -and $tt -ge ($st - 2) -and $tr -le ($sr + 2) -and $tbm -le ($sbm + 2))
}

function Get-PptComponentPrefix($name) {
    $descriptor = Get-PptComponentDescriptor ([string]$name)
    if ($null -eq $descriptor) { return "" }
    return [string]$descriptor.componentId
}

function Test-PptSameComponentIntentional($a, $b) {
    $aDescriptor = Get-ObjectPropertyValue $a "component"
    if ($null -eq $aDescriptor) { $aDescriptor = Get-PptComponentDescriptor ([string]$a.shapeName) }
    $bDescriptor = Get-ObjectPropertyValue $b "component"
    if ($null -eq $bDescriptor) { $bDescriptor = Get-PptComponentDescriptor ([string]$b.shapeName) }
    if ($null -eq $aDescriptor -or $null -eq $bDescriptor) { return $false }
    $aLayoutComponentId = if ($aDescriptor.layoutComponentId) { [string]$aDescriptor.layoutComponentId } else { [string]$aDescriptor.componentId }
    $bLayoutComponentId = if ($bDescriptor.layoutComponentId) { [string]$bDescriptor.layoutComponentId } else { [string]$bDescriptor.componentId }
    if ($aLayoutComponentId -ne $bLayoutComponentId) { return $false }
    $decorativePart = '(^|_)(bg|band|background|accent|accent_rule|top_rule|side_rule|strip|index|dot|line|badge|soft_panel|caption_bg|image_placeholder)($|_)'
    $visualCaptionPart = '(^|_)(image|picture|caption)($|_)'
    $aIsText = @("textbox", "title", "subtitle", "text") -contains [string]$a.kind
    $bIsText = @("textbox", "title", "subtitle", "text") -contains [string]$b.kind
    if ($aIsText -and $bIsText) { return $false }
    if ([string]$aDescriptor.part -match $visualCaptionPart -and [string]$bDescriptor.part -match $visualCaptionPart) { return $true }
    return ([string]$aDescriptor.part -match $decorativePart -or [string]$bDescriptor.part -match $decorativePart)
}

function New-PptGeometryIssue([string]$severity, [string]$issueType, [int]$slideIndex, $obj, [string]$message, $metrics = @{}, $other = $null) {
    $issue = @{
        severity = $severity
        issueType = $issueType
        slideIndex = $slideIndex
        objectId = $obj.objectId
        shapeId = $obj.shapeId
        shapeIndex = $obj.shapeIndex
        shapeName = $obj.shapeName
        kind = $obj.kind
        bounds = $obj.bounds
        message = $message
        metrics = $metrics
    }
    if ($null -ne $other) {
        $issue["otherObjectId"] = $other.objectId
        $issue["otherShapeName"] = $other.shapeName
        $issue["otherKind"] = $other.kind
        $issue["otherBounds"] = $other.bounds
    }
    return $issue
}

function Test-PptSlideGeometry($pres, [int]$slideIndex, $options) {
    $modeResult = Get-PptSlideStructureResult $pres $slideIndex "content"
    if (-not $modeResult.success) { return $modeResult }
    $data = $modeResult.data
    $slide = $data.slide
    $objects = @($data.objects)
    foreach ($obj in $objects) {
        $descriptor = Get-PptComponentDescriptor ([string]$obj.shapeName)
        if ($null -ne $descriptor) { $obj["component"] = $descriptor }
    }
    $componentIdentityDiagnostics = @(Resolve-PptRuntimeComponentInstances $objects)
    $slideWidth = if ($slide.width) { [double]$slide.width } else { 960 }
    $slideHeight = if ($slide.height) { [double]$slide.height } else { 540 }
    $margin = Get-ObjectPropertyValue $options "margin"
    if ($null -eq $margin) { $margin = 12 }
    $overlapThreshold = Get-ObjectPropertyValue $options "overlapThreshold"
    if ($null -eq $overlapThreshold) { $overlapThreshold = 0.2 }
    $ignoreBackgrounds = Get-ObjectPropertyValue $options "ignoreBackgrounds"
    if ($null -eq $ignoreBackgrounds) { $ignoreBackgrounds = $true }
    $requireTitle = Get-ObjectPropertyValue $options "requireTitle"
    if ($null -eq $requireTitle) { $requireTitle = $false }
    $maxObjects = Get-ObjectPropertyValue $options "maxObjects"
    if ($null -eq $maxObjects) { $maxObjects = 35 }

    # Use the same layout-token contract as the deterministic normalizer. The
    # plan may be supplied either as one slideLayoutPlan or in slideLayoutPlans.
    $activeLayoutPlan = Get-ObjectPropertyValue $options "slideLayoutPlan"
    if ($null -eq $activeLayoutPlan -or [int](Get-ObjectPropertyValue $activeLayoutPlan "slideIndex") -ne $slideIndex) {
        $activeLayoutPlan = $null
        foreach ($candidatePlan in @(Get-ObjectPropertyValue $options "slideLayoutPlans")) {
            if ($null -ne $candidatePlan -and [int](Get-ObjectPropertyValue $candidatePlan "slideIndex") -eq $slideIndex) {
                $activeLayoutPlan = $candidatePlan
                break
            }
        }
    }
    $layoutTokens = if ($null -ne $activeLayoutPlan) { Get-ObjectPropertyValue $activeLayoutPlan "tokens" } else { $null }
    $minimumColumnGapValue = if ($null -ne $layoutTokens) { Get-ObjectPropertyValue $layoutTokens "minimumColumnGap" } else { $null }
    $minimumColumnGap = if ($null -ne $minimumColumnGapValue) { [double]$minimumColumnGapValue } else { 8.0 }
    $preferredColumnGapValue = if ($null -ne $layoutTokens) { Get-ObjectPropertyValue $layoutTokens "preferredColumnGap" } else { $null }
    if ($null -eq $preferredColumnGapValue -and $null -ne $layoutTokens) { $preferredColumnGapValue = Get-ObjectPropertyValue $layoutTokens "columnGap" }
    $preferredColumnGap = if ($null -ne $preferredColumnGapValue) { [double]$preferredColumnGapValue } else { 14.0 }
    $footerGapValue = if ($null -ne $layoutTokens) { Get-ObjectPropertyValue $layoutTokens "footerGap" } else { $null }
    $requiredFooterGap = if ($null -ne $footerGapValue) { [double]$footerGapValue } else { 12.0 }

    $issues = @()
    if ($objects.Count -eq 0) {
        $issues += @{
            severity = "warning"
            issueType = "empty_slide"
            slideIndex = $slideIndex
            message = "Slide has no objects."
            metrics = @{ objectCount = 0 }
        }
    }

    if ([bool]$requireTitle -and [int]$slide.counts.title -eq 0) {
        $issues += @{
            severity = "info"
            issueType = "missing_title"
            slideIndex = $slideIndex
            message = "Slide has no title-like object."
            metrics = @{ titleCount = 0 }
        }
    }

    $componentIds = @($objects | ForEach-Object {
        $descriptor = Get-ObjectPropertyValue $_ "component"
        if ($null -ne $descriptor) { [string]$descriptor.componentId }
    } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
    $componentShapeCount = @($objects | Where-Object { $null -ne (Get-ObjectPropertyValue $_ "component") }).Count
    $ungroupedObjectCount = [Math]::Max(0, $objects.Count - $componentShapeCount)
    $logicalObjectCount = $componentIds.Count + $ungroupedObjectCount
    $maxLogicalObjects = [Math]::Max(18, [Math]::Floor([int]$maxObjects / 2))
    if ($logicalObjectCount -gt $maxLogicalObjects) {
        $issues += @{
            severity = "warning"
            issueType = "logical_layout_complexity_high"
            slideIndex = $slideIndex
            message = "Slide has many logical components or ungrouped objects; consider simplifying the layout."
            metrics = @{ shapeCount = $objects.Count; componentCount = $componentIds.Count; ungroupedObjectCount = $ungroupedObjectCount; logicalObjectCount = $logicalObjectCount; maxLogicalObjects = $maxLogicalObjects }
        }
    }

    $visualCount = 0
    foreach ($obj in $objects) {
        if (@("picture", "table", "chart", "shape", "autoShape") -contains [string]$obj.kind) { $visualCount++ }
    }
    if ($objects.Count -gt 0 -and $visualCount -eq 0) {
        $issues += @{
            severity = "info"
            issueType = "no_visual_element"
            slideIndex = $slideIndex
            message = "Slide has text/placeholder objects but no picture/table/chart/shape visual element."
            metrics = @{ visualObjectCount = 0 }
        }
    }

    foreach ($obj in $objects) {
        $bounds = $obj.bounds
        $left = Get-PptBoundsNumber $bounds "left"
        $top = Get-PptBoundsNumber $bounds "top"
        $width = Get-PptBoundsNumber $bounds "width"
        $height = Get-PptBoundsNumber $bounds "height"
        $right = $left + $width
        $bottom = $top + $height
        $isBackground = Test-PptBackgroundCandidate $obj $slideWidth $slideHeight ([double]$margin)

        if ($width -le 0 -or $height -le 0) {
            $issues += New-PptGeometryIssue "warning" "invalid_size" $slideIndex $obj "Object has non-positive width or height." @{ width = $width; height = $height }
            continue
        }

        if ($left -lt -1 -or $top -lt -1 -or $right -gt ($slideWidth + 1) -or $bottom -gt ($slideHeight + 1)) {
            $issues += New-PptGeometryIssue "error" "out_of_bounds" $slideIndex $obj "Object extends outside slide bounds." @{ left = $left; top = $top; right = $right; bottom = $bottom; slideWidth = $slideWidth; slideHeight = $slideHeight }
        } elseif (-not $isBackground -and ($left -lt [double]$margin -or $top -lt [double]$margin -or ($slideWidth - $right) -lt [double]$margin -or ($slideHeight - $bottom) -lt [double]$margin)) {
            $issues += New-PptGeometryIssue "info" "near_edge" $slideIndex $obj "Object is close to slide edge." @{ margin = [double]$margin; leftGap = $left; topGap = $top; rightGap = $slideWidth - $right; bottomGap = $slideHeight - $bottom }
        }

        if (@("textbox", "title", "subtitle", "placeholder") -contains [string]$obj.kind -and $obj.textLength) {
            if ([bool]$obj.textOverflow) {
                $issues += New-PptGeometryIssue "error" "text_overflow" $slideIndex $obj "Rendered text height exceeds the available text box height." $obj.textFit
            }
            $area = [Math]::Max(1, $width * $height)
            $density = [double]$obj.textLength / $area
            if ([int]$obj.textLength -gt 120 -and $density -gt 0.006) {
                $issues += New-PptGeometryIssue "warning" "text_density_high" $slideIndex $obj "Text may be too dense for this object bounds; rendered overflow requires screenshot/multimodal QA." @{ textLength = [int]$obj.textLength; area = [Math]::Round($area, 2); density = [Math]::Round($density, 5) }
            }
        }
    }

    for ($i = 0; $i -lt $objects.Count; $i++) {
        for ($j = $i + 1; $j -lt $objects.Count; $j++) {
            $a = $objects[$i]
            $b = $objects[$j]
            if ([bool]$ignoreBackgrounds -and ((Test-PptBackgroundCandidate $a $slideWidth $slideHeight ([double]$margin)) -or (Test-PptBackgroundCandidate $b $slideWidth $slideHeight ([double]$margin)))) { continue }
            $aDescriptor = Get-ObjectPropertyValue $a "component"
            $bDescriptor = Get-ObjectPropertyValue $b "component"
            $crossComponent = $null -ne $aDescriptor -and $null -ne $bDescriptor -and [string]$aDescriptor.componentId -ne [string]$bDescriptor.componentId
            if (-not $crossComponent -and (Test-PptTextOnShapeIntentional $a $b)) { continue }
            if (Test-PptSameComponentIntentional $a $b) { continue }

            $ab = $a.bounds
            $bb = $b.bounds
            $left = [Math]::Max((Get-PptBoundsNumber $ab "left"), (Get-PptBoundsNumber $bb "left"))
            $top = [Math]::Max((Get-PptBoundsNumber $ab "top"), (Get-PptBoundsNumber $bb "top"))
            $right = [Math]::Min((Get-PptBoundsNumber $ab "left") + (Get-PptBoundsNumber $ab "width"), (Get-PptBoundsNumber $bb "left") + (Get-PptBoundsNumber $bb "width"))
            $bottom = [Math]::Min((Get-PptBoundsNumber $ab "top") + (Get-PptBoundsNumber $ab "height"), (Get-PptBoundsNumber $bb "top") + (Get-PptBoundsNumber $bb "height"))
            if ($right -le $left -or $bottom -le $top) { continue }

            $overlapArea = ($right - $left) * ($bottom - $top)
            $aArea = Get-PptObjectArea $a
            $bArea = Get-PptObjectArea $b
            $smallerArea = [Math]::Max(1, [Math]::Min($aArea, $bArea))
            $ratio = $overlapArea / $smallerArea
            if ($crossComponent -and $overlapArea -gt 0.01) {
                $issues += New-PptGeometryIssue "error" "cross_component_overlap" $slideIndex $a "Objects from different logical components overlap." @{ overlapArea = [Math]::Round($overlapArea, 2); overlapRatioOfSmaller = [Math]::Round($ratio, 4); componentId = [string]$aDescriptor.componentId; otherComponentId = [string]$bDescriptor.componentId; allowedOverlap = 0 } $b
            } elseif ($ratio -ge [double]$overlapThreshold) {
                $severity = if ($ratio -ge 0.6) { "error" } else { "warning" }
                $issues += New-PptGeometryIssue $severity "overlap" $slideIndex $a "Objects overlap more than the configured threshold." @{ overlapArea = [Math]::Round($overlapArea, 2); overlapRatioOfSmaller = [Math]::Round($ratio, 4); threshold = [double]$overlapThreshold } $b
            }
        }
    }

    # Deterministic component-grid checks. These do not guess aesthetic intent: they only
    # inspect R4 component backgrounds that already form an apparent visual row.
    $componentBackgrounds = @()
    $componentPartsById = @{}
    foreach ($obj in $objects) {
        $descriptor = Get-ObjectPropertyValue $obj "component"
        if ($null -eq $descriptor) { continue }
        $descriptorId = [string]$descriptor.componentId
        if (-not $componentPartsById.ContainsKey($descriptorId)) { $componentPartsById[$descriptorId] = @() }
        $componentPartsById[$descriptorId] += @{ obj = $obj; part = [string]$descriptor.part }
        if ([string]$descriptor.part -notmatch '(^|_)(bg|band|background)($|_)') { continue }
        $componentBackgrounds += @{
            componentId = $descriptorId
            componentType = [string]$descriptor.componentType
            obj = $obj
            left = Get-PptBoundsNumber $obj.bounds "left"
            top = Get-PptBoundsNumber $obj.bounds "top"
            width = Get-PptBoundsNumber $obj.bounds "width"
            height = Get-PptBoundsNumber $obj.bounds "height"
        }
    }
    foreach ($component in $componentBackgrounds) {
        $backgroundLeft = [double]$component.left
        $backgroundTop = [double]$component.top
        $backgroundRight = $backgroundLeft + [double]$component.width
        $backgroundBottom = $backgroundTop + [double]$component.height
        foreach ($part in @($componentPartsById[[string]$component.componentId])) {
            if ([string]$part.part -match '(^|_)(bg|band|background)($|_)') { continue }
            if ([string]$part.part -notmatch '(^|_)(title|body|note|label|value|subtitle|caption|accent|rule|strip)($|_)') { continue }
            $partLeft = Get-PptBoundsNumber $part.obj.bounds "left"
            $partTop = Get-PptBoundsNumber $part.obj.bounds "top"
            $partRight = $partLeft + (Get-PptBoundsNumber $part.obj.bounds "width")
            $partBottom = $partTop + (Get-PptBoundsNumber $part.obj.bounds "height")
            if ($partLeft -lt ($backgroundLeft - 2) -or $partTop -lt ($backgroundTop - 2) -or $partRight -gt ($backgroundRight + 2) -or $partBottom -gt ($backgroundBottom + 2)) {
                $issues += New-PptGeometryIssue "error" "component_internal_layout_inconsistent" $slideIndex $part.obj "Component part extends outside its own background." @{ componentId = [string]$component.componentId; part = [string]$part.part; partBounds = @{ left = $partLeft; top = $partTop; right = $partRight; bottom = $partBottom }; backgroundBounds = @{ left = $backgroundLeft; top = $backgroundTop; right = $backgroundRight; bottom = $backgroundBottom } }
            }
        }
    }
    $rowBuckets = @()
    foreach ($component in @($componentBackgrounds | Sort-Object top, left)) {
        $bucket = @($rowBuckets | Where-Object { [Math]::Abs([double]$_.anchorTop - [double]$component.top) -le 15 } | Select-Object -First 1)
        if ($bucket.Count -gt 0) {
            $bucket[0].items += $component
        } else {
            $rowBuckets += @{ anchorTop = [double]$component.top; items = @($component) }
        }
    }
    foreach ($bucket in $rowBuckets) {
        $rowItems = @($bucket.items | Sort-Object { [double]$_.left })
        if ($rowItems.Count -lt 2) { continue }
        $widths = @($rowItems | ForEach-Object { [double]$_.width })
        $heights = @($rowItems | ForEach-Object { [double]$_.height })
        $tops = @($rowItems | ForEach-Object { [double]$_.top })
        $gaps = @()
        for ($g = 1; $g -lt $rowItems.Count; $g++) {
            $gaps += [double]$rowItems[$g].left - ([double]$rowItems[$g - 1].left + [double]$rowItems[$g - 1].width)
        }
        $componentIds = @($rowItems | ForEach-Object { [string]$_.componentId })
        $declaredRows = @()
        $singlePlan = Get-ObjectPropertyValue $options "slideLayoutPlan"
        if ($null -ne $singlePlan -and [int](Get-ObjectPropertyValue $singlePlan "slideIndex") -eq $slideIndex) {
            $declaredRows += @(Get-ObjectPropertyValue $singlePlan "rows")
        }
        foreach ($candidatePlan in @(Get-ObjectPropertyValue $options "slideLayoutPlans")) {
            if ($null -ne $candidatePlan -and [int](Get-ObjectPropertyValue $candidatePlan "slideIndex") -eq $slideIndex) {
                $declaredRows += @(Get-ObjectPropertyValue $candidatePlan "rows")
            }
        }
        $hasDeclaredRow = $false
        $declaredCoverage = @()
        foreach ($declaredRow in $declaredRows) {
            $declaredMembers = @(Get-PptGridRowMembers $declaredRow)
            $declaredCoverage += @($componentIds | Where-Object { $declaredMembers -contains $_ })
            if ($declaredMembers.Count -eq $componentIds.Count -and @($componentIds | Where-Object { $declaredMembers -notcontains $_ }).Count -eq 0) {
                $hasDeclaredRow = $true
                break
            }
        }
        if (-not $hasDeclaredRow -and @($declaredCoverage | Select-Object -Unique).Count -eq $componentIds.Count) {
            # Multiple declared peer groups can intentionally share a top edge
            # while occupying independent columns. Do not merge them back into
            # one heuristic peer row.
            $hasDeclaredRow = $true
        }
        if ($hasDeclaredRow) { continue }
        $first = $rowItems[0].obj
        $topSpread = (($tops | Measure-Object -Maximum).Maximum - ($tops | Measure-Object -Minimum).Minimum)
        $widthSpread = (($widths | Measure-Object -Maximum).Maximum - ($widths | Measure-Object -Minimum).Minimum)
        $heightSpread = (($heights | Measure-Object -Maximum).Maximum - ($heights | Measure-Object -Minimum).Minimum)
        if (($gaps | Where-Object { $_ -ge -1 -and $_ -lt ($minimumColumnGap - 0.25) }).Count -gt 0) {
            $issues += New-PptGeometryIssue "error" "spacing_too_tight" $slideIndex $first "Apparent component-row gap is below the acceptable minimum visual rhythm token." @{ componentIds = $componentIds; actualGaps = @($gaps | ForEach-Object { [Math]::Round($_, 2) }); minimumGap = $minimumColumnGap; preferredGap = $preferredColumnGap }
        }
        if ($gaps.Count -gt 1) {
            $gapSpread = (($gaps | Measure-Object -Maximum).Maximum - ($gaps | Measure-Object -Minimum).Minimum)
            if ($gapSpread -gt 2) {
                $issues += New-PptGeometryIssue "warning" "column_gap_inconsistent" $slideIndex $first "Apparent component-row column gaps are inconsistent." @{ componentIds = $componentIds; actualGaps = @($gaps | ForEach-Object { [Math]::Round($_, 2) }); gapSpread = [Math]::Round($gapSpread, 2); tolerance = 2 }
            }
        }
        if ($topSpread -gt 2) {
            $issues += New-PptGeometryIssue "warning" "peer_alignment_inconsistent" $slideIndex $first "Apparent peer components do not share a common top alignment." @{ componentIds = $componentIds; topSpread = [Math]::Round($topSpread, 2); tolerance = 2 }
        }
        if ($rowItems.Count -ge 3 -and ($widthSpread -gt 2 -or $heightSpread -gt 2)) {
            $issues += New-PptGeometryIssue "warning" "peer_size_inconsistent" $slideIndex $first "Apparent peer components use inconsistent card dimensions." @{ componentIds = $componentIds; widthSpread = [Math]::Round($widthSpread, 2); heightSpread = [Math]::Round($heightSpread, 2); tolerance = 2 }
        }
    }

    $footerCandidates = @($objects | Where-Object {
        [string]$_.kind -match 'placeholder|textbox|text' -and
        (Get-PptBoundsNumber $_.bounds "top") -ge ($slideHeight * 0.88)
    })
    if ($footerCandidates.Count -gt 0) {
        $footerTop = ($footerCandidates | ForEach-Object { Get-PptBoundsNumber $_.bounds "top" } | Measure-Object -Minimum).Minimum
        foreach ($component in $componentBackgrounds) {
            $bottom = [double]$component.top + [double]$component.height
            $gap = [double]$footerTop - $bottom
            if ($gap -lt ($requiredFooterGap - 0.25)) {
                $issues += New-PptGeometryIssue "warning" "protected_region_gap_too_small" $slideIndex $component.obj "Component is too close to or enters the footer/page-number protected region." @{ componentId = $component.componentId; actualGap = [Math]::Round($gap, 2); requiredGap = $requiredFooterGap; protectedRegionTop = [Math]::Round([double]$footerTop, 2) }
            }
        }
    }

    $errorCount = @($issues | Where-Object { $_.severity -eq "error" }).Count
    $warningCount = @($issues | Where-Object { $_.severity -eq "warning" }).Count
    $infoCount = @($issues | Where-Object { $_.severity -eq "info" }).Count
    $suggestedTargets = @()
    if ($issues.Count -gt 0) {
        $suggestedTargets += @{
            slideIndex = $slideIndex
            reason = "geometry_issues_found"
            issueCount = $issues.Count
        }
    } elseif ($objects.Count -gt 12) {
        $suggestedTargets += @{
            slideIndex = $slideIndex
            reason = "dense_slide_manual_screenshot_recommended"
            issueCount = 0
        }
    }

    $resultData = @{
        success = $true
        data = @{
            slideIndex = $slideIndex
            ok = ($errorCount -eq 0 -and $warningCount -eq 0)
            issueCount = $issues.Count
            errorCount = $errorCount
            warningCount = $warningCount
            infoCount = $infoCount
            issues = $issues
            slide = $slide
            suggestedVerificationTargets = $suggestedTargets
            visualQaPending = @{
                requiresMultimodal = $true
                status = "not_implemented"
                pendingChecks = @(
                    "rendered_text_overflow",
                    "visual_style_quality",
                    "contrast_by_rendered_pixels",
                    "image_relevance",
                    "theme_consistency"
                )
            }
        }
    }
    $includeObjects = Get-ObjectPropertyValue $options "includeObjects"
    if ([bool]$includeObjects) {
        $resultData.data["objects"] = $objects
    }
    return $resultData
}

function Get-PptTableShape($slide, $tableIndex, $tableName) {
    if ($tableName) { return $slide.Shapes.Item($tableName) }
    $targetIndex = if ($tableIndex) { [int]$tableIndex } else { 1 }
    $tableCount = 0
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $shape = $slide.Shapes.Item($i)
        if ($shape.HasTable) {
            $tableCount++
            if ($tableCount -eq $targetIndex) { return $shape }
        }
    }
    return $null
}

function Set-PptTableCellShapeStyle($cellShape, $style) {
    $applied = @()
    if ($null -eq $cellShape -or $null -eq $style) { return $applied }

    $backgroundColor = Get-ObjectPropertyValue $style "backgroundColor"
    if ($backgroundColor) {
        $bg = Convert-HexColorToRgbInt([string]$backgroundColor)
        if ($null -ne $bg) {
            $cellShape.Fill.Visible = $true
            $cellShape.Fill.Solid()
            $cellShape.Fill.ForeColor.RGB = $bg
            $applied += "backgroundColor"
        }
    }

    $fontColor = Get-ObjectPropertyValue $style "fontColor"
    if ($fontColor) {
        $fc = Convert-HexColorToRgbInt([string]$fontColor)
        if ($null -ne $fc) {
            $cellShape.TextFrame.TextRange.Font.Color.RGB = $fc
            $applied += "fontColor"
        }
    }

    $fontName = Get-ObjectPropertyValue $style "fontName"
    if ($fontName) {
        $cellShape.TextFrame.TextRange.Font.Name = [string]$fontName
        $applied += "fontName"
    }

    $fontSize = Get-ObjectPropertyValue $style "fontSize"
    if ($fontSize) {
        $cellShape.TextFrame.TextRange.Font.Size = [double]$fontSize
        $applied += "fontSize"
    }

    $bold = Get-ObjectPropertyValue $style "bold"
    if ($null -ne $bold) {
        $cellShape.TextFrame.TextRange.Font.Bold = if ([bool]$bold) { -1 } else { 0 }
        $applied += "bold"
    }

    $italic = Get-ObjectPropertyValue $style "italic"
    if ($null -ne $italic) {
        $cellShape.TextFrame.TextRange.Font.Italic = if ([bool]$italic) { -1 } else { 0 }
        $applied += "italic"
    }

    $alignment = Get-ObjectPropertyValue $style "alignment"
    if ($alignment) {
        $alignmentMap = @{ left = 1; center = 2; right = 3 }
        $alignmentValue = $alignmentMap[[string]$alignment]
        if ($null -ne $alignmentValue) {
            $cellShape.TextFrame.TextRange.ParagraphFormat.Alignment = $alignmentValue
            $applied += "alignment"
        }
    }

    $verticalAlignment = Get-ObjectPropertyValue $style "verticalAlignment"
    if ($verticalAlignment) {
        $verticalMap = @{ top = 1; middle = 3; bottom = 4 }
        $verticalValue = $verticalMap[[string]$verticalAlignment]
        if ($null -ne $verticalValue) {
            $cellShape.TextFrame.VerticalAnchor = $verticalValue
            $applied += "verticalAlignment"
        }
    }

    return $applied
}

function Get-PptBatchTarget($obj) {
    if ($null -eq $obj) { return $null }
    # Preserve a frozen identity binding when the compiler provides one.
    # Resolve-PptShape will use native Shape.Id first, verify the expected
    # name, and use the old index only as a legacy fallback.
    if ($null -ne (Get-ObjectPropertyValue $obj "nativeShapeId") -or
        -not [string]::IsNullOrWhiteSpace([string](Get-ObjectPropertyValue $obj "expectedShapeName")) -or
        $null -ne (Get-ObjectPropertyValue $obj "shapeIndexFallback")) {
        return $obj
    }
    $shapeIndex = Get-ObjectPropertyValue $obj "shapeIndex"
    if ($null -ne $shapeIndex) { return $shapeIndex }
    $textboxIndex = Get-ObjectPropertyValue $obj "textboxIndex"
    if ($null -ne $textboxIndex) { return $textboxIndex }
    $textBoxIndex = Get-ObjectPropertyValue $obj "textBoxIndex"
    if ($null -ne $textBoxIndex) { return $textBoxIndex }
    $index = Get-ObjectPropertyValue $obj "index"
    if ($null -ne $index) { return $index }
    $name = Get-ObjectPropertyValue $obj "name"
    if ($name) { return $name }
    $shapeName = Get-ObjectPropertyValue $obj "shapeName"
    if ($shapeName) { return $shapeName }
    return $obj
}

function Get-PptShapeIndexByName($slide, [string]$shapeName) {
    if (-not $shapeName) { return $null }
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        try {
            if ([string]$slide.Shapes.Item($i).Name -eq $shapeName) { return $i }
        } catch {}
    }
    return $null
}

function Get-PptShapeTypeValue($requestedType) {
    $shapeTypeMap = @{
        rectangle = 1
        roundedRectangle = 5
        oval = 9
        triangle = 7
        diamond = 4
        pentagon = 12
        hexagon = 10
        arrow = 33
        rightArrow = 33
        leftArrow = 34
        upArrow = 35
        downArrow = 36
        star = 92
        heart = 21
        cloud = 179
    }
    $typeText = if ($requestedType) { [string]$requestedType } else { "rectangle" }
    $mapped = $shapeTypeMap[$typeText]
    if ($null -ne $mapped) { return $mapped }
    try { return [int]$requestedType } catch { return 1 }
}

function Set-PptShapePositionValues($shape, $source) {
    $applied = @()
    $left = Get-ObjectPropertyValue $source "left"
    if ($null -ne $left) { $shape.Left = [double]$left; $applied += "left" }
    $top = Get-ObjectPropertyValue $source "top"
    if ($null -ne $top) { $shape.Top = [double]$top; $applied += "top" }
    $width = Get-ObjectPropertyValue $source "width"
    if ($null -ne $width) { $shape.Width = [double]$width; $applied += "width" }
    $height = Get-ObjectPropertyValue $source "height"
    if ($null -ne $height) { $shape.Height = [double]$height; $applied += "height" }
    return $applied
}

function Get-PptShapeGeometrySnapshot($shape) {
    return @{
        left = [double]$shape.Left
        top = [double]$shape.Top
        width = [double]$shape.Width
        height = [double]$shape.Height
    }
}

function Restore-PptShapeGeometrySnapshot($shape, $snapshot) {
    if ($null -eq $shape -or $null -eq $snapshot) { return }
    $shape.Left = [double]$snapshot.left
    $shape.Top = [double]$snapshot.top
    $shape.Width = [double]$snapshot.width
    $shape.Height = [double]$snapshot.height
}

function Set-PptTextFrameStyleValues($shape, $style) {
    $applied = @()
    if ($null -eq $shape -or $null -eq $style) { return $applied }

    try {
        $tr = $shape.TextFrame.TextRange

        $fontSize = Get-ObjectPropertyValue $style "fontSize"
        if ($fontSize) { $tr.Font.Size = [double]$fontSize; $applied += "fontSize" }

        $fontName = Get-ObjectPropertyValue $style "fontName"
        if ($fontName) { $tr.Font.Name = [string]$fontName; $applied += "fontName" }

        $bold = Get-ObjectPropertyValue $style "bold"
        if ($null -ne $bold) { $tr.Font.Bold = if ([bool]$bold) { -1 } else { 0 }; $applied += "bold" }

        $italic = Get-ObjectPropertyValue $style "italic"
        if ($null -ne $italic) { $tr.Font.Italic = if ([bool]$italic) { -1 } else { 0 }; $applied += "italic" }

        $color = Get-ObjectPropertyValue $style "fontColor"
        if (-not $color) { $color = Get-ObjectPropertyValue $style "color" }
        if ($color) {
            $colorValue = Convert-HexColorToRgbInt([string]$color)
            if ($null -ne $colorValue) { $tr.Font.Color.RGB = $colorValue; $applied += "fontColor" }
        }

        $alignment = Get-ObjectPropertyValue $style "alignment"
        if (-not $alignment) { $alignment = Get-ObjectPropertyValue $style "align" }
        if (-not $alignment) { $alignment = Get-ObjectPropertyValue $style "horizontalAlignment" }
        if ($alignment) {
            $alignMap = @{ left = 1; center = 2; right = 3 }
            $alignmentValue = $alignMap[[string]$alignment]
            if ($null -ne $alignmentValue) { $tr.ParagraphFormat.Alignment = $alignmentValue; $applied += "alignment" }
        }

        $verticalAlignment = Get-ObjectPropertyValue $style "verticalAlignment"
        if (-not $verticalAlignment) { $verticalAlignment = Get-ObjectPropertyValue $style "verticalAlign" }
        if ($verticalAlignment) {
            $verticalMap = @{ top = 1; middle = 3; center = 3; bottom = 4 }
            $verticalValue = $verticalMap[[string]$verticalAlignment]
            if ($null -ne $verticalValue) { $shape.TextFrame.VerticalAnchor = $verticalValue; $applied += "verticalAlignment" }
        }

        foreach ($marginName in @("marginLeft", "marginRight", "marginTop", "marginBottom")) {
            $value = Get-ObjectPropertyValue $style $marginName
            if ($null -ne $value) {
                try {
                    $shape.TextFrame.$marginName = [double]$value
                    $applied += $marginName
                } catch {}
            }
        }
    } catch {}

    return $applied
}

function Set-PptTextRangeStyleValues($shape, $ranges) {
    $applied = @()
    if ($null -eq $shape) { return $applied }
    $textLength = [int]$shape.TextFrame.TextRange.Length
    foreach ($rangeUpdate in @($ranges)) {
        $start = [int](Get-ObjectPropertyValue $rangeUpdate "start")
        $length = [int](Get-ObjectPropertyValue $rangeUpdate "length")
        if ($start -lt 1 -or $length -lt 1 -or ($start + $length - 1) -gt $textLength) {
            throw "Text range out of bounds: start=$start, length=$length, textLength=$textLength"
        }
        $style = Get-ObjectPropertyValue $rangeUpdate "style"
        $range = $shape.TextFrame.TextRange.Characters($start, $length)
        $range2 = $shape.TextFrame2.TextRange.Characters($start, $length)
        $prefix = "ranges[$start,$length]"

        $fontName = Get-ObjectPropertyValue $style "fontName"
        if ($null -ne $fontName) { $range.Font.Name = [string]$fontName; $applied += "$prefix.fontName" }
        $fontSize = Get-ObjectPropertyValue $style "fontSize"
        if ($null -ne $fontSize) { $range.Font.Size = [double]$fontSize; $applied += "$prefix.fontSize" }
        $fontColor = Get-ObjectPropertyValue $style "fontColor"
        if ($null -ne $fontColor) {
            $rgb = Convert-HexColorToRgbInt([string]$fontColor)
            if ($null -eq $rgb) { throw "Invalid text range fontColor" }
            $range.Font.Color.RGB = $rgb
            $applied += "$prefix.fontColor"
        }
        foreach ($field in @("bold", "italic", "underline", "strikethrough")) {
            $value = Get-ObjectPropertyValue $style $field
            if ($null -eq $value) { continue }
            $nativeValue = if ([bool]$value) { -1 } else { 0 }
            switch ($field) {
                "bold" { $range.Font.Bold = $nativeValue }
                "italic" { $range.Font.Italic = $nativeValue }
                "underline" { $range.Font.Underline = $nativeValue }
                "strikethrough" { $range2.Font.Strike = $(if ([bool]$value) { 1 } else { 0 }) }
            }
            $applied += "$prefix.$field"
        }
        $baseline = Get-ObjectPropertyValue $style "baseline"
        if ($null -ne $baseline) {
            $range.Font.Subscript = $(if ([string]$baseline -eq "subscript") { -1 } else { 0 })
            $range.Font.Superscript = $(if ([string]$baseline -eq "superscript") { -1 } else { 0 })
            $applied += "$prefix.baseline"
        }
        $characterSpacing = Get-ObjectPropertyValue $style "characterSpacing"
        if ($null -ne $characterSpacing) {
            $range2.Font.Spacing = [double]$characterSpacing
            $applied += "$prefix.characterSpacing"
        }
    }
    return $applied
}

function Set-PptParagraphStyleValues($shape, $paragraphs) {
    $applied = @()
    if ($null -eq $shape) { return $applied }
    $paragraphCount = [int]$shape.TextFrame.TextRange.Paragraphs().Count
    foreach ($paragraphUpdate in @($paragraphs)) {
        $index = [int](Get-ObjectPropertyValue $paragraphUpdate "index")
        if ($index -lt 1 -or $index -gt $paragraphCount) {
            throw "Paragraph index out of bounds: index=$index, paragraphCount=$paragraphCount"
        }
        $style = Get-ObjectPropertyValue $paragraphUpdate "style"
        $format = $shape.TextFrame.TextRange.Paragraphs($index, 1).ParagraphFormat
        $prefix = "paragraphs[$index]"

        $alignment = Get-ObjectPropertyValue $style "alignment"
        if ($null -ne $alignment) {
            $map = @{ left = 1; center = 2; right = 3; justify = 4 }
            $nativeValue = $map[[string]$alignment]
            if ($null -eq $nativeValue) { throw "Unsupported paragraph alignment '$alignment'" }
            $format.Alignment = $nativeValue
            $applied += "$prefix.alignment"
        }
        foreach ($field in @("spaceBefore", "spaceAfter", "lineSpacing")) {
            $value = Get-ObjectPropertyValue $style $field
            if ($null -eq $value) { continue }
            switch ($field) {
                "spaceBefore" { $format.SpaceBefore = [double]$value }
                "spaceAfter" { $format.SpaceAfter = [double]$value }
                "lineSpacing" { $format.SpaceWithin = [double]$value }
            }
            $applied += "$prefix.$field"
        }
        $bullet = Get-ObjectPropertyValue $style "bullet"
        if ($null -ne $bullet) {
            $kind = [string](Get-ObjectPropertyValue $bullet "kind")
            switch ($kind) {
                "none" { $format.Bullet.Visible = 0 }
                "bullet" {
                    $format.Bullet.Visible = -1
                    $format.Bullet.Type = 1
                    $character = [string](Get-ObjectPropertyValue $bullet "character")
                    if (-not [string]::IsNullOrEmpty($character)) { $format.Bullet.Character = [int][char]$character[0] }
                }
                "number" {
                    $format.Bullet.Visible = -1
                    $format.Bullet.Type = 2
                    $startAt = Get-ObjectPropertyValue $bullet "startAt"
                    if ($null -ne $startAt) { $format.Bullet.StartValue = [int]$startAt }
                }
                default { throw "Unsupported paragraph bullet kind '$kind'" }
            }
            $applied += "$prefix.bullet"
        }
    }
    return $applied
}

function Set-PptTextFrameValues($shape, $frame) {
    $applied = @()
    if ($null -eq $shape -or $null -eq $frame) { return $applied }
    foreach ($field in @("marginLeft", "marginRight", "marginTop", "marginBottom")) {
        $value = Get-ObjectPropertyValue $frame $field
        if ($null -eq $value) { continue }
        $shape.TextFrame.$field = [double]$value
        $applied += $field
    }
    $verticalAlignment = Get-ObjectPropertyValue $frame "verticalAlignment"
    if ($null -ne $verticalAlignment) {
        $map = @{ top = 1; middle = 3; bottom = 4 }
        $nativeValue = $map[[string]$verticalAlignment]
        if ($null -eq $nativeValue) { throw "Unsupported vertical alignment '$verticalAlignment'" }
        $shape.TextFrame.VerticalAnchor = $nativeValue
        $applied += "verticalAlignment"
    }
    $autoFit = Get-ObjectPropertyValue $frame "autoFit"
    if ($null -ne $autoFit) {
        $map = @{ none = 0; fit_shape_to_text = 1; shrink_text_on_overflow = 2 }
        $nativeValue = $map[[string]$autoFit]
        if ($null -eq $nativeValue) { throw "Unsupported text autoFit '$autoFit'" }
        $shape.TextFrame.AutoSize = $nativeValue
        $applied += "autoFit"
    }
    $wordWrap = Get-ObjectPropertyValue $frame "wordWrap"
    if ($null -ne $wordWrap) {
        $shape.TextFrame.WordWrap = $(if ([bool]$wordWrap) { -1 } else { 0 })
        $applied += "wordWrap"
    }
    return $applied
}

function Set-PptShapeStyleValues($shape, $style) {
    $applied = @()
    if ($null -eq $shape -or $null -eq $style) { return $applied }

    $fillColor = Get-ObjectPropertyValue $style "fillColor"
    if (-not $fillColor) { $fillColor = Get-ObjectPropertyValue $style "backgroundColor" }
    if ($fillColor) {
        $rgb = Convert-HexColorToRgbInt([string]$fillColor)
        if ($null -ne $rgb) {
            $shape.Fill.Visible = $true
            $shape.Fill.Solid()
            $shape.Fill.ForeColor.RGB = $rgb
            $applied += "fillColor"
        }
    }

    $lineColor = Get-ObjectPropertyValue $style "lineColor"
    if (-not $lineColor) { $lineColor = Get-ObjectPropertyValue $style "borderColor" }
    if ($lineColor) {
        $rgb = Convert-HexColorToRgbInt([string]$lineColor)
        if ($null -ne $rgb) { $shape.Line.ForeColor.RGB = $rgb; $applied += "lineColor" }
    }

    $lineWidth = Get-ObjectPropertyValue $style "lineWidth"
    if ($null -eq $lineWidth) { $lineWidth = Get-ObjectPropertyValue $style "borderWidth" }
    if ($null -ne $lineWidth) { $shape.Line.Weight = [double]$lineWidth; $applied += "lineWidth" }

    $transparency = Get-ObjectPropertyValue $style "transparency"
    if ($null -eq $transparency) { $transparency = Get-ObjectPropertyValue $style "fillTransparency" }
    if ($null -ne $transparency) { $shape.Fill.Transparency = [double]$transparency; $applied += "transparency" }

    $lineTransparency = Get-ObjectPropertyValue $style "lineTransparency"
    if ($null -ne $lineTransparency) {
        $shape.Line.Transparency = [double]$lineTransparency
        $applied += "lineTransparency"
    }

    $lineDashStyle = Get-ObjectPropertyValue $style "lineDashStyle"
    if ($null -ne $lineDashStyle) {
        $dashMap = @{ solid = 1; dash = 4 }
        $nativeDashStyle = $dashMap[[string]$lineDashStyle]
        if ($null -eq $nativeDashStyle) { throw "Unsupported shape line dash style '$lineDashStyle'" }
        $shape.Line.DashStyle = [int]$nativeDashStyle
        $applied += "lineDashStyle"
    }

    $text = Get-ObjectPropertyValue $style "text"
    if ($null -ne $text) { $shape.TextFrame.TextRange.Text = [string]$text; $applied += "text" }

    $applied += Set-PptShapePositionValues $shape $style
    $textStyle = Get-ObjectPropertyValue $style "textStyle"
    if ($null -eq $textStyle) { $textStyle = $style }
    $applied += Set-PptTextFrameStyleValues $shape $textStyle

    return @($applied | Select-Object -Unique)
}

function Set-PptPictureStyleValues($shape, $style) {
    $applied = @()
    if ($null -eq $shape -or $null -eq $style) { return $applied }
    $borderColor = Get-ObjectPropertyValue $style "borderColor"
    if ($borderColor) {
        $rgb = Convert-HexColorToRgbInt ([string]$borderColor)
        if ($null -ne $rgb) {
            $shape.Line.Visible = $true
            $shape.Line.ForeColor.RGB = $rgb
            $applied += "borderColor"
        }
    }
    $borderWidth = Get-ObjectPropertyValue $style "borderWidth"
    if ($null -ne $borderWidth) {
        $shape.Line.Weight = [double]$borderWidth
        $applied += "borderWidth"
    }
    foreach ($field in @("cropLeft", "cropTop", "cropRight", "cropBottom")) {
        $value = Get-ObjectPropertyValue $style $field
        if ($null -eq $value) { continue }
        $nativeField = $field.Substring(0, 1).ToUpper() + $field.Substring(1)
        $shape.PictureFormat.$nativeField = [double]$value
        $applied += $field
    }
    $rotation = Get-ObjectPropertyValue $style "rotation"
    if ($null -ne $rotation) {
        $shape.Rotation = [double]$rotation
        $applied += "rotation"
    }
    $colorMode = Get-ObjectPropertyValue $style "colorMode"
    if ($null -ne $colorMode) {
        $colorTypeMap = @{ automatic = 1; grayscale = 2 }
        $nativeColorType = $colorTypeMap[[string]$colorMode]
        if ($null -eq $nativeColorType) { throw "Unsupported picture color mode '$colorMode'" }
        $shape.PictureFormat.ColorType = [int]$nativeColorType
        $applied += "colorMode"
    }
    return $applied
}

function Set-PptConnectorStyleValues($shape, $style) {
    $applied = @()
    if ($null -eq $shape -or $null -eq $style) { return $applied }
    $lineColor = Get-ObjectPropertyValue $style "lineColor"
    if ($lineColor) {
        $rgb = Convert-HexColorToRgbInt ([string]$lineColor)
        if ($null -ne $rgb) {
            $shape.Line.ForeColor.RGB = $rgb
            $applied += "lineColor"
        }
    }
    $lineWidth = Get-ObjectPropertyValue $style "lineWidth"
    if ($null -ne $lineWidth) {
        $shape.Line.Weight = [double]$lineWidth
        $applied += "lineWidth"
    }
    $transparency = Get-ObjectPropertyValue $style "transparency"
    if ($null -ne $transparency) {
        $shape.Line.Transparency = [double]$transparency
        $applied += "transparency"
    }
    foreach ($field in @("beginArrow", "endArrow")) {
        $value = Get-ObjectPropertyValue $style $field
        if ($null -eq $value) { continue }
        $arrowMap = @{
            none = 1
            triangle = 2
            open = 3
            stealth = 4
            diamond = 5
            oval = 6
        }
        $nativeValue = $arrowMap[[string]$value]
        if ($null -eq $nativeValue) { throw "Unsupported connector arrow style '$value'" }
        if ($field -eq "beginArrow") { $shape.Line.BeginArrowheadStyle = $nativeValue }
        else { $shape.Line.EndArrowheadStyle = $nativeValue }
        $applied += $field
    }
    return $applied
}

function Set-PptConnectorRouteValues($slide, $shape, $values) {
    $applied = @()
    if ($null -eq $slide -or $null -eq $shape -or $null -eq $values) { return $applied }
    foreach ($endpointName in @("begin", "end")) {
        $endpoint = Get-ObjectPropertyValue $values $endpointName
        if ($null -eq $endpoint) { continue }
        $endpointTarget = Get-ObjectPropertyValue $endpoint "target"
        $resolvedEndpoint = Resolve-PptShape $slide $endpointTarget "setConnectorRoute" "connector endpoint"
        if (-not $resolvedEndpoint.ok) { throw $resolvedEndpoint.result.error }
        $site = [int](Get-ObjectPropertyValue $endpoint "site")
        if ($site -lt 1) { throw "Connector endpoint site must be a positive integer" }
        if ($endpointName -eq "begin") {
            try { $shape.ConnectorFormat.BeginDisconnect() } catch {}
            $shape.ConnectorFormat.BeginConnect($resolvedEndpoint.shape, $site)
        } else {
            try { $shape.ConnectorFormat.EndDisconnect() } catch {}
            $shape.ConnectorFormat.EndConnect($resolvedEndpoint.shape, $site)
        }
        $applied += $endpointName
    }
    $routeType = Get-ObjectPropertyValue $values "routeType"
    if ($null -ne $routeType) {
        $routeTypeMap = @{ straight = 1; elbow = 2 }
        $nativeRouteType = $routeTypeMap[[string]$routeType]
        if ($null -eq $nativeRouteType) { throw "Unsupported connector route type '$routeType'" }
        $shape.ConnectorFormat.Type = [int]$nativeRouteType
        $applied += "routeType"
    }
    if ($applied.Count -gt 0) { $shape.RerouteConnections() }
    return $applied
}

function Set-PptTableDataValues($tableShape, $data, $startRow, $startCol) {
    $written = @()
    $failed = @()
    if ($null -eq $tableShape -or -not $tableShape.HasTable) {
        return @{ written = $written; failed = @(@{ error = "Table not found" }) }
    }
    if ($null -eq $data) {
        return @{ written = $written; failed = @(@{ error = "Missing data" }) }
    }

    $rowStart = if ($startRow) { [int]$startRow } else { 1 }
    $colStart = if ($startCol) { [int]$startCol } else { 1 }
    $rows = @($data)

    for ($r = 0; $r -lt $rows.Count; $r++) {
        $rowValues = @($rows[$r])
        for ($c = 0; $c -lt $rowValues.Count; $c++) {
            $targetRow = $rowStart + $r
            $targetCol = $colStart + $c
            try {
                if ($targetRow -lt 1 -or $targetRow -gt $tableShape.Table.Rows.Count -or $targetCol -lt 1 -or $targetCol -gt $tableShape.Table.Columns.Count) {
                    throw "Cell ($targetRow,$targetCol) is out of table range"
                }
                $textValue = if ($null -ne $rowValues[$c]) { [string]$rowValues[$c] } else { "" }
                $tableShape.Table.Cell($targetRow, $targetCol).Shape.TextFrame.TextRange.Text = $textValue
                $written += @{ row = $targetRow; col = $targetCol; text = $textValue }
            } catch {
                $failed += @{ row = $targetRow; col = $targetCol; error = $_.Exception.Message }
            }
        }
    }

    return @{ written = $written; failed = $failed }
}

function Add-PptBatchShape($slide, $op) {
    $requestedType = Get-ObjectPropertyValue $op "type"
    if (-not $requestedType) { $requestedType = Get-ObjectPropertyValue $op "shapeType" }
    $shapeType = Get-PptShapeTypeValue $requestedType
    $left = if ($null -ne (Get-ObjectPropertyValue $op "left")) { [double](Get-ObjectPropertyValue $op "left") } else { 100 }
    $top = if ($null -ne (Get-ObjectPropertyValue $op "top")) { [double](Get-ObjectPropertyValue $op "top") } else { 100 }
    $width = if ($null -ne (Get-ObjectPropertyValue $op "width")) { [double](Get-ObjectPropertyValue $op "width") } else { 100 }
    $height = if ($null -ne (Get-ObjectPropertyValue $op "height")) { [double](Get-ObjectPropertyValue $op "height") } else { 100 }
    $shape = $slide.Shapes.AddShape($shapeType, $left, $top, $width, $height)
    $text = Get-ObjectPropertyValue $op "text"
    if ($null -ne $text) { $shape.TextFrame.TextRange.Text = [string]$text }
    $name = Get-ObjectPropertyValue $op "name"
    if ($name) { try { $shape.Name = [string]$name } catch {} }
    $style = Get-ObjectPropertyValue $op "style"
    if ($null -eq $style) { $style = $op }
    $applied = Set-PptShapeStyleValues $shape $style
    return @{ shape = $shape; applied = $applied; shapeType = $shapeType }
}

function Add-PptBatchTextbox($slide, $op) {
    $left = if ($null -ne (Get-ObjectPropertyValue $op "left")) { [double](Get-ObjectPropertyValue $op "left") } else { 100 }
    $top = if ($null -ne (Get-ObjectPropertyValue $op "top")) { [double](Get-ObjectPropertyValue $op "top") } else { 100 }
    $width = if ($null -ne (Get-ObjectPropertyValue $op "width")) { [double](Get-ObjectPropertyValue $op "width") } else { 400 }
    $height = if ($null -ne (Get-ObjectPropertyValue $op "height")) { [double](Get-ObjectPropertyValue $op "height") } else { 50 }
    $shape = $slide.Shapes.AddTextbox(1, $left, $top, $width, $height)
    $text = Get-ObjectPropertyValue $op "text"
    if ($null -ne $text) { $shape.TextFrame.TextRange.Text = [string]$text }
    $name = Get-ObjectPropertyValue $op "name"
    if ($name) { try { $shape.Name = [string]$name } catch {} }
    $style = Get-ObjectPropertyValue $op "style"
    if ($null -eq $style) { $style = $op }
    $applied = Set-PptTextFrameStyleValues $shape $style
    return @{ shape = $shape; applied = $applied }
}

function Add-PptBatchImage($slide, $op) {
    $pathValue = Get-ObjectPropertyValue $op "path"
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $op "filePath" }
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $op "imagePath" }
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $op "localPath" }
    if (-not $pathValue) { throw "Missing image path/filePath/localPath" }
    $left = if ($null -ne (Get-ObjectPropertyValue $op "left")) { [double](Get-ObjectPropertyValue $op "left") } else { 100 }
    $top = if ($null -ne (Get-ObjectPropertyValue $op "top")) { [double](Get-ObjectPropertyValue $op "top") } else { 100 }
    $width = if ($null -ne (Get-ObjectPropertyValue $op "width")) { [double](Get-ObjectPropertyValue $op "width") } else { -1 }
    $height = if ($null -ne (Get-ObjectPropertyValue $op "height")) { [double](Get-ObjectPropertyValue $op "height") } else { -1 }
    $pic = $slide.Shapes.AddPicture([string]$pathValue, $false, $true, $left, $top, $width, $height)
    $name = Get-ObjectPropertyValue $op "name"
    if ($name) { try { $pic.Name = [string]$name } catch {} }
    return @{ shape = $pic; path = [string]$pathValue }
}

function Get-PptTemplateShapeTarget($item) {
    if ($null -eq $item) { return $null }
    $shapeName = Get-ObjectPropertyValue $item "shapeName"
    if (-not $shapeName) { $shapeName = Get-ObjectPropertyValue $item "name" }
    if ($shapeName) { return $shapeName }
    $shapeIndex = Get-ObjectPropertyValue $item "shapeIndex"
    if ($null -ne $shapeIndex) { return [int]$shapeIndex }
    $slotId = Get-ObjectPropertyValue $item "slotId"
    if ($slotId -and ([string]$slotId -match "shape:(\d+)$")) { return [int]$matches[1] }
    return $null
}

function Find-PptTemplateSlotShape($pres, [int]$slideIndex, $item, [string]$slotKind) {
    $slide = $pres.Slides.Item($slideIndex)
    $target = Get-PptTemplateShapeTarget $item
    if ($null -ne $target) {
        try { return @{ shape = $slide.Shapes.Item($target); target = $target; role = $null } } catch {}
    }

    $role = Get-ObjectPropertyValue $item "role"
    if (-not $role) { $role = Get-ObjectPropertyValue $item "slotType" }
    if (-not $role -and $slotKind) { $role = $slotKind }
    if (-not $role) { return $null }

    $structureResult = Get-PptSlideStructureResult $pres $slideIndex "structure"
    if (-not $structureResult.success) { return $null }
    foreach ($obj in @($structureResult.data.objects)) {
        $objRole = [string]$obj.role
        $slotType = Get-PptTemplateSlotType $obj
        if ($objRole -eq [string]$role -or $slotType -eq [string]$role) {
            try { return @{ shape = $slide.Shapes.Item([int]$obj.shapeIndex); target = [int]$obj.shapeIndex; role = $role } } catch {}
        }
    }
    return $null
}

function Set-PptTemplateTextReplacements($pres, [int]$slideIndex, $items) {
    $changed = @()
    $failed = @()
    foreach ($item in @($items)) {
        try {
            $textValue = Get-ObjectPropertyValue $item "text"
            if ($null -eq $textValue) { $textValue = Get-ObjectPropertyValue $item "value" }
            if ($null -eq $textValue) { $textValue = "" }
            $resolved = Find-PptTemplateSlotShape $pres $slideIndex $item "text"
            if ($null -eq $resolved -or $null -eq $resolved.shape) { throw "Text slot not found" }
            $resolved.shape.TextFrame.TextRange.Text = [string]$textValue
            $changed += @{
                kind = "text"
                target = $resolved.target
                shapeName = $resolved.shape.Name
                objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $pres.Slides.Item($slideIndex) $resolved.shape.Name)"
                text = [string]$textValue
            }
        } catch {
            $failed += @{ kind = "text"; target = (Get-PptTemplateShapeTarget $item); role = (Get-ObjectPropertyValue $item "role"); error = $_.Exception.Message }
        }
    }
    return @{ changed = $changed; failed = $failed }
}

function Set-PptTemplateTableReplacements($pres, [int]$slideIndex, $items) {
    $changed = @()
    $failed = @()
    $slide = $pres.Slides.Item($slideIndex)
    foreach ($item in @($items)) {
        try {
            $data = Get-ObjectPropertyValue $item "data"
            if ($null -eq $data) { throw "Missing table replacement data" }
            $tableName = Get-ObjectPropertyValue $item "tableName"
            if (-not $tableName) { $tableName = Get-ObjectPropertyValue $item "shapeName" }
            $tableIndex = Get-ObjectPropertyValue $item "tableIndex"
            if ($null -eq $tableIndex) {
                $target = Get-PptTemplateShapeTarget $item
                if ($target -is [int]) {
                    try {
                        $shape = $slide.Shapes.Item($target)
                        if ($shape.HasTable) { $tableName = $shape.Name }
                    } catch {}
                }
            }
            $shape = Get-PptTableShape $slide $tableIndex $tableName
            if ($null -eq $shape -or -not $shape.HasTable) { throw "Table slot not found" }
            $dataResult = Set-PptTableDataValues $shape $data 1 1
            $changed += @{
                kind = "table"
                shapeName = $shape.Name
                objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $shape.Name)"
                written = $dataResult.written
                failedCells = $dataResult.failed
            }
            foreach ($cellFailure in @($dataResult.failed)) {
                $failed += @{ kind = "tableCell"; shapeName = $shape.Name; error = $cellFailure.error; row = $cellFailure.row; col = $cellFailure.col }
            }
        } catch {
            $failed += @{ kind = "table"; target = (Get-PptTemplateShapeTarget $item); tableName = (Get-ObjectPropertyValue $item "tableName"); error = $_.Exception.Message }
        }
    }
    return @{ changed = $changed; failed = $failed }
}

function Set-PptTemplateImageReplacements($pres, [int]$slideIndex, $items) {
    $created = @()
    $changed = @()
    $failed = @()
    $slide = $pres.Slides.Item($slideIndex)
    foreach ($item in @($items)) {
        try {
            $pathValue = Get-ObjectPropertyValue $item "path"
            if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $item "localPath" }
            if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $item "filePath" }
            if (-not $pathValue) { throw "Missing image path/localPath/filePath" }
            $resolved = Find-PptTemplateSlotShape $pres $slideIndex $item "image"
            if ($null -eq $resolved -or $null -eq $resolved.shape) { throw "Image slot not found" }
            $oldShape = $resolved.shape
            $left = [double]$oldShape.Left
            $top = [double]$oldShape.Top
            $width = [double]$oldShape.Width
            $height = [double]$oldShape.Height
            $oldName = $oldShape.Name
            $newPic = $slide.Shapes.AddPicture([string]$pathValue, $false, $true, $left, $top, $width, $height)
            try { $newPic.Name = ([string](Get-PptR4Value $item "name" ($oldName + "_replacement"))) } catch {}
            try { $oldShape.Delete() } catch {}
            $created += @{
                kind = "picture"
                oldShapeName = $oldName
                shapeName = $newPic.Name
                path = [string]$pathValue
                objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $newPic.Name)"
                bounds = @{ left = $left; top = $top; width = $width; height = $height }
            }
            $changed += @{ kind = "image"; oldShapeName = $oldName; newShapeName = $newPic.Name }
        } catch {
            $failed += @{ kind = "image"; target = (Get-PptTemplateShapeTarget $item); error = $_.Exception.Message }
        }
    }
    return @{ created = $created; changed = $changed; failed = $failed }
}

function Get-PptTemplatePreservationReport($sourceStructure, $newStructure) {
    $warnings = @()
    $sourceSlide = $sourceStructure.slide
    $newSlide = $newStructure.slide
    if ([int]$sourceSlide.layout -ne [int]$newSlide.layout) {
        $warnings += @{ warningType = "layout_changed"; message = "Copied slide layout differs from source template."; sourceLayout = $sourceSlide.layout; newLayout = $newSlide.layout }
    }
    $sourceCount = [int]$sourceSlide.objectCount
    $newCount = [int]$newSlide.objectCount
    if ([Math]::Abs($sourceCount - $newCount) -gt 1) {
        $warnings += @{ warningType = "object_count_changed"; message = "Object count changed significantly after template insertion."; sourceObjectCount = $sourceCount; newObjectCount = $newCount }
    }
    foreach ($sourceObj in @($sourceStructure.objects)) {
        $match = $null
        foreach ($newObj in @($newStructure.objects)) {
            if ([int]$newObj.shapeIndex -eq [int]$sourceObj.shapeIndex) { $match = $newObj; break }
        }
        if ($null -eq $match) { continue }
        $sb = $sourceObj.bounds
        $nb = $match.bounds
        $delta = [Math]::Abs([double]$sb.left - [double]$nb.left) + [Math]::Abs([double]$sb.top - [double]$nb.top) + [Math]::Abs([double]$sb.width - [double]$nb.width) + [Math]::Abs([double]$sb.height - [double]$nb.height)
        if ($delta -gt 4) {
            $warnings += @{ warningType = "slot_geometry_changed"; message = "A copied template slot moved or resized unexpectedly."; shapeIndex = $sourceObj.shapeIndex; sourceBounds = $sb; newBounds = $nb }
        }
    }
    return @{
        ok = ($warnings.Count -eq 0)
        warningCount = $warnings.Count
        warnings = $warnings
        preserved = @{
            layout = ([int]$sourceSlide.layout -eq [int]$newSlide.layout)
            approximateObjectCount = ([Math]::Abs($sourceCount - $newCount) -le 1)
        }
    }
}

function Get-PptR4Value($obj, [string]$name, $fallback) {
    $value = Get-ObjectPropertyValue $obj $name
    if ($null -eq $value) { return $fallback }
    if ($value -is [string] -and [string]::IsNullOrWhiteSpace($value)) { return $fallback }
    return $value
}

function Get-PptR4Number($obj, [string]$name, [double]$fallback) {
    $value = Get-ObjectPropertyValue $obj $name
    if ($null -eq $value) { return $fallback }
    try { return [double]$value } catch { return $fallback }
}

function Normalize-PptR4FontName([string]$fontName) {
    if ([string]::IsNullOrWhiteSpace($fontName)) { return "Microsoft YaHei" }
    $normalized = $fontName.Trim()
    $compact = $normalized.Replace(" ", "").ToLowerInvariant()
    $fontAliases = @{
        microsoftyahei = "Microsoft YaHei"
        msyh = "Microsoft YaHei"
        yahei = "Microsoft YaHei"
        "微软雅黑" = "Microsoft YaHei"
        simhei = "SimHei"
        "黑体" = "SimHei"
        simsun = "SimSun"
        "宋体" = "SimSun"
        dengxian = "DengXian"
        "等线" = "DengXian"
    }
    if ($fontAliases.ContainsKey($compact)) { return $fontAliases[$compact] }
    return $normalized
}

function Get-PptR4PaletteColors([string]$paletteId) {
    $normalized = if ([string]::IsNullOrWhiteSpace($paletteId)) { "modern_investment_steel" } else { $paletteId.Trim().ToLower().Replace("-", "_").Replace(" ", "_") }
    switch ($normalized) {
        "silk_road_jade_sand" {
            return @{ paletteId = "silk_road_jade_sand"; paletteName = "丝路玉石沙色"; primary = "#245C4F"; secondary = "#8A5A44"; accent = "#C47A3D"; background = "#F6EFE3"; surface = "#FFFCF7"; surfaceAlt = "#EFE3D0"; surfaceTint = "#E7F0E9"; text = "#1F2933"; mutedText = "#667085"; border = "#D8C7A3"; line = "#CDBA9D"; title = "#183C35"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#D9B06D"; tableHeader = "#245C4F"; tableAltRow = "#F3E8D8"; imageOverlay = "#183C35" }
        }
        "snow_lake_pine" {
            return @{ paletteId = "snow_lake_pine"; paletteName = "雪山湖泊松绿"; primary = "#1E5B67"; secondary = "#2F6B4F"; accent = "#7DB6D8"; background = "#F4FAFB"; surface = "#FFFFFF"; surfaceAlt = "#E7F3F7"; surfaceTint = "#EAF6F1"; text = "#15313A"; mutedText = "#5D7380"; border = "#BFDDE8"; line = "#A9CBD8"; title = "#123B45"; onPrimary = "#FFFFFF"; onAccent = "#15313A"; badgeFill = "#DCEFF6"; tableHeader = "#1E5B67"; tableAltRow = "#EDF7FA"; imageOverlay = "#123B45" }
        }
        "desert_sunset_turquoise" {
            return @{ paletteId = "desert_sunset_turquoise"; paletteName = "沙漠日落绿松石"; primary = "#8A3F2D"; secondary = "#2A6F73"; accent = "#00A6A6"; background = "#FBF1E6"; surface = "#FFF9F2"; surfaceAlt = "#F6DFC8"; surfaceTint = "#E5F3F2"; text = "#2F241F"; mutedText = "#7A6256"; border = "#E2B992"; line = "#D49A70"; title = "#6E2F22"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#F2C08D"; tableHeader = "#8A3F2D"; tableAltRow = "#F8E5D2"; imageOverlay = "#4F2A24" }
        }
        "grassland_sky" {
            return @{ paletteId = "grassland_sky"; paletteName = "草原天空"; primary = "#2F6B4F"; secondary = "#3D7FA6"; accent = "#6BB7D6"; background = "#F3F8EF"; surface = "#FFFFFF"; surfaceAlt = "#E5F1DE"; surfaceTint = "#E7F3FA"; text = "#1F2D24"; mutedText = "#5D725F"; border = "#C9DEC7"; line = "#B7D0B5"; title = "#244F3A"; onPrimary = "#FFFFFF"; onAccent = "#15313A"; badgeFill = "#D8EBCF"; tableHeader = "#2F6B4F"; tableAltRow = "#ECF5E8"; imageOverlay = "#1F3D2D" }
        }
        "heritage_crimson_ink" {
            return @{ paletteId = "heritage_crimson_ink"; paletteName = "古城朱砂墨色"; primary = "#4A1F24"; secondary = "#2D2424"; accent = "#B64A3A"; background = "#F6EFE8"; surface = "#FFFDFC"; surfaceAlt = "#EFE0D7"; surfaceTint = "#F7E8E5"; text = "#241A1A"; mutedText = "#6C5B57"; border = "#D8B8A9"; line = "#CFA08F"; title = "#3A171B"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#E7B8A8"; tableHeader = "#4A1F24"; tableAltRow = "#F3E4DD"; imageOverlay = "#2D2424" }
        }
        "modern_investment_steel" {
            return @{ paletteId = "modern_investment_steel"; paletteName = "现代招商钢蓝"; primary = "#253746"; secondary = "#52616B"; accent = "#4F8AA8"; background = "#F6F8FA"; surface = "#FFFFFF"; surfaceAlt = "#EEF2F5"; surfaceTint = "#E9F2F7"; text = "#1F2933"; mutedText = "#667085"; border = "#D5DCE5"; line = "#C2CDD8"; title = "#253746"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#DCE8EF"; tableHeader = "#253746"; tableAltRow = "#F0F4F7"; imageOverlay = "#1F2933" }
        }
        "tech_clean_cyan" {
            return @{ paletteId = "tech_clean_cyan"; paletteName = "科技清透青蓝"; primary = "#14213D"; secondary = "#264653"; accent = "#00A6B4"; background = "#F7FAFC"; surface = "#FFFFFF"; surfaceAlt = "#EAF1F7"; surfaceTint = "#E7FAFC"; text = "#111827"; mutedText = "#6B7280"; border = "#CAD5E2"; line = "#B7C6D8"; title = "#14213D"; onPrimary = "#FFFFFF"; onAccent = "#061B20"; badgeFill = "#D7F5F7"; tableHeader = "#14213D"; tableAltRow = "#EFF6FA"; imageOverlay = "#14213D" }
        }
        "medical_teal_clean" {
            return @{ paletteId = "medical_teal_clean"; paletteName = "医疗洁净青绿"; primary = "#0F766E"; secondary = "#2A9D8F"; accent = "#63C7B2"; background = "#F4FBFA"; surface = "#FFFFFF"; surfaceAlt = "#E5F5F2"; surfaceTint = "#EDF8F6"; text = "#113532"; mutedText = "#5B716E"; border = "#BFE4DD"; line = "#A7D6CD"; title = "#0D5E58"; onPrimary = "#FFFFFF"; onAccent = "#103B37"; badgeFill = "#D4F1EC"; tableHeader = "#0F766E"; tableAltRow = "#ECF8F6"; imageOverlay = "#0D3F3B" }
        }
        "academic_ink_blue" {
            return @{ paletteId = "academic_ink_blue"; paletteName = "教育墨蓝"; primary = "#243B53"; secondary = "#486581"; accent = "#3E7CB1"; background = "#F5F7FA"; surface = "#FFFFFF"; surfaceAlt = "#EAF0F7"; surfaceTint = "#EDF5FB"; text = "#102A43"; mutedText = "#627D98"; border = "#D9E2EC"; line = "#C6D3E1"; title = "#243B53"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#D8E8F5"; tableHeader = "#243B53"; tableAltRow = "#EEF4F9"; imageOverlay = "#102A43" }
        }
        default {
            return @{ paletteId = "modern_investment_steel"; paletteName = "现代招商钢蓝"; primary = "#253746"; secondary = "#52616B"; accent = "#4F8AA8"; background = "#F6F8FA"; surface = "#FFFFFF"; surfaceAlt = "#EEF2F5"; surfaceTint = "#E9F2F7"; text = "#1F2933"; mutedText = "#667085"; border = "#D5DCE5"; line = "#C2CDD8"; title = "#253746"; onPrimary = "#FFFFFF"; onAccent = "#FFFFFF"; badgeFill = "#DCE8EF"; tableHeader = "#253746"; tableAltRow = "#F0F4F7"; imageOverlay = "#1F2933" }
        }
    }
}

function Get-PptR4VisualSystem($source) {
    $colors = Get-ObjectPropertyValue $source "colors"
    $paletteId = [string](Get-PptR4Value $source "paletteId" (Get-PptR4Value $source "visualPaletteId" "modern_investment_steel"))
    $palette = Get-PptR4PaletteColors $paletteId
    return @{
        name = [string](Get-PptR4Value $source "name" (Get-PptR4Value $palette "paletteName" "default"))
        paletteId = [string](Get-PptR4Value $palette "paletteId" "modern_investment_steel")
        paletteName = [string](Get-PptR4Value $palette "paletteName" "现代招商钢蓝")
        primary = [string](Get-PptR4Value $colors "primary" (Get-PptR4Value $source "primary" $palette.primary))
        secondary = [string](Get-PptR4Value $colors "secondary" (Get-PptR4Value $source "secondary" $palette.secondary))
        accent = [string](Get-PptR4Value $colors "accent" (Get-PptR4Value $source "accent" $palette.accent))
        background = [string](Get-PptR4Value $colors "background" (Get-PptR4Value $source "background" $palette.background))
        surface = [string](Get-PptR4Value $colors "surface" (Get-PptR4Value $source "surface" $palette.surface))
        surfaceAlt = [string](Get-PptR4Value $colors "surfaceAlt" (Get-PptR4Value $source "surfaceAlt" $palette.surfaceAlt))
        surfaceTint = [string](Get-PptR4Value $colors "surfaceTint" (Get-PptR4Value $source "surfaceTint" $palette.surfaceTint))
        text = [string](Get-PptR4Value $colors "text" (Get-PptR4Value $source "text" $palette.text))
        mutedText = [string](Get-PptR4Value $colors "mutedText" (Get-PptR4Value $source "mutedText" $palette.mutedText))
        border = [string](Get-PptR4Value $colors "border" (Get-PptR4Value $source "border" $palette.border))
        line = [string](Get-PptR4Value $colors "line" (Get-PptR4Value $source "line" $palette.line))
        title = [string](Get-PptR4Value $colors "title" (Get-PptR4Value $source "title" $palette.title))
        onPrimary = [string](Get-PptR4Value $colors "onPrimary" (Get-PptR4Value $source "onPrimary" $palette.onPrimary))
        onAccent = [string](Get-PptR4Value $colors "onAccent" (Get-PptR4Value $source "onAccent" $palette.onAccent))
        badgeFill = [string](Get-PptR4Value $colors "badgeFill" (Get-PptR4Value $source "badgeFill" $palette.badgeFill))
        tableHeader = [string](Get-PptR4Value $colors "tableHeader" (Get-PptR4Value $source "tableHeader" $palette.tableHeader))
        tableAltRow = [string](Get-PptR4Value $colors "tableAltRow" (Get-PptR4Value $source "tableAltRow" $palette.tableAltRow))
        imageOverlay = [string](Get-PptR4Value $colors "imageOverlay" (Get-PptR4Value $source "imageOverlay" $palette.imageOverlay))
        fontName = Normalize-PptR4FontName ([string](Get-PptR4Value $source "fontName" "Microsoft YaHei"))
        titleFontSize = [double](Get-PptR4Value $source "titleFontSize" 24)
        bodyFontSize = [double](Get-PptR4Value $source "bodyFontSize" 13)
        smallFontSize = [double](Get-PptR4Value $source "smallFontSize" 10)
        margin = [double](Get-PptR4Value $source "margin" 48)
        gap = [double](Get-PptR4Value $source "gap" 16)
    }
}

function New-PptR4Shape($slide, [int]$slideIndex, [string]$name, [string]$shapeType, [double]$left, [double]$top, [double]$width, [double]$height, $style, [int]$componentIndex, [string]$componentType) {
    $op = @{
        shapeType = $shapeType
        name = $name
        left = $left
        top = $top
        width = $width
        height = $height
        style = $style
    }
    $result = Add-PptBatchShape $slide $op
    $nativeShapeId = $null
    try { $nativeShapeId = [int]$result.shape.Id } catch {}
    $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
    return @{
        operationIndex = $componentIndex
        componentType = $componentType
        kind = "shape"
        name = $result.shape.Name
        objectId = "slide:${slideIndex}:shape:$shapeIndex"
        nativeShapeId = $nativeShapeId
        shapeIndex = $shapeIndex
        applied = $result.applied
    }
}

function New-PptR4Textbox($slide, [int]$slideIndex, [string]$name, [string]$text, [double]$left, [double]$top, [double]$width, [double]$height, $style, [int]$componentIndex, [string]$componentType) {
    $op = @{
        name = $name
        text = $text
        left = $left
        top = $top
        width = $width
        height = $height
        style = $style
    }
    $result = Add-PptBatchTextbox $slide $op
    try {
        $result.shape.TextFrame.AutoSize = 0
        $result.shape.TextFrame.WordWrap = -1
        $result.shape.Left = $left
        $result.shape.Top = $top
        $result.shape.Width = $width
        $result.shape.Height = $height
    } catch {}
    try {
        $result.shape.TextFrame2.AutoSize = 0
        $result.shape.TextFrame2.WordWrap = -1
    } catch {}
    $nativeShapeId = $null
    try { $nativeShapeId = [int]$result.shape.Id } catch {}
    $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
    return @{
        operationIndex = $componentIndex
        componentType = $componentType
        kind = "textbox"
        name = $result.shape.Name
        objectId = "slide:${slideIndex}:shape:$shapeIndex"
        nativeShapeId = $nativeShapeId
        shapeIndex = $shapeIndex
        text = $text
        applied = $result.applied
    }
}

function New-PptR4Table($slide, [int]$slideIndex, [string]$name, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $data = Get-ObjectPropertyValue $component "data"
    if ($null -eq $data) { $data = @(@("项目", "内容"), @("示例", "待填写")) }
    $rows = @($data).Count
    $cols = 0
    if ($rows -gt 0) { $cols = @(@($data)[0]).Count }
    if ($rows -lt 1) { $rows = 2 }
    if ($cols -lt 1) { $cols = 2 }

    $left = Get-PptR4Number $component "left" 80
    $top = Get-PptR4Number $component "top" 150
    $width = Get-PptR4Number $component "width" 800
    $height = Get-PptR4Number $component "height" 240
    $table = $slide.Shapes.AddTable($rows, $cols, $left, $top, $width, $height)
    try { $table.Name = $name } catch {}

    $dataResult = Set-PptTableDataValues $table $data 1 1
    $style = Get-ObjectPropertyValue $component "style"
    $baseStyle = @{
        fontName = $visual.fontName
        fontSize = [double](Get-PptR4Value $style "fontSize" 11)
        fontColor = [string](Get-PptR4Value $style "fontColor" $visual.text)
        backgroundColor = [string](Get-PptR4Value $style "backgroundColor" $visual.surface)
        alignment = "center"
        verticalAlignment = "middle"
    }
    $headerStyle = @{
        fontName = $visual.fontName
        fontSize = [double](Get-PptR4Value $style "headerFontSize" 11)
        fontColor = [string](Get-PptR4Value $style "headerFontColor" $visual.onPrimary)
        backgroundColor = [string](Get-PptR4Value $style "headerBackground" $visual.tableHeader)
        bold = $true
        alignment = "center"
        verticalAlignment = "middle"
    }
    $alternateStyle = @{
        backgroundColor = [string](Get-PptR4Value $style "alternateRowColor" $visual.tableAltRow)
        fontColor = [string](Get-PptR4Value $style "fontColor" $visual.text)
        fontName = $visual.fontName
        fontSize = [double](Get-PptR4Value $style "fontSize" 11)
        alignment = "center"
        verticalAlignment = "middle"
    }

    $applied = @()
    for ($r = 1; $r -le $table.Table.Rows.Count; $r++) {
        for ($c = 1; $c -le $table.Table.Columns.Count; $c++) {
            if ($r -eq 1) {
                $applied += Set-PptTableCellShapeStyle $table.Table.Cell($r, $c).Shape $headerStyle
            } elseif ($r % 2 -eq 0) {
                $applied += Set-PptTableCellShapeStyle $table.Table.Cell($r, $c).Shape $alternateStyle
            } else {
                $applied += Set-PptTableCellShapeStyle $table.Table.Cell($r, $c).Shape $baseStyle
            }
        }
    }

    $nativeShapeId = $null
    try { $nativeShapeId = [int]$table.Id } catch {}
    $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
    return @{
        operationIndex = $componentIndex
        componentType = $componentType
        kind = "table"
        name = $table.Name
        objectId = "slide:${slideIndex}:shape:$shapeIndex"
        nativeShapeId = $nativeShapeId
        shapeIndex = $shapeIndex
        rows = $rows
        cols = $cols
        cells = $dataResult.written
        failedCells = $dataResult.failed
        applied = @($applied | Select-Object -Unique)
    }
}

function Get-PptR4ComponentItems($component, [string]$fallbackTitlePrefix, [int]$fallbackCount) {
    $items = Get-ObjectPropertyValue $component "items"
    if ($null -eq $items) { $items = Get-ObjectPropertyValue $component "steps" }
    if ($null -eq $items) { $items = Get-ObjectPropertyValue $component "events" }
    if ($null -eq $items) {
        $items = @()
        for ($i = 1; $i -le $fallbackCount; $i++) {
            $items += @{ title = "$fallbackTitlePrefix$i"; body = "说明$i" }
        }
    }

    $result = @()
    $rawItems = @($items)
    for ($i = 0; $i -lt $rawItems.Count; $i++) {
        $item = $rawItems[$i]
        if ($null -eq $item) { continue }
        if ($item -is [string]) {
            $text = [string]$item
            if ($text -notmatch '^\s*([^：:]+)[：:]\s*(.+)\s*$') {
                throw "timeline_band item $($i + 1) must be a structured title/body object or an unambiguous 'title: body' compatibility value"
            }
            $result += @{ itemId = "timeline-item-$($i + 1)"; title = [string]$Matches[1].Trim(); body = [string]$Matches[2].Trim() }
        } else {
            $title = Get-ObjectPropertyValue $item "title"
            if (-not $title) { $title = Get-ObjectPropertyValue $item "date" }
            if (-not $title) { $title = Get-ObjectPropertyValue $item "label" }
            if (-not $title) { $title = [string]($i + 1) }
            $body = Get-ObjectPropertyValue $item "body"
            if (-not $body) { $body = Get-ObjectPropertyValue $item "text" }
            if (-not $body) { $body = Get-ObjectPropertyValue $item "note" }
            if (-not $body) { $body = Get-ObjectPropertyValue $item "value" }
            $contentBlockId = Get-ObjectPropertyValue $item "contentBlockId"
            $itemId = Get-ObjectPropertyValue $item "itemId"
            if ([string]::IsNullOrWhiteSpace([string]$itemId)) { $itemId = if ($contentBlockId) { [string]$contentBlockId } else { "timeline-item-$($i + 1)" } }
            if ([string]::IsNullOrWhiteSpace([string]$title) -or [string]::IsNullOrWhiteSpace([string]$body)) {
                throw "timeline_band item $($i + 1) must contain non-empty title and body"
            }
            $result += @{ itemId = [string]$itemId; title = [string]$title; body = [string]$body; contentBlockId = [string]$contentBlockId }
        }
    }
    return $result
}

function New-PptR4KpiCard($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" (64 + (($componentIndex % 4) * 210))
    $top = Get-PptR4Number $component "top" 380
    $width = Get-PptR4Number $component "width" 180
    $height = Get-PptR4Number $component "height" 92
    $suppressTitle = [bool](Get-PptR4Value $component "suppressTitle" $false)
    $label = if ($suppressTitle) { "" } else { [string](Get-PptR4Value $component "label" (Get-PptR4Value $component "title" "指标")) }
    $value = [string](Get-PptR4Value $component "value" "0")
    $note = [string](Get-PptR4Value $component "note" (Get-PptR4Value $component "trend" ""))
    $valueHeight = Get-PptR4Number $component "valueHeight" 32
    $valueFontSize = Get-PptR4Number $component "valueFontSize" 24
    $labelHeight = if ([string]::IsNullOrWhiteSpace($label)) { 0 } else { Get-PptR4Number $component "labelHeight" 18 }
    $noteHeight = if ([string]::IsNullOrWhiteSpace($note)) { 0 } else { Get-PptR4Number $component "noteHeight" 16 }
    $valueTopOffset = 21
    $labelTopOffset = $valueTopOffset + $valueHeight + 3
    $noteTopOffset = if ($labelHeight -gt 0) { $labelTopOffset + $labelHeight + 4 } else { $valueTopOffset + $valueHeight + 4 }
    $requiredHeight = $(if ($noteHeight -gt 0) { $noteTopOffset + $noteHeight + 10 } elseif ($labelHeight -gt 0) { $labelTopOffset + $labelHeight + 10 } else { $valueTopOffset + $valueHeight + 10 })
    if ($requiredHeight -gt $height) {
        throw "${componentType} content requires $requiredHeight pt but only $height pt is available"
    }
    $created = @()
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surface; lineColor = $visual.line; lineWidth = 1 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_top_rule") "rectangle" ($left + 18) ($top + 12) ($width - 36) 5 @{ fillColor = $visual.accent; lineColor = $visual.accent; lineWidth = 0 } $componentIndex $componentType
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_value") $value ($left + 14) ($top + $valueTopOffset) ($width - 28) $valueHeight @{ fontName = $visual.fontName; fontSize = $valueFontSize; fontColor = $visual.title; bold = $true; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
    if (-not [string]::IsNullOrWhiteSpace($label)) {
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_label") $label ($left + 14) ($top + $labelTopOffset) ($width - 28) $labelHeight @{ fontName = $visual.fontName; fontSize = 11; fontColor = $visual.text; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
    }
    if (-not [string]::IsNullOrWhiteSpace($note)) {
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_note") $note ($left + 14) ($top + $noteTopOffset) ($width - 28) $noteHeight @{ fontName = $visual.fontName; fontSize = $visual.smallFontSize; fontColor = $visual.mutedText; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
    }
    return $created
}

function New-PptR4PersonaCard($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" (64 + (($componentIndex % 3) * 280))
    $top = Get-PptR4Number $component "top" 170
    $width = Get-PptR4Number $component "width" 250
    $height = Get-PptR4Number $component "height" 130
    $suppressTitle = [bool](Get-PptR4Value $component "suppressTitle" $false)
    $title = if ($suppressTitle) { "" } else { [string](Get-PptR4Value $component "title" (Get-PptR4Value $component "label" "目标客群")) }
    $body = [string](Get-PptR4Value $component "body" (Get-PptR4Value $component "text" (Get-PptR4Value $component "note" "核心诉求与触达方式")))
    $badge = [string](Get-PptR4Value $component "badge" (Get-PptR4Value $component "value" "人群"))

    # Badge copy is model-generated and can be much wider than the early MVP's
    # fixed 58pt box. Size it from the actual characters so a later repair does
    # not have to grow the textbox into the title below it.
    $badgeFontSize = 9.0
    $estimatedBadgeTextWidth = 0.0
    foreach ($character in $badge.ToCharArray()) {
        $codePoint = [int][char]$character
        if ([char]::IsWhiteSpace($character)) {
            $estimatedBadgeTextWidth += 3.5
        } elseif ($codePoint -le 127) {
            $estimatedBadgeTextWidth += 5.5
        } else {
            $estimatedBadgeTextWidth += 9.5
        }
    }
    $maxBadgeWidth = [Math]::Max(58.0, $width - 50.0)
    $badgeWidth = [Math]::Min($maxBadgeWidth, [Math]::Max(58.0, $estimatedBadgeTextWidth + 16.0))
    if (($estimatedBadgeTextWidth + 12.0) -gt $maxBadgeWidth -and $estimatedBadgeTextWidth -gt 0) {
        $badgeFontSize = [Math]::Max(7.5, 9.0 * (($maxBadgeWidth - 12.0) / $estimatedBadgeTextWidth))
    }
    $badgeTextWidth = [Math]::Max(20.0, $badgeWidth - 8.0)
    $scaledBadgeTextWidth = $estimatedBadgeTextWidth * ($badgeFontSize / 9.0)
    $badgeLineCount = [Math]::Max(1, [Math]::Ceiling($scaledBadgeTextWidth / $badgeTextWidth))
    $badgeTextHeight = [Math]::Max(18.0, ($badgeLineCount * $badgeFontSize * 1.25) + 2.0)
    $badgeHeight = $badgeTextHeight + 6.0
    $titleTopOffset = 20.0 + $badgeHeight + 7.0
    $bodyTopOffset = if ($suppressTitle) { $titleTopOffset } else { $titleTopOffset + 29.0 }
    $bodyHeight = [Math]::Max(18.0, $height - $bodyTopOffset - 10.0)
    $created = @()
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surfaceAlt; lineColor = $visual.line; lineWidth = 1 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_side_rule") "rectangle" ($left + 14) ($top + 18) 5 ($height - 36) @{ fillColor = $visual.secondary; lineColor = $visual.secondary; lineWidth = 0 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_badge") "roundedRectangle" ($left + 32) ($top + 20) $badgeWidth $badgeHeight @{ fillColor = $visual.badgeFill; lineColor = $visual.line; lineWidth = 0.5 } $componentIndex $componentType
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_badge_text") $badge ($left + 36) ($top + 23) $badgeTextWidth $badgeTextHeight @{ fontName = $visual.fontName; fontSize = $badgeFontSize; fontColor = $visual.title; bold = $true; alignment = "center"; verticalAlignment = "middle"; marginTop = 0; marginBottom = 0; marginLeft = 0; marginRight = 0 } $componentIndex $componentType
    if (-not [string]::IsNullOrWhiteSpace($title)) {
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_title") $title ($left + 32) ($top + $titleTopOffset) ($width - 54) 26 @{ fontName = $visual.fontName; fontSize = 15; fontColor = $visual.title; bold = $true; alignment = "left"; verticalAlignment = "middle" } $componentIndex $componentType
    }
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_body") $body ($left + 32) ($top + $bodyTopOffset) ($width - 54) $bodyHeight @{ fontName = $visual.fontName; fontSize = $visual.smallFontSize; fontColor = $visual.text; alignment = "left"; verticalAlignment = "top" } $componentIndex $componentType
    return $created
}

function New-PptR4StepCard($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" (64 + (($componentIndex % 3) * 280))
    $top = Get-PptR4Number $component "top" 170
    $width = Get-PptR4Number $component "width" 250
    $height = Get-PptR4Number $component "height" 108
    $indexText = [string](Get-PptR4Value $component "index" (Get-PptR4Value $component "step" ($componentIndex + 1)))
    $suppressTitle = [bool](Get-PptR4Value $component "suppressTitle" $false)
    $title = if ($suppressTitle) { "" } else { [string](Get-PptR4Value $component "title" "步骤标题") }
    $body = [string](Get-PptR4Value $component "body" (Get-PptR4Value $component "text" "步骤说明"))
    $indexFill = $visual.primary
    $stripFill = $visual.surfaceTint
    if ($componentType -match "route") {
        $indexFill = $visual.secondary
        $stripFill = $visual.surfaceAlt
    } elseif ($componentType -match "process") {
        $indexFill = $visual.accent
        $stripFill = $visual.surfaceTint
    } elseif ($componentType -match "timeline") {
        $indexFill = $visual.primary
        $stripFill = $visual.surfaceTint
    }
    $created = @()
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surface; lineColor = $visual.line; lineWidth = 1 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_strip") "rectangle" ($left + 1) ($top + 1) 10 ($height - 2) @{ fillColor = $stripFill; lineColor = $stripFill; lineWidth = 0 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_index") "oval" ($left + 18) ($top + 18) 34 34 @{ fillColor = $indexFill; lineColor = $indexFill; lineWidth = 0 } $componentIndex $componentType
    $indexTextColor = if ($componentType -match "process") { $visual.onAccent } else { $visual.onPrimary }
    $indexFontSize = if ($indexText.Length -gt 2) { 8.5 } else { 10 }
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_index_text") $indexText ($left + 18) ($top + 22) 34 26 @{ fontName = $visual.fontName; fontSize = $indexFontSize; fontColor = $indexTextColor; bold = $true; alignment = "center"; verticalAlignment = "middle"; marginTop = 0; marginBottom = 0; marginLeft = 0; marginRight = 0 } $componentIndex $componentType
    if (-not [string]::IsNullOrWhiteSpace($title)) {
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_title") $title ($left + 66) ($top + 15) ($width - 82) 26 @{ fontName = $visual.fontName; fontSize = 14; fontColor = $visual.title; bold = $true; alignment = "left"; verticalAlignment = "middle" } $componentIndex $componentType
    }
    $bodyTopOffset = if ($suppressTitle) { 15 } else { 44 }
    $bodyBottomPadding = if ($suppressTitle) { 12 } else { 10 }
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_body") $body ($left + 66) ($top + $bodyTopOffset) ($width - 82) ($height - $bodyTopOffset - $bodyBottomPadding) @{ fontName = $visual.fontName; fontSize = $visual.smallFontSize; fontColor = $visual.text; alignment = "left"; verticalAlignment = "top" } $componentIndex $componentType
    return $created
}

function New-PptR4TimelineBand($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" 76
    $top = Get-PptR4Number $component "top" 185
    $width = Get-PptR4Number $component "width" 808
    $height = Get-PptR4Number $component "height" 150
    $items = @(Get-PptR4ComponentItems $component "阶段" 3)
    if ($items.Count -lt 1) { $items = @(@{ title = "阶段1"; body = "说明" }) }
    $lineLeft = $left + 78
    $lineWidth = [Math]::Max(0, $width - 156)
    $gap = if ($items.Count -le 1) { 0 } else { $lineWidth / ($items.Count - 1) }
    $itemBoxWidth = if ($items.Count -le 1) {
        [Math]::Min(156.0, [Math]::Max(72.0, $width - 24.0))
    } else {
        [Math]::Max(60.0, [Math]::Min(156.0, $gap - 16.0))
    }
    $titleBoxWidth = [Math]::Min(140.0, $itemBoxWidth)
    $titleFontSize = if ($items.Count -ge 6) { 11.0 } elseif ($items.Count -eq 5) { 12.0 } else { 13.0 }
    $bodyFontSize = if ($items.Count -ge 6) { 9.0 } else { [double]$visual.smallFontSize }
    $maxTitleHeight = 28.0
    # Match the TypeScript capacity preflight. Mixed CJK/Latin milestone
    # titles wrap earlier in WPS TextFrame2 than their nominal box width.
    $effectiveTitleWidth = [Math]::Max(48.0, ($titleBoxWidth - 4.0) * 0.72)
    foreach ($item in $items) {
        $estimatedTitleWidth = 0.0
        foreach ($character in ([string]$item.title).ToCharArray()) {
            if ([char]::IsWhiteSpace($character)) {
                $estimatedTitleWidth += 4.0
            } elseif ([int][char]$character -le 127) {
                $estimatedTitleWidth += 7.0
            } else {
                $estimatedTitleWidth += 13.0
            }
        }
        $estimatedLines = [Math]::Max(1, [Math]::Ceiling($estimatedTitleWidth / $effectiveTitleWidth))
        $estimatedHeight = ($estimatedLines * $titleFontSize * 1.2) + 3.0
        $maxTitleHeight = [Math]::Max($maxTitleHeight, $estimatedHeight)
    }
    $maxTitleHeight = [Math]::Min(48.0, $maxTitleHeight)
    $lineY = $top + $maxTitleHeight + 20.0
    $created = @()
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_band_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surfaceAlt; lineColor = $visual.line; lineWidth = 0.75; transparency = 0.08 } $componentIndex $componentType
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_line") "rectangle" $lineLeft $lineY $lineWidth 4 @{ fillColor = $visual.line; lineColor = $visual.line; lineWidth = 0 } $componentIndex $componentType
    for ($i = 0; $i -lt $items.Count; $i++) {
        $x = if ($items.Count -le 1) { $left + ($width / 2) } else { $lineLeft + ($gap * $i) }
        $item = $items[$i]
        $itemId = [string](Get-ObjectPropertyValue $item "itemId")
        if ([string]::IsNullOrWhiteSpace($itemId)) { $itemId = [string](Get-ObjectPropertyValue $item "contentBlockId") }
        $safeItemId = $itemId -replace '[^a-zA-Z0-9-]+', '-'
        $itemSuffix = if ([string]::IsNullOrWhiteSpace($safeItemId)) { "" } else { "__ITEM_" + $safeItemId }
        $dotFill = if (($i % 2) -eq 0) { $visual.secondary } else { $visual.accent }
        $dotTextColor = if (($i % 2) -eq 0) { $visual.onPrimary } else { $visual.onAccent }
        $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_dot_" + ($i + 1) + $itemSuffix) "oval" ($x - 12) ($lineY - 10) 24 24 @{ fillColor = $dotFill; lineColor = $visual.surface; lineWidth = 1.5 } $componentIndex $componentType
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_dot_text_" + ($i + 1) + $itemSuffix) ([string]($i + 1)) ($x - 10) ($lineY - 5) 20 14 @{ fontName = $visual.fontName; fontSize = 8; fontColor = $dotTextColor; bold = $true; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_title_" + ($i + 1) + $itemSuffix) ([string]$item.title) ($x - ($titleBoxWidth / 2.0)) ($top + 8) $titleBoxWidth $maxTitleHeight @{ fontName = $visual.fontName; fontSize = $titleFontSize; fontColor = $visual.title; bold = $true; alignment = "center"; verticalAlignment = "middle"; marginTop = 0; marginBottom = 0; marginLeft = 0; marginRight = 0 } $componentIndex $componentType
        $bodyHeight = [Math]::Max(22.0, $height - (($lineY - $top) + 28.0))
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_body_" + ($i + 1) + $itemSuffix) ([string]$item.body) ($x - ($itemBoxWidth / 2.0)) ($lineY + 20) $itemBoxWidth $bodyHeight @{ fontName = $visual.fontName; fontSize = $bodyFontSize; fontColor = $visual.text; alignment = "center"; verticalAlignment = "top" } $componentIndex $componentType
    }
    $fitIssues = @()
    foreach ($createdObject in @($created | Where-Object { [string]$_.kind -eq "textbox" })) {
        $shapeIndex = Get-PptShapeIndexByNativeId $slide $createdObject.nativeShapeId
        if ($null -eq $shapeIndex) {
            $fitIssues += @{ shapeName = [string]$createdObject.name; code = "created_shape_missing" }
            continue
        }
        $shape = $slide.Shapes.Item($shapeIndex)
        $fit = Test-PptShapeTextOverflow $shape
        if ($fit.overflow) {
            $maximumBottom = if ([string]$shape.Name -match '_title_[0-9]+(?:__ITEM_[a-zA-Z0-9-]+)?$') { $lineY - 6.0 } else { $top + $height - 8.0 }
            $requiredHeight = [Math]::Ceiling([double](Get-ObjectPropertyValue $fit "boundHeight") + 2.0)
            if ($requiredHeight -gt 0 -and ([double]$shape.Top + $requiredHeight) -le ($maximumBottom + 0.25)) {
                $shape.Height = [single]$requiredHeight
                $fit = Test-PptShapeTextOverflow $shape
            }
        }
        if ($fit.overflow) {
            $fitIssues += @{ shapeName = [string]$shape.Name; code = "text_overflow"; metrics = $fit }
        }
    }
    if ($fitIssues.Count -gt 0) {
        foreach ($createdObject in @($created | Sort-Object { [int]$_.shapeIndex } -Descending)) {
            $shapeIndex = Get-PptShapeIndexByNativeId $slide $createdObject.nativeShapeId
            if ($null -ne $shapeIndex) { try { $slide.Shapes.Item($shapeIndex).Delete() } catch {} }
        }
        throw "timeline_band failed authoritative WPS text-fit validation: $($fitIssues | ConvertTo-Json -Compress -Depth 8)"
    }
    return $created
}

function New-PptR4QuoteBanner($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" 80
    $top = Get-PptR4Number $component "top" 170
    $width = Get-PptR4Number $component "width" 800
    $height = Get-PptR4Number $component "height" 160
    $quote = [string](Get-PptR4Value $component "quote" (Get-PptR4Value $component "text" (Get-PptR4Value $component "title" "核心金句")))
    $subtitle = [string](Get-PptR4Value $component "subtitle" (Get-PptR4Value $component "body" ""))
    $isWide = $width -ge 520
    $panelWidth = if ($isWide) { [Math]::Min(150, [Math]::Max(90, $width * 0.2)) } else { 0 }
    $rightReserve = if ($isWide) { $panelWidth + 68 } else { 40 }
    $textWidth = [Math]::Max(100, $width - 56 - $rightReserve)
    $innerTop = 20
    $innerBottom = 18
    $innerGap = 6
    $availableHeight = [Math]::Max(42, $height - $innerTop - $innerBottom)
    $requestedSubtitleHeight = Get-PptR4Number $component "subtitleHeight" 0
    $requestedQuoteHeight = Get-PptR4Number $component "quoteTextHeight" 0
    $subtitleHeight = if ([string]::IsNullOrWhiteSpace($subtitle)) { 0 } elseif ($requestedSubtitleHeight -gt 0) { $requestedSubtitleHeight } else { [Math]::Max(36, [Math]::Min(52, $availableHeight * 0.32)) }
    $quoteHeight = if ($requestedQuoteHeight -gt 0) { $requestedQuoteHeight } else { [Math]::Max(28, $availableHeight - $subtitleHeight - $(if ($subtitleHeight -gt 0) { $innerGap } else { 0 })) }
    $requiredInnerHeight = $quoteHeight + $subtitleHeight + $(if ($subtitleHeight -gt 0) { $innerGap } else { 0 })
    if ($requiredInnerHeight -gt $availableHeight) {
        throw "quote_banner content requires $requiredInnerHeight pt but only $availableHeight pt is available"
    }
    $quoteFontSize = if ($isWide) { 26 } elseif ($width -ge 300) { 20 } else { 17 }
    $created = @()
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.primary; lineColor = $visual.primary; lineWidth = 0 } $componentIndex $componentType
    if ($panelWidth -gt 0) {
        $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_soft_panel") "roundedRectangle" ($left + $width - $panelWidth - 40) ($top + 18) $panelWidth ($height - 36) @{ fillColor = $visual.secondary; lineColor = $visual.secondary; lineWidth = 0; transparency = 0.18 } $componentIndex $componentType
    }
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_accent") "rectangle" ($left + 28) ($top + 28) 8 ($height - 56) @{ fillColor = $visual.accent; lineColor = $visual.accent; lineWidth = 0 } $componentIndex $componentType
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_quote") $quote ($left + 56) ($top + $innerTop) $textWidth $quoteHeight @{ fontName = $visual.fontName; fontSize = $quoteFontSize; fontColor = $visual.onPrimary; bold = $true; alignment = "left"; verticalAlignment = "middle"; marginTop = 0; marginBottom = 0; marginLeft = 0; marginRight = 0 } $componentIndex $componentType
    if (-not [string]::IsNullOrWhiteSpace($subtitle)) {
        $subtitleTop = $top + $innerTop + $quoteHeight + $innerGap
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_subtitle") $subtitle ($left + 56) $subtitleTop $textWidth $subtitleHeight @{ fontName = $visual.fontName; fontSize = $visual.bodyFontSize; fontColor = $visual.onPrimary; alignment = "left"; verticalAlignment = "middle"; marginTop = 0; marginBottom = 0; marginLeft = 0; marginRight = 0 } $componentIndex $componentType
    }
    return $created
}

function New-PptR4ImageCaptionBlock($slide, [int]$slideIndex, [string]$namePrefix, $component, $visual, [int]$componentIndex, [string]$componentType) {
    $left = Get-PptR4Number $component "left" 520
    $top = Get-PptR4Number $component "top" 140
    $width = Get-PptR4Number $component "width" 340
    $height = Get-PptR4Number $component "height" 230
    $strictContent = [bool](Get-PptR4Value $component "strictContent" $false)
    $caption = [string](Get-PptR4Value $component "caption" (Get-PptR4Value $component "text" $(if ($strictContent) { "" } else { "图片说明" })))
    $pathValue = Get-ObjectPropertyValue $component "path"
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $component "filePath" }
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $component "imagePath" }
    if (-not $pathValue) { $pathValue = Get-ObjectPropertyValue $component "localPath" }
    $targetValue = Get-ObjectPropertyValue $component "captionTarget"
    if (-not $targetValue) { $targetValue = Get-ObjectPropertyValue $component "captionFor" }
    if (-not $targetValue) { $targetValue = Get-ObjectPropertyValue $component "targetObjectId" }
    if (-not $targetValue) { $targetValue = Get-ObjectPropertyValue $component "targetAssetId" }
    $boundToExistingShape = $false
    if (-not $pathValue -and $targetValue) {
        $shapeTarget = $targetValue
        if ([string]$shapeTarget -match '^slide:\d+:shape:(\d+)$') { $shapeTarget = [int]$Matches[1] }
        $resolvedTarget = Resolve-PptShape $slide $shapeTarget "createImageCaptionBlock" "caption target"
        if ($resolvedTarget.ok) {
            $left = [double]$resolvedTarget.shape.Left
            $top = [double]$resolvedTarget.shape.Top
            $width = [double]$resolvedTarget.shape.Width
            $height = [double]$resolvedTarget.shape.Height
            $boundToExistingShape = $true
        } elseif ($strictContent) {
            throw "strictContent image_caption_block target '$targetValue' was not found"
        }
    }
    if ($strictContent -and [string]::IsNullOrWhiteSpace($caption)) {
        throw "strictContent image_caption_block requires caption text"
    }
    $created = @()
    if ($pathValue) {
        $imageResult = Add-PptBatchImage $slide @{ name = ($namePrefix + "_image"); path = [string]$pathValue; left = $left; top = $top; width = $width; height = $height }
        $nativeShapeId = $null
        try { $nativeShapeId = [int]$imageResult.shape.Id } catch {}
        $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
        $created += @{
            operationIndex = $componentIndex
            componentType = $componentType
            kind = "picture"
            name = $imageResult.shape.Name
            objectId = "slide:${slideIndex}:shape:$shapeIndex"
            nativeShapeId = $nativeShapeId
            shapeIndex = $shapeIndex
            path = $imageResult.path
        }
    } elseif (-not $boundToExistingShape -and -not $strictContent) {
        $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_image_placeholder") "rectangle" $left $top $width $height @{ fillColor = $visual.surfaceAlt; lineColor = $visual.line; lineWidth = 1 } $componentIndex $componentType
        $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_placeholder_text") "IMAGE" ($left + 20) ($top + ($height / 2) - 14) ($width - 40) 28 @{ fontName = $visual.fontName; fontSize = 13; fontColor = $visual.mutedText; bold = $true; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
    } elseif (-not $boundToExistingShape) {
        throw "strictContent image_caption_block requires an existing caption target or image path"
    }
    $captionHeight = Get-PptR4Number $component "captionHeight" 34
    $captionTop = $top + $height - $captionHeight
    $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_caption_bg") "rectangle" $left $captionTop $width $captionHeight @{ fillColor = $visual.imageOverlay; lineColor = $visual.imageOverlay; lineWidth = 0; transparency = 0.28 } $componentIndex $componentType
    $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_caption") $caption ($left + 10) ($captionTop + 6) ($width - 20) ($captionHeight - 8) @{ fontName = $visual.fontName; fontSize = $visual.smallFontSize; fontColor = $visual.onPrimary; alignment = "center"; verticalAlignment = "middle" } $componentIndex $componentType
    return $created
}

function Get-PptNextR4ComponentIndex($slide) {
    $maxIndex = 0
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $descriptor = Get-PptComponentDescriptor ([string]$slide.Shapes.Item($i).Name)
        if ($null -ne $descriptor -and [int]$descriptor.componentIndex -gt $maxIndex) {
            $maxIndex = [int]$descriptor.componentIndex
        }
    }
    return ($maxIndex + 1)
}

function Get-PptDuplicateShapeSignature($shape, [double]$originLeft, [double]$originTop) {
    $text = $null
    $fontName = $null
    $fontSize = $null
    $fontBold = $null
    $fontColor = $null
    $fillVisible = $null
    $fillColor = $null
    $fillTransparency = $null
    $lineVisible = $null
    $lineColor = $null
    $lineTransparency = $null
    $lineDashStyle = $null
    $lineWeight = $null
    $autoShapeType = $null
    $placeholderType = $null
    $pictureLinked = $null
    $pictureSourcePath = $null
    $pictureColorType = $null
    $cropLeft = $null
    $cropTop = $null
    $cropRight = $null
    $cropBottom = $null
    $groupMembers = @()
    try { $text = [string]$shape.TextFrame.TextRange.Text } catch {}
    try { $fontName = [string]$shape.TextFrame.TextRange.Font.Name } catch {}
    try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
    try { $fontBold = [int]$shape.TextFrame.TextRange.Font.Bold } catch {}
    try { $fontColor = [int]$shape.TextFrame.TextRange.Font.Color.RGB } catch {}
    try { $fillVisible = [int]$shape.Fill.Visible } catch {}
    try { $fillColor = [int]$shape.Fill.ForeColor.RGB } catch {}
    try { $fillTransparency = [double]$shape.Fill.Transparency } catch {}
    try { $lineVisible = [int]$shape.Line.Visible } catch {}
    try { $lineColor = [int]$shape.Line.ForeColor.RGB } catch {}
    try { $lineTransparency = [double]$shape.Line.Transparency } catch {}
    try { $lineDashStyle = [int]$shape.Line.DashStyle } catch {}
    try { $lineWeight = [double]$shape.Line.Weight } catch {}
    try { $autoShapeType = [int]$shape.AutoShapeType } catch {}
    try { $placeholderType = [int]$shape.PlaceholderFormat.Type } catch {}
    try {
        $typeCode = [int]$shape.Type
        if ($typeCode -eq 11 -or $typeCode -eq 13) {
            $pictureSourcePath = $(try { [string]$shape.LinkFormat.SourceFullName } catch { $null })
            $pictureLinked = [bool]($typeCode -eq 11 -or -not [string]::IsNullOrWhiteSpace([string]$pictureSourcePath))
            $pictureColorType = $(try { [int]$shape.PictureFormat.ColorType } catch { $null })
            $cropLeft = $(try { [double]$shape.PictureFormat.CropLeft } catch { $null })
            $cropTop = $(try { [double]$shape.PictureFormat.CropTop } catch { $null })
            $cropRight = $(try { [double]$shape.PictureFormat.CropRight } catch { $null })
            $cropBottom = $(try { [double]$shape.PictureFormat.CropBottom } catch { $null })
        }
        if ($typeCode -eq 6) {
            for ($memberIndex = 1; $memberIndex -le $shape.GroupItems.Count; $memberIndex++) {
                $groupMembers += Get-PptDuplicateShapeSignature $shape.GroupItems.Item($memberIndex) $originLeft $originTop
            }
        }
    } catch {}
    return @{
        type = $(try { [int]$shape.Type } catch { $null })
        autoShapeType = $autoShapeType
        placeholderType = $placeholderType
        left = [double]$shape.Left - $originLeft
        top = [double]$shape.Top - $originTop
        width = [double]$shape.Width
        height = [double]$shape.Height
        text = $text
        fontName = $fontName
        fontSize = $fontSize
        fontBold = $fontBold
        fontColor = $fontColor
        fillVisible = $fillVisible
        fillColor = $fillColor
        fillTransparency = $fillTransparency
        lineVisible = $lineVisible
        lineColor = $lineColor
        lineTransparency = $lineTransparency
        lineDashStyle = $lineDashStyle
        lineWeight = $lineWeight
        rotation = $(try { [double]$shape.Rotation } catch { 0 })
        pictureLinked = $pictureLinked
        pictureSourcePath = $pictureSourcePath
        pictureColorType = $pictureColorType
        cropLeft = $cropLeft
        cropTop = $cropTop
        cropRight = $cropRight
        cropBottom = $cropBottom
        groupMembers = $groupMembers
    }
}

function Test-PptDuplicateShapeSignature($expected, $actual, [double]$tolerance = 0.15) {
    $mismatches = @()
    foreach ($property in @("type", "autoShapeType", "placeholderType", "text", "fontName", "fontBold", "fontColor", "fillVisible", "fillColor", "lineVisible", "lineColor", "lineDashStyle", "pictureLinked", "pictureSourcePath", "pictureColorType")) {
        $expectedValue = Get-ObjectPropertyValue $expected $property
        $actualValue = Get-ObjectPropertyValue $actual $property
        if ([string]$expectedValue -ne [string]$actualValue) { $mismatches += $property }
    }
    foreach ($property in @("left", "top", "width", "height", "rotation", "fontSize", "fillTransparency", "lineTransparency", "lineWeight", "cropLeft", "cropTop", "cropRight", "cropBottom")) {
        $expectedValue = Get-ObjectPropertyValue $expected $property
        $actualValue = Get-ObjectPropertyValue $actual $property
        if ($null -eq $expectedValue -and $null -eq $actualValue) { continue }
        if ($null -eq $expectedValue -or $null -eq $actualValue -or [Math]::Abs([double]$expectedValue - [double]$actualValue) -gt $tolerance) {
            $mismatches += $property
        }
    }
    $expectedMembers = @((Get-ObjectPropertyValue $expected "groupMembers"))
    $actualMembers = @((Get-ObjectPropertyValue $actual "groupMembers"))
    if ($expectedMembers.Count -ne $actualMembers.Count) {
        $mismatches += "groupMembers.count"
    } else {
        for ($memberIndex = 0; $memberIndex -lt $expectedMembers.Count; $memberIndex++) {
            foreach ($memberMismatch in @(Test-PptDuplicateShapeSignature $expectedMembers[$memberIndex] $actualMembers[$memberIndex] $tolerance)) {
                $mismatches += "groupMembers[$memberIndex].$memberMismatch"
            }
        }
    }
    return $mismatches
}

function Test-PptDuplicateEnvelopePlacement($slide, $sourceNativeIds, [double]$left, [double]$top, [double]$width, [double]$height, [double]$slideWidth, [double]$slideHeight, [double]$margin = 8) {
    if ($left -lt $margin -or $top -lt $margin -or ($left + $width) -gt ($slideWidth - $margin) -or ($top + $height) -gt ($slideHeight - $margin)) {
        return $false
    }
    $slideArea = [Math]::Max(1, $slideWidth * $slideHeight)
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $shape = $slide.Shapes.Item($i)
        $nativeId = $null
        try { $nativeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeId -and $sourceNativeIds.ContainsKey([string]$nativeId)) { continue }
        $shapeWidth = [double]$shape.Width
        $shapeHeight = [double]$shape.Height
        if (($shapeWidth * $shapeHeight) / $slideArea -ge 0.8) { continue }
        $overlap = Get-PptRectOverlapArea $left $top $width $height ([double]$shape.Left) ([double]$shape.Top) $shapeWidth $shapeHeight
        if ($overlap -gt 0.5) { return $false }
    }
    return $true
}

function Find-PptDuplicateEnvelopePlacement($slide, $sourceNativeIds, $sourceBounds, [double]$slideWidth, [double]$slideHeight, [double]$gap = 12) {
    $left = [double]$sourceBounds.left
    $top = [double]$sourceBounds.top
    $width = [double]$sourceBounds.width
    $height = [double]$sourceBounds.height
    $candidateMap = @{}
    $candidates = New-Object System.Collections.ArrayList
    function Add-PptDuplicateCandidate([double]$candidateLeft, [double]$candidateTop) {
        $key = "{0:F2}|{1:F2}" -f $candidateLeft, $candidateTop
        if (-not $candidateMap.ContainsKey($key)) {
            $candidateMap[$key] = $true
            $null = $candidates.Add(@{ left = $candidateLeft; top = $candidateTop })
        }
    }
    Add-PptDuplicateCandidate ($left + $width + $gap) $top
    Add-PptDuplicateCandidate $left ($top + $height + $gap)
    Add-PptDuplicateCandidate ($left - $width - $gap) $top
    Add-PptDuplicateCandidate $left ($top - $height - $gap)

    $xValues = @(8, $left, ($left + $width + $gap), ($left - $width - $gap))
    $yValues = @(8, $top, ($top + $height + $gap), ($top - $height - $gap))
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $shape = $slide.Shapes.Item($i)
        $nativeId = $null
        try { $nativeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeId -and $sourceNativeIds.ContainsKey([string]$nativeId)) { continue }
        $xValues += [double]$shape.Left + [double]$shape.Width + $gap
        $xValues += [double]$shape.Left - $width - $gap
        $yValues += [double]$shape.Top + [double]$shape.Height + $gap
        $yValues += [double]$shape.Top - $height - $gap
    }
    foreach ($candidateTop in @($yValues | Sort-Object -Unique)) {
        foreach ($candidateLeft in @($xValues | Sort-Object -Unique)) {
            Add-PptDuplicateCandidate ([double]$candidateLeft) ([double]$candidateTop)
        }
    }
    foreach ($candidate in $candidates) {
        if (Test-PptDuplicateEnvelopePlacement $slide $sourceNativeIds ([double]$candidate.left) ([double]$candidate.top) $width $height $slideWidth $slideHeight 8) {
            return @{ left = [double]$candidate.left; top = [double]$candidate.top; width = $width; height = $height }
        }
    }
    return $null
}

function Remove-PptShapesByNativeId($slide, $nativeShapeIds) {
    foreach ($nativeShapeId in @($nativeShapeIds | Sort-Object -Descending)) {
        $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
        if ($null -ne $shapeIndex) {
            try { $slide.Shapes.Item($shapeIndex).Delete() } catch {}
        }
    }
}

function Get-PptShapeRecordEnvelope($records) {
    $left = [double]::PositiveInfinity
    $top = [double]::PositiveInfinity
    $right = [double]::NegativeInfinity
    $bottom = [double]::NegativeInfinity
    foreach ($record in @($records)) {
        $shape = $record.shape
        $left = [Math]::Min($left, [double]$shape.Left)
        $top = [Math]::Min($top, [double]$shape.Top)
        $right = [Math]::Max($right, [double]$shape.Left + [double]$shape.Width)
        $bottom = [Math]::Max($bottom, [double]$shape.Top + [double]$shape.Height)
    }
    if ([double]::IsPositiveInfinity($left) -or [double]::IsPositiveInfinity($top)) { return $null }
    return @{ left = $left; top = $top; width = $right - $left; height = $bottom - $top }
}

function Move-PptShapeRecords($records, [double]$deltaLeft, [double]$deltaTop) {
    foreach ($record in @($records)) {
        $record.shape.Left = [single]([double]$record.shape.Left + $deltaLeft)
        $record.shape.Top = [single]([double]$record.shape.Top + $deltaTop)
    }
}

function Resolve-PptDuplicateBindingRecords($slide, $bindings, [string]$label) {
    $records = @()
    foreach ($binding in @($bindings)) {
        $nativeShapeId = Get-ObjectPropertyValue $binding "nativeShapeId"
        $shapeIndex = if ($null -ne $nativeShapeId) { Get-PptShapeIndexByNativeId $slide $nativeShapeId } else { $null }
        if ($null -eq $shapeIndex) {
            $shapeIndex = Get-ObjectPropertyValue $binding "shapeIndexFallback"
            if ($null -eq $shapeIndex) { $shapeIndex = Get-ObjectPropertyValue $binding "shapeIndex" }
        }
        if ($null -eq $shapeIndex -or [int]$shapeIndex -lt 1 -or [int]$shapeIndex -gt $slide.Shapes.Count) {
            throw "PPT_DUPLICATE_REFERENCE_BINDING_STALE: $label shape no longer exists"
        }
        $shape = $slide.Shapes.Item([int]$shapeIndex)
        $actualNativeShapeId = $null
        try { $actualNativeShapeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeShapeId -and [int]$nativeShapeId -ne [int]$actualNativeShapeId) {
            throw "PPT_DUPLICATE_REFERENCE_BINDING_STALE: $label nativeShapeId changed"
        }
        $expectedShapeName = [string](Get-ObjectPropertyValue $binding "expectedShapeName")
        if (-not [string]::IsNullOrWhiteSpace($expectedShapeName) -and [string]$shape.Name -ne $expectedShapeName) {
            throw "PPT_DUPLICATE_REFERENCE_BINDING_STALE: $label shapeName changed"
        }
        $records += @{
            shape = $shape
            shapeIndex = [int]$shapeIndex
            nativeShapeId = $actualNativeShapeId
            binding = $binding
            part = [string](Get-ObjectPropertyValue $binding "part")
            canonicalPart = [string](Get-ObjectPropertyValue $binding "canonicalPart")
            itemId = [string](Get-ObjectPropertyValue $binding "itemId")
            contentBlockId = [string](Get-ObjectPropertyValue $binding "contentBlockId")
        }
    }
    return @($records | Sort-Object @{ Expression = { [int]$_.shapeIndex } })
}

function Get-PptDuplicateGapValues($relativePlacement, $spacingPolicy) {
    $gapIntent = [string](Get-ObjectPropertyValue $relativePlacement "gapIntent")
    $minimumGap = Get-ObjectPropertyValue $spacingPolicy "minimumGap"
    if ($null -eq $minimumGap -or [double]$minimumGap -lt 8) { $minimumGap = 8.0 }
    $preferredGap = Get-ObjectPropertyValue $spacingPolicy "preferredGap"
    if ($null -eq $preferredGap -or [double]$preferredGap -lt [double]$minimumGap) { $preferredGap = [Math]::Max(12.0, [double]$minimumGap) }
    if ($gapIntent -eq "exact") {
        $requestedGap = Get-ObjectPropertyValue $relativePlacement "gap"
        $parsedGap = 0.0
        if ($null -eq $requestedGap -or -not [double]::TryParse([string]$requestedGap, [ref]$parsedGap) -or [double]::IsNaN($parsedGap) -or [double]::IsInfinity($parsedGap) -or $parsedGap -lt 0) {
            throw "PPT_DUPLICATE_EXACT_GAP_INVALID: exact gap must be a finite non-negative number"
        }
        return @{ intent = "exact"; candidates = @([double]$parsedGap) }
    }
    if ($gapIntent -eq "minimum") {
        return @{ intent = "minimum"; candidates = @([double]$minimumGap) }
    }
    return @{ intent = "preferred"; candidates = @(@([double]$preferredGap, [double]$minimumGap) | Select-Object -Unique) }
}

function Get-PptRelativePlacementCandidate($referenceBounds, $copyBounds, [string]$direction, [string]$alignment, [double]$gap) {
    $left = [double]$copyBounds.left
    $top = [double]$copyBounds.top
    $width = [double]$copyBounds.width
    $height = [double]$copyBounds.height
    $refLeft = [double]$referenceBounds.left
    $refTop = [double]$referenceBounds.top
    $refWidth = [double]$referenceBounds.width
    $refHeight = [double]$referenceBounds.height
    if ($direction -eq "below" -or $direction -eq "above") {
        $top = if ($direction -eq "below") { $refTop + $refHeight + $gap } else { $refTop - $gap - $height }
        $left = switch ($alignment) {
            "center" { $refLeft + (($refWidth - $width) / 2) }
            "end" { $refLeft + $refWidth - $width }
            default { $refLeft }
        }
    } elseif ($direction -eq "left" -or $direction -eq "right") {
        $left = if ($direction -eq "right") { $refLeft + $refWidth + $gap } else { $refLeft - $gap - $width }
        $top = switch ($alignment) {
            "center" { $refTop + (($refHeight - $height) / 2) }
            "end" { $refTop + $refHeight - $height }
            default { $refTop }
        }
    } else {
        throw "PPT_DUPLICATE_RELATIVE_DIRECTION_INVALID: $direction"
    }
    return @{ left = [double]$left; top = [double]$top; width = $width; height = $height; direction = $direction; alignment = $alignment; actualGap = $gap }
}

function Get-PptResolvedPlacementRelation($referenceBounds, $createdBounds, [string]$requestedDirection, [string]$alignment, [string]$gapIntent) {
    $refLeft = [double]$referenceBounds.left
    $refTop = [double]$referenceBounds.top
    $refRight = $refLeft + [double]$referenceBounds.width
    $refBottom = $refTop + [double]$referenceBounds.height
    $createdLeft = [double]$createdBounds.left
    $createdTop = [double]$createdBounds.top
    $createdRight = $createdLeft + [double]$createdBounds.width
    $createdBottom = $createdTop + [double]$createdBounds.height
    $direction = $requestedDirection
    if ($direction -eq "auto") {
        $distances = @(
            @{ direction = "right"; gap = $createdLeft - $refRight },
            @{ direction = "below"; gap = $createdTop - $refBottom },
            @{ direction = "left"; gap = $refLeft - $createdRight },
            @{ direction = "above"; gap = $refTop - $createdBottom }
        )
        $valid = @($distances | Where-Object { [double]$_.gap -ge 0 } | Sort-Object @{ Expression = { [double]$_.gap } })
        if ($valid.Count -eq 0) { throw "PPT_DUPLICATE_RELATION_UNRESOLVED: created bounds overlap the reference" }
        $direction = [string]$valid[0].direction
    }
    $actualGap = switch ($direction) {
        "right" { $createdLeft - $refRight }
        "below" { $createdTop - $refBottom }
        "left" { $refLeft - $createdRight }
        "above" { $refTop - $createdBottom }
        default { [double]::NaN }
    }
    return @{
        direction = $requestedDirection
        resolvedDirection = $direction
        alignment = $alignment
        gapIntent = $gapIntent
        actualGap = [double]$actualGap
    }
}

function Resolve-PptDuplicatePlacement($slide, $ignoredNativeIds, $referenceBounds, $copyBounds, $relativePlacement, $spacingPolicy, [double]$slideWidth, [double]$slideHeight) {
    $direction = [string](Get-ObjectPropertyValue $relativePlacement "direction")
    if ([string]::IsNullOrWhiteSpace($direction)) { $direction = "auto" }
    $alignment = [string](Get-ObjectPropertyValue $relativePlacement "alignment")
    if ([string]::IsNullOrWhiteSpace($alignment)) { $alignment = "start" }
    $gapValues = Get-PptDuplicateGapValues $relativePlacement $spacingPolicy
    if ($direction -eq "auto") {
        foreach ($gap in @($gapValues.candidates)) {
            $candidate = Find-PptDuplicateEnvelopePlacement $slide $ignoredNativeIds $referenceBounds $slideWidth $slideHeight ([double]$gap)
            if ($null -ne $candidate) {
                $relation = Get-PptResolvedPlacementRelation $referenceBounds $candidate "auto" $alignment ([string]$gapValues.intent)
                return @{ bounds = $candidate; relation = $relation }
            }
        }
        return $null
    }
    foreach ($gap in @($gapValues.candidates)) {
        $candidate = Get-PptRelativePlacementCandidate $referenceBounds $copyBounds $direction $alignment ([double]$gap)
        if (Test-PptDuplicateEnvelopePlacement $slide $ignoredNativeIds ([double]$candidate.left) ([double]$candidate.top) ([double]$candidate.width) ([double]$candidate.height) $slideWidth $slideHeight 8) {
            $relation = Get-PptResolvedPlacementRelation $referenceBounds $candidate $direction $alignment ([string]$gapValues.intent)
            return @{ bounds = $candidate; relation = $relation }
        }
    }
    return $null
}

function Get-PptDuplicateEntityBinding($pres, $slide, [int]$slideIndex, $records, [string]$componentInstanceId = "", [string]$objectId = "") {
    $nativeSlideId = $null
    try { $nativeSlideId = [string]$slide.SlideID } catch {}
    $nativeShapeIds = @($records | ForEach-Object { [int]$_.nativeShapeId })
    $bounds = Get-PptShapeRecordEnvelope $records
    $anchorNativeShapeId = $null
    if (-not [string]::IsNullOrWhiteSpace($componentInstanceId)) {
        $anchor = @($records | Where-Object {
            [string]$_.canonicalPart -eq "background" -or [string]$_.part -match '(^|_)(bg|band|background)($|_)'
        })[0]
        if ($null -ne $anchor) { $anchorNativeShapeId = [int]$anchor.nativeShapeId }
    }
    return @{
        presentationId = [string]$pres.Name
        nativeSlideId = $nativeSlideId
        slideIndexSnapshot = $slideIndex
        objectId = $objectId
        nativeShapeId = $(if ($nativeShapeIds.Count -eq 1) { $nativeShapeIds[0] } else { $null })
        expectedShapeName = $(if ($records.Count -eq 1) { [string]$records[0].shape.Name } else { "" })
        componentInstanceId = $componentInstanceId
        anchorNativeShapeId = $anchorNativeShapeId
        nativeShapeIds = $nativeShapeIds
        shapeNames = @($records | ForEach-Object { [string]$_.shape.Name })
        bounds = $bounds
    }
}

function Get-PptRollbackDuplicateWriteResult($ppt, $pres, $options) {
    $slideIndex = [int](Get-ObjectPropertyValue $options "slideIndex")
    $resolvedSlide = Resolve-PptSlideBinding $pres $slideIndex (Get-ObjectPropertyValue $options "nativeSlideId") "rollbackPptDuplicateWrite"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $slideIndex = [int]$resolvedSlide.slideIndex
    $receipts = @((Get-ObjectPropertyValue $options "creationReceipts"))
    if ($receipts.Count -eq 0) {
        return New-PptRecoverableError "PPT_DUPLICATE_ROLLBACK_RECEIPT_REQUIRED" "Duplicate rollback requires at least one creation receipt." @{ slideIndex = $slideIndex }
    }
    $targets = @()
    foreach ($receipt in $receipts) {
        $created = Get-ObjectPropertyValue $receipt "created"
        $nativeShapeIds = @((Get-ObjectPropertyValue $created "nativeShapeIds"))
        if ($nativeShapeIds.Count -eq 0) {
            $singleId = Get-ObjectPropertyValue $created "nativeShapeId"
            if ($null -ne $singleId) { $nativeShapeIds = @($singleId) }
        }
        $expectedNames = @((Get-ObjectPropertyValue $created "shapeNames"))
        foreach ($nativeShapeId in $nativeShapeIds) {
            $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
            if ($null -eq $shapeIndex) { continue }
            $shape = $slide.Shapes.Item([int]$shapeIndex)
            if ($expectedNames.Count -gt 0 -and -not ($expectedNames -contains [string]$shape.Name)) {
                return New-PptRecoverableError "PPT_DUPLICATE_ROLLBACK_IDENTITY_MISMATCH" "A created nativeShapeId now resolves to an unexpected shape name." @{
                    nativeShapeId = $nativeShapeId
                    actualShapeName = [string]$shape.Name
                    expectedShapeNames = $expectedNames
                }
            }
            $targets += @{ nativeShapeId = [int]$nativeShapeId; shapeName = [string]$shape.Name }
        }
    }
    $targetIds = @($targets | ForEach-Object { [int]$_.nativeShapeId } | Sort-Object -Unique)
    Remove-PptShapesByNativeId $slide $targetIds
    $remaining = @($targetIds | Where-Object { $null -ne (Get-PptShapeIndexByNativeId $slide $_) })
    if ($remaining.Count -gt 0) {
        return New-PptRecoverableError "PPT_DUPLICATE_ROLLBACK_INCOMPLETE" "Some duplicate objects could not be removed." @{
            slideIndex = $slideIndex
            remainingNativeShapeIds = $remaining
        }
    }
    return @{
        success = $true
        data = @{
            transactional = $true
            rolledBack = $true
            rollbackVerified = $true
            wroteToWps = ($targetIds.Count -gt 0)
            slideIndex = $slideIndex
            removedNativeShapeIds = $targetIds
            removedObjectCount = $targetIds.Count
        }
    }
}

function Fit-PptDuplicatedComponentContent($slide, $cloneRecords, [string]$componentId, [string]$componentType, [double]$slideWidth, [double]$slideHeight) {
    $backgroundRecords = @($cloneRecords | Where-Object {
        [string]$_.canonicalPart -eq "background" -or [string]$_.part -match '(^|_)(bg|band|background|table)($|_)'
    } | Sort-Object { -([double]$_.shape.Width * [double]$_.shape.Height) })
    if ($backgroundRecords.Count -ne 1) {
        throw "PPT_DUPLICATE_COMPONENT_BACKGROUND_REQUIRED: component=$componentId, found=$($backgroundRecords.Count)"
    }
    $group = @{
        componentId = $componentId
        componentType = $componentType
        internalLayoutMode = $(if ($componentType -eq "timeline_band") { "repeated_items" } elseif ($componentType -eq "styled_table" -or $componentType -eq "data_table") { "native_grid" } else { "atomic" })
        background = $backgroundRecords[0].shape
        parts = @($cloneRecords | ForEach-Object {
            @{
                shape = $_.shape
                nativeShapeId = $_.nativeShapeId
                descriptor = @{ componentId = $componentId; componentType = $componentType; part = [string]$_.part }
            }
        })
    }
    $before = Get-PptShapeRecordEnvelope $cloneRecords
    $overflowing = @($group.parts | Where-Object {
        $hasText = $false
        try { $hasText = [bool]$_.shape.HasTextFrame -and [bool]$_.shape.TextFrame.HasText } catch {}
        $hasText -and (Test-PptShapeTextOverflow $_.shape).overflow
    })
    if ($overflowing.Count -gt 0) {
        if ((Resolve-PptGridInternalLayoutMode $group) -eq "native_grid") {
            throw "PPT_DUPLICATE_COMPONENT_TEXT_OVERFLOW: native-grid component=$componentId cannot be safely resized by the atomic component fitter"
        }
        $padding = 8.0
        $minimumFontSize = 9.0
        $shellToken = Resolve-PptGridShellToken $group ""
        $requiredHeight = Get-PptGridMinimumHeightForGroup $group ([double]$group.background.Width) $shellToken $padding $minimumFontSize $true
        if ($requiredHeight -gt ([double]$group.background.Height + 0.25)) {
            $group.background.Height = [single]$requiredHeight
        }
        if ((Resolve-PptGridInternalLayoutMode $group) -eq "repeated_items") {
            Set-PptGridRepeatedItemsLayout $group $padding $minimumFontSize | Out-Null
        } else {
            Set-PptGridUnifiedShell $group (Get-PptR4VisualSystem $null) $shellToken "" $padding $null $true
        }
    }
    $fitItems = @()
    foreach ($part in @($group.parts)) {
        $shape = $part.shape
        $hasText = $false
        try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
        if (-not $hasText) { continue }
        $fit = Test-PptShapeTextOverflow $shape
        $fitItems += @{
            componentId = $componentId
            part = [string]$part.descriptor.part
            nativeShapeId = $part.nativeShapeId
            overflow = [bool]$fit.overflow
            boundHeight = [double]$fit.boundHeight
            availableHeight = [double]$fit.availableHeight
        }
        if ([bool]$fit.overflow) {
            throw "PPT_DUPLICATE_COMPONENT_TEXT_OVERFLOW: component=$componentId, part=$([string]$part.descriptor.part), boundHeight=$([double]$fit.boundHeight), availableHeight=$([double]$fit.availableHeight)"
        }
    }
    $after = Get-PptShapeRecordEnvelope $cloneRecords
    if ($null -eq $after -or [double]$after.width -le 0 -or [double]$after.height -le 0) {
        throw "PPT_DUPLICATE_COMPONENT_INVALID_ENVELOPE: component=$componentId"
    }
    if ([double]$after.left -lt 8 -or [double]$after.top -lt 8 -or
        ([double]$after.left + [double]$after.width) -gt ($slideWidth - 8) -or
        ([double]$after.top + [double]$after.height) -gt ($slideHeight - 8)) {
        throw "PPT_DUPLICATE_COMPONENT_OUT_OF_BOUNDS: component=$componentId"
    }
    return @{ beforeBounds = $before; afterBounds = $after; items = $fitItems; passed = $true }
}

function Get-PptDuplicateObjectResult($ppt, $pres, $options) {
    $slideIndex = [int](Get-ObjectPropertyValue $options "slideIndex")
    $resolvedSlide = Resolve-PptSlideBinding $pres $slideIndex (Get-ObjectPropertyValue $options "nativeSlideId") "duplicatePptObject"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $slideIndex = [int]$resolvedSlide.slideIndex
    $binding = Get-ObjectPropertyValue $options "sourceBinding"
    if ($null -eq $binding) {
        return New-PptRecoverableError "PPT_DUPLICATE_OBJECT_BINDING_REQUIRED" "duplicatePptObject requires a frozen sourceBinding." @{ slideIndex = $slideIndex }
    }
    $nativeShapeId = Get-ObjectPropertyValue $binding "nativeShapeId"
    $shapeIndex = if ($null -ne $nativeShapeId) { Get-PptShapeIndexByNativeId $slide $nativeShapeId } else { $null }
    if ($null -eq $shapeIndex) { $shapeIndex = [int](Get-ObjectPropertyValue $binding "shapeIndex") }
    if ($shapeIndex -lt 1 -or $shapeIndex -gt $slide.Shapes.Count) {
        return New-PptRecoverableError "PPT_DUPLICATE_OBJECT_BINDING_STALE" "The frozen source object no longer exists." @{ slideIndex = $slideIndex; binding = $binding }
    }
    $source = $slide.Shapes.Item($shapeIndex)
    $actualNativeId = $null
    try { $actualNativeId = [int]$source.Id } catch {}
    if ($null -ne $nativeShapeId -and [int]$nativeShapeId -ne [int]$actualNativeId) {
        return New-PptRecoverableError "PPT_DUPLICATE_OBJECT_BINDING_STALE" "The frozen source object binding changed." @{ expectedNativeShapeId = $nativeShapeId; actualNativeShapeId = $actualNativeId }
    }
    $expectedShapeName = [string](Get-ObjectPropertyValue $binding "expectedShapeName")
    if (-not [string]::IsNullOrWhiteSpace($expectedShapeName) -and [string]$source.Name -ne $expectedShapeName) {
        return New-PptRecoverableError "PPT_DUPLICATE_OBJECT_BINDING_STALE" "The frozen source object name changed." @{ expectedShapeName = $expectedShapeName; actualShapeName = [string]$source.Name }
    }
    $sourceRecord = @{
        shape = $source
        shapeIndex = $shapeIndex
        nativeShapeId = $actualNativeId
        binding = $binding
        part = ""
        canonicalPart = ""
        itemId = ""
        contentBlockId = ""
    }
    $sourceRecords = @($sourceRecord)
    $sourceBounds = Get-PptShapeRecordEnvelope $sourceRecords
    $slideWidth = [double]$pres.PageSetup.SlideWidth
    $slideHeight = [double]$pres.PageSetup.SlideHeight
    if ($contentFitOnly) {
        $safeLeft = 0.0
        $safeRight = [double]$pres.PageSetup.SlideWidth
        $safeTop = 0.0
        $safeBottom = $slideHeight
    }
    $sourceNativeIds = @{ ([string]$actualNativeId) = $true }
    $copyCount = [Math]::Max(1, [Math]::Min(20, [int](Get-ObjectPropertyValue $options "copyCount")))
    $relativePlacement = Get-ObjectPropertyValue $options "relativePlacement"
    if ($null -eq $relativePlacement) {
        $relativePlacement = @{ reference = @{ kind = "source" }; direction = "auto"; alignment = "start"; gapIntent = "preferred" }
    }
    $spacingPolicy = Get-ObjectPropertyValue $options "spacingPolicy"
    $reference = Get-ObjectPropertyValue $options "reference"
    $referenceRecords = $sourceRecords
    if ($null -ne $reference -and [string](Get-ObjectPropertyValue $reference "kind") -ne "source") {
        $referenceRecords = @(Resolve-PptDuplicateBindingRecords $slide @((Get-ObjectPropertyValue $reference "bindings")) "reference")
    }
    $referenceBounds = Get-PptShapeRecordEnvelope $referenceRecords
    if ($null -eq $referenceBounds) {
        return New-PptRecoverableError "PPT_DUPLICATE_REFERENCE_BINDING_REQUIRED" "The relative placement reference could not be resolved." @{ slideIndex = $slideIndex }
    }
    $operationId = [string](Get-ObjectPropertyValue $options "operationId")
    $createdNativeIds = @()
    $createdObjectIds = @()
    $createdSummary = @()
    $placements = @()
    $verificationItems = @()
    $creationReceipts = @()
    $sourceSnapshot = Get-PptShapeSnapshot $source
    $nextReferenceRecords = $referenceRecords
    try {
        for ($copyIndex = 0; $copyIndex -lt $copyCount; $copyIndex++) {
            $currentReferenceBounds = Get-PptShapeRecordEnvelope $nextReferenceRecords
            $placementResult = Resolve-PptDuplicatePlacement $slide $sourceNativeIds $currentReferenceBounds $sourceBounds $relativePlacement $spacingPolicy $slideWidth $slideHeight
            if ($null -eq $placementResult) {
                $direction = [string](Get-ObjectPropertyValue $relativePlacement "direction")
                $alignment = [string](Get-ObjectPropertyValue $relativePlacement "alignment")
                throw "PPT_DUPLICATE_RELATIVE_PLACEMENT_NO_SPACE: direction=$direction, alignment=$alignment, slide=$slideIndex"
            }
            $placement = $placementResult.bounds
            $clone = Copy-PptShapeAndResolveClone $slide $source
            $clone.Left = [double]$placement.left
            $clone.Top = [double]$placement.top
            $cloneNativeId = [int]$clone.Id
            $clone.Name = "$([string]$source.Name)_copy_$cloneNativeId"
            $createdNativeIds += $cloneNativeId
            $cloneShapeIndex = Get-PptShapeIndexByNativeId $slide $cloneNativeId
            $cloneObjectId = "slide:${slideIndex}:shape:$cloneShapeIndex"
            $createdObjectIds += $cloneObjectId
            $cloneRecord = @{
                shape = $clone
                shapeIndex = $cloneShapeIndex
                nativeShapeId = $cloneNativeId
                binding = @{}
                part = ""
                canonicalPart = ""
                itemId = ""
                contentBlockId = ""
            }
            $cloneRecords = @($cloneRecord)
            $sourceSignature = Get-PptDuplicateShapeSignature $source ([double]$sourceBounds.left) ([double]$sourceBounds.top)
            $cloneSignature = Get-PptDuplicateShapeSignature $clone ([double]$placement.left) ([double]$placement.top)
            $mismatches = @(Test-PptDuplicateShapeSignature $sourceSignature $cloneSignature)
            $verificationItems += @{
                sourceNativeShapeId = $actualNativeId
                cloneNativeShapeId = $cloneNativeId
                equivalent = ($mismatches.Count -eq 0)
                mismatches = $mismatches
            }
            if ($mismatches.Count -gt 0) { throw "PPT_DUPLICATE_OBJECT_EQUIVALENCE_FAILED: fields=$($mismatches -join ',')" }
            $createdSummary += @{
                objectId = $cloneObjectId
                nativeShapeId = $cloneNativeId
                shapeIndex = $cloneShapeIndex
                shapeName = [string]$clone.Name
                bounds = @{ left = [double]$clone.Left; top = [double]$clone.Top; width = [double]$clone.Width; height = [double]$clone.Height }
            }
            $placements += @{
                objectId = $cloneObjectId
                bounds = $placement
                deltaLeft = [double]$placement.left - [double]$sourceBounds.left
                deltaTop = [double]$placement.top - [double]$sourceBounds.top
                relation = $placementResult.relation
            }
            $createdBinding = Get-PptDuplicateEntityBinding $pres $slide $slideIndex $cloneRecords "" $cloneObjectId
            $creationReceipts += @{
                operationId = $operationId
                resultIndex = $copyIndex
                entityKind = "object"
                source = (Get-PptDuplicateEntityBinding $pres $slide $slideIndex $sourceRecords "" ([string](Get-ObjectPropertyValue $binding "objectId")))
                reference = (Get-PptDuplicateEntityBinding $pres $slide $slideIndex $nextReferenceRecords)
                created = $createdBinding
                placement = $placementResult.relation
                status = "committed"
            }
            $nextReferenceRecords = $cloneRecords
        }
        $sourceCheck = Test-PptShapeSnapshotsRestored $slide @($sourceSnapshot)
        if (-not [bool]$sourceCheck.ok) {
            throw "PPT_DUPLICATE_OBJECT_SOURCE_CHANGED: source object was modified during clone"
        }
    } catch {
        Remove-PptShapesByNativeId $slide $createdNativeIds
        $rollbackVerification = Test-PptShapeSnapshotsRestored $slide @($sourceSnapshot)
        if (-not [bool]$rollbackVerification.ok) {
            Restore-PptShapeSnapshots $slide @($sourceSnapshot)
            $rollbackVerification = Test-PptShapeSnapshotsRestored $slide @($sourceSnapshot)
        }
        return @{
            success = $false
            error = $_.Exception.Message
            data = @{
                transactional = $true
                rolledBack = $true
                rollbackVerified = [bool]$rollbackVerification.ok
                rollbackVerification = $rollbackVerification
                wroteToWps = $false
                slideIndex = $slideIndex
                sourceObjectId = [string](Get-ObjectPropertyValue $binding "objectId")
                created = $createdSummary
                verification = @{ passed = $false; items = $verificationItems }
                diagnostic = @{ scriptStackTrace = [string]$_.ScriptStackTrace; position = [string]$_.InvocationInfo.PositionMessage }
            }
        }
    }
    return @{
        success = $true
        data = @{
            transactional = $true
            rolledBack = $false
            wroteToWps = $true
            slideIndex = $slideIndex
            sourceObjectId = [string](Get-ObjectPropertyValue $binding "objectId")
            createdObjectCount = $createdNativeIds.Count
            createdObjectIds = $createdObjectIds
            created = $createdSummary
            placement = $placements
            creationReceipts = $creationReceipts
            verification = @{ passed = $true; checkedObjectCount = $verificationItems.Count; items = $verificationItems }
        }
    }
}

function Get-PptDuplicateComponentResult($ppt, $pres, $options) {
    $slideIndex = [int](Get-ObjectPropertyValue $options "slideIndex")
    $resolvedSlide = Resolve-PptSlideBinding $pres $slideIndex (Get-ObjectPropertyValue $options "nativeSlideId") "duplicatePptComponent"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $slideIndex = [int]$resolvedSlide.slideIndex
    $bindings = @((Get-ObjectPropertyValue $options "componentBindings"))
    if ($bindings.Count -eq 0) {
        return New-PptRecoverableError "PPT_DUPLICATE_COMPONENT_BINDINGS_REQUIRED" "duplicatePptComponent requires frozen componentBindings." @{ slideIndex = $slideIndex }
    }
    $sourceRecords = @()
    $sourceNativeIds = @{}
    foreach ($binding in $bindings) {
        $nativeShapeId = Get-ObjectPropertyValue $binding "nativeShapeId"
        $shapeIndex = if ($null -ne $nativeShapeId) { Get-PptShapeIndexByNativeId $slide $nativeShapeId } else { $null }
        if ($null -eq $shapeIndex) { $shapeIndex = [int](Get-ObjectPropertyValue $binding "shapeIndex") }
        if ($shapeIndex -lt 1 -or $shapeIndex -gt $slide.Shapes.Count) {
            return New-PptRecoverableError "PPT_DUPLICATE_COMPONENT_BINDING_STALE" "A frozen source shape no longer exists." @{ slideIndex = $slideIndex; binding = $binding }
        }
        $shape = $slide.Shapes.Item($shapeIndex)
        $actualNativeId = $null
        try { $actualNativeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeShapeId -and [int]$nativeShapeId -ne [int]$actualNativeId) {
            return New-PptRecoverableError "PPT_DUPLICATE_COMPONENT_BINDING_STALE" "A frozen source shape binding changed." @{ expectedNativeShapeId = $nativeShapeId; actualNativeShapeId = $actualNativeId }
        }
        $expectedShapeName = [string](Get-ObjectPropertyValue $binding "expectedShapeName")
        if (-not [string]::IsNullOrWhiteSpace($expectedShapeName) -and [string]$shape.Name -ne $expectedShapeName) {
            return New-PptRecoverableError "PPT_DUPLICATE_COMPONENT_BINDING_STALE" "A frozen source shape name changed." @{ expectedShapeName = $expectedShapeName; actualShapeName = [string]$shape.Name }
        }
        $sourceNativeIds[[string]$actualNativeId] = $true
        $sourceRecords += @{
            shape = $shape
            shapeIndex = $shapeIndex
            nativeShapeId = $actualNativeId
            binding = $binding
            part = [string](Get-ObjectPropertyValue $binding "part")
            canonicalPart = [string](Get-ObjectPropertyValue $binding "canonicalPart")
            itemId = [string](Get-ObjectPropertyValue $binding "itemId")
            contentBlockId = [string](Get-ObjectPropertyValue $binding "contentBlockId")
        }
    }
    $sourceRecords = @($sourceRecords | Sort-Object @{ Expression = { [int]$_.shapeIndex } })
    $sourceLeft = [double]::PositiveInfinity
    $sourceTop = [double]::PositiveInfinity
    $sourceRight = [double]::NegativeInfinity
    $sourceBottom = [double]::NegativeInfinity
    foreach ($sourceRecord in $sourceRecords) {
        $shapeLeft = [double]$sourceRecord.shape.Left
        $shapeTop = [double]$sourceRecord.shape.Top
        $shapeRight = $shapeLeft + [double]$sourceRecord.shape.Width
        $shapeBottom = $shapeTop + [double]$sourceRecord.shape.Height
        if ($shapeLeft -lt $sourceLeft) { $sourceLeft = $shapeLeft }
        if ($shapeTop -lt $sourceTop) { $sourceTop = $shapeTop }
        if ($shapeRight -gt $sourceRight) { $sourceRight = $shapeRight }
        if ($shapeBottom -gt $sourceBottom) { $sourceBottom = $shapeBottom }
    }
    $sourceBounds = @{ left = $sourceLeft; top = $sourceTop; width = $sourceRight - $sourceLeft; height = $sourceBottom - $sourceTop }
    $slideWidth = [double]$pres.PageSetup.SlideWidth
    $slideHeight = [double]$pres.PageSetup.SlideHeight
    $copyCount = [Math]::Max(1, [Math]::Min(20, [int](Get-ObjectPropertyValue $options "copyCount")))
    $partOverrides = Get-ObjectPropertyValue $options "partOverrides"
    $relativePlacement = Get-ObjectPropertyValue $options "relativePlacement"
    if ($null -eq $relativePlacement) {
        $relativePlacement = @{ reference = @{ kind = "source" }; direction = "auto"; alignment = "start"; gapIntent = "preferred" }
    }
    $spacingPolicy = Get-ObjectPropertyValue $options "spacingPolicy"
    $reference = Get-ObjectPropertyValue $options "reference"
    $referenceRecords = $sourceRecords
    if ($null -ne $reference -and [string](Get-ObjectPropertyValue $reference "kind") -ne "source") {
        $referenceRecords = @(Resolve-PptDuplicateBindingRecords $slide @((Get-ObjectPropertyValue $reference "bindings")) "reference")
    }
    $referenceBounds = Get-PptShapeRecordEnvelope $referenceRecords
    if ($null -eq $referenceBounds) {
        return New-PptRecoverableError "PPT_DUPLICATE_REFERENCE_BINDING_REQUIRED" "The relative placement reference could not be resolved." @{ slideIndex = $slideIndex }
    }
    $operationId = [string](Get-ObjectPropertyValue $options "operationId")
    $createdNativeIds = @()
    $cloneComponentIds = @()
    $placements = @()
    $verificationItems = @()
    $overrideVerificationItems = @()
    $contentFitVerificationItems = @()
    $createdSummary = @()
    $creationReceipts = @()
    $sourceSnapshots = @($sourceRecords | ForEach-Object { Get-PptShapeSnapshot $_.shape })
    $nextReferenceRecords = $referenceRecords
    try {
        for ($copyIndex = 0; $copyIndex -lt $copyCount; $copyIndex++) {
            $currentReferenceBounds = Get-PptShapeRecordEnvelope $nextReferenceRecords
            $placementResult = Resolve-PptDuplicatePlacement $slide $sourceNativeIds $currentReferenceBounds $sourceBounds $relativePlacement $spacingPolicy $slideWidth $slideHeight
            if ($null -eq $placementResult) {
                $direction = [string](Get-ObjectPropertyValue $relativePlacement "direction")
                $alignment = [string](Get-ObjectPropertyValue $relativePlacement "alignment")
                throw "PPT_DUPLICATE_RELATIVE_PLACEMENT_NO_SPACE: direction=$direction, alignment=$alignment, slide=$slideIndex"
            }
            $placement = $placementResult.bounds
            $componentType = [string](Get-ObjectPropertyValue $sourceRecords[0].binding "componentType")
            if ([string]::IsNullOrWhiteSpace($componentType)) {
                $descriptor = Get-PptComponentDescriptor ([string]$sourceRecords[0].shape.Name)
                if ($null -ne $descriptor) { $componentType = [string]$descriptor.componentType }
            }
            if ([string]::IsNullOrWhiteSpace($componentType)) { $componentType = "component" }
            $componentType = $componentType -replace '[^a-zA-Z0-9_]', '_'
            $cloneComponentId = "R4_${componentType}_$(Get-PptNextR4ComponentIndex $slide)"
            $cloneComponentIds += $cloneComponentId
            $deltaLeft = [double]$placement.left - $sourceLeft
            $deltaTop = [double]$placement.top - $sourceTop
            $cloneRecords = @()
            for ($sourceIndex = 0; $sourceIndex -lt $sourceRecords.Count; $sourceIndex++) {
                $sourceRecord = $sourceRecords[$sourceIndex]
                # WPS exposes Shape.Duplicate(), but some builds return a 1x1
                # placeholder instead of a faithful clone. Clipboard copy/paste
                # preserves the native shape type, text, and complete styling.
                $clone = Copy-PptShapeAndResolveClone $slide $sourceRecord.shape
                $clone.Left = [double]$sourceRecord.shape.Left + $deltaLeft
                $clone.Top = [double]$sourceRecord.shape.Top + $deltaTop
                $part = [string](Get-ObjectPropertyValue $sourceRecord.binding "part")
                if ([string]::IsNullOrWhiteSpace($part)) { $part = "part_$($sourceIndex + 1)" }
                $canonicalPart = [string](Get-ObjectPropertyValue $sourceRecord.binding "canonicalPart")
                $itemId = [string](Get-ObjectPropertyValue $sourceRecord.binding "itemId")
                $itemSuffix = if (-not [string]::IsNullOrWhiteSpace($itemId)) { "__ITEM_${itemId}" } else { "" }
                $clone.Name = "${cloneComponentId}_${part}${itemSuffix}"
                $cloneNativeId = [int]$clone.Id
                $createdNativeIds += $cloneNativeId
                $cloneRecords += @{
                    shape = $clone
                    nativeShapeId = $cloneNativeId
                    sourceNativeShapeId = $sourceRecord.nativeShapeId
                    part = $part
                    canonicalPart = $canonicalPart
                    itemId = $itemId
                    contentBlockId = [string](Get-ObjectPropertyValue $sourceRecord.binding "contentBlockId")
                }
            }
            for ($sourceIndex = 0; $sourceIndex -lt $sourceRecords.Count; $sourceIndex++) {
                $sourceSignature = Get-PptDuplicateShapeSignature $sourceRecords[$sourceIndex].shape $sourceLeft $sourceTop
                $cloneSignature = Get-PptDuplicateShapeSignature $cloneRecords[$sourceIndex].shape ([double]$placement.left) ([double]$placement.top)
                $mismatches = @(Test-PptDuplicateShapeSignature $sourceSignature $cloneSignature)
                $verificationItems += @{
                    part = $cloneRecords[$sourceIndex].part
                    sourceNativeShapeId = $sourceRecords[$sourceIndex].nativeShapeId
                    cloneNativeShapeId = $cloneRecords[$sourceIndex].nativeShapeId
                    equivalent = ($mismatches.Count -eq 0)
                    mismatches = $mismatches
                }
                if ($mismatches.Count -gt 0) { throw "PPT_DUPLICATE_COMPONENT_EQUIVALENCE_FAILED: part=$($cloneRecords[$sourceIndex].part), fields=$($mismatches -join ',')" }
            }
            if ($null -ne $partOverrides) {
                foreach ($cloneRecord in $cloneRecords) {
                    $canonicalPart = [string]$cloneRecord.canonicalPart
                    if ([string]::IsNullOrWhiteSpace($canonicalPart)) { continue }
                    $overrideText = Get-ObjectPropertyValue $partOverrides $canonicalPart
                    if ($null -eq $overrideText) { continue }
                    $shape = $cloneRecord.shape
                    $hasTextFrame = $false
                    try { $hasTextFrame = ([int]$shape.HasTextFrame -ne 0) } catch {}
                    if (-not $hasTextFrame) {
                        throw "PPT_DUPLICATE_COMPONENT_OVERRIDE_NOT_TEXT: part=$canonicalPart"
                    }
                    $shape.TextFrame.TextRange.Text = [string]$overrideText
                    $actualText = [string]$shape.TextFrame.TextRange.Text
                    $overridePassed = ($actualText -eq [string]$overrideText)
                    $overrideVerificationItems += @{
                        componentId = $cloneComponentId
                        part = $canonicalPart
                        cloneNativeShapeId = $cloneRecord.nativeShapeId
                        expectedText = [string]$overrideText
                        actualText = $actualText
                        passed = $overridePassed
                    }
                    if (-not $overridePassed) {
                        throw "PPT_DUPLICATE_COMPONENT_OVERRIDE_FAILED: part=$canonicalPart"
                    }
                }
            }
            $hasPartOverrides = $null -ne $partOverrides -and @($partOverrides.psobject.Properties).Count -gt 0
            if ($hasPartOverrides) {
                $fitVerification = Fit-PptDuplicatedComponentContent $slide $cloneRecords $cloneComponentId $componentType $slideWidth $slideHeight
                $contentFitVerificationItems += @($fitVerification.items)
            }
            $cloneIgnoreIds = @{}
            foreach ($cloneRecord in $cloneRecords) { $cloneIgnoreIds[[string]$cloneRecord.nativeShapeId] = $true }
            $finalBounds = Get-PptShapeRecordEnvelope $cloneRecords
            $direction = [string](Get-ObjectPropertyValue $relativePlacement "direction")
            if ($direction -ne "auto") {
                $finalPlacementResult = Resolve-PptDuplicatePlacement $slide $cloneIgnoreIds $currentReferenceBounds $finalBounds $relativePlacement $spacingPolicy $slideWidth $slideHeight
                if ($null -eq $finalPlacementResult) {
                    throw "PPT_DUPLICATE_COMPONENT_NO_SPACE_AFTER_CONTENT_FIT: component=$cloneComponentId, direction=$direction"
                }
                Move-PptShapeRecords $cloneRecords ([double]$finalPlacementResult.bounds.left - [double]$finalBounds.left) ([double]$finalPlacementResult.bounds.top - [double]$finalBounds.top)
                $placementResult = $finalPlacementResult
                $finalBounds = Get-PptShapeRecordEnvelope $cloneRecords
            } elseif (-not (Test-PptDuplicateEnvelopePlacement $slide $cloneIgnoreIds ([double]$finalBounds.left) ([double]$finalBounds.top) ([double]$finalBounds.width) ([double]$finalBounds.height) $slideWidth $slideHeight 8)) {
                $finalPlacementResult = Resolve-PptDuplicatePlacement $slide $cloneIgnoreIds $currentReferenceBounds $finalBounds $relativePlacement $spacingPolicy $slideWidth $slideHeight
                if ($null -eq $finalPlacementResult) {
                    throw "PPT_DUPLICATE_COMPONENT_NO_SPACE_AFTER_CONTENT_FIT: component=$cloneComponentId"
                }
                Move-PptShapeRecords $cloneRecords ([double]$finalPlacementResult.bounds.left - [double]$finalBounds.left) ([double]$finalPlacementResult.bounds.top - [double]$finalBounds.top)
                $placementResult = $finalPlacementResult
                $finalBounds = Get-PptShapeRecordEnvelope $cloneRecords
            }
            if (-not (Test-PptDuplicateEnvelopePlacement $slide $cloneIgnoreIds ([double]$finalBounds.left) ([double]$finalBounds.top) ([double]$finalBounds.width) ([double]$finalBounds.height) $slideWidth $slideHeight 8)) {
                throw "PPT_DUPLICATE_COMPONENT_PLACEMENT_CONFLICT_AFTER_CONTENT_FIT: component=$cloneComponentId"
            }
            foreach ($cloneRecord in $cloneRecords) {
                $clone = $cloneRecord.shape
                $createdSummary += @{
                    componentId = $cloneComponentId
                    part = [string]$cloneRecord.part
                    canonicalPart = [string]$cloneRecord.canonicalPart
                    nativeShapeId = $cloneRecord.nativeShapeId
                    shapeIndex = (Get-PptShapeIndexByNativeId $slide $cloneRecord.nativeShapeId)
                    shapeName = [string]$clone.Name
                    bounds = @{ left = [double]$clone.Left; top = [double]$clone.Top; width = [double]$clone.Width; height = [double]$clone.Height }
                }
            }
            $placements += @{
                componentId = $cloneComponentId
                bounds = $finalBounds
                deltaLeft = [double]$finalBounds.left - $sourceLeft
                deltaTop = [double]$finalBounds.top - $sourceTop
                relation = $placementResult.relation
            }
            $createdBinding = Get-PptDuplicateEntityBinding $pres $slide $slideIndex $cloneRecords $cloneComponentId
            $createdBinding["partBindings"] = @($cloneRecords | ForEach-Object {
                @{
                    itemId = [string]$_.itemId
                    contentBlockId = [string]$_.contentBlockId
                    part = $(if (-not [string]::IsNullOrWhiteSpace([string]$_.canonicalPart)) { [string]$_.canonicalPart } else { [string]$_.part })
                    sourceNativeShapeId = [int]$_.sourceNativeShapeId
                    createdNativeShapeId = [int]$_.nativeShapeId
                }
            })
            $contentLineage = @($cloneRecords | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.contentBlockId) } | ForEach-Object {
                $lineagePart = $(if (-not [string]::IsNullOrWhiteSpace([string]$_.canonicalPart)) { [string]$_.canonicalPart } else { [string]$_.part })
                @{
                    sourceContentBlockId = [string]$_.contentBlockId
                    createdOccurrenceId = "${operationId}:${copyIndex}:$([string]$_.contentBlockId):${lineagePart}"
                    authorizedDuplicate = $true
                    overridden = ($null -ne $partOverrides -and $null -ne (Get-ObjectPropertyValue $partOverrides $lineagePart))
                }
            })
            $creationReceipts += @{
                operationId = $operationId
                resultIndex = $copyIndex
                entityKind = "component"
                source = (Get-PptDuplicateEntityBinding $pres $slide $slideIndex $sourceRecords ([string](Get-ObjectPropertyValue $options "sourceComponentId")))
                reference = (Get-PptDuplicateEntityBinding $pres $slide $slideIndex $nextReferenceRecords)
                created = $createdBinding
                placement = $placementResult.relation
                contentLineage = $contentLineage
                status = "committed"
            }
            $nextReferenceRecords = $cloneRecords
        }
        $sourceRollbackCheck = Test-PptShapeSnapshotsRestored $slide $sourceSnapshots
        if (-not [bool]$sourceRollbackCheck.ok) {
            throw "PPT_DUPLICATE_COMPONENT_SOURCE_CHANGED: source component was modified during clone"
        }
    } catch {
        Remove-PptShapesByNativeId $slide $createdNativeIds
        $rollbackVerification = Test-PptShapeSnapshotsRestored $slide $sourceSnapshots
        if (-not [bool]$rollbackVerification.ok) {
            Restore-PptShapeSnapshots $slide $sourceSnapshots
            $rollbackVerification = Test-PptShapeSnapshotsRestored $slide $sourceSnapshots
        }
        $rawReason = [string]$_.Exception.Message
        $blockedBeforeWrite =
            $createdNativeIds.Count -eq 0 -and
            $rawReason -match '^PPT_DUPLICATE_RELATIVE_PLACEMENT_NO_SPACE'
        $hadProvisionalWrites = $createdNativeIds.Count -gt 0
        return @{
            success = $false
            error = $rawReason
            data = @{
                transactional = $true
                blocked = $blockedBeforeWrite
                rolledBack = $hadProvisionalWrites
                rollbackVerified = $(if ($hadProvisionalWrites) { [bool]$rollbackVerification.ok } else { $false })
                pageUnchangedVerified = [bool]$rollbackVerification.ok
                rollbackVerification = $rollbackVerification
                wroteToWps = $false
                slideIndex = $slideIndex
                sourceComponentId = [string](Get-ObjectPropertyValue $options "sourceComponentId")
                reasonDetails = @{
                    rawReason = $rawReason
                    requestedPlacement = $relativePlacement
                    sourceBounds = $sourceBounds
                    referenceBounds = $referenceBounds
                    slideBounds = @{ left = 0; top = 0; width = $slideWidth; height = $slideHeight }
                }
                created = $createdSummary
                verification = @{ passed = $false; items = $verificationItems; overrideItems = $overrideVerificationItems; contentFitItems = $contentFitVerificationItems }
                diagnostic = @{ scriptStackTrace = [string]$_.ScriptStackTrace; position = [string]$_.InvocationInfo.PositionMessage }
            }
        }
    }
    return @{
        success = $true
        data = @{
            transactional = $true
            rolledBack = $false
            wroteToWps = $true
            slideIndex = $slideIndex
            sourceComponentId = [string](Get-ObjectPropertyValue $options "sourceComponentId")
            sourceObjectCount = $sourceRecords.Count
            createdObjectCount = $createdNativeIds.Count
            created = $createdSummary
            cloneComponentIds = $cloneComponentIds
            placement = $placements
            creationReceipts = $creationReceipts
            verification = @{
                passed = $true
                checkedObjectCount = $verificationItems.Count
                items = $verificationItems
                overrideItems = $overrideVerificationItems
                contentFitItems = $contentFitVerificationItems
            }
        }
    }
}

function Add-PptR4Component($slide, [int]$slideIndex, $component, $visual, [int]$componentIndex) {
    $typeValue = Get-ObjectPropertyValue $component "type"
    if (-not $typeValue) { $typeValue = Get-ObjectPropertyValue $component "componentType" }
    if (-not $typeValue) { $typeValue = Get-ObjectPropertyValue $component "kind" }
    $type = if ($typeValue) { [string]$typeValue } else { "" }
    $normalizedType = $type.Replace("-", "_")
    $requestedName = [string](Get-PptR4Value $component "name" "")
    $requestedNameInUse = $false
    if (-not [string]::IsNullOrWhiteSpace($requestedName)) {
        for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
            $existingName = [string]$slide.Shapes.Item($shapeIndex).Name
            if ($existingName -eq $requestedName -or $existingName.StartsWith($requestedName + "_")) {
                $requestedNameInUse = $true
                break
            }
        }
    }
    $namePrefix = if ([string]::IsNullOrWhiteSpace($requestedName) -or $requestedNameInUse) {
        "R4_" + $normalizedType + "_" + (Get-PptNextR4ComponentIndex $slide)
    } else {
        $requestedName
    }
    $created = @()
    $strictContent = [bool](Get-PptR4Value $component "strictContent" $false)

    switch ($normalizedType) {
        "section_header" {
            $left = Get-PptR4Number $component "left" $visual.margin
            $top = Get-PptR4Number $component "top" 36
            $width = Get-PptR4Number $component "width" (960 - ($visual.margin * 2))
            $height = Get-PptR4Number $component "height" 86
            $title = [string](Get-PptR4Value $component "title" $(if ($strictContent) { "" } else { "章节标题" }))
            $subtitle = [string](Get-PptR4Value $component "subtitle" "")
            $titleFontSize = Get-PptR4Number $component "titleFontSize" $visual.titleFontSize
            $accentWidth = Get-PptR4Number $component "accentWidth" 8
            if ($strictContent -and [string]::IsNullOrWhiteSpace($title)) {
                throw "strictContent section_header requires title"
            }

            $titleTop = $top + 4
            $hasSubtitle = -not [string]::IsNullOrWhiteSpace($subtitle)
            $requestedSubtitleHeight = Get-PptR4Number $component "subtitleHeight" 0
            $requestedTitleHeight = Get-PptR4Number $component "titleTextHeight" 0
            $subtitleHeight = if (-not $hasSubtitle) { 0 } elseif ($requestedSubtitleHeight -gt 0) { $requestedSubtitleHeight } else { [Math]::Max(24, [Math]::Min(48, $height * 0.3)) }
            $titleHeight = if ($requestedTitleHeight -gt 0) { $requestedTitleHeight } elseif ($hasSubtitle) {
                [Math]::Max(34, $height - 4 - 4 - $subtitleHeight - 8)
            } else {
                [Math]::Max(34, $height - 8)
            }
            $requiredHeaderHeight = 8 + $titleHeight + $(if ($hasSubtitle) { 4 + $subtitleHeight } else { 0 })
            if ($requiredHeaderHeight -gt $height) {
                throw "section_header content requires $requiredHeaderHeight pt but only $height pt is available"
            }
            $subtitleTop = $titleTop + $titleHeight + 4

            $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_band") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surfaceTint; lineColor = $visual.line; lineWidth = 0.75; transparency = 0.08 } $componentIndex $normalizedType
            $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_accent") "rectangle" $left $top $accentWidth $height @{ fillColor = $visual.accent; lineColor = $visual.accent; lineWidth = 0 } $componentIndex $normalizedType
            $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_title") $title ($left + 24) $titleTop ($width - 38) $titleHeight @{ fontName = $visual.fontName; fontSize = $titleFontSize; fontColor = $visual.title; bold = $true; alignment = "left"; verticalAlignment = "middle" } $componentIndex $normalizedType
            if (-not [string]::IsNullOrWhiteSpace($subtitle)) {
                $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_subtitle") $subtitle ($left + 24) $subtitleTop ($width - 38) $subtitleHeight @{ fontName = $visual.fontName; fontSize = $visual.bodyFontSize; fontColor = $visual.mutedText; alignment = "left"; verticalAlignment = "middle" } $componentIndex $normalizedType
            }
            break
        }
        "content_card" {
            $left = Get-PptR4Number $component "left" (64 + (($componentIndex % 2) * 420))
            $top = Get-PptR4Number $component "top" (140 + ([Math]::Floor($componentIndex / 2) * 128))
            $width = Get-PptR4Number $component "width" 380
            $height = Get-PptR4Number $component "height" 110
            $title = [string](Get-PptR4Value $component "title" $(if ($strictContent) { "" } else { "卡片标题" }))
            $body = [string](Get-PptR4Value $component "body" (Get-PptR4Value $component "text" $(if ($strictContent) { "" } else { "卡片内容" })))
            $bodyFontSize = Get-PptR4Number $component "bodyFontSize" $visual.bodyFontSize
            if ($strictContent -and [string]::IsNullOrWhiteSpace($title) -and [string]::IsNullOrWhiteSpace($body)) {
                throw "strictContent content_card requires title or body"
            }
            $titleHeight = if ([string]::IsNullOrWhiteSpace($title)) { 0 } else { Get-PptR4Number $component "titleTextHeight" 24 }
            $bodyHeight = if ([string]::IsNullOrWhiteSpace($body)) { 0 } else { Get-PptR4Number $component "bodyTextHeight" 0 }
            $bodyTopOffset = if ($titleHeight -gt 0) { 22 + $titleHeight + 5 } else { 26 }
            if ($bodyHeight -le 0 -and -not [string]::IsNullOrWhiteSpace($body)) {
                $bodyHeight = [Math]::Max(18, $height - $bodyTopOffset - 11)
            }
            $requiredHeight = $bodyTopOffset + $bodyHeight + 11
            if ($requiredHeight -gt $height + 0.5) {
                throw "content_card content requires $requiredHeight pt but only $height pt is available"
            }
            $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_bg") "roundedRectangle" $left $top $width $height @{ fillColor = $visual.surface; lineColor = $visual.line; lineWidth = 1 } $componentIndex $normalizedType
            $created += New-PptR4Shape $slide $slideIndex ($namePrefix + "_accent_rule") "rectangle" ($left + 18) ($top + 14) 48 4 @{ fillColor = $visual.secondary; lineColor = $visual.secondary; lineWidth = 0 } $componentIndex $normalizedType
            if (-not [string]::IsNullOrWhiteSpace($title)) {
                $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_title") $title ($left + 18) ($top + 22) ($width - 36) $titleHeight @{ fontName = $visual.fontName; fontSize = 15; fontColor = $visual.title; bold = $true; alignment = "left"; verticalAlignment = "middle" } $componentIndex $normalizedType
            }
            if (-not [string]::IsNullOrWhiteSpace($body)) {
                $bodyTop = $top + $bodyTopOffset
                $created += New-PptR4Textbox $slide $slideIndex ($namePrefix + "_body") $body ($left + 18) $bodyTop ($width - 36) $bodyHeight @{ fontName = $visual.fontName; fontSize = $bodyFontSize; fontColor = $visual.text; alignment = "left"; verticalAlignment = "top" } $componentIndex $normalizedType
            }
            break
        }
        "metric_card" {
            $created += New-PptR4KpiCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "kpi" {
            $created += New-PptR4KpiCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "kpi_card" {
            $created += New-PptR4KpiCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "persona_card" {
            $created += New-PptR4PersonaCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "route_step" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex "route_step_card"
            break
        }
        "route_step_card" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "process_step" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex "process_step_card"
            break
        }
        "process_step_card" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "timeline_step" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex "timeline_step_card"
            break
        }
        "timeline_step_card" {
            $created += New-PptR4StepCard $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "timeline_band" {
            $created += New-PptR4TimelineBand $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "quote" {
            $created += New-PptR4QuoteBanner $slide $slideIndex $namePrefix $component $visual $componentIndex "quote_banner"
            break
        }
        "quote_banner" {
            $created += New-PptR4QuoteBanner $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "image_caption" {
            $created += New-PptR4ImageCaptionBlock $slide $slideIndex $namePrefix $component $visual $componentIndex "image_caption_block"
            break
        }
        "image_caption_block" {
            $created += New-PptR4ImageCaptionBlock $slide $slideIndex $namePrefix $component $visual $componentIndex $normalizedType
            break
        }
        "styled_table" {
            $created += New-PptR4Table $slide $slideIndex ($namePrefix + "_table") $component $visual $componentIndex $normalizedType
            break
        }
        "data_table" {
            $created += New-PptR4Table $slide $slideIndex ($namePrefix + "_table") $component $visual $componentIndex $normalizedType
            break
        }
        default {
            throw "Unsupported R4 component type '$type'. Supported: section_header, content_card, metric_card, kpi_card, persona_card, route_step_card, timeline_step_card, timeline_band, process_step_card, quote_banner, image_caption_block, styled_table, data_table."
        }
    }

    return @{
        componentIndex = $componentIndex
        componentType = $normalizedType
        created = $created
    }
}

function Get-PptShapeSnapshot($shape, $groupPath = @()) {
    $textCapable = $false
    $hasText = $false
    $fontSize = $null
    $fontName = $null
    $fontBold = $null
    $fontItalic = $null
    $fontColor = $null
    $text = $null
    $alignment = $null
    $verticalAnchor = $null
    $fillVisible = $null
    $fillColor = $null
    $fillTransparency = $null
    $lineVisible = $null
    $lineColor = $null
    $lineTransparency = $null
    $lineDashStyle = $null
    $wordWrap = $null
    $autoSize = $null
    $marginLeft = $null
    $marginRight = $null
    $marginTop = $null
    $marginBottom = $null
    $lineWeight = $null
    $rotation = $null
    $lockAspectRatio = $null
    $zOrderPosition = $null
    $tableCells = @()
    $tableRowCount = $null
    $tableColumnCount = $null
    $tableRowHeights = @()
    $tableColumnWidths = @()
    $chartSnapshot = $null
    $textFormatting = $null
    $textParagraphs = @()
    $nativeType = $null
    $placeholderType = $null
    $pictureSnapshot = $null
    $connectorSnapshot = $null
    $groupMemberCount = $null
    try { $textCapable = [bool]($shape.HasTextFrame -ne 0) } catch {}
    try { $hasText = [bool]($textCapable -and $shape.TextFrame.HasText) } catch {}
    if ($textCapable) {
        try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
        try { $fontName = [string]$shape.TextFrame.TextRange.Font.Name } catch {}
        try { $fontBold = [int]$shape.TextFrame.TextRange.Font.Bold } catch {}
        try { $fontItalic = [int]$shape.TextFrame.TextRange.Font.Italic } catch {}
        try { $fontColor = [int]$shape.TextFrame.TextRange.Font.Color.RGB } catch {}
        try { $text = [string]$shape.TextFrame.TextRange.Text } catch {}
        try { $alignment = [int]$shape.TextFrame.TextRange.ParagraphFormat.Alignment } catch {}
        try { $verticalAnchor = [int]$shape.TextFrame.VerticalAnchor } catch {}
        try { $textFormatting = Get-PptTextFormattingSnapshot $shape.TextFrame.TextRange $shape } catch {}
        try { $textParagraphs = @(Get-PptCanonicalTextParagraphs $shape) } catch {}
    }
    try { $fillVisible = [int]$shape.Fill.Visible } catch {}
    try { $fillColor = [int]$shape.Fill.ForeColor.RGB } catch {}
    try { $fillTransparency = [double]$shape.Fill.Transparency } catch {}
    try { $lineVisible = [int]$shape.Line.Visible } catch {}
    try { $lineColor = [int]$shape.Line.ForeColor.RGB } catch {}
    try { $lineTransparency = [double]$shape.Line.Transparency } catch {}
    try { $lineDashStyle = [int]$shape.Line.DashStyle } catch {}
    try { $wordWrap = [int]$shape.TextFrame.WordWrap } catch {}
    try { $autoSize = [int]$shape.TextFrame.AutoSize } catch {}
    try { $marginLeft = [double]$shape.TextFrame.MarginLeft } catch {}
    try { $marginRight = [double]$shape.TextFrame.MarginRight } catch {}
    try { $marginTop = [double]$shape.TextFrame.MarginTop } catch {}
    try { $marginBottom = [double]$shape.TextFrame.MarginBottom } catch {}
    try { $lineWeight = [double]$shape.Line.Weight } catch {}
    try { $rotation = [double]$shape.Rotation } catch {}
    try { $lockAspectRatio = [int]$shape.LockAspectRatio } catch {}
    try { $zOrderPosition = [int]$shape.ZOrderPosition } catch {}
    try { $nativeType = [int]$shape.Type } catch {}
    try { $placeholderType = [int]$shape.PlaceholderFormat.Type } catch {}
    try {
        if ($nativeType -eq 11 -or $nativeType -eq 13) {
            $sourcePath = $(try { [string]$shape.LinkFormat.SourceFullName } catch { $null })
            $pictureSnapshot = @{
                linked = [bool]($nativeType -eq 11 -or -not [string]::IsNullOrWhiteSpace([string]$sourcePath))
                sourcePath = $sourcePath
                colorType = $(try { [int]$shape.PictureFormat.ColorType } catch { $null })
                cropLeft = $(try { [double]$shape.PictureFormat.CropLeft } catch { $null })
                cropTop = $(try { [double]$shape.PictureFormat.CropTop } catch { $null })
                cropRight = $(try { [double]$shape.PictureFormat.CropRight } catch { $null })
                cropBottom = $(try { [double]$shape.PictureFormat.CropBottom } catch { $null })
            }
        }
    } catch {}
    try {
        if ($shape.Connector -ne 0 -or $nativeType -eq 9) {
            $connectorSnapshot = @{
                connectorType = $(try { [int]$shape.ConnectorFormat.Type } catch { $null })
                beginConnected = [bool]($shape.ConnectorFormat.BeginConnected -ne 0)
                endConnected = [bool]($shape.ConnectorFormat.EndConnected -ne 0)
                beginConnectedShapeId = $(try { [int]$shape.ConnectorFormat.BeginConnectedShape.Id } catch { $null })
                endConnectedShapeId = $(try { [int]$shape.ConnectorFormat.EndConnectedShape.Id } catch { $null })
                beginConnectionSite = $(try { [int]$shape.ConnectorFormat.BeginConnectionSite } catch { $null })
                endConnectionSite = $(try { [int]$shape.ConnectorFormat.EndConnectionSite } catch { $null })
                beginArrow = $(try { [int]$shape.Line.BeginArrowheadStyle } catch { $null })
                endArrow = $(try { [int]$shape.Line.EndArrowheadStyle } catch { $null })
            }
        }
    } catch {}
    try { if ($nativeType -eq 6) { $groupMemberCount = [int]$shape.GroupItems.Count } } catch {}
    try {
        if ($shape.HasTable) {
            $tableRowCount = [int]$shape.Table.Rows.Count
            $tableColumnCount = [int]$shape.Table.Columns.Count
            $tableRowHeights = @(1..$shape.Table.Rows.Count | ForEach-Object { [double]$shape.Table.Rows.Item($_).Height })
            $tableColumnWidths = @(1..$shape.Table.Columns.Count | ForEach-Object { [double]$shape.Table.Columns.Item($_).Width })
            for ($row = 1; $row -le $shape.Table.Rows.Count; $row++) {
                for ($col = 1; $col -le $shape.Table.Columns.Count; $col++) {
                    $tableCells += @{
                        row = $row
                        col = $col
                        text = [string]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Text
                        fillColor = $(try { [int]$shape.Table.Cell($row, $col).Shape.Fill.ForeColor.RGB } catch { $null })
                        fontColor = $(try { [int]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Font.Color.RGB } catch { $null })
                        fontName = $(try { [string]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Font.Name } catch { $null })
                        fontSize = $(try { [double]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Font.Size } catch { $null })
                        fontBold = $(try { [int]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Font.Bold } catch { $null })
                        alignment = $(try { [int]$shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.ParagraphFormat.Alignment } catch { $null })
                        paragraph = $(try { Get-PptTableCellParagraph $shape.Table.Cell($row, $col).Shape } catch { $null })
                        borders = $(try { Get-PptTableCellBorders $shape.Table.Cell($row, $col) } catch { $null })
                    }
                }
            }
        }
    } catch {}
    try {
        if ([int]$shape.Type -eq 3) {
            $chartHasTitle = [bool]$shape.Chart.HasTitle
            $chartSnapshot = @{
                chartType = [int]$shape.Chart.ChartType
                hasTitle = $chartHasTitle
                title = $(if ($chartHasTitle) { [string]$shape.Chart.ChartTitle.Text } else { "" })
                hasLegend = [bool]$shape.Chart.HasLegend
                legendPosition = $(if ([bool]$shape.Chart.HasLegend) { try { [int]$shape.Chart.Legend.Position } catch { $null } } else { $null })
                axes = @(Get-PptChartAxesSnapshot $shape.Chart)
                series = @(Get-PptChartSeriesSnapshot $shape.Chart)
            }
        }
    } catch {}
    return @{
        nativeShapeId = $(try { [int]$shape.Id } catch { $null })
        name = [string]$shape.Name
        groupPath = @($groupPath | ForEach-Object { [int]$_ })
        textCapable = $textCapable
        hasText = $hasText
        left = [double]$shape.Left
        top = [double]$shape.Top
        width = [double]$shape.Width
        height = [double]$shape.Height
        fontSize = $fontSize
        fontName = $fontName
        fontBold = $fontBold
        fontItalic = $fontItalic
        fontColor = $fontColor
        text = $text
        textFormatting = $textFormatting
        textParagraphs = $textParagraphs
        alignment = $alignment
        verticalAnchor = $verticalAnchor
        fillVisible = $fillVisible
        fillColor = $fillColor
        fillTransparency = $fillTransparency
        lineVisible = $lineVisible
        lineColor = $lineColor
        lineTransparency = $lineTransparency
        lineDashStyle = $lineDashStyle
        wordWrap = $wordWrap
        autoSize = $autoSize
        marginLeft = $marginLeft
        marginRight = $marginRight
        marginTop = $marginTop
        marginBottom = $marginBottom
        lineWeight = $lineWeight
        rotation = $rotation
        lockAspectRatio = $lockAspectRatio
        zOrderPosition = $zOrderPosition
        tableCells = $tableCells
        tableRowCount = $tableRowCount
        tableColumnCount = $tableColumnCount
        tableRowHeights = $tableRowHeights
        tableColumnWidths = $tableColumnWidths
        chart = $chartSnapshot
        nativeType = $nativeType
        placeholderType = $placeholderType
        picture = $pictureSnapshot
        connector = $connectorSnapshot
        groupMemberCount = $groupMemberCount
        nativeSignature = Get-PptDuplicateShapeSignature $shape ([double]$shape.Left) ([double]$shape.Top)
    }
}

function Restore-PptShapeSnapshots($slide, $snapshots) {
    foreach ($snapshot in @($snapshots)) {
        $snapshotTarget = @{
            nativeShapeId = Get-ObjectPropertyValue $snapshot "nativeShapeId"
            expectedShapeName = [string](Get-ObjectPropertyValue $snapshot "name")
            groupPath = @((Get-ObjectPropertyValue $snapshot "groupPath"))
        }
        $resolvedShape = Resolve-PptShape $slide $snapshotTarget "restorePptMutationSnapshot"
        if (-not $resolvedShape.ok) { continue }
        $shape = $resolvedShape.shape
        $current = Get-PptShapeSnapshot $shape
        if ([Math]::Abs([double]$current.left - [double]$snapshot.left) -gt 0.01) { try { $shape.Left = [double]$snapshot.left } catch {} }
        if ([Math]::Abs([double]$current.top - [double]$snapshot.top) -gt 0.01) { try { $shape.Top = [double]$snapshot.top } catch {} }
        if ([Math]::Abs([double]$current.width - [double]$snapshot.width) -gt 0.01) { try { $shape.Width = [double]$snapshot.width } catch {} }
        if ([Math]::Abs([double]$current.height - [double]$snapshot.height) -gt 0.01) { try { $shape.Height = [double]$snapshot.height } catch {} }
        if ($null -ne $snapshot.text -and [string]$current.text -ne [string]$snapshot.text) { try { $shape.TextFrame.TextRange.Text = [string]$snapshot.text } catch {} }
        $formattingRuns = @((Get-ObjectPropertyValue (Get-ObjectPropertyValue $snapshot "textFormatting") "runs"))
        if ($formattingRuns.Count -gt 0) {
            Restore-PptTextFormattingSnapshot $shape (Get-ObjectPropertyValue $snapshot "textFormatting") | Out-Null
        } else {
            if ($null -ne $snapshot.fontSize -and ($null -eq $current.fontSize -or [Math]::Abs([double]$current.fontSize - [double]$snapshot.fontSize) -gt 0.01)) { try { $shape.TextFrame.TextRange.Font.Size = [double]$snapshot.fontSize } catch {} }
            if ($null -ne $snapshot.fontName -and [string]$current.fontName -ne [string]$snapshot.fontName) { try { $shape.TextFrame.TextRange.Font.Name = [string]$snapshot.fontName } catch {} }
            if ($null -ne $snapshot.fontBold -and [string]$current.fontBold -ne [string]$snapshot.fontBold) { try { $shape.TextFrame.TextRange.Font.Bold = [int]$snapshot.fontBold } catch {} }
            if ($null -ne $snapshot.fontItalic -and [string]$current.fontItalic -ne [string]$snapshot.fontItalic) { try { $shape.TextFrame.TextRange.Font.Italic = [int]$snapshot.fontItalic } catch {} }
            if ($null -ne $snapshot.fontColor -and [string]$current.fontColor -ne [string]$snapshot.fontColor) { try { $shape.TextFrame.TextRange.Font.Color.RGB = [int]$snapshot.fontColor } catch {} }
            if ($null -ne $snapshot.alignment -and [string]$current.alignment -ne [string]$snapshot.alignment) { try { $shape.TextFrame.TextRange.ParagraphFormat.Alignment = [int]$snapshot.alignment } catch {} }
        }
        if ($null -ne $snapshot.verticalAnchor -and [string]$current.verticalAnchor -ne [string]$snapshot.verticalAnchor) { try { $shape.TextFrame.VerticalAnchor = [int]$snapshot.verticalAnchor } catch {} }
        if ($null -ne $snapshot.fillVisible -and [string]$current.fillVisible -ne [string]$snapshot.fillVisible) { try { $shape.Fill.Visible = [int]$snapshot.fillVisible } catch {} }
        if ($null -ne $snapshot.fillColor -and [string]$current.fillColor -ne [string]$snapshot.fillColor) { try { $shape.Fill.ForeColor.RGB = [int]$snapshot.fillColor } catch {} }
        if ($null -ne $snapshot.fillTransparency -and ($null -eq $current.fillTransparency -or [Math]::Abs([double]$current.fillTransparency - [double]$snapshot.fillTransparency) -gt 0.01)) { try { $shape.Fill.Transparency = [double]$snapshot.fillTransparency } catch {} }
        if ($null -ne $snapshot.lineVisible -and [string]$current.lineVisible -ne [string]$snapshot.lineVisible) { try { $shape.Line.Visible = [int]$snapshot.lineVisible } catch {} }
        if ($null -ne $snapshot.lineColor -and [string]$current.lineColor -ne [string]$snapshot.lineColor) { try { $shape.Line.ForeColor.RGB = [int]$snapshot.lineColor } catch {} }
        if ($null -ne $snapshot.lineTransparency -and ($null -eq $current.lineTransparency -or [Math]::Abs([double]$current.lineTransparency - [double]$snapshot.lineTransparency) -gt 0.01)) { try { $shape.Line.Transparency = [double]$snapshot.lineTransparency } catch {} }
        if ($null -ne $snapshot.lineDashStyle -and [string]$current.lineDashStyle -ne [string]$snapshot.lineDashStyle) { try { $shape.Line.DashStyle = [int]$snapshot.lineDashStyle } catch {} }
        if ($null -ne $snapshot.wordWrap -and [string]$current.wordWrap -ne [string]$snapshot.wordWrap) { try { $shape.TextFrame.WordWrap = [int]$snapshot.wordWrap } catch {} }
        if ($null -ne $snapshot.autoSize -and [string]$current.autoSize -ne [string]$snapshot.autoSize) { try { $shape.TextFrame.AutoSize = [int]$snapshot.autoSize } catch {} }
        if ($null -ne $snapshot.marginLeft -and ($null -eq $current.marginLeft -or [Math]::Abs([double]$current.marginLeft - [double]$snapshot.marginLeft) -gt 0.01)) { try { $shape.TextFrame.MarginLeft = [double]$snapshot.marginLeft } catch {} }
        if ($null -ne $snapshot.marginRight -and ($null -eq $current.marginRight -or [Math]::Abs([double]$current.marginRight - [double]$snapshot.marginRight) -gt 0.01)) { try { $shape.TextFrame.MarginRight = [double]$snapshot.marginRight } catch {} }
        if ($null -ne $snapshot.marginTop -and ($null -eq $current.marginTop -or [Math]::Abs([double]$current.marginTop - [double]$snapshot.marginTop) -gt 0.01)) { try { $shape.TextFrame.MarginTop = [double]$snapshot.marginTop } catch {} }
        if ($null -ne $snapshot.marginBottom -and ($null -eq $current.marginBottom -or [Math]::Abs([double]$current.marginBottom - [double]$snapshot.marginBottom) -gt 0.01)) { try { $shape.TextFrame.MarginBottom = [double]$snapshot.marginBottom } catch {} }
        $paragraphSnapshots = @((Get-ObjectPropertyValue $snapshot "textParagraphs"))
        if ($paragraphSnapshots.Count -gt 0) {
            # WPS AutoSize can recompute effective paragraph spacing, so replay paragraphs after the frame mode.
            Restore-PptCanonicalTextParagraphs $shape $paragraphSnapshots | Out-Null
        }
        if ($null -ne $snapshot.lineWeight -and ($null -eq $current.lineWeight -or [Math]::Abs([double]$current.lineWeight - [double]$snapshot.lineWeight) -gt 0.01)) { try { $shape.Line.Weight = [double]$snapshot.lineWeight } catch {} }
        if ($null -ne $snapshot.rotation -and ($null -eq $current.rotation -or [Math]::Abs([double]$current.rotation - [double]$snapshot.rotation) -gt 0.01)) { try { $shape.Rotation = [double]$snapshot.rotation } catch {} }
        if ($null -ne $snapshot.lockAspectRatio -and [string]$current.lockAspectRatio -ne [string]$snapshot.lockAspectRatio) { try { $shape.LockAspectRatio = [int]$snapshot.lockAspectRatio } catch {} }
        $snapshotRowCount = Get-ObjectPropertyValue $snapshot "tableRowCount"
        if ($null -ne $snapshotRowCount -and [bool]$shape.HasTable) {
            while ([int]$shape.Table.Rows.Count -gt [int]$snapshotRowCount) {
                $shape.Table.Rows.Item($shape.Table.Rows.Count).Delete()
            }
            while ([int]$shape.Table.Rows.Count -lt [int]$snapshotRowCount) {
                $null = $shape.Table.Rows.Add()
            }
        }
        foreach ($cell in @($snapshot.tableCells)) {
            try {
                $cellShape = $shape.Table.Cell([int]$cell.row, [int]$cell.col).Shape
                $currentCellText = [string]$cellShape.TextFrame.TextRange.Text
                if ($currentCellText -ne [string]$cell.text) {
                    $cellShape.TextFrame.TextRange.Text = [string]$cell.text
                }
                if ($null -ne $cell.fillColor) { $cellShape.Fill.Solid(); $cellShape.Fill.ForeColor.RGB = [int]$cell.fillColor }
                if ($null -ne $cell.fontColor) { $cellShape.TextFrame.TextRange.Font.Color.RGB = [int]$cell.fontColor }
                if ($null -ne $cell.fontName) { $cellShape.TextFrame.TextRange.Font.Name = [string]$cell.fontName }
                if ($null -ne $cell.fontSize) { $cellShape.TextFrame.TextRange.Font.Size = [double]$cell.fontSize }
                if ($null -ne $cell.fontBold) { $cellShape.TextFrame.TextRange.Font.Bold = [int]$cell.fontBold }
                if ($null -ne $cell.alignment) { $cellShape.TextFrame.TextRange.ParagraphFormat.Alignment = [int]$cell.alignment }
                $paragraph = Get-ObjectPropertyValue $cell "paragraph"
                if ($null -ne $paragraph) {
                    $paragraphFormat = $cellShape.TextFrame.TextRange.ParagraphFormat
                    $paragraphAlignment = Get-ObjectPropertyValue $paragraph "alignment"
                    if ($null -ne $paragraphAlignment) {
                        $paragraphMap = @{ left = 1; center = 2; right = 3; justify = 4 }
                        $paragraphFormat.Alignment = [int]$paragraphMap[[string]$paragraphAlignment]
                    }
                    $spaceBefore = Get-ObjectPropertyValue $paragraph "spaceBefore"
                    if ($null -ne $spaceBefore) { $paragraphFormat.SpaceBefore = [double]$spaceBefore }
                    $spaceAfter = Get-ObjectPropertyValue $paragraph "spaceAfter"
                    if ($null -ne $spaceAfter) { $paragraphFormat.SpaceAfter = [double]$spaceAfter }
                    $lineSpacing = Get-ObjectPropertyValue $paragraph "lineSpacing"
                    if ($null -ne $lineSpacing) { $paragraphFormat.SpaceWithin = [double]$lineSpacing }
                }
                $borders = Get-ObjectPropertyValue $cell "borders"
                if ($null -ne $borders) {
                    foreach ($definition in @(
                        @{ name = "top"; value = 1 },
                        @{ name = "left"; value = 2 },
                        @{ name = "bottom"; value = 3 },
                        @{ name = "right"; value = 4 }
                    )) {
                        $borderSnapshot = Get-ObjectPropertyValue $borders ([string]$definition.name)
                        if ($null -eq $borderSnapshot) { continue }
                        $border = $shape.Table.Cell([int]$cell.row, [int]$cell.col).Borders.Item([int]$definition.value)
                        $borderColor = Get-ObjectPropertyValue $borderSnapshot "color"
                        if ($null -ne $borderColor) {
                            $rgb = Convert-HexColorToRgbInt ([string]$borderColor)
                            if ($null -ne $rgb) { $border.ForeColor.RGB = [int]$rgb }
                        }
                        $borderWidth = Get-ObjectPropertyValue $borderSnapshot "width"
                        if ($null -ne $borderWidth) { $border.Weight = [double]$borderWidth }
                    }
                }
            } catch {}
        }
        $rowHeights = @((Get-ObjectPropertyValue $snapshot "tableRowHeights"))
        for ($rowIndex = 0; $rowIndex -lt $rowHeights.Count; $rowIndex++) {
            try { $shape.Table.Rows.Item($rowIndex + 1).Height = [double]$rowHeights[$rowIndex] } catch {}
        }
        $columnWidths = @((Get-ObjectPropertyValue $snapshot "tableColumnWidths"))
        for ($columnIndex = 0; $columnIndex -lt $columnWidths.Count; $columnIndex++) {
            try { $shape.Table.Columns.Item($columnIndex + 1).Width = [double]$columnWidths[$columnIndex] } catch {}
        }
        $chartSnapshot = Get-ObjectPropertyValue $snapshot "chart"
        if ($null -ne $chartSnapshot) {
            try { $shape.Chart.ChartType = [int](Get-ObjectPropertyValue $chartSnapshot "chartType") } catch {}
            try { $shape.Chart.HasLegend = [bool](Get-ObjectPropertyValue $chartSnapshot "hasLegend") } catch {}
            $legendPosition = Get-ObjectPropertyValue $chartSnapshot "legendPosition"
            if ([bool](Get-ObjectPropertyValue $chartSnapshot "hasLegend") -and $null -ne $legendPosition) {
                try { $shape.Chart.Legend.Position = [int]$legendPosition } catch {}
            }
            try {
                $shape.Chart.HasTitle = [bool](Get-ObjectPropertyValue $chartSnapshot "hasTitle")
                if ([bool](Get-ObjectPropertyValue $chartSnapshot "hasTitle")) {
                    $shape.Chart.ChartTitle.Text = [string](Get-ObjectPropertyValue $chartSnapshot "title")
                }
            } catch {}
            foreach ($axisSnapshot in @((Get-ObjectPropertyValue $chartSnapshot "axes"))) {
                try {
                    $axisType = if ([string](Get-ObjectPropertyValue $axisSnapshot "kind") -eq "category") { 1 } else { 2 }
                    $axis = $shape.Chart.Axes($axisType, 1)
                    $axis.HasTitle = [bool](Get-ObjectPropertyValue $axisSnapshot "hasTitle")
                    if ([bool](Get-ObjectPropertyValue $axisSnapshot "hasTitle")) {
                        $axis.AxisTitle.Text = [string](Get-ObjectPropertyValue $axisSnapshot "title")
                    }
                    $axis.HasMajorGridlines = [bool](Get-ObjectPropertyValue $axisSnapshot "hasMajorGridlines")
                    $minimumScaleIsAuto = Get-ObjectPropertyValue $axisSnapshot "minimumScaleIsAuto"
                    if ($null -ne $minimumScaleIsAuto) {
                        if ([bool]$minimumScaleIsAuto) {
                            $axis.MinimumScaleIsAuto = $true
                        } else {
                            $minimumScale = Get-ObjectPropertyValue $axisSnapshot "minimumScale"
                            if ($null -ne $minimumScale) { $axis.MinimumScale = [double]$minimumScale }
                        }
                    }
                    $maximumScaleIsAuto = Get-ObjectPropertyValue $axisSnapshot "maximumScaleIsAuto"
                    if ($null -ne $maximumScaleIsAuto) {
                        if ([bool]$maximumScaleIsAuto) {
                            $axis.MaximumScaleIsAuto = $true
                        } else {
                            $maximumScale = Get-ObjectPropertyValue $axisSnapshot "maximumScale"
                            if ($null -ne $maximumScale) { $axis.MaximumScale = [double]$maximumScale }
                        }
                    }
                } catch {}
            }
            foreach ($seriesSnapshot in @((Get-ObjectPropertyValue $chartSnapshot "series"))) {
                try {
                    $series = $shape.Chart.SeriesCollection().Item([int](Get-ObjectPropertyValue $seriesSnapshot "index"))
                    if ([bool](Get-ObjectPropertyValue $seriesSnapshot "hasDataLabels")) {
                        $series.ApplyDataLabels()
                    } else {
                        try { $series.DataLabels().Delete() } catch {}
                    }
                } catch {}
            }
        }
        $pictureSnapshot = Get-ObjectPropertyValue $snapshot "picture"
        if ($null -ne $pictureSnapshot) {
            $colorType = Get-ObjectPropertyValue $pictureSnapshot "colorType"
            if ($null -ne $colorType) { try { $shape.PictureFormat.ColorType = [int]$colorType } catch {} }
            foreach ($property in @("CropLeft", "CropTop", "CropRight", "CropBottom")) {
                $snapshotProperty = $property.Substring(0, 1).ToLowerInvariant() + $property.Substring(1)
                $value = Get-ObjectPropertyValue $pictureSnapshot $snapshotProperty
                if ($null -ne $value) { try { $shape.PictureFormat.$property = [double]$value } catch {} }
            }
        }
        $connectorSnapshot = Get-ObjectPropertyValue $snapshot "connector"
        if ($null -ne $connectorSnapshot) {
            $beginConnected = Get-ObjectPropertyValue $connectorSnapshot "beginConnected"
            $endConnected = Get-ObjectPropertyValue $connectorSnapshot "endConnected"
            try { $shape.ConnectorFormat.BeginDisconnect() } catch {}
            try { $shape.ConnectorFormat.EndDisconnect() } catch {}
            if ([bool]$beginConnected) {
                $beginShape = Find-PptShapeByNativeIdRecursive $slide.Shapes (Get-ObjectPropertyValue $connectorSnapshot "beginConnectedShapeId")
                $beginSite = Get-ObjectPropertyValue $connectorSnapshot "beginConnectionSite"
                if ($null -ne $beginShape -and $null -ne $beginSite) { try { $shape.ConnectorFormat.BeginConnect($beginShape, [int]$beginSite) } catch {} }
            }
            if ([bool]$endConnected) {
                $endShape = Find-PptShapeByNativeIdRecursive $slide.Shapes (Get-ObjectPropertyValue $connectorSnapshot "endConnectedShapeId")
                $endSite = Get-ObjectPropertyValue $connectorSnapshot "endConnectionSite"
                if ($null -ne $endShape -and $null -ne $endSite) { try { $shape.ConnectorFormat.EndConnect($endShape, [int]$endSite) } catch {} }
            }
            $connectorType = Get-ObjectPropertyValue $connectorSnapshot "connectorType"
            if ($null -ne $connectorType) { try { $shape.ConnectorFormat.Type = [int]$connectorType } catch {} }
            $beginArrow = Get-ObjectPropertyValue $connectorSnapshot "beginArrow"
            $endArrow = Get-ObjectPropertyValue $connectorSnapshot "endArrow"
            if ($null -ne $beginArrow) { try { $shape.Line.BeginArrowheadStyle = [int]$beginArrow } catch {} }
            if ($null -ne $endArrow) { try { $shape.Line.EndArrowheadStyle = [int]$endArrow } catch {} }
            try { $shape.RerouteConnections() } catch {}
        }
        $current = Get-PptShapeSnapshot $shape
        if ([Math]::Abs([double]$current.left - [double]$snapshot.left) -gt 0.01) { try { $shape.Left = [double]$snapshot.left } catch {} }
        if ([Math]::Abs([double]$current.top - [double]$snapshot.top) -gt 0.01) { try { $shape.Top = [double]$snapshot.top } catch {} }
        if ([Math]::Abs([double]$current.width - [double]$snapshot.width) -gt 0.01) { try { $shape.Width = [double]$snapshot.width } catch {} }
        if ([Math]::Abs([double]$current.height - [double]$snapshot.height) -gt 0.01) { try { $shape.Height = [double]$snapshot.height } catch {} }
    }
}

function Test-PptShapeSnapshotsRestored($slide, $snapshots, [double]$tolerance = 0.25) {
    $issues = @()
    foreach ($snapshot in @($snapshots)) {
        $snapshotTarget = @{
            nativeShapeId = Get-ObjectPropertyValue $snapshot "nativeShapeId"
            expectedShapeName = [string](Get-ObjectPropertyValue $snapshot "name")
            groupPath = @((Get-ObjectPropertyValue $snapshot "groupPath"))
        }
        $resolvedShape = Resolve-PptShape $slide $snapshotTarget "verifyPptMutationRollback"
        if (-not $resolvedShape.ok) {
            $issues += @{ code = "rollback_shape_missing"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name }
            continue
        }
        $shape = $resolvedShape.shape
        foreach ($property in @("left", "top", "width", "height")) {
            $actual = [double](Get-ObjectPropertyValue (Get-PptShapeSnapshot $shape) $property)
            $expected = [double](Get-ObjectPropertyValue $snapshot $property)
            if ([Math]::Abs($actual - $expected) -gt $tolerance) {
                $issues += @{ code = "rollback_geometry_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
            }
        }
        $actualSnapshot = Get-PptShapeSnapshot $shape
        foreach ($property in @("text", "fontName", "fontBold", "fontItalic", "fontColor", "alignment", "verticalAnchor", "fillVisible", "fillColor", "lineVisible", "lineColor", "lineDashStyle", "wordWrap", "autoSize", "lockAspectRatio")) {
            $expected = Get-ObjectPropertyValue $snapshot $property
            if ($null -eq $expected) { continue }
            $actual = Get-ObjectPropertyValue $actualSnapshot $property
            if ([string]$actual -ne [string]$expected) {
                $issues += @{ code = "rollback_property_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
            }
        }
        foreach ($property in @("fontSize", "fillTransparency", "lineTransparency", "marginLeft", "marginRight", "marginTop", "marginBottom", "lineWeight", "rotation")) {
            $expected = Get-ObjectPropertyValue $snapshot $property
            if ($null -eq $expected) { continue }
            $actual = Get-ObjectPropertyValue $actualSnapshot $property
            if ($null -eq $actual -or [Math]::Abs([double]$actual - [double]$expected) -gt $tolerance) {
                $issues += @{ code = "rollback_property_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
            }
        }
        $expectedFormatting = Get-ObjectPropertyValue $snapshot "textFormatting"
        if ($null -ne $expectedFormatting) {
            $actualFormatting = Get-ObjectPropertyValue $actualSnapshot "textFormatting"
            if ([string](Get-ObjectPropertyValue $actualFormatting "formatState") -ne [string](Get-ObjectPropertyValue $expectedFormatting "formatState")) {
                $issues += @{ code = "rollback_text_format_state_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; expected = (Get-ObjectPropertyValue $expectedFormatting "formatState"); actual = (Get-ObjectPropertyValue $actualFormatting "formatState") }
            }
            $expectedRuns = @((Get-ObjectPropertyValue $expectedFormatting "runs"))
            $actualRuns = @((Get-ObjectPropertyValue $actualFormatting "runs"))
            if ($expectedRuns.Count -ne $actualRuns.Count) {
                $issues += @{ code = "rollback_text_run_count_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; expected = $expectedRuns.Count; actual = $actualRuns.Count }
            } else {
                for ($runIndex = 0; $runIndex -lt $expectedRuns.Count; $runIndex++) {
                    foreach ($property in @("start", "length", "fontName", "fontBold", "fontItalic", "fontColor", "alignment")) {
                        $expected = Get-ObjectPropertyValue $expectedRuns[$runIndex] $property
                        $actual = Get-ObjectPropertyValue $actualRuns[$runIndex] $property
                        if ([string]$actual -ne [string]$expected) {
                            $issues += @{ code = "rollback_text_run_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; runIndex = $runIndex; property = $property; expected = $expected; actual = $actual }
                        }
                    }
                    foreach ($property in @("fontUnderline", "fontSubscript", "fontSuperscript", "fontStrike", "allCaps", "smallCaps")) {
                        $expected = Get-ObjectPropertyValue $expectedRuns[$runIndex] $property
                        if ($null -eq $expected) { continue }
                        $actual = Get-ObjectPropertyValue $actualRuns[$runIndex] $property
                        if ([string]$actual -ne [string]$expected) {
                            $issues += @{ code = "rollback_text_run_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; runIndex = $runIndex; property = $property; expected = $expected; actual = $actual }
                        }
                    }
                    $expectedSpacing = Get-ObjectPropertyValue $expectedRuns[$runIndex] "characterSpacing"
                    $actualSpacing = Get-ObjectPropertyValue $actualRuns[$runIndex] "characterSpacing"
                    if ($null -ne $expectedSpacing -and ($null -eq $actualSpacing -or [Math]::Abs([double]$actualSpacing - [double]$expectedSpacing) -gt $tolerance)) {
                        $issues += @{ code = "rollback_text_run_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; runIndex = $runIndex; property = "characterSpacing"; expected = $expectedSpacing; actual = $actualSpacing }
                    }
                    $expectedSize = Get-ObjectPropertyValue $expectedRuns[$runIndex] "fontSize"
                    $actualSize = Get-ObjectPropertyValue $actualRuns[$runIndex] "fontSize"
                    if ($null -ne $expectedSize -and ($null -eq $actualSize -or [Math]::Abs([double]$actualSize - [double]$expectedSize) -gt $tolerance)) {
                        $issues += @{ code = "rollback_text_run_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; runIndex = $runIndex; property = "fontSize"; expected = $expectedSize; actual = $actualSize }
                    }
                }
            }
        }
        $expectedParagraphs = @((Get-ObjectPropertyValue $snapshot "textParagraphs"))
        if ($expectedParagraphs.Count -gt 0) {
            $actualParagraphs = @((Get-ObjectPropertyValue $actualSnapshot "textParagraphs"))
            if ($expectedParagraphs.Count -ne $actualParagraphs.Count) {
                $issues += @{ code = "rollback_text_paragraph_count_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; expected = $expectedParagraphs.Count; actual = $actualParagraphs.Count }
            } else {
                for ($paragraphIndex = 0; $paragraphIndex -lt $expectedParagraphs.Count; $paragraphIndex++) {
                    $expectedParagraph = $expectedParagraphs[$paragraphIndex]
                    $actualParagraph = $actualParagraphs[$paragraphIndex]
                    foreach ($property in @("index", "start", "length", "alignment")) {
                        $expected = Get-ObjectPropertyValue $expectedParagraph $property
                        $actual = Get-ObjectPropertyValue $actualParagraph $property
                        if ([string]$actual -ne [string]$expected) {
                            $issues += @{ code = "rollback_text_paragraph_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; paragraphIndex = $paragraphIndex; property = $property; expected = $expected; actual = $actual }
                        }
                    }
                    $paragraphTolerance = 0.01
                    foreach ($property in @("leftIndent", "rightIndent", "firstLineIndent", "spaceBefore", "spaceAfter", "lineSpacing")) {
                        $expected = Get-ObjectPropertyValue $expectedParagraph $property
                        if ($null -eq $expected) { continue }
                        $actual = Get-ObjectPropertyValue $actualParagraph $property
                        if ($null -eq $actual -or [Math]::Abs([double]$actual - [double]$expected) -gt $paragraphTolerance) {
                            $issues += @{ code = "rollback_text_paragraph_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; paragraphIndex = $paragraphIndex; property = $property; expected = $expected; actual = $actual }
                        }
                    }
                    $expectedBullet = Get-ObjectPropertyValue $expectedParagraph "bullet"
                    $actualBullet = Get-ObjectPropertyValue $actualParagraph "bullet"
                    foreach ($property in @("kind", "character", "startAt")) {
                        $expected = Get-ObjectPropertyValue $expectedBullet $property
                        $actual = Get-ObjectPropertyValue $actualBullet $property
                        if ([string]$actual -ne [string]$expected) {
                            $issues += @{ code = "rollback_text_paragraph_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; paragraphIndex = $paragraphIndex; property = "bullet.$property"; expected = $expected; actual = $actual }
                        }
                    }
                }
            }
        }
        $expectedCells = @($snapshot.tableCells)
        foreach ($countProperty in @("tableRowCount", "tableColumnCount")) {
            $expectedCount = Get-ObjectPropertyValue $snapshot $countProperty
            if ($null -eq $expectedCount) { continue }
            $actualCount = Get-ObjectPropertyValue $actualSnapshot $countProperty
            if ([int]$actualCount -ne [int]$expectedCount) {
                $issues += @{
                    code = "rollback_table_structure_mismatch"
                    nativeShapeId = $snapshot.nativeShapeId
                    shapeName = $snapshot.name
                    property = $countProperty
                    expected = $expectedCount
                    actual = $actualCount
                }
            }
        }
        if ($expectedCells.Count -gt 0) {
            $actualCells = @($actualSnapshot.tableCells)
            foreach ($expectedCell in $expectedCells) {
                $actualCell = @($actualCells | Where-Object {
                    [int]$_.row -eq [int]$expectedCell.row -and [int]$_.col -eq [int]$expectedCell.col
                })[0]
                $cellMismatch = $null -eq $actualCell -or [string]$actualCell.text -ne [string]$expectedCell.text
                foreach ($property in @("fillColor", "fontColor", "fontName", "fontBold", "alignment")) {
                    $expected = Get-ObjectPropertyValue $expectedCell $property
                    if ($null -ne $expected -and [string](Get-ObjectPropertyValue $actualCell $property) -ne [string]$expected) { $cellMismatch = $true }
                }
                $expectedSize = Get-ObjectPropertyValue $expectedCell "fontSize"
                $actualSize = Get-ObjectPropertyValue $actualCell "fontSize"
                if ($null -ne $expectedSize -and ($null -eq $actualSize -or [Math]::Abs([double]$actualSize - [double]$expectedSize) -gt $tolerance)) { $cellMismatch = $true }
                foreach ($nestedProperty in @("paragraph", "borders")) {
                    $expectedNested = Get-ObjectPropertyValue $expectedCell $nestedProperty
                    if ($null -eq $expectedNested) { continue }
                    $actualNested = Get-ObjectPropertyValue $actualCell $nestedProperty
                    if (($expectedNested | ConvertTo-Json -Compress -Depth 10) -ne ($actualNested | ConvertTo-Json -Compress -Depth 10)) {
                        $cellMismatch = $true
                    }
                }
                if ($cellMismatch) {
                    $issues += @{
                        code = "rollback_table_cell_mismatch"
                        nativeShapeId = $snapshot.nativeShapeId
                        shapeName = $snapshot.name
                        row = $expectedCell.row
                        col = $expectedCell.col
                    }
                }
            }
        }
        foreach ($dimensionProperty in @("tableRowHeights", "tableColumnWidths")) {
            $expectedDimensions = @((Get-ObjectPropertyValue $snapshot $dimensionProperty))
            $actualDimensions = @((Get-ObjectPropertyValue $actualSnapshot $dimensionProperty))
            if ($expectedDimensions.Count -ne $actualDimensions.Count) {
                $issues += @{ code = "rollback_table_dimension_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $dimensionProperty; expected = $expectedDimensions.Count; actual = $actualDimensions.Count }
                continue
            }
            for ($dimensionIndex = 0; $dimensionIndex -lt $expectedDimensions.Count; $dimensionIndex++) {
                if ([Math]::Abs([double]$actualDimensions[$dimensionIndex] - [double]$expectedDimensions[$dimensionIndex]) -gt $tolerance) {
                    $issues += @{ code = "rollback_table_dimension_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $dimensionProperty; index = $dimensionIndex + 1; expected = $expectedDimensions[$dimensionIndex]; actual = $actualDimensions[$dimensionIndex] }
                }
            }
        }
        $expectedChart = Get-ObjectPropertyValue $snapshot "chart"
        if ($null -ne $expectedChart) {
            $actualChart = Get-ObjectPropertyValue $actualSnapshot "chart"
            foreach ($property in @("chartType", "hasTitle", "title", "hasLegend", "legendPosition")) {
                $expected = Get-ObjectPropertyValue $expectedChart $property
                $actual = Get-ObjectPropertyValue $actualChart $property
                if ([string]$actual -ne [string]$expected) {
                    $issues += @{
                        code = "rollback_chart_property_mismatch"
                        nativeShapeId = $snapshot.nativeShapeId
                        shapeName = $snapshot.name
                        property = $property
                        expected = $expected
                        actual = $actual
                    }
                }
            }
            foreach ($collectionProperty in @("axes", "series")) {
                $expectedItems = @((Get-ObjectPropertyValue $expectedChart $collectionProperty))
                $actualItems = @((Get-ObjectPropertyValue $actualChart $collectionProperty))
                if ($expectedItems.Count -ne $actualItems.Count) {
                    $issues += @{ code = "rollback_chart_collection_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $collectionProperty; expected = $expectedItems.Count; actual = $actualItems.Count }
                    continue
                }
                for ($itemIndex = 0; $itemIndex -lt $expectedItems.Count; $itemIndex++) {
                    $properties = if ($collectionProperty -eq "axes") { @("kind", "hasTitle", "title", "hasMajorGridlines", "minimumScaleIsAuto", "maximumScaleIsAuto") } else { @("index", "name", "hasDataLabels") }
                    foreach ($property in $properties) {
                        $expected = Get-ObjectPropertyValue $expectedItems[$itemIndex] $property
                        $actual = Get-ObjectPropertyValue $actualItems[$itemIndex] $property
                        if ([string]$actual -ne [string]$expected) {
                            $issues += @{ code = "rollback_chart_collection_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; collection = $collectionProperty; itemIndex = $itemIndex; property = $property; expected = $expected; actual = $actual }
                        }
                    }
                    if ($collectionProperty -eq "axes") {
                        foreach ($property in @("minimumScale", "maximumScale")) {
                            $expected = Get-ObjectPropertyValue $expectedItems[$itemIndex] $property
                            if ($null -eq $expected) { continue }
                            $actual = Get-ObjectPropertyValue $actualItems[$itemIndex] $property
                            if ($null -eq $actual -or [Math]::Abs([double]$actual - [double]$expected) -gt $tolerance) {
                                $issues += @{ code = "rollback_chart_collection_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; collection = $collectionProperty; itemIndex = $itemIndex; property = $property; expected = $expected; actual = $actual }
                            }
                        }
                    }
                }
            }
        }
        foreach ($property in @("nativeType", "placeholderType", "groupMemberCount")) {
            $expected = Get-ObjectPropertyValue $snapshot $property
            if ($null -eq $expected) { continue }
            $actual = Get-ObjectPropertyValue $actualSnapshot $property
            if ([string]$actual -ne [string]$expected) {
                $issues += @{ code = "rollback_native_identity_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
            }
        }
        $expectedPicture = Get-ObjectPropertyValue $snapshot "picture"
        if ($null -ne $expectedPicture) {
            $actualPicture = Get-ObjectPropertyValue $actualSnapshot "picture"
            foreach ($property in @("linked", "sourcePath", "colorType")) {
                $expected = Get-ObjectPropertyValue $expectedPicture $property
                $actual = Get-ObjectPropertyValue $actualPicture $property
                if ([string]$actual -ne [string]$expected) {
                    $issues += @{ code = "rollback_picture_identity_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
                }
            }
            foreach ($property in @("cropLeft", "cropTop", "cropRight", "cropBottom")) {
                $expected = Get-ObjectPropertyValue $expectedPicture $property
                $actual = Get-ObjectPropertyValue $actualPicture $property
                if ($null -ne $expected -and ($null -eq $actual -or [Math]::Abs([double]$actual - [double]$expected) -gt $tolerance)) {
                    $issues += @{ code = "rollback_picture_crop_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
                }
            }
        }
        $expectedConnector = Get-ObjectPropertyValue $snapshot "connector"
        if ($null -ne $expectedConnector) {
            $actualConnector = Get-ObjectPropertyValue $actualSnapshot "connector"
            foreach ($property in @("connectorType", "beginConnected", "endConnected", "beginConnectedShapeId", "endConnectedShapeId", "beginConnectionSite", "endConnectionSite", "beginArrow", "endArrow")) {
                $expected = Get-ObjectPropertyValue $expectedConnector $property
                if ($null -eq $expected) { continue }
                $actual = Get-ObjectPropertyValue $actualConnector $property
                if ([string]$actual -ne [string]$expected) {
                    $issues += @{ code = "rollback_connector_identity_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; property = $property; expected = $expected; actual = $actual }
                }
            }
        }
        $nativeMismatches = @(Test-PptDuplicateShapeSignature (Get-ObjectPropertyValue $snapshot "nativeSignature") (Get-ObjectPropertyValue $actualSnapshot "nativeSignature") $tolerance)
        if ($nativeMismatches.Count -gt 0) {
            $issues += @{ code = "rollback_native_signature_mismatch"; nativeShapeId = $snapshot.nativeShapeId; shapeName = $snapshot.name; fields = $nativeMismatches }
        }
    }
    return @{ ok = ($issues.Count -eq 0); issues = $issues; issueCount = $issues.Count }
}

function Get-PptMutationRollbackSnapshot($pres, $slideIndexes, $targetsBySlide = @()) {
    $slides = @()
    foreach ($slideIndexInput in @($slideIndexes)) {
        $resolvedSlide = Resolve-PptSlide $pres ([int]$slideIndexInput) "capturePptMutationSnapshot"
        if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
        $shapeSnapshots = @()
        $baselineShapeOrder = @()
        $slideTargets = @($targetsBySlide | Where-Object {
            [int](Get-ObjectPropertyValue $_ "slideIndex") -eq [int]$resolvedSlide.slideIndex
        })
        $nativeShapeIds = @($slideTargets | ForEach-Object { @((Get-ObjectPropertyValue $_ "nativeShapeIds")) } | ForEach-Object { $_ })
        $shapeIndexes = @($slideTargets | ForEach-Object { @((Get-ObjectPropertyValue $_ "shapeIndexes")) } | ForEach-Object { $_ })
        $shapeNames = @($slideTargets | ForEach-Object { @((Get-ObjectPropertyValue $_ "shapeNames")) } | ForEach-Object { $_ })
        $componentIds = @($slideTargets | ForEach-Object { @((Get-ObjectPropertyValue $_ "componentIds")) } | ForEach-Object { $_ })
        $groupPaths = @($slideTargets | ForEach-Object { @((Get-ObjectPropertyValue $_ "groupPaths")) } | ForEach-Object { ,@($_) })
        for ($shapeIndex = 1; $shapeIndex -le $resolvedSlide.slide.Shapes.Count; $shapeIndex++) {
            $shape = $resolvedSlide.slide.Shapes.Item($shapeIndex)
            $nativeShapeId = $null
            $zOrderPosition = $shapeIndex
            try { $nativeShapeId = [int]$shape.Id } catch {}
            try { $zOrderPosition = [int]$shape.ZOrderPosition } catch {}
            if ($null -ne $nativeShapeId) {
                $baselineShapeOrder += @{ nativeShapeId = $nativeShapeId; zOrderPosition = $zOrderPosition }
            }
            $descriptor = Get-PptComponentDescriptor ([string]$shape.Name)
            $componentId = if ($null -ne $descriptor) { [string]$descriptor.componentId } else { "" }
            $layoutComponentId = if ($null -ne $descriptor) { [string]$descriptor.layoutComponentId } else { "" }
            $selectedForRollback =
                ($null -ne $nativeShapeId -and $nativeShapeIds -contains $nativeShapeId) -or
                ($shapeIndexes -contains $shapeIndex) -or
                ($shapeNames -contains [string]$shape.Name) -or
                (-not [string]::IsNullOrWhiteSpace($componentId) -and $componentIds -contains $componentId) -or
                (-not [string]::IsNullOrWhiteSpace($layoutComponentId) -and $componentIds -contains $layoutComponentId)
            if ($selectedForRollback) {
                $shapeSnapshots += Get-PptShapeSnapshot $shape
            }
        }
        $capturedGroupPathKeys = @{}
        foreach ($groupPath in @($groupPaths)) {
            $normalizedGroupPath = @($groupPath | ForEach-Object { [int]$_ })
            if ($normalizedGroupPath.Count -lt 2) { continue }
            $groupPathKey = $normalizedGroupPath -join "/"
            if ($capturedGroupPathKeys.ContainsKey($groupPathKey)) { continue }
            $resolvedMember = Resolve-PptShape $resolvedSlide.slide @{ groupPath = $normalizedGroupPath } "capturePptMutationSnapshot"
            if (-not $resolvedMember.ok) { throw $resolvedMember.result.error }
            $shapeSnapshots += Get-PptShapeSnapshot $resolvedMember.shape $normalizedGroupPath
            $capturedGroupPathKeys[$groupPathKey] = $true
        }
        $nativeSlideId = $null
        try { $nativeSlideId = [int]$resolvedSlide.slide.SlideID } catch {}
        $orderedNativeShapeIds = @($baselineShapeOrder |
            Sort-Object -Property zOrderPosition |
            ForEach-Object { [int]$_.nativeShapeId })
        $slides += @{
            slideIndexSnapshot = [int]$resolvedSlide.slideIndex
            nativeSlideId = $nativeSlideId
            baselineNativeShapeIds = $orderedNativeShapeIds
            baselineZOrderNativeShapeIds = $orderedNativeShapeIds
            shapes = $shapeSnapshots
        }
    }
    return @{
        presentationId = [string]$pres.Name
        presentationPath = $(try { [string]$pres.FullName } catch { "" })
        slides = $slides
    }
}

function Restore-PptBaselineZOrder($slide, $baselineZOrderNativeShapeIds) {
    $baselineIds = @($baselineZOrderNativeShapeIds | ForEach-Object { [int]$_ })
    if ($baselineIds.Count -le 1) { return }
    $currentIds = @()
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
        $shape = $slide.Shapes.Item($shapeIndex)
        $nativeShapeId = $null
        try { $nativeShapeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeShapeId -and $baselineIds -contains $nativeShapeId) {
            $currentIds += @{ nativeShapeId = $nativeShapeId; zOrderPosition = $(try { [int]$shape.ZOrderPosition } catch { $shapeIndex }) }
        }
    }
    $currentOrder = @($currentIds | Sort-Object -Property zOrderPosition | ForEach-Object { [int]$_.nativeShapeId })
    if (($currentOrder -join ",") -eq ($baselineIds -join ",")) { return }
    foreach ($nativeShapeId in $baselineIds) {
        $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
        if ($null -ne $shapeIndex) {
            try { $slide.Shapes.Item([int]$shapeIndex).ZOrder(0) } catch {}
        }
    }
}

function Restore-PptMutationRollbackSnapshot($pres, $snapshot, $creationReceipts) {
    $issues = @()
    $restoredSlideIndexes = @()
    $removedNativeShapeIds = @()
    $expectedPresentationId = [string](Get-ObjectPropertyValue $snapshot "presentationId")
    if (-not [string]::IsNullOrWhiteSpace($expectedPresentationId) -and [string]$pres.Name -ne $expectedPresentationId) {
        return @{
            rolledBack = $false
            rollbackVerified = $false
            issues = @(@{
                code = "rollback_presentation_mismatch"
                expectedPresentationId = $expectedPresentationId
                actualPresentationId = [string]$pres.Name
            })
        }
    }

    $createdBySlide = @{}
    foreach ($receipt in @($creationReceipts)) {
        $created = Get-ObjectPropertyValue $receipt "created"
        if ($null -eq $created) { continue }
        $slideIndex = [int](Get-ObjectPropertyValue $created "slideIndexSnapshot")
        if ($slideIndex -le 0) { continue }
        if (-not $createdBySlide.ContainsKey($slideIndex)) { $createdBySlide[$slideIndex] = @() }
        foreach ($nativeShapeId in @((Get-ObjectPropertyValue $created "nativeShapeIds"))) {
            $parsed = 0
            if ([int]::TryParse([string]$nativeShapeId, [ref]$parsed) -and $parsed -gt 0 -and $createdBySlide[$slideIndex] -notcontains $parsed) {
                $createdBySlide[$slideIndex] += $parsed
            }
        }
    }

    foreach ($slideSnapshot in @((Get-ObjectPropertyValue $snapshot "slides"))) {
        $slideIndexSnapshot = [int](Get-ObjectPropertyValue $slideSnapshot "slideIndexSnapshot")
        $nativeSlideId = Get-ObjectPropertyValue $slideSnapshot "nativeSlideId"
        $resolvedSlide = Resolve-PptSlideBinding $pres $slideIndexSnapshot $nativeSlideId "restorePptMutationSnapshot"
        if (-not $resolvedSlide.ok) {
            $issues += @{ code = "rollback_slide_binding_failed"; slideIndexSnapshot = $slideIndexSnapshot; message = $resolvedSlide.result.error }
            continue
        }
        $slide = $resolvedSlide.slide
        foreach ($nativeShapeId in @($createdBySlide[$slideIndexSnapshot])) {
            $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
            if ($null -ne $shapeIndex) {
                try {
                    $slide.Shapes.Item([int]$shapeIndex).Delete()
                    $removedNativeShapeIds += [int]$nativeShapeId
                } catch {
                    $issues += @{ code = "rollback_created_shape_delete_failed"; slideIndex = $resolvedSlide.slideIndex; nativeShapeId = $nativeShapeId; message = $_.Exception.Message }
                }
            }
        }
        $shapeSnapshots = @((Get-ObjectPropertyValue $slideSnapshot "shapes"))
        Restore-PptShapeSnapshots $slide $shapeSnapshots
        $baselineZOrderNativeShapeIds = @((Get-ObjectPropertyValue $slideSnapshot "baselineZOrderNativeShapeIds"))
        Restore-PptBaselineZOrder $slide $baselineZOrderNativeShapeIds
        $verification = Test-PptShapeSnapshotsRestored $slide $shapeSnapshots
        if (-not $verification.ok) { $issues += @($verification.issues) }
        $baselineNativeShapeIds = @((Get-ObjectPropertyValue $slideSnapshot "baselineNativeShapeIds"))
        if ($baselineNativeShapeIds.Count -eq 0) {
            $baselineNativeShapeIds = @($shapeSnapshots | ForEach-Object { [int](Get-ObjectPropertyValue $_ "nativeShapeId") })
        }
        foreach ($nativeShapeId in $baselineNativeShapeIds) {
            if ($null -eq (Get-PptShapeIndexByNativeId $slide $nativeShapeId)) {
                $issues += @{ code = "rollback_baseline_shape_missing"; slideIndex = $resolvedSlide.slideIndex; nativeShapeId = $nativeShapeId }
            }
        }
        if ($baselineZOrderNativeShapeIds.Count -gt 0) {
            $actualZOrder = @()
            for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
                $shape = $slide.Shapes.Item($shapeIndex)
                $nativeShapeId = $null
                try { $nativeShapeId = [int]$shape.Id } catch {}
                if ($null -ne $nativeShapeId -and $baselineZOrderNativeShapeIds -contains $nativeShapeId) {
                    $actualZOrder += @{ nativeShapeId = $nativeShapeId; zOrderPosition = $(try { [int]$shape.ZOrderPosition } catch { $shapeIndex }) }
                }
            }
            $actualZOrderIds = @($actualZOrder | Sort-Object -Property zOrderPosition | ForEach-Object { [int]$_.nativeShapeId })
            if (($actualZOrderIds -join ",") -ne (@($baselineZOrderNativeShapeIds | ForEach-Object { [int]$_ }) -join ",")) {
                $issues += @{ code = "rollback_z_order_mismatch"; slideIndex = $resolvedSlide.slideIndex }
            }
        }
        foreach ($nativeShapeId in @($createdBySlide[$slideIndexSnapshot])) {
            if ($null -ne (Get-PptShapeIndexByNativeId $slide $nativeShapeId)) {
                $issues += @{ code = "rollback_created_shape_still_exists"; slideIndex = $resolvedSlide.slideIndex; nativeShapeId = $nativeShapeId }
            }
        }
        for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
            $currentNativeShapeId = $null
            try { $currentNativeShapeId = [int]$slide.Shapes.Item($shapeIndex).Id } catch {}
            if ($null -ne $currentNativeShapeId -and $baselineNativeShapeIds -notcontains $currentNativeShapeId) {
                $issues += @{
                    code = "rollback_unattributed_created_shape"
                    slideIndex = $resolvedSlide.slideIndex
                    nativeShapeId = $currentNativeShapeId
                    shapeName = [string]$slide.Shapes.Item($shapeIndex).Name
                }
            }
        }
        $restoredSlideIndexes += [int]$resolvedSlide.slideIndex
    }

    return @{
        rolledBack = ($issues.Count -eq 0)
        rollbackVerified = ($issues.Count -eq 0)
        restoredSlideIndexes = $restoredSlideIndexes
        removedNativeShapeIds = $removedNativeShapeIds
        issues = $issues
    }
}

function Get-PptRectOverlapArea([double]$leftA, [double]$topA, [double]$widthA, [double]$heightA, [double]$leftB, [double]$topB, [double]$widthB, [double]$heightB) {
    $left = [Math]::Max($leftA, $leftB)
    $top = [Math]::Max($topA, $topB)
    $right = [Math]::Min($leftA + $widthA, $leftB + $widthB)
    $bottom = [Math]::Min($topA + $heightA, $topB + $heightB)
    if ($right -le $left -or $bottom -le $top) { return 0 }
    return ($right - $left) * ($bottom - $top)
}

function Get-PptTextVisualUnits([string]$text) {
    $units = 0.0
    foreach ($char in $text.ToCharArray()) {
        if ($char -eq "`r") { continue }
        if ($char -eq "`n") { $units += 8; continue }
        if ([int][char]$char -gt 255) { $units += 1.0 } else { $units += 0.55 }
    }
    return $units
}

function Get-PptEstimatedTextHeight($shape, [double]$targetWidth, [double]$minFontSize) {
    $text = ""
    try { $text = [string]$shape.TextFrame.TextRange.Text } catch {}
    if ([string]::IsNullOrWhiteSpace($text)) { return 0 }
    $fontSize = 12.0
    try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
    if ($fontSize -lt $minFontSize) { $fontSize = $minFontSize }
    $usableWidth = [Math]::Max(24, $targetWidth)
    $unitsPerLine = [Math]::Max(6, [Math]::Floor($usableWidth / ([Math]::Max(1, $fontSize * 0.72))))
    $explicitLines = [Math]::Max(1, @($text -split "`r?`n").Count)
    $wrappedLines = [Math]::Max($explicitLines, [Math]::Ceiling((Get-PptTextVisualUnits $text) / $unitsPerLine))
    return [Math]::Ceiling($wrappedLines * $fontSize * 1.35 + 4)
}

function Test-PptShapeTextOverflow($shape) {
    $hasText = $false
    try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
    if (-not $hasText) { return @{ overflow = $false; boundHeight = 0; availableHeight = [double]$shape.Height } }
    $boundHeight = $null
    try { $boundHeight = [double]$shape.TextFrame2.TextRange.BoundHeight } catch {}
    if ($null -eq $boundHeight -or $boundHeight -le 0) {
        $boundHeight = Get-PptEstimatedTextHeight $shape ([double]$shape.Width - 4) 1
    }
    $availableHeight = [Math]::Max(1, [double]$shape.Height - 2)
    return @{
        overflow = ([double]$boundHeight -gt ($availableHeight + 1))
        boundHeight = [Math]::Round([double]$boundHeight, 2)
        availableHeight = [Math]::Round($availableHeight, 2)
    }
}

function Get-PptUniformComponentLayoutResult($ppt, $pres, $options) {
    $slideIndex = [int](Get-ObjectPropertyValue $options "slideIndex")
    $resolvedSlide = Resolve-PptSlide $pres $slideIndex "uniformPptComponentLayout"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $slideIndex = [int]$resolvedSlide.slideIndex
    $slideWidth = [double]$pres.PageSetup.SlideWidth
    $slideHeight = [double]$pres.PageSetup.SlideHeight
    $marginValue = Get-ObjectPropertyValue $options "margin"
    $margin = if ($null -ne $marginValue) { [double]$marginValue } else { 12.0 }
    $paddingValue = Get-ObjectPropertyValue $options "padding"
    $padding = if ($null -ne $paddingValue) { [double]$paddingValue } else { 10.0 }
    $minFontValue = Get-ObjectPropertyValue $options "minFontSize"
    $minFontSize = if ($null -ne $minFontValue) { [double]$minFontValue } else { 9.0 }
    $componentIds = @()
    foreach ($value in @(Get-ObjectPropertyValue $options "componentIds")) {
        $id = [string]$value
        if (-not [string]::IsNullOrWhiteSpace($id) -and $componentIds -notcontains $id) { $componentIds += $id }
    }
    foreach ($value in @(Get-ObjectPropertyValue $options "targetShapeIndexes")) {
        $shapeIndex = [int]$value
        if ($shapeIndex -lt 1 -or $shapeIndex -gt $slide.Shapes.Count) { continue }
        $descriptor = Get-PptComponentDescriptor ([string]$slide.Shapes.Item($shapeIndex).Name)
        if ($null -ne $descriptor -and $componentIds -notcontains [string]$descriptor.componentId) {
            $componentIds += [string]$descriptor.componentId
        }
    }
    if ($componentIds.Count -lt 2) {
        return New-PptRecoverableError "PPT_UNIFORM_LAYOUT_TARGETS_REQUIRED" "At least two existing R4 componentIds are required. This tool never creates missing components." @{ componentIds = $componentIds; suggestedAction = "select_existing_components_then_retry" }
    }

    $groups = @()
    $targetNativeIds = @()
    foreach ($componentId in $componentIds) {
        $parts = @()
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            $descriptor = Get-PptComponentDescriptor ([string]$shape.Name)
            if ($null -ne $descriptor -and [string]$descriptor.componentId -eq [string]$componentId) {
                $nativeId = $null
                try { $nativeId = [int]$shape.Id } catch {}
                if ($null -ne $nativeId) { $targetNativeIds += $nativeId }
                $parts += @{ shape = $shape; descriptor = $descriptor; shapeIndex = $i; nativeShapeId = $nativeId }
            }
        }
        $backgroundParts = @($parts | Where-Object { [string]$_.descriptor.part -match '(^|_)(bg|band|background)($|_)' } | Sort-Object { -([double]$_.shape.Width * [double]$_.shape.Height) })
        if ($backgroundParts.Count -eq 0) {
            return New-PptRecoverableError "PPT_COMPONENT_BACKGROUND_NOT_FOUND" "Component '$componentId' has no resizable background part." @{ componentId = $componentId; suggestedAction = "use_explicit_shape_position_for_non_component_objects" }
        }
        $groups += @{
            componentId = [string]$componentId
            componentType = [string]$backgroundParts[0].descriptor.componentType
            parts = $parts
            background = $backgroundParts[0].shape
            backgroundNativeId = $backgroundParts[0].nativeShapeId
        }
    }

    $componentTypes = @($groups | ForEach-Object { $_.componentType } | Select-Object -Unique)
    if ($componentTypes.Count -ne 1) {
        return New-PptRecoverableError "PPT_UNIFORM_LAYOUT_MIXED_COMPONENT_TYPES" "Uniform layout requires components of the same type." @{ componentTypes = $componentTypes; componentIds = $componentIds }
    }
    $frozen = Get-ObjectPropertyValue $options "frozen"
    $freezeImageBounds = if ($null -ne $frozen) { [bool](Get-ObjectPropertyValue $frozen "imageBounds") } else { $true }
    if ($freezeImageBounds) {
        foreach ($group in $groups) {
            foreach ($part in @($group.parts)) {
                $summary = Get-PptShapeSummary $part.shape
                if ([string]$summary.type -match 'picture') {
                    return New-PptRecoverableError "PPT_UNIFORM_LAYOUT_IMAGE_FROZEN" "Target component contains an image while imageBounds is frozen." @{ componentId = $group.componentId }
                }
            }
        }
    }

    $baseline = @($groups | Sort-Object { [double]$_.background.Width * [double]$_.background.Height })[0]
    $targetWidth = [double]$baseline.background.Width
    $targetHeight = [double]$baseline.background.Height
    $requiredHeight = $targetHeight
    foreach ($group in $groups) {
        $shellToken = "$([string]$group.componentType)_default"
        $groupRequired = Get-PptGridMinimumHeightForGroup $group $targetWidth $shellToken $padding $minFontSize
        if ($groupRequired -gt $requiredHeight) { $requiredHeight = $groupRequired }
    }

    $safeHeight = $slideHeight - $margin
    foreach ($group in $groups) {
        $background = $group.background
        $groupSafeBottom = $slideHeight - $margin
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $other = $slide.Shapes.Item($i)
            $otherNativeId = $null
            try { $otherNativeId = [int]$other.Id } catch {}
            if ($targetNativeIds -contains $otherNativeId) { continue }
            $summary = Get-PptShapeSummary $other
            $isFullBackground = ([double]$summary.left -le $margin -and [double]$summary.top -le $margin -and ([double]$summary.left + [double]$summary.width) -ge ($slideWidth - $margin) -and ([double]$summary.top + [double]$summary.height) -ge ($slideHeight - $margin))
            if ($isFullBackground) { continue }
            $horizontalOverlap = (Get-PptRectOverlapArea ([double]$background.Left) 0 $targetWidth 1 ([double]$other.Left) 0 ([double]$other.Width) 1) -gt 0
            if ($horizontalOverlap -and [double]$other.Top -ge ([double]$background.Top + 2)) {
                $groupSafeBottom = [Math]::Min($groupSafeBottom, [double]$other.Top - $margin)
            }
        }
        foreach ($otherGroup in $groups) {
            if ($otherGroup.componentId -eq $group.componentId) { continue }
            $otherBackground = $otherGroup.background
            $horizontalOverlap = (Get-PptRectOverlapArea ([double]$background.Left) 0 $targetWidth 1 ([double]$otherBackground.Left) 0 $targetWidth 1) -gt 0
            if ($horizontalOverlap -and [double]$otherBackground.Top -gt [double]$background.Top) {
                $groupSafeBottom = [Math]::Min($groupSafeBottom, [double]$otherBackground.Top - $margin)
            }
        }
        $availableHeight = $groupSafeBottom - [double]$background.Top
        $safeHeight = [Math]::Min($safeHeight, $availableHeight)
    }
    $targetHeight = [Math]::Max($targetHeight, [Math]::Min($requiredHeight, $safeHeight))
    if ($targetHeight -gt $safeHeight -or $targetWidth -le 0 -or $targetHeight -le 0) {
        return New-PptRecoverableError "PPT_UNIFORM_LAYOUT_NO_SAFE_SPACE" "The smallest visual scale cannot be expanded enough without entering a protected region." @{ targetWidth = $targetWidth; requiredHeight = $requiredHeight; safeHeight = $safeHeight; protected = @("pictures", "footer", "page_bounds", "non_target_objects") }
    }

    $snapshots = @()
    foreach ($group in $groups) {
        foreach ($part in @($group.parts)) { $snapshots += Get-PptShapeSnapshot $part.shape }
    }
    $changed = @()
    $postIssues = @()
    try {
        foreach ($group in $groups) {
            $background = $group.background
            $oldLeft = [double]$background.Left
            $oldTop = [double]$background.Top
            $oldWidth = [double]$background.Width
            $oldHeight = [double]$background.Height
            $scaleX = if ($oldWidth -gt 0) { $targetWidth / $oldWidth } else { 1 }
            $scaleY = if ($oldHeight -gt 0) { $targetHeight / $oldHeight } else { 1 }
            foreach ($part in @($group.parts)) {
                $shape = $part.shape
                $relativeLeft = [double]$shape.Left - $oldLeft
                $relativeTop = [double]$shape.Top - $oldTop
                $shape.Left = $oldLeft + ($relativeLeft * $scaleX)
                $shape.Top = $oldTop + ($relativeTop * $scaleY)
                $shape.Width = [Math]::Max(2, [double]$shape.Width * $scaleX)
                $shape.Height = [Math]::Max(2, [double]$shape.Height * $scaleY)
            }
            foreach ($part in @($group.parts)) {
                $shape = $part.shape
                $partName = [string]$part.descriptor.part
                $hasText = $false
                try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
                if (-not $hasText) { continue }
                $textRole = Get-PptGridTextRole $partName
                $roleMinFontSize = Get-PptGridRoleMinimumFontSize $textRole $minFontSize
                try { $shape.TextFrame.WordWrap = -1 } catch {}
                try { $shape.TextFrame.AutoSize = 0 } catch {}
                if ($partName -match 'body|subtitle|note|quote|caption') {
                    $maxTextHeight = ($oldTop + $targetHeight - $padding) - [double]$shape.Top
                    if ($maxTextHeight -gt [double]$shape.Height) { $shape.Height = [single]$maxTextHeight }
                }
                $fit = Test-PptShapeTextOverflow $shape
                while ($fit.overflow) {
                    $fontSize = $null
                    try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
                    if ($null -eq $fontSize -or $fontSize -le $roleMinFontSize) { break }
                    try { $shape.TextFrame.TextRange.Font.Size = [Math]::Max($roleMinFontSize, $fontSize - 0.5) } catch { break }
                    $fit = Test-PptShapeTextOverflow $shape
                }
                if ($fit.overflow) {
                    $postIssues += @{ issueType = "text_overflow"; componentId = $group.componentId; shapeName = [string]$shape.Name; shapeIndex = Get-PptShapeIndexByNativeId $slide $part.nativeShapeId; metrics = $fit }
                }
            }
            $changed += @{ componentId = $group.componentId; backgroundName = [string]$background.Name; left = [Math]::Round($oldLeft, 2); top = [Math]::Round($oldTop, 2); width = [Math]::Round($targetWidth, 2); height = [Math]::Round($targetHeight, 2) }
        }

        foreach ($group in $groups) {
            $background = $group.background
            if ([double]$background.Left -lt -1 -or [double]$background.Top -lt -1 -or ([double]$background.Left + [double]$background.Width) -gt ($slideWidth + 1) -or ([double]$background.Top + [double]$background.Height) -gt ($slideHeight + 1)) {
                $postIssues += @{ issueType = "out_of_bounds"; componentId = $group.componentId; shapeName = [string]$background.Name }
            }
            foreach ($part in @($group.parts)) {
                $shape = $part.shape
                if ([double]$shape.Left -lt ([double]$background.Left - 2) -or [double]$shape.Top -lt ([double]$background.Top - 2) -or ([double]$shape.Left + [double]$shape.Width) -gt ([double]$background.Left + [double]$background.Width + 2) -or ([double]$shape.Top + [double]$shape.Height) -gt ([double]$background.Top + [double]$background.Height + 2)) {
                    if ([string]$part.descriptor.part -notmatch '(^|_)(bg|band|background)($|_)') {
                        $postIssues += @{ issueType = "component_part_outside_background"; componentId = $group.componentId; shapeName = [string]$shape.Name }
                    }
                }
            }
        }
    } catch {
        $postIssues += @{
            issueType = "mutation_exception"
            message = $_.Exception.Message
            position = $_.InvocationInfo.PositionMessage
            scriptStackTrace = $_.ScriptStackTrace
        }
    }

    $rolledBack = $postIssues.Count -gt 0
    if ($rolledBack) { Restore-PptShapeSnapshots $slide $snapshots }
    $verification = $null
    $verifyAfterValue = Get-ObjectPropertyValue $options "verifyAfter"
    $verifyAfter = if ($null -ne $verifyAfterValue) { [bool]$verifyAfterValue } else { $true }
    if ($verifyAfter) {
        $verificationResult = Test-PptSlideGeometry $pres $slideIndex @{ margin = $margin; overlapThreshold = 0.35; ignoreBackgrounds = $true; requireTitle = $false; maxObjects = 50 }
        if ($verificationResult.success) { $verification = $verificationResult.data }
    }
    return @{
        success = (-not $rolledBack)
        error = $(if ($rolledBack) { "uniformPptComponentLayout failed post-check and was rolled back" } else { $null })
        data = @{
            partialMutation = (-not $rolledBack)
            transactional = $true
            rolledBack = $rolledBack
            slideIndex = $slideIndex
            strategy = "smallest_safe"
            componentType = $componentTypes[0]
            componentIds = $componentIds
            targetSize = @{ width = [Math]::Round($targetWidth, 2); height = [Math]::Round($targetHeight, 2); baselineHeight = [Math]::Round([double]$baseline.background.Height, 2); requiredHeight = [Math]::Round($requiredHeight, 2); safeHeight = [Math]::Round($safeHeight, 2) }
            frozen = @{ visibleText = $true; objectCount = $true; imageBounds = $freezeImageBounds; nonTargetObjects = $true }
            changed = $(if ($rolledBack) { @() } else { $changed })
            postCheck = @{ ok = (-not $rolledBack); issues = $postIssues; issueCount = $postIssues.Count }
            verification = $verification
        }
    }
}

function Get-PptComponentGroupsForGridFromBindings($slide, $componentBindings) {
    $groups = @{}
    foreach ($binding in @($componentBindings)) {
        $componentId = [string](Get-ObjectPropertyValue $binding "componentId")
        $shapeIndex = [int](Get-ObjectPropertyValue $binding "shapeIndex")
        if ([string]::IsNullOrWhiteSpace($componentId) -or $shapeIndex -lt 1 -or $shapeIndex -gt [int]$slide.Shapes.Count) {
            throw "Frozen component binding is invalid for component '$componentId' at shapeIndex $shapeIndex."
        }
        $shape = $slide.Shapes.Item($shapeIndex)
        $expectedNativeId = Get-ObjectPropertyValue $binding "nativeShapeId"
        if ($null -ne $expectedNativeId) {
            $actualNativeId = $null
            try { $actualNativeId = [int]$shape.Id } catch {}
            if ($null -eq $actualNativeId -or [int]$actualNativeId -ne [int]$expectedNativeId) {
                throw "Frozen component binding is stale for '$componentId' at shapeIndex $shapeIndex."
            }
        }
        $expectedName = [string](Get-ObjectPropertyValue $binding "shapeName")
        if (-not [string]::IsNullOrWhiteSpace($expectedName) -and [string]$shape.Name -ne $expectedName) {
            throw "Frozen component binding name changed for '$componentId' at shapeIndex $shapeIndex."
        }
        if (-not $groups.ContainsKey($componentId)) {
            $groups[$componentId] = @{
                componentId = $componentId
                componentType = [string](Get-ObjectPropertyValue $binding "componentType")
                internalLayoutMode = [string](Get-ObjectPropertyValue $binding "internalLayoutMode")
                parts = @()
            }
        }
        $rawPart = [string](Get-ObjectPropertyValue $binding "part")
        if ([string]::IsNullOrWhiteSpace($rawPart)) { throw "Frozen component binding is missing part for '$componentId'." }
        $groups[$componentId].parts += @{
            shape = $shape
            descriptor = @{
                componentId = $componentId
                componentType = [string](Get-ObjectPropertyValue $binding "componentType")
                part = $rawPart
                itemId = [string](Get-ObjectPropertyValue $binding "itemId")
            }
            shapeIndex = $shapeIndex
            nativeShapeId = $expectedNativeId
        }
    }
    $result = @{}
    foreach ($componentId in @($groups.Keys)) {
        $group = $groups[$componentId]
        $backgrounds = @($group.parts | Where-Object { [string]$_.descriptor.part -match '(^|_)(bg|band|background|table)($|_)' } | Sort-Object { -([double]$_.shape.Width * [double]$_.shape.Height) })
        if ($backgrounds.Count -ne 1) {
            throw "Frozen component '$componentId' must have exactly one background part; found $($backgrounds.Count)."
        }
        $group.background = $backgrounds[0].shape
        $group.backgroundNativeId = $backgrounds[0].nativeShapeId
        $result[$componentId] = $group
    }
    return $result
}

function Get-PptComponentGroupsForGrid($slide, $componentBindings = $null) {
    if ($null -ne $componentBindings -and @($componentBindings).Count -gt 0) {
        return Get-PptComponentGroupsForGridFromBindings $slide $componentBindings
    }
    $objects = @()
    $shapeByIndex = @{}
    for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
        $shape = $slide.Shapes.Item($i)
        $descriptor = Get-PptComponentDescriptor ([string]$shape.Name)
        if ($null -eq $descriptor) { continue }
        $nativeId = $null
        try { $nativeId = [int]$shape.Id } catch {}
        $shapeByIndex[[string]$i] = $shape
        $objects += @{
            objectId = "slide:$([int]$slide.SlideIndex):shape:$i"
            nativeShapeId = $nativeId
            shapeIndex = $i
            shapeName = [string]$shape.Name
            bounds = @{
                left = [double]$shape.Left
                top = [double]$shape.Top
                width = [double]$shape.Width
                height = [double]$shape.Height
            }
            component = @{
                componentId = [string]$descriptor.componentId
                componentType = [string]$descriptor.componentType
                componentIndex = [int]$descriptor.componentIndex
                part = [string]$descriptor.part
            }
        }
    }

    Resolve-PptRuntimeComponentInstances $objects | Out-Null
    $groups = @{}
    foreach ($obj in $objects) {
        $component = Get-ObjectPropertyValue $obj "component"
        $componentId = [string](Get-ObjectPropertyValue $component "componentId")
        if ([string]::IsNullOrWhiteSpace($componentId)) { continue }
        if (-not $groups.ContainsKey($componentId)) {
            $componentType = [string](Get-ObjectPropertyValue $component "componentType")
            $groups[$componentId] = @{
                componentId = $componentId
                componentType = $componentType
                internalLayoutMode = $(if ($componentType -eq 'timeline_band') { 'repeated_items' } elseif ($componentType -eq 'styled_table' -or $componentType -eq 'data_table') { 'native_grid' } else { 'atomic' })
                parts = @()
            }
        }
        $shapeIndex = [int](Get-ObjectPropertyValue $obj "shapeIndex")
        $groups[$componentId].parts += @{
            shape = $shapeByIndex[[string]$shapeIndex]
            descriptor = @{
                componentId = $componentId
                componentType = [string](Get-ObjectPropertyValue $component "componentType")
                componentIndex = [int](Get-ObjectPropertyValue $component "componentIndex")
                part = [string](Get-ObjectPropertyValue $component "part")
                itemId = [string](Get-ObjectPropertyValue $component "itemId")
            }
            shapeIndex = $shapeIndex
            nativeShapeId = Get-ObjectPropertyValue $obj "nativeShapeId"
        }
    }

    $result = @{}
    foreach ($componentId in @($groups.Keys)) {
        $group = $groups[$componentId]
        $backgrounds = @($group.parts | Where-Object { [string]$_.descriptor.part -match '(^|_)(bg|band|background|table)($|_)' } | Sort-Object { -([double]$_.shape.Width * [double]$_.shape.Height) })
        if ($backgrounds.Count -eq 0) { continue }
        $group.background = $backgrounds[0].shape
        $group.backgroundNativeId = $backgrounds[0].nativeShapeId
        $result[$componentId] = $group
    }
    return $result
}

function Get-PptComponentGroupForGrid($slide, [string]$componentId) {
    $groups = Get-PptComponentGroupsForGrid $slide
    if (-not $groups.ContainsKey($componentId)) { return $null }
    return $groups[$componentId]
}

function Get-PptGridRowMembers($row) {
    $values = Get-ObjectPropertyValue $row "members"
    if ($null -eq $values) { $values = Get-ObjectPropertyValue $row "componentIds" }
    $result = @()
    foreach ($value in @($values)) {
        $id = [string]$value
        if (-not [string]::IsNullOrWhiteSpace($id) -and $result -notcontains $id) { $result += $id }
    }
    return $result
}

function Get-PptGridTextRole([string]$part) {
    if ($part -match '(^|_)(value|title|quote)($|_)') { return "primary" }
    if ($part -match '(^|_)(label|subtitle|badge_text)($|_)') { return "secondary" }
    if ($part -match '(^|_)(body|note|caption)($|_)') { return "body" }
    return "other"
}

function Get-PptGridMinimumHeight([string]$shellToken) {
    # Recommended template height only. Readable minimum height is calculated
    # from the live component parts by Get-PptGridMinimumHeightForGroup.
    $token = ([string]$shellToken).ToLowerInvariant()
    if ($token -match '^content_card') { return 64.0 }
    if ($token -match 'summary|metric|kpi') { return 73.0 }
    if ($token -match 'persona|route|timeline|process') { return 76.0 }
    return 72.0
}

function Get-PptGridRoleMinimumFontSize([string]$role, [double]$bodyMinimum) {
    if ($role -eq "primary") { return [Math]::Max(12.0, $bodyMinimum) }
    if ($role -eq "secondary") { return [Math]::Max(8.0, [Math]::Min($bodyMinimum, 9.0)) }
    return [Math]::Max(9.0, $bodyMinimum)
}

function Set-PptGridShapeFontSize($shape, [double]$fontSize) {
    # WPS can expose the same text through TextFrame and TextFrame2. Update both
    # ranges so BoundHeight is recalculated from the requested compact font.
    try { $shape.TextFrame.TextRange.Font.Size = $fontSize } catch {}
    try { $shape.TextFrame2.TextRange.Font.Size = $fontSize } catch {}
    try { $shape.TextFrame.TextRange.Characters().Font.Size = $fontSize } catch {}
    try { $shape.TextFrame2.TextRange.Characters().Font.Size = $fontSize } catch {}
}

function Resolve-PptGridShellToken($group, [string]$requestedShellToken) {
    if (-not [string]::IsNullOrWhiteSpace($requestedShellToken)) { return $requestedShellToken }
    $componentType = ([string]$group.componentType).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($componentType)) { return "summary_card_default" }
    return "$componentType`_default"
}

function Get-PptGridRenderedTextHeight($shape, [double]$targetTextWidth, [double]$minFontSize, [bool]$scaleToMinimumFont = $true) {
    $boundHeight = 0.0
    try { $boundHeight = [double]$shape.TextFrame2.TextRange.BoundHeight } catch {}
    if ($boundHeight -le 0) {
        try { $boundHeight = [double]$shape.TextFrame.TextRange.BoundHeight } catch {}
    }
    if ($boundHeight -le 0) { return 0.0 }
    $currentWidth = 0.0
    try { $currentWidth = [double]$shape.Width } catch {}
    if ($targetTextWidth -gt 0 -and $currentWidth -gt $targetTextWidth) {
        $boundHeight *= ($currentWidth / $targetTextWidth)
    }
    $currentFontSize = 0.0
    try { $currentFontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
    if ($scaleToMinimumFont -and $minFontSize -gt 0 -and $currentFontSize -gt $minFontSize) {
        $boundHeight *= ($minFontSize / $currentFontSize)
    }
    $verticalMargins = 0.0
    try { $verticalMargins = [Math]::Max(0.0, [double]$shape.TextFrame.MarginTop) + [Math]::Max(0.0, [double]$shape.TextFrame.MarginBottom) } catch {}
    return [Math]::Ceiling(($boundHeight + $verticalMargins) * 10) / 10
}

function Resolve-PptGridInternalLayoutMode($group) {
    $explicit = ([string](Get-ObjectPropertyValue $group "internalLayoutMode")).Trim().ToLowerInvariant()
    if ($explicit -eq "repeated_items" -or $explicit -eq "native_grid") { return $explicit }
    $componentType = ([string](Get-ObjectPropertyValue $group "componentType")).Trim().ToLowerInvariant()
    if ($componentType -eq "timeline_band") { return "repeated_items" }
    if ($componentType -eq "styled_table" -or $componentType -eq "data_table") { return "native_grid" }
    return "atomic"
}

function Get-PptRepeatedItemPartDescriptor([string]$partName) {
    if ($partName -match '(dot_text|title|body|dot)_([0-9]+)$') {
        return @{ role = [string]$Matches[1]; itemIndex = [int]$Matches[2] }
    }
    return $null
}

function Get-PptRepeatedItemsMinimumHeightForGroup($group, [double]$targetWidth, [double]$padding, [double]$minFontSize, [bool]$preserveCurrentFont = $false) {
    $background = $group.background
    $scaleX = if ($null -ne $background -and [double]$background.Width -gt 0) { $targetWidth / [double]$background.Width } else { 1.0 }
    $titleHeight = 28.0
    $bodyHeight = 22.0
    $itemCount = 0
    foreach ($part in @($group.parts)) {
        $descriptor = Get-PptRepeatedItemPartDescriptor ([string]$part.descriptor.part)
        if ($null -eq $descriptor) { continue }
        $itemCount = [Math]::Max($itemCount, [int]$descriptor.itemIndex)
        if ($descriptor.role -ne "title" -and $descriptor.role -ne "body") { continue }
        $shape = $part.shape
        $targetTextWidth = [Math]::Max(24.0, [double]$shape.Width * $scaleX)
        $role = if ($descriptor.role -eq "title") { "primary" } else { "body" }
        $roleMinimumFontSize = Get-PptGridRoleMinimumFontSize $role $minFontSize
        $required = Get-PptGridRenderedTextHeight $shape $targetTextWidth $roleMinimumFontSize (-not $preserveCurrentFont)
        if ($descriptor.role -eq "title") { $titleHeight = [Math]::Max($titleHeight, $required + 2.0) }
        else { $bodyHeight = [Math]::Max($bodyHeight, $required + 2.0) }
    }
    if ($itemCount -lt 1) { throw "Repeated-items component '$($group.componentId)' has no indexed item parts." }
    $outerPadding = [Math]::Max(6.0, [Math]::Min(12.0, $padding))
    return [Math]::Ceiling([Math]::Max(96.0, $outerPadding + $titleHeight + 40.0 + $bodyHeight + $outerPadding))
}

function Set-PptGridRepeatedItemsLayout($group, [double]$padding, [double]$minFontSize) {
    $background = $group.background
    $backgroundTop = [double]$background.Top
    $backgroundBottom = $backgroundTop + [double]$background.Height
    $titleHeight = 28.0
    $bodyHeight = 22.0
    $itemParts = @()
    foreach ($part in @($group.parts)) {
        $descriptor = Get-PptRepeatedItemPartDescriptor ([string]$part.descriptor.part)
        if ($null -eq $descriptor) { continue }
        $itemParts += @{ part = $part; role = [string]$descriptor.role; itemIndex = [int]$descriptor.itemIndex }
        if ($descriptor.role -eq "title") {
            $titleHeight = [Math]::Max($titleHeight, (Get-PptGridRenderedTextHeight $part.shape ([double]$part.shape.Width) (Get-PptGridRoleMinimumFontSize "primary" $minFontSize) $true) + 2.0)
        } elseif ($descriptor.role -eq "body") {
            $bodyHeight = [Math]::Max($bodyHeight, (Get-PptGridRenderedTextHeight $part.shape ([double]$part.shape.Width) (Get-PptGridRoleMinimumFontSize "body" $minFontSize) $true) + 2.0)
        }
    }
    $topPadding = [Math]::Max(6.0, [Math]::Min(12.0, $padding))
    $lineTop = $backgroundTop + $topPadding + $titleHeight + 12.0
    $bodyTop = $lineTop + 20.0
    $availableBodyHeight = $backgroundBottom - $bodyTop - $topPadding
    if ($availableBodyHeight -lt ($bodyHeight - 0.25)) {
        throw "Repeated-items component '$($group.componentId)' requires $([Math]::Ceiling($bodyHeight - $availableBodyHeight)) additional pt of body height."
    }
    $changedNativeIds = @()
    foreach ($part in @($group.parts)) {
        $shape = $part.shape
        $partName = [string]$part.descriptor.part
        $descriptor = Get-PptRepeatedItemPartDescriptor $partName
        if ($partName -eq "line" -or $partName -match '(^|_)line$') {
            $shape.Top = [single]$lineTop
        } elseif ($null -ne $descriptor) {
            switch ($descriptor.role) {
                "title" { $shape.Top = [single]($backgroundTop + $topPadding); $shape.Height = [single]$titleHeight }
                "body" { $shape.Top = [single]$bodyTop; $shape.Height = [single]$availableBodyHeight }
                "dot" { $shape.Top = [single]($lineTop - ([double]$shape.Height / 2.0) + 2.0) }
                "dot_text" { $shape.Top = [single]($lineTop - ([double]$shape.Height / 2.0) + 2.0) }
            }
        }
        $nativeId = $null
        try { $nativeId = [int]$shape.Id } catch {}
        if ($null -ne $nativeId -and $changedNativeIds -notcontains $nativeId) { $changedNativeIds += $nativeId }
    }
    return $changedNativeIds
}

function Get-PptGridMinimumHeightForGroup($group, [double]$targetWidth, [string]$shellToken, [double]$padding, [double]$minFontSize, [bool]$preserveCurrentFont = $false) {
    if ((Resolve-PptGridInternalLayoutMode $group) -eq "repeated_items") {
        return Get-PptRepeatedItemsMinimumHeightForGroup $group $targetWidth $padding $minFontSize $preserveCurrentFont
    }
    $token = ([string]$shellToken).ToLowerInvariant()
    $minimumPadding = if ($preserveCurrentFont) {
        [Math]::Max(4.0, [Math]::Min(12.0, $padding))
    } else {
        [Math]::Max(4.0, [Math]::Min(6.0, $padding))
    }
    $isStepCard = $token -match 'persona|route|timeline|process'
    $indexLaneWidth = if ($isStepCard) { 58.0 } else { 0.0 }
    $targetTextWidth = [Math]::Max(24, $targetWidth - $indexLaneWidth - (2 * $minimumPadding))
    $roleHeights = @{ primary = 0.0; secondary = 0.0; body = 0.0 }
    $fixedDecorationHeight = 0.0
    foreach ($part in @($group.parts)) {
        $shape = $part.shape
        $partName = [string]$part.descriptor.part
        if ($partName -match '(^|_)(index|dot|badge|avatar)($|_)' -and $partName -notmatch 'text') {
            try { $fixedDecorationHeight = [Math]::Max($fixedDecorationHeight, [double]$shape.Height) } catch {}
        }
        $hasText = $false
        try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
        if (-not $hasText) { continue }
        $role = Get-PptGridTextRole $partName
        if (-not $roleHeights.ContainsKey($role)) { continue }
        $roleMinimumFontSize = Get-PptGridRoleMinimumFontSize $role $minFontSize
        $roleHeights[$role] = [Math]::Max([double]$roleHeights[$role], (Get-PptGridRenderedTextHeight $shape $targetTextWidth $roleMinimumFontSize (-not $preserveCurrentFont)))
    }
    $primaryHeight = if ([double]$roleHeights.primary -gt 0) { [Math]::Max(16.0, [double]$roleHeights.primary) } else { 0.0 }
    $secondaryHeight = if ([double]$roleHeights.secondary -gt 0) { [Math]::Max(12.0, [double]$roleHeights.secondary) } else { 0.0 }
    $bodyHeight = if ([double]$roleHeights.body -gt 0) { [Math]::Max(14.0, [double]$roleHeights.body) } else { 0.0 }
    $textRoleCount = @(@($primaryHeight, $secondaryHeight, $bodyHeight) | Where-Object { $_ -gt 0 }).Count
    $textGapTotal = [Math]::Max(0, $textRoleCount - 1) * 3.0
    $textStackHeight = $primaryHeight + $secondaryHeight + $bodyHeight + $textGapTotal + (2 * $minimumPadding)
    $decorationHeight = if ($fixedDecorationHeight -gt 0) { $fixedDecorationHeight + (2 * $minimumPadding) } else { 0.0 }
    $structuralFloor = if ($token -match 'summary|metric|kpi') { 48.0 } elseif ($isStepCard) { 46.0 } else { 42.0 }
    $calculatedMinimum = [Math]::Ceiling([Math]::Max($structuralFloor, [Math]::Max($textStackHeight, $decorationHeight)))

    # A live component that already contains every part and rendered line at the
    # role-specific font floor is a stronger feasibility observation than the
    # conservative text-height estimate. Reuse its current height as an upper
    # bound for the minimum when the target width is not narrower.
    $background = $group.background
    $currentHeightIsFeasible = $null -ne $background -and $targetWidth -ge ([double]$background.Width - 1)
    if ($currentHeightIsFeasible) {
        $backgroundLeft = [double]$background.Left
        $backgroundTop = [double]$background.Top
        $backgroundRight = $backgroundLeft + [double]$background.Width
        $backgroundBottom = $backgroundTop + [double]$background.Height
        foreach ($part in @($group.parts)) {
            $shape = $part.shape
            $partName = [string]$part.descriptor.part
            if ($partName -notmatch '(^|_)(bg|band|background)($|_)') {
                $partRight = [double]$shape.Left + [double]$shape.Width
                $partBottom = [double]$shape.Top + [double]$shape.Height
                if ([double]$shape.Left -lt ($backgroundLeft - 2) -or [double]$shape.Top -lt ($backgroundTop - 2) -or $partRight -gt ($backgroundRight + 2) -or $partBottom -gt ($backgroundBottom + 2)) {
                    $currentHeightIsFeasible = $false
                    break
                }
            }
            $hasText = $false
            try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
            if (-not $hasText) { continue }
            $role = Get-PptGridTextRole $partName
            if ($role -ne 'other') {
                $roleMinimumFontSize = Get-PptGridRoleMinimumFontSize $role $minFontSize
                $currentFontSize = 0.0
                try { $currentFontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
                if ($currentFontSize -gt 0 -and $currentFontSize -lt ($roleMinimumFontSize - 0.01)) {
                    $currentHeightIsFeasible = $false
                    break
                }
            }
            if ((Test-PptShapeTextOverflow $shape).overflow) {
                $currentHeightIsFeasible = $false
                break
            }
        }
    }
    if ($currentHeightIsFeasible) {
        $calculatedMinimum = [Math]::Max($structuralFloor, [Math]::Min($calculatedMinimum, [double]$background.Height))
    }
    return [Math]::Ceiling($calculatedMinimum)
}

function Set-PptGridUnifiedShell($group, $visual, [string]$shellToken, [string]$decorationToken, [double]$padding, $roleTypography = $null, [bool]$preserveExistingStyle = $false) {
    if ([string]::IsNullOrWhiteSpace($shellToken)) { return }
    $background = $group.background
    $surface = Convert-HexColorToRgbInt([string]$visual.surface)
    $line = Convert-HexColorToRgbInt([string]$visual.line)
    $token = $shellToken.ToLowerInvariant()
    $isContentCard = $token -match '^content_card'
    $isMetricCard = $token -match 'summary|metric|kpi'
    $isStepCard = $token -match 'persona|route|timeline|process'
    $compactShell = ($null -ne $roleTypography) -or ($isContentCard -and [double]$background.Height -lt 76) -or ($isMetricCard -and [double]$background.Height -lt 82) -or ($isStepCard -and [double]$background.Height -lt 76)
    $compactPadding = [Math]::Max(4.0, [Math]::Min($padding, [Math]::Min(12.0, [double]$background.Height * 0.14)))
    $stepIndexSize = if ($isStepCard) { [Math]::Max(24.0, [Math]::Min(34.0, [double]$background.Height - (2 * $compactPadding))) } else { 0.0 }
    $stepTextLeft = [double]$background.Left + $compactPadding + $stepIndexSize + 12.0
    $stepTextWidth = [Math]::Max(24.0, [double]$background.Width - ($stepTextLeft - [double]$background.Left) - $compactPadding)
    if (-not $preserveExistingStyle) {
        if ($null -ne $surface) { try { $background.Fill.Visible = $true; $background.Fill.Solid(); $background.Fill.ForeColor.RGB = $surface } catch {} }
        if ($null -ne $line) { try { $background.Line.Visible = $true; $background.Line.ForeColor.RGB = $line; $background.Line.Weight = 1 } catch {} }
    }
    foreach ($part in @($group.parts)) {
        $shape = $part.shape
        $partName = [string]$part.descriptor.part
        if ($partName -match 'accent|rule|strip') {
            if ($isStepCard -and $partName -match '(^|_)strip($|_)') {
                try { $shape.Left = [double]$background.Left + 1 } catch {}
                try { $shape.Top = [double]$background.Top + 1 } catch {}
                try { $shape.Width = [Math]::Min(10.0, [Math]::Max(5.0, [double]$background.Width * 0.04)) } catch {}
                try { $shape.Height = [Math]::Max(8.0, [double]$background.Height - 2) } catch {}
            } elseif ($partName -match 'top_rule') {
                try { $shape.Left = [double]$background.Left + $compactPadding } catch {}
                try { $shape.Top = [double]$background.Top + 9 } catch {}
                try { $shape.Width = [Math]::Max(24, [double]$background.Width - (2 * $compactPadding)) } catch {}
                try { $shape.Height = 4 } catch {}
            } else {
                try { $shape.Left = [double]$background.Left + $compactPadding } catch {}
                try { $shape.Top = [double]$background.Top + 9 } catch {}
                try { $shape.Width = [Math]::Min(48, [Math]::Max(24, [double]$background.Width - (2 * $compactPadding))) } catch {}
                try { $shape.Height = 4 } catch {}
            }
            if (-not $preserveExistingStyle -and -not [string]::IsNullOrWhiteSpace($decorationToken)) {
                $accent = Convert-HexColorToRgbInt([string]$visual.secondary)
                if ($null -ne $accent) {
                    try { $shape.Fill.Visible = $true; $shape.Fill.Solid(); $shape.Fill.ForeColor.RGB = $accent; $shape.Line.Visible = 0 } catch {}
                }
            }
        }
        if ($isStepCard -and $partName -match '(^|_)index($|_)' -and $partName -notmatch 'text') {
            try { $shape.Left = [double]$background.Left + $compactPadding } catch {}
            try { $shape.Top = [double]$background.Top + (([double]$background.Height - $stepIndexSize) / 2) } catch {}
            try { $shape.Width = $stepIndexSize; $shape.Height = $stepIndexSize } catch {}
        }
        if ($isStepCard -and $partName -match 'index_text') {
            try { $shape.Left = [double]$background.Left + $compactPadding } catch {}
            try { $shape.Top = [double]$background.Top + (([double]$background.Height - $stepIndexSize) / 2) } catch {}
            try { $shape.Width = $stepIndexSize; $shape.Height = $stepIndexSize } catch {}
            if (-not $preserveExistingStyle) {
                Set-PptGridShapeFontSize $shape 9
                try { $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 2; $shape.TextFrame.VerticalAnchor = 3 } catch {}
            }
        }
        $hasText = $false
        try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
        if (-not $hasText) { continue }
        try { $shape.TextFrame.AutoSize = 0; $shape.TextFrame.WordWrap = -1 } catch {}
        try { $shape.TextFrame2.AutoSize = 0; $shape.TextFrame2.WordWrap = -1 } catch {}
        if (-not $preserveExistingStyle) {
            try { $shape.TextFrame.VerticalAnchor = 1; $shape.TextFrame.MarginTop = 0; $shape.TextFrame.MarginBottom = 0 } catch {}
            try { $shape.TextFrame2.VerticalAnchor = 1; $shape.TextFrame2.MarginTop = 0; $shape.TextFrame2.MarginBottom = 0 } catch {}
        }
        $role = Get-PptGridTextRole $partName
        if (-not $preserveExistingStyle) { try { $shape.TextFrame.TextRange.Font.Name = [string]$visual.fontName } catch {} }
        if ($role -eq "primary") {
            $primaryOffset = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "primaryTop")) { [double](Get-ObjectPropertyValue $roleTypography "primaryTop") } else { $compactPadding }
            $primaryTop = [double]$background.Top + $primaryOffset
            try { $shape.Left = $(if ($isStepCard) { $stepTextLeft } else { [double]$background.Left + $compactPadding }) } catch {}
            try { $shape.Top = $primaryTop } catch {}
            try { $shape.Width = $(if ($isStepCard) { $stepTextWidth } else { [Math]::Max(24, [double]$background.Width - (2 * $compactPadding)) }) } catch {}
            $primaryFontSize = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "primary")) { [double](Get-ObjectPropertyValue $roleTypography "primary") } elseif ($compactShell -and $isMetricCard) { 14 } elseif ($compactShell) { 13 } elseif ($isContentCard) { 14 } else { 13 }
            if ($preserveExistingStyle) {
                try {
                    $existingPrimaryFontSize = [double]$shape.TextFrame.TextRange.Font.Size
                    if ($existingPrimaryFontSize -gt 0) { $primaryFontSize = $existingPrimaryFontSize }
                } catch {}
            } else {
                Set-PptGridShapeFontSize $shape $primaryFontSize
            }
            $primaryEstimate = Get-PptEstimatedTextHeight $shape ([double]$shape.Width) $primaryFontSize
            $primaryRenderedHeight = Get-PptGridRenderedTextHeight $shape ([double]$shape.Width) (Get-PptGridRoleMinimumFontSize "primary" $primaryFontSize) $false
            $primaryRequiredHeight = [Math]::Max($primaryEstimate, $primaryRenderedHeight + 2.0)
            $primaryHeight = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "primaryHeight")) { [Math]::Max([double](Get-ObjectPropertyValue $roleTypography "primaryHeight"), $primaryRequiredHeight) } else { [Math]::Max(16.0, $primaryRequiredHeight) }
            $primaryHeight = [Math]::Min($primaryHeight, [Math]::Max(16.0, [double]$background.Height - (2 * $compactPadding)))
            try { $shape.TextFrame.AutoSize = 0 } catch {}
            try { $shape.TextFrame2.AutoSize = 0 } catch {}
            try { $shape.Height = $primaryHeight } catch {}
            if (-not $preserveExistingStyle) {
                try { $shape.TextFrame.TextRange.Font.Bold = -1 } catch {}
                try { $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 1 } catch {}
                $titleColor = Convert-HexColorToRgbInt([string]$visual.title)
                if ($null -ne $titleColor) { try { $shape.TextFrame.TextRange.Font.Color.RGB = $titleColor } catch {} }
            }
        } elseif ($role -eq "secondary") {
            $secondaryOffset = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "secondaryTop")) { [double](Get-ObjectPropertyValue $roleTypography "secondaryTop") } else { $compactPadding }
            $secondaryTop = [double]$background.Top + $secondaryOffset
            foreach ($candidate in @($group.parts)) {
                if ((Get-PptGridTextRole ([string]$candidate.descriptor.part)) -ne 'primary') { continue }
                $secondaryTop = [Math]::Max($secondaryTop, [double]$candidate.shape.Top + [double]$candidate.shape.Height + 2)
            }
            try { $shape.Left = [double]$background.Left + $compactPadding } catch {}
            try { $shape.Top = $secondaryTop } catch {}
            try { $shape.Width = [Math]::Max(24, [double]$background.Width - (2 * $compactPadding)) } catch {}
            $secondaryFontSize = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "secondary")) { [double](Get-ObjectPropertyValue $roleTypography "secondary") } elseif ($compactShell) { 9 } else { 10 }
            if ($preserveExistingStyle) {
                try {
                    $existingSecondaryFontSize = [double]$shape.TextFrame.TextRange.Font.Size
                    if ($existingSecondaryFontSize -gt 0) { $secondaryFontSize = $existingSecondaryFontSize }
                } catch {}
            } else {
                Set-PptGridShapeFontSize $shape $secondaryFontSize
            }
            $secondaryEstimate = Get-PptEstimatedTextHeight $shape ([double]$shape.Width) $secondaryFontSize
            $secondaryRenderedHeight = Get-PptGridRenderedTextHeight $shape ([double]$shape.Width) (Get-PptGridRoleMinimumFontSize "secondary" $secondaryFontSize) $false
            $secondaryRequiredHeight = [Math]::Max($secondaryEstimate, $secondaryRenderedHeight + 2.0)
            $secondaryHeight = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "secondaryHeight")) { [Math]::Max([double](Get-ObjectPropertyValue $roleTypography "secondaryHeight"), $secondaryRequiredHeight) } else { [Math]::Max(12.0, $secondaryRequiredHeight) }
            $secondaryHeight = [Math]::Min($secondaryHeight, [Math]::Max(12.0, [double]$background.Top + [double]$background.Height - $compactPadding - $secondaryTop))
            try { $shape.TextFrame.AutoSize = 0 } catch {}
            try { $shape.TextFrame2.AutoSize = 0 } catch {}
            try { $shape.Height = $secondaryHeight } catch {}
            if (-not $preserveExistingStyle) { try { $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 1 } catch {} }
        } elseif ($role -eq "body") {
            $bodyOffset = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "bodyTop")) { [double](Get-ObjectPropertyValue $roleTypography "bodyTop") } else { $compactPadding }
            $bodyTop = [double]$background.Top + $bodyOffset
            foreach ($candidate in @($group.parts)) {
                $candidateRole = Get-PptGridTextRole ([string]$candidate.descriptor.part)
                if ($candidateRole -notin @('primary', 'secondary')) { continue }
                $bodyTop = [Math]::Max($bodyTop, [double]$candidate.shape.Top + [double]$candidate.shape.Height + 2)
            }
            try { $shape.Left = $(if ($isStepCard) { $stepTextLeft } else { [double]$background.Left + $compactPadding }) } catch {}
            try { $shape.Top = $bodyTop } catch {}
            try { $shape.Width = $(if ($isStepCard) { $stepTextWidth } else { [Math]::Max(24, [double]$background.Width - (2 * $compactPadding)) }) } catch {}
            $bodyFontSize = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "body")) { [double](Get-ObjectPropertyValue $roleTypography "body") } elseif ($compactShell) { [Math]::Min(10, [double]$visual.bodyFontSize) } else { [Math]::Min(11, [double]$visual.bodyFontSize) }
            if ($preserveExistingStyle) {
                try {
                    $existingBodyFontSize = [double]$shape.TextFrame.TextRange.Font.Size
                    if ($existingBodyFontSize -gt 0) { $bodyFontSize = $existingBodyFontSize }
                } catch {}
            } else {
                Set-PptGridShapeFontSize $shape $bodyFontSize
            }
            if (-not $preserveExistingStyle -and $null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "bodyColor")) {
                $bodyColor = Convert-HexColorToRgbInt ([string](Get-ObjectPropertyValue $roleTypography "bodyColor"))
                if ($null -ne $bodyColor) { try { $shape.TextFrame.TextRange.Font.Color.RGB = $bodyColor } catch {} }
            }
            $roleBottomPadding = if ($null -ne $roleTypography -and $null -ne (Get-ObjectPropertyValue $roleTypography "bodyBottomPadding")) { [double](Get-ObjectPropertyValue $roleTypography "bodyBottomPadding") } else { $null }
            $bottomPadding = if ($null -ne $roleBottomPadding) { $roleBottomPadding } elseif ($compactShell) { 6.0 } else { 8.0 }
            try { $shape.TextFrame.AutoSize = 0 } catch {}
            try { $shape.TextFrame2.AutoSize = 0 } catch {}
            $desiredBodyHeight = [Math]::Max(14.0, [double](([double]$background.Top + [double]$background.Height - $bottomPadding) - $bodyTop))
            Set-PptShapePositionValues $shape @{ height = $desiredBodyHeight } | Out-Null
            if ([Math]::Abs([double]$shape.Height - $desiredBodyHeight) -gt 0.25) {
                throw "Failed to resize component body '$([string]$shape.Name)' to $desiredBodyHeight pt."
            }
            if (-not $preserveExistingStyle) { try { $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 1 } catch {} }
        }
    }
}

function Invoke-PptGridPreOperations($slide, $operations) {
    $changed = @()
    $failed = @()
    $index = 0
    foreach ($op in @($operations)) {
        $opType = [string](Get-ObjectPropertyValue $op "type")
        if ([string]::IsNullOrWhiteSpace($opType)) {
            $index++
            continue
        }
        try {
            $target = Get-PptBatchTarget $op
            switch ($opType) {
                { $_ -in @("setShapeStyle", "set_shape_style") } {
                    $resolvedShape = Resolve-PptShape $slide $target "normalizePptComponentGrid.preOperations"
                    if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                    $style = Get-ObjectPropertyValue $op "style"
                    if ($null -eq $style) { $style = $op }
                    $applied = Set-PptShapeStyleValues $resolvedShape.shape $style
                    $changed += @{ operationIndex = $index; type = $opType; name = [string]$resolvedShape.shape.Name; applied = $applied }
                    break
                }
                { $_ -in @("setShapeText", "set_shape_text", "setTextboxText", "setTextBoxText", "set_textbox_text") } {
                    $resolvedShape = Resolve-PptShape $slide $target "normalizePptComponentGrid.preOperations" "textbox"
                    if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                    $textValue = Get-ObjectPropertyValue $op "text"
                    if ($null -eq $textValue) { $textValue = "" }
                    $resolvedShape.shape.TextFrame.TextRange.Text = [string]$textValue
                    $changed += @{ operationIndex = $index; type = $opType; name = [string]$resolvedShape.shape.Name; text = [string]$textValue }
                    break
                }
                { $_ -in @("setTextBoxStyle", "setTextboxStyle", "set_textbox_style") } {
                    $resolvedShape = Resolve-PptShape $slide $target "normalizePptComponentGrid.preOperations" "textbox"
                    if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                    $style = Get-ObjectPropertyValue $op "style"
                    if ($null -eq $style) { $style = $op }
                    $applied = Set-PptTextFrameStyleValues $resolvedShape.shape $style
                    $changed += @{ operationIndex = $index; type = $opType; name = [string]$resolvedShape.shape.Name; applied = $applied }
                    break
                }
                default { throw "Unsupported compiled pre-operation '$opType'" }
            }
        } catch {
            $failed += @{ operationIndex = $index; type = $opType; error = $_.Exception.Message }
            break
        }
        $index++
    }
    return @{ success = ($failed.Count -eq 0); changed = $changed; failed = $failed }
}

function Get-PptNormalizeComponentGridResult($ppt, $pres, $options) {
    $slideIndex = [int](Get-ObjectPropertyValue $options "slideIndex")
    $resolvedSlide = Resolve-PptSlide $pres $slideIndex "normalizePptComponentGrid"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $slideIndex = [int]$resolvedSlide.slideIndex
    $plan = Get-ObjectPropertyValue $options "slideLayoutPlan"
    $preserveExistingStyleValue = if ($null -ne $plan) { Get-ObjectPropertyValue $plan "preserveExistingStyle" } else { $null }
    $preserveExistingStyle = $null -ne $preserveExistingStyleValue -and [bool]$preserveExistingStyleValue
    $rowsInput = if ($null -ne $plan) { Get-ObjectPropertyValue $plan "rows" } else { $null }
    if ($null -eq $rowsInput) { $rowsInput = Get-ObjectPropertyValue $options "rowGroups" }
    $rows = @($rowsInput)
    if ($rows.Count -eq 0) {
        return New-PptRecoverableError "PPT_LAYOUT_PLAN_REQUIRED" "normalizePptComponentGrid requires SlideLayoutPlan.rows or rowGroups." @{ suggestedAction = "build_slide_layout_plan_then_retry" }
    }
    $safeArea = if ($null -ne $plan) { Get-ObjectPropertyValue $plan "safeArea" } else { $null }
    $safeLeft = if ($null -ne $safeArea -and $null -ne (Get-ObjectPropertyValue $safeArea "left")) { [double](Get-ObjectPropertyValue $safeArea "left") } else { 48.0 }
    $safeRight = if ($null -ne $safeArea -and $null -ne (Get-ObjectPropertyValue $safeArea "right")) { [double](Get-ObjectPropertyValue $safeArea "right") } else { 912.0 }
    $safeTop = if ($null -ne $safeArea -and $null -ne (Get-ObjectPropertyValue $safeArea "top")) { [double](Get-ObjectPropertyValue $safeArea "top") } else { 128.0 }
    $safeBottom = if ($null -ne $safeArea -and $null -ne (Get-ObjectPropertyValue $safeArea "bottom")) { [double](Get-ObjectPropertyValue $safeArea "bottom") } else { 481.0 }
    $paddingValue = Get-ObjectPropertyValue $options "padding"
    $padding = if ($null -ne $paddingValue) { [double]$paddingValue } else { 10.0 }
    $minFontValue = Get-ObjectPropertyValue $options "minFontSize"
    $minFontSize = if ($null -ne $minFontValue) { [double]$minFontValue } else { 9.0 }
    $componentSizeIntent = ([string](Get-ObjectPropertyValue $options "componentSizeIntent")).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($componentSizeIntent)) { $componentSizeIntent = "preserve" }
    $contentFitOnlyValue = Get-ObjectPropertyValue $options "contentFitOnly"
    $contentFitOnly = $null -ne $contentFitOnlyValue -and [bool]$contentFitOnlyValue
    $layoutAspect = ([string](Get-ObjectPropertyValue $options "layoutAspect")).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($layoutAspect)) { $layoutAspect = "full" }
    if (@("spacing", "alignment", "size", "internal", "full") -notcontains $layoutAspect) {
        return New-PptRecoverableError "PPT_LAYOUT_ASPECT_UNSUPPORTED" "Unsupported layoutAspect '$layoutAspect'." @{ allowed = @("spacing", "alignment", "size", "internal", "full") }
    }
    $externalOnly = $layoutAspect -eq "spacing" -or $layoutAspect -eq "alignment"
    $internalOnly = $layoutAspect -eq "internal"
    $sizeAxes = @((Get-ObjectPropertyValue $options "sizeAxes") | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() } | Where-Object { $_ -eq "auto" -or $_ -eq "width" -or $_ -eq "height" })
    if ($sizeAxes.Count -eq 0) { $sizeAxes = @("auto") }
    $allowWidthResize = $sizeAxes -contains "auto" -or $sizeAxes -contains "width"
    $allowHeightResize = $sizeAxes -contains "auto" -or $sizeAxes -contains "height"
    $visualInput = Get-ObjectPropertyValue $options "visualSystem"
    $visual = Get-PptR4VisualSystem $visualInput
    $groupMap = @{}
    $allGroups = @()
    $componentBindings = Get-ObjectPropertyValue $options "componentBindings"
    try {
        $availableGroups = Get-PptComponentGroupsForGrid $slide $componentBindings
    } catch {
        return New-PptRecoverableError "PPT_LAYOUT_COMPONENT_BINDING_STALE" $_.Exception.Message @{ suggestedAction = "refresh_current_context_and_restart_mutation" }
    }
    foreach ($row in $rows) {
        foreach ($componentId in @(Get-PptGridRowMembers $row)) {
            if ($groupMap.ContainsKey($componentId)) { continue }
            $group = if ($availableGroups.ContainsKey($componentId)) { $availableGroups[$componentId] } else { $null }
            if ($null -eq $group) {
                return New-PptRecoverableError "PPT_LAYOUT_COMPONENT_NOT_FOUND" "SlideLayoutPlan component '$componentId' was not found or has no background part." @{ componentId = $componentId; suggestedAction = "read_current_context_then_rebuild_layout_plan" }
            }
            $groupMap[$componentId] = $group
            $allGroups += $group
        }
    }
    if ($allGroups.Count -lt 1) {
        return New-PptRecoverableError "PPT_LAYOUT_GRID_TARGETS_REQUIRED" "At least one existing component is required." @{ componentCount = $allGroups.Count }
    }

    # The caller cannot weaken the real footer/page-number boundary. Intersect the
    # declared safe area with late-slide text placeholders that are not target parts.
    $tokens = if ($null -ne $plan) { Get-ObjectPropertyValue $plan "tokens" } else { $null }
    $planProtectedRegions = @()
    if ($null -ne $plan) {
        $regionsValue = Get-ObjectPropertyValue $plan "protectedRegions"
        if ($null -ne $regionsValue) { $planProtectedRegions = @($regionsValue) }
    }
    $preferredProtectedGapValue = if ($null -ne $tokens) { Get-ObjectPropertyValue $tokens "preferredProtectedGap" } else { $null }
    if ($null -eq $preferredProtectedGapValue -and $null -ne $tokens) { $preferredProtectedGapValue = Get-ObjectPropertyValue $tokens "protectedGap" }
    $preferredProtectedGap = if ($null -ne $preferredProtectedGapValue) { [double]$preferredProtectedGapValue } else { 12.0 }
    $minimumProtectedGapValue = if ($null -ne $tokens) { Get-ObjectPropertyValue $tokens "minimumProtectedGap" } else { $null }
    $minimumProtectedGap = if ($null -ne $minimumProtectedGapValue) { [double]$minimumProtectedGapValue } else { 8.0 }
    $footerGapValue = if ($null -ne $tokens) { Get-ObjectPropertyValue $tokens "footerGap" } else { $null }
    $footerGap = if ($null -ne $footerGapValue) { [double]$footerGapValue } else { 12.0 }
    $slideHeight = [double]$pres.PageSetup.SlideHeight
    $targetShapeNames = @($allGroups | ForEach-Object { $_.parts } | ForEach-Object { [string]$_.shape.Name })
    $footerTop = $null
    for ($shapeIndex = 1; $shapeIndex -le [int]$slide.Shapes.Count; $shapeIndex++) {
        $shape = $slide.Shapes.Item($shapeIndex)
        if ($targetShapeNames -contains [string]$shape.Name) { continue }
        $shapeTop = [double]$shape.Top
        if ($shapeTop -lt ($slideHeight * 0.88)) { continue }
        $hasText = $false
        try { $hasText = [bool]$shape.HasTextFrame } catch {}
        if (-not $hasText) { continue }
        if ($null -eq $footerTop -or $shapeTop -lt [double]$footerTop) { $footerTop = $shapeTop }
    }
    if (-not $contentFitOnly -and $null -ne $footerTop) { $safeBottom = [Math]::Min($safeBottom, [double]$footerTop - $footerGap) }

    $snapshots = @()
    foreach ($group in $allGroups) { foreach ($part in @($group.parts)) { $snapshots += Get-PptShapeSnapshot $part.shape } }
    $preOperationsInput = Get-ObjectPropertyValue $options "preOperations"
    $preOperations = if ($null -ne $preOperationsInput) { @($preOperationsInput) } else { @() }
    $preOperationResult = Invoke-PptGridPreOperations $slide $preOperations
    if (-not $preOperationResult.success) {
        Restore-PptShapeSnapshots $slide $snapshots
        return @{
            success = $false
            error = "normalizePptComponentGrid pre-operations failed and were rolled back"
            data = @{ partialMutation = $false; transactional = $true; rolledBack = $true; wroteToWps = $false; preOperations = $preOperationResult }
        }
    }
    $targets = @()
    $issues = @()
    $rowSpecs = @()
    $layoutBudget = $null
    foreach ($row in $rows) {
        $memberIds = @(Get-PptGridRowMembers $row)
        if ($memberIds.Count -eq 0) { continue }
        $members = @($memberIds | ForEach-Object { $groupMap[[string]$_] })
        $preferredColumnGapValue = Get-ObjectPropertyValue $row "preferredColumnGap"
        if ($null -eq $preferredColumnGapValue) { $preferredColumnGapValue = Get-ObjectPropertyValue $row "columnGap" }
        if ($null -eq $preferredColumnGapValue) { $preferredColumnGapValue = Get-ObjectPropertyValue $row "gap" }
        if ($null -eq $preferredColumnGapValue -and $null -ne $tokens) { $preferredColumnGapValue = Get-ObjectPropertyValue $tokens "preferredColumnGap" }
        if ($null -eq $preferredColumnGapValue -and $null -ne $tokens) { $preferredColumnGapValue = Get-ObjectPropertyValue $tokens "columnGap" }
        $preferredColumnGap = if ($null -ne $preferredColumnGapValue) { [double]$preferredColumnGapValue } else { 14.0 }
        $minimumColumnGapValue = Get-ObjectPropertyValue $row "minimumColumnGap"
        if ($null -eq $minimumColumnGapValue -and $null -ne $tokens) { $minimumColumnGapValue = Get-ObjectPropertyValue $tokens "minimumColumnGap" }
        $minimumColumnGap = if ($null -ne $minimumColumnGapValue) { [double]$minimumColumnGapValue } else { 8.0 }
        $minimumColumnGap = [Math]::Min($preferredColumnGap, [Math]::Max(0, $minimumColumnGap))
        $explicitRects = @{}
        $componentRectsValue = Get-ObjectPropertyValue $row "componentRects"
        if ($null -eq $componentRectsValue) { $componentRectsValue = Get-ObjectPropertyValue $row "predictedComponents" }
        foreach ($item in @($componentRectsValue)) {
            $componentId = [string](Get-ObjectPropertyValue $item "componentId")
            if ([string]::IsNullOrWhiteSpace($componentId)) { continue }
            $boundsValue = Get-ObjectPropertyValue $item "bounds"
            if ($null -eq $boundsValue) { $boundsValue = $item }
            $rectLeft = Get-PptBoundsNumber $boundsValue "left"
            $rectWidth = Get-PptBoundsNumber $boundsValue "width"
            if ($rectWidth -le 0) { continue }
            $explicitRects[$componentId] = @{
                left = $rectLeft
                top = Get-PptBoundsNumber $boundsValue "top"
                width = $rectWidth
                height = Get-PptBoundsNumber $boundsValue "height"
            }
        }
        $preferredRowGapValue = Get-ObjectPropertyValue $row "preferredGapAfter"
        if ($null -eq $preferredRowGapValue) { $preferredRowGapValue = Get-ObjectPropertyValue $row "minGapAfter" }
        if ($null -eq $preferredRowGapValue -and $null -ne $tokens) { $preferredRowGapValue = Get-ObjectPropertyValue $tokens "preferredRowGap" }
        if ($null -eq $preferredRowGapValue -and $null -ne $tokens) { $preferredRowGapValue = Get-ObjectPropertyValue $tokens "rowGap" }
        $preferredRowGap = if ($null -ne $preferredRowGapValue) { [double]$preferredRowGapValue } else { 16.0 }
        $minimumRowGapValue = Get-ObjectPropertyValue $row "minimumGapAfter"
        if ($null -eq $minimumRowGapValue) { $minimumRowGapValue = Get-ObjectPropertyValue $row "minimumGap" }
        if ($null -eq $minimumRowGapValue -and $null -ne $tokens) { $minimumRowGapValue = Get-ObjectPropertyValue $tokens "minimumRowGap" }
        $minimumRowGap = if ($null -ne $minimumRowGapValue) { [double]$minimumRowGapValue } else { 8.0 }
        $minimumRowGap = [Math]::Min($preferredRowGap, [Math]::Max(0, $minimumRowGap))
        $rowLeft = [Math]::Max($safeLeft, ($members | ForEach-Object { [double]$_.background.Left } | Measure-Object -Minimum).Minimum)
        $rowRight = [Math]::Min($safeRight, ($members | ForEach-Object { [double]$_.background.Left + [double]$_.background.Width } | Measure-Object -Maximum).Maximum)
        if (($rowRight - $rowLeft) -lt 160) { $rowLeft = $safeLeft; $rowRight = $safeRight }
        $columnGap = $preferredColumnGap
        if ($memberIds.Count -gt 1) {
            $availableRowWidth = $rowRight - $rowLeft
            $minimumReadableWidth = 80.0
            $maximumGapAtReadableWidth = ($availableRowWidth - ($memberIds.Count * $minimumReadableWidth)) / ($memberIds.Count - 1)
            $columnGap = [Math]::Max($minimumColumnGap, [Math]::Min($preferredColumnGap, $maximumGapAtReadableWidth))
        }
        $targetWidth = ($rowRight - $rowLeft - (($memberIds.Count - 1) * $columnGap)) / $memberIds.Count
        $targetRects = @()
        for ($memberIndex = 0; $memberIndex -lt $memberIds.Count; $memberIndex++) {
            $memberId = [string]$memberIds[$memberIndex]
            if ($explicitRects.ContainsKey($memberId)) {
                $targetRects += @{ left = [double]$explicitRects[$memberId].left; width = [double]$explicitRects[$memberId].width }
            } else {
                $targetRects += @{ left = [double]$rowLeft + ($memberIndex * ([double]$targetWidth + [double]$columnGap)); width = [double]$targetWidth }
            }
        }
        $shellToken = [string](Get-ObjectPropertyValue $row "shellToken")
        $heightValue = Get-ObjectPropertyValue $row "height"
        $targetHeight = if ($null -ne $heightValue) { [double]$heightValue } else { ($members | ForEach-Object { [double]$_.background.Height } | Measure-Object -Maximum).Maximum }
        $memberMinimumHeights = @()
        $memberPreferredHeights = @()
        for ($memberIndex = 0; $memberIndex -lt $members.Count; $memberIndex++) {
            $effectiveShellToken = Resolve-PptGridShellToken $members[$memberIndex] $shellToken
            $memberMinimumHeights += Get-PptGridMinimumHeightForGroup $members[$memberIndex] ([double]$targetRects[$memberIndex].width) $effectiveShellToken $padding $minFontSize
            $memberPreferredHeights += Get-PptGridMinimumHeightForGroup $members[$memberIndex] ([double]$targetRects[$memberIndex].width) $effectiveShellToken $padding $minFontSize $true
        }
        $minimumHeight = ($memberMinimumHeights | Measure-Object -Maximum).Maximum
        if ($null -eq $minimumHeight) { $minimumHeight = Get-PptGridMinimumHeight $shellToken }
        $preferredContentHeight = ($memberPreferredHeights | Measure-Object -Maximum).Maximum
        if ($null -eq $preferredContentHeight) { $preferredContentHeight = $minimumHeight }
        $contentDrivenSizingValue = if ($null -ne $tokens) { Get-ObjectPropertyValue $tokens "contentDrivenSizing" } else { $null }
        $contentDrivenSizing = $null -ne $contentDrivenSizingValue -and [bool]$contentDrivenSizingValue
        # Explicit fit-to-content requests use the real minimum height. Normal
        # layout normalization keeps the existing visual scale and only grows
        # when content requires it.
        $targetHeight = if ($contentDrivenSizing) { [Math]::Max([double]$minimumHeight, [double]$preferredContentHeight) } else { [Math]::Max($minimumHeight, $targetHeight) }
        $layoutMinimumHeight = if ($componentSizeIntent -eq "preserve") {
            [double]$targetHeight
        } else {
            [double]$minimumHeight
        }
        $existingTop = ($members | ForEach-Object { [double]$_.background.Top } | Measure-Object -Minimum).Minimum
        $topValue = Get-ObjectPropertyValue $row "top"
        $desiredTop = if ($null -ne $topValue) { [double]$topValue } else { [double]$existingTop }
        $rowSpecs += @{
            row = $row; memberIds = $memberIds; members = $members; rowLeft = $rowLeft; targetWidth = $targetWidth
            targetRects = $targetRects
            columnGap = $columnGap; preferredColumnGap = $preferredColumnGap; minimumColumnGap = $minimumColumnGap
            preferredRowGap = $preferredRowGap; minimumRowGap = $minimumRowGap; resolvedRowGap = $preferredRowGap; desiredTop = $desiredTop
            desiredHeight = $targetHeight; minimumHeight = $layoutMinimumHeight; contentMinimumHeight = $minimumHeight; shellToken = $shellToken
        }
    }
    $rowSpecs = @($rowSpecs | Sort-Object { [double]$_.desiredTop })

    if ($rowSpecs.Count -gt 0) {
        $firstTop = if ($contentFitOnly) { [double]$rowSpecs[0].desiredTop } else { [Math]::Max($safeTop, [double]$rowSpecs[0].desiredTop) }
        $leadingGap = if ($null -ne $tokens -and $null -ne (Get-ObjectPropertyValue $tokens "preferredRowGap")) { [double](Get-ObjectPropertyValue $tokens "preferredRowGap") } elseif ($null -ne $tokens -and $null -ne (Get-ObjectPropertyValue $tokens "rowGap")) { [double](Get-ObjectPropertyValue $tokens "rowGap") } else { 16.0 }
        $protectedShapeIndexes = @{}
        foreach ($region in $planProtectedRegions) {
            $regionId = [string](Get-ObjectPropertyValue $region "id")
            if ($regionId -match 'shape:(\d+)$') {
                $regionGapValue = Get-ObjectPropertyValue $region "minGap"
                $protectedShapeIndexes[[int]$matches[1]] = if ($null -ne $regionGapValue) { [double]$regionGapValue } else { $minimumProtectedGap }
            }
        }
        $obstacleRequiredTop = $null
        for ($shapeIndex = 1; $shapeIndex -le [int]$slide.Shapes.Count; $shapeIndex++) {
            $shape = $slide.Shapes.Item($shapeIndex)
            if ($targetShapeNames -contains [string]$shape.Name) { continue }
            $shapeBottom = [double]$shape.Top + [double]$shape.Height
            $shapeRight = [double]$shape.Left + [double]$shape.Width
            if ($shapeBottom -gt ([double]$rowSpecs[0].desiredTop + 15)) { continue }
            if ($shapeRight -le $safeLeft -or [double]$shape.Left -ge $safeRight) { continue }
            $shapeGap = if ($protectedShapeIndexes.ContainsKey($shapeIndex)) { [double]$protectedShapeIndexes[$shapeIndex] } else { $leadingGap }
            $requiredTop = $shapeBottom + $shapeGap
            if ($null -eq $obstacleRequiredTop -or $requiredTop -gt [double]$obstacleRequiredTop) { $obstacleRequiredTop = $requiredTop }
        }
        if (-not $contentFitOnly -and $null -ne $obstacleRequiredTop) { $firstTop = [Math]::Max($firstTop, [double]$obstacleRequiredTop) }

        $spanHeight = $safeBottom - $firstTop
        $preferredGapTotal = 0.0
        $minimumGapTotal = 0.0
        for ($i = 0; $i -lt ($rowSpecs.Count - 1); $i++) {
            $preferredGapTotal += [double]$rowSpecs[$i].preferredRowGap
            $minimumGapTotal += [double]$rowSpecs[$i].minimumRowGap
        }
        $minimumTotal = ($rowSpecs | ForEach-Object { [double]$_.minimumHeight } | Measure-Object -Sum).Sum
        $desiredTotal = ($rowSpecs | ForEach-Object { [double]$_.desiredHeight } | Measure-Object -Sum).Sum
        $layoutBudget = @{
            availableSpan = [Math]::Round($spanHeight, 2)
            desiredComponentHeightTotal = [Math]::Round($desiredTotal, 2)
            minimumComponentHeightTotal = [Math]::Round($minimumTotal, 2)
            preferredGapTotal = [Math]::Round($preferredGapTotal, 2)
            minimumGapTotal = [Math]::Round($minimumGapTotal, 2)
            minimumRequiredSpan = [Math]::Round($minimumTotal + $minimumGapTotal, 2)
            shortage = [Math]::Round([Math]::Max(0, ($minimumTotal + $minimumGapTotal) - $spanHeight), 2)
            componentMinimumHeights = @($rowSpecs | ForEach-Object { @{ rowId = [string](Get-ObjectPropertyValue $_.row "rowId"); componentIds = $_.memberIds; minimumHeight = [Math]::Round([double]$_.minimumHeight, 2); contentMinimumHeight = [Math]::Round([double]$_.contentMinimumHeight, 2); desiredHeight = [Math]::Round([double]$_.desiredHeight, 2) } })
        }
        if ($spanHeight -lt (($minimumTotal + $minimumGapTotal) - 0.01)) {
            $issues += @{ issueType = "layout_dry_run_infeasible"; severity = "error"; componentIds = @($rowSpecs | ForEach-Object { $_.memberIds }); metrics = @{ firstTop = $firstTop; availableHeight = $spanHeight; minimumHeight = $minimumTotal; preferredGapTotal = $preferredGapTotal; minimumGapTotal = $minimumGapTotal; safeBottom = $safeBottom; footerTop = $footerTop }; message = "Peer rows cannot fit between the preceding module and the real footer safe boundary at readable minimum heights and minimum gaps." }
        } else {
            $gapBudget = [Math]::Min($preferredGapTotal, [Math]::Max($minimumGapTotal, $spanHeight - $minimumTotal))
            $gapFlexTotal = [Math]::Max(0, $preferredGapTotal - $minimumGapTotal)
            for ($i = 0; $i -lt ($rowSpecs.Count - 1); $i++) {
                $resolvedGap = [double]$rowSpecs[$i].minimumRowGap
                if ($gapFlexTotal -gt 0) {
                    $ownGapFlex = [Math]::Max(0, [double]$rowSpecs[$i].preferredRowGap - [double]$rowSpecs[$i].minimumRowGap)
                    $resolvedGap += ([Math]::Max(0, $gapBudget - $minimumGapTotal) * $ownGapFlex / $gapFlexTotal)
                }
                $rowSpecs[$i].resolvedRowGap = [Math]::Floor($resolvedGap * 2) / 2
            }
            $resolvedGapTotal = 0.0
            for ($i = 0; $i -lt ($rowSpecs.Count - 1); $i++) { $resolvedGapTotal += [double]$rowSpecs[$i].resolvedRowGap }
            $availableHeight = $spanHeight - $resolvedGapTotal
            $extraAvailable = [Math]::Max(0, $availableHeight - $minimumTotal)
            $desiredExtra = [Math]::Max(0, $desiredTotal - $minimumTotal)
            $cursorTop = $firstTop
            foreach ($spec in $rowSpecs) {
                $height = [double]$spec.desiredHeight
                if ($desiredTotal -gt $availableHeight -and $desiredExtra -gt 0) {
                    $ownExtra = [Math]::Max(0, [double]$spec.desiredHeight - [double]$spec.minimumHeight)
                    $height = [double]$spec.minimumHeight + ($extraAvailable * $ownExtra / $desiredExtra)
                }
                $protectedTop = $cursorTop
                foreach ($region in $(if ($contentFitOnly) { @() } else { $planProtectedRegions })) {
                    $kind = [string](Get-ObjectPropertyValue $region "kind")
                    if ($kind -eq 'footer') { continue }
                    $regionBounds = Get-ObjectPropertyValue $region "bounds"
                    if ($null -eq $regionBounds) { continue }
                    $regionLeft = Get-PptBoundsNumber $regionBounds "left"
                    $regionTop = Get-PptBoundsNumber $regionBounds "top"
                    $regionWidth = Get-PptBoundsNumber $regionBounds "width"
                    $regionHeight = Get-PptBoundsNumber $regionBounds "height"
                    if ($regionWidth -le 0 -or $regionHeight -le 0) { continue }
                    $regionRight = $regionLeft + $regionWidth
                    $regionBottom = $regionTop + $regionHeight
                    $regionGapValue = Get-ObjectPropertyValue $region "minGap"
                    $regionGap = if ($null -ne $regionGapValue) { [double]$regionGapValue } else { $minimumProtectedGap }
                    for ($i = 0; $i -lt $spec.members.Count; $i++) {
                        $candidateLeft = [double]$spec.targetRects[$i].left
                        $candidateRight = $candidateLeft + [double]$spec.targetRects[$i].width
                        if ($candidateRight -le $regionLeft -or $candidateLeft -ge $regionRight) { continue }
                        $candidateBottom = $protectedTop + $height
                        $conflictsVertically = $candidateBottom -gt ($regionTop - $regionGap) -and $protectedTop -lt ($regionBottom + $regionGap)
                        if (-not $conflictsVertically) { continue }
                        $candidateCenter = $protectedTop + ($height / 2)
                        $regionCenter = $regionTop + ($regionHeight / 2)
                        if ($candidateCenter -lt $regionCenter -and $candidateBottom -le $regionTop) { continue }
                        $protectedTop = [Math]::Max($protectedTop, $regionBottom + $regionGap)
                    }
                }
                $cursorTop = $protectedTop
                if (($cursorTop + $height) -gt ($safeBottom + 0.01)) {
                    $issues += @{ issueType = "layout_dry_run_infeasible"; severity = "error"; componentIds = $spec.memberIds; rowId = [string](Get-ObjectPropertyValue $spec.row "rowId"); metrics = @{ requiredBottom = $cursorTop + $height; safeBottom = $safeBottom }; message = "Protected-region reflow cannot fit this row above the footer boundary." }
                }
                $declaredRoleTypography = Get-ObjectPropertyValue $spec.row "roleTypography"
                $peerRoleTypography = $declaredRoleTypography
                if ($null -eq $peerRoleTypography -and $spec.members.Count -gt 1) {
                    # Peer components share one internal text skeleton. Derive
                    # the title slot from the longest rendered peer title so a
                    # wrapped title cannot push only its own body downward.
                    $sharedPrimaryHeight = 16.0
                    for ($peerIndex = 0; $peerIndex -lt $spec.members.Count; $peerIndex++) {
                        $peerShellToken = Resolve-PptGridShellToken $spec.members[$peerIndex] ([string]$spec.shellToken)
                        $peerIsStepCard = ([string]$peerShellToken).ToLowerInvariant() -match 'persona|route|timeline|process'
                        $peerPadding = [Math]::Max(4.0, [Math]::Min($padding, [Math]::Min(12.0, [double]$height * 0.14)))
                        $peerIndexLane = if ($peerIsStepCard) { [Math]::Max(24.0, [Math]::Min(34.0, [double]$height - (2 * $peerPadding))) + 12.0 } else { 0.0 }
                        $peerTextWidth = [Math]::Max(24.0, [double]$spec.targetRects[$peerIndex].width - $peerIndexLane - (2 * $peerPadding))
                        foreach ($peerPart in @($spec.members[$peerIndex].parts)) {
                            if ((Get-PptGridTextRole ([string]$peerPart.descriptor.part)) -ne 'primary') { continue }
                            $peerShape = $peerPart.shape
                            $peerEstimate = Get-PptEstimatedTextHeight $peerShape $peerTextWidth 13.0
                            $peerRendered = Get-PptGridRenderedTextHeight $peerShape $peerTextWidth 12.0 $false
                            $sharedPrimaryHeight = [Math]::Max($sharedPrimaryHeight, [Math]::Max($peerEstimate, $peerRendered + 2.0))
                        }
                    }
                    $peerRoleTypography = @{
                        primary = 13.0
                        primaryHeight = [Math]::Ceiling($sharedPrimaryHeight * 2.0) / 2.0
                        secondary = 9.0
                        body = 9.0
                        bodyColor = [string]$visual.text
                    }
                }
                for ($i = 0; $i -lt $spec.members.Count; $i++) {
                    $effectiveShellToken = Resolve-PptGridShellToken $spec.members[$i] ([string]$spec.shellToken)
                    $currentBackground = $spec.members[$i].background
                    $resolvedLeft = if ($internalOnly) { [double]$currentBackground.Left } else { [double]$spec.targetRects[$i].left }
                    $resolvedTop = if ($internalOnly) { [double]$currentBackground.Top } else { $cursorTop }
                    $resolvedWidth = if ($externalOnly -or $internalOnly -or -not $allowWidthResize) { [double]$currentBackground.Width } else { [double]$spec.targetRects[$i].width }
                    $resolvedHeight = if ($externalOnly -or $internalOnly -or -not $allowHeightResize) { [double]$currentBackground.Height } else { $height }
                    $targets += @{ group = $spec.members[$i]; left = $resolvedLeft; top = $resolvedTop; width = $resolvedWidth; height = $resolvedHeight; shellToken = $effectiveShellToken; decorationToken = [string](Get-ObjectPropertyValue $spec.row "decorationToken"); roleTypography = $peerRoleTypography; rowId = [string](Get-ObjectPropertyValue $spec.row "rowId") }
                }
                $cursorTop += $height + [double]$spec.resolvedRowGap
            }
        }
    }
    if ($componentSizeIntent -eq "shrink" -or $componentSizeIntent -eq "grow") {
        foreach ($target in $targets) {
            $currentWidth = [double]$target.group.background.Width
            $currentHeight = [double]$target.group.background.Height
            foreach ($axis in $sizeAxes) {
                if ($axis -eq "auto") {
                    $plannedWidth = [double]$target.width
                    $plannedHeight = [double]$target.height
                    $beforeArea = $currentWidth * $currentHeight
                    $plannedArea = $plannedWidth * $plannedHeight
                    $invalidAuto = if ($componentSizeIntent -eq "shrink") {
                        $plannedWidth -gt ($currentWidth + 0.25) -or
                        $plannedHeight -gt ($currentHeight + 0.25) -or
                        $plannedArea -ge ($beforeArea - 0.25)
                    } else {
                        $plannedWidth -lt ($currentWidth - 0.25) -or
                        $plannedHeight -lt ($currentHeight - 0.25) -or
                        $plannedArea -le ($beforeArea + 0.25)
                    }
                    if ($invalidAuto) {
                        $issues += @{
                            issueType = "component_size_intent_infeasible"
                            severity = "error"
                            componentId = [string]$target.group.componentId
                            metrics = @{
                                intent = $componentSizeIntent
                                axis = "auto"
                                before = @{ width = [Math]::Round($currentWidth, 2); height = [Math]::Round($currentHeight, 2); area = [Math]::Round($beforeArea, 2) }
                                planned = @{ width = [Math]::Round($plannedWidth, 2); height = [Math]::Round($plannedHeight, 2); area = [Math]::Round($plannedArea, 2) }
                            }
                            message = "The deterministic layout solution did not change every target component in the requested area direction."
                        }
                    }
                    continue
                }
                $before = if ($axis -eq "width") { $currentWidth } else { $currentHeight }
                $after = if ($axis -eq "width") { [double]$target.width } else { [double]$target.height }
                $oppositeDirection = ($componentSizeIntent -eq "shrink" -and $after -gt ($before + 0.25)) -or
                    ($componentSizeIntent -eq "grow" -and $after -lt ($before - 0.25))
                if ($oppositeDirection) {
                    $issues += @{
                        issueType = "component_size_intent_infeasible"
                        severity = "error"
                        componentId = [string]$target.group.componentId
                        metrics = @{ intent = $componentSizeIntent; axis = $axis; before = [Math]::Round($before, 2); planned = [Math]::Round($after, 2) }
                        message = "The deterministic layout solution would move a requested size axis in the opposite direction."
                    }
                }
            }
        }
    }
    $contentDrivenSizingToken = if ($null -ne $tokens) { Get-ObjectPropertyValue $tokens "contentDrivenSizing" } else { $null }
    $allowsContentAdaptation = $componentSizeIntent -ne "preserve" -and
        $null -ne $contentDrivenSizingToken -and [bool]$contentDrivenSizingToken
    $adaptationSequence = if ($allowsContentAdaptation) {
        @("reduce_internal_padding", "shrink_to_content_minimum_height", "reduce_body_font_with_role_floor")
    } else {
        @()
    }
    $fallbackSequence = @($adaptationSequence) + @("report_infeasible_without_topology_change")
    $dryRun = @{ ok = ($issues.Count -eq 0); slideIndex = $slideIndex; layoutAspect = $layoutAspect; componentSizeIntent = $componentSizeIntent; sizeAxes = $sizeAxes; safeArea = @{ left = $safeLeft; right = $safeRight; top = $safeTop; bottom = $safeBottom; declaredBottom = $(if ($null -ne $safeArea) { Get-ObjectPropertyValue $safeArea "bottom" } else { $null }); footerTop = $footerTop; preferredProtectedGap = $preferredProtectedGap; minimumProtectedGap = $minimumProtectedGap; footerGap = $footerGap }; gapPolicy = @{ preferred = @($rowSpecs | Select-Object -First ([Math]::Max(0, $rowSpecs.Count - 1)) | ForEach-Object { [double]$_.preferredRowGap }); minimum = @($rowSpecs | Select-Object -First ([Math]::Max(0, $rowSpecs.Count - 1)) | ForEach-Object { [double]$_.minimumRowGap }); resolved = @($rowSpecs | Select-Object -First ([Math]::Max(0, $rowSpecs.Count - 1)) | ForEach-Object { [double]$_.resolvedRowGap }) }; layoutBudget = $layoutBudget; fallbackSequence = $fallbackSequence; targetCount = $targets.Count; issues = $issues }
    $layoutShortage = if ($null -ne $layoutBudget -and $null -ne (Get-ObjectPropertyValue $layoutBudget "shortage")) { [double](Get-ObjectPropertyValue $layoutBudget "shortage") } else { 0.0 }
    $adaptationsExhausted = $issues.Count -gt 0 -and $layoutShortage -gt 0.25
    $feasibility = @{
        version = "1.0"
        feasible = ($issues.Count -eq 0)
        slideIndex = $slideIndex
        source = "live_bound_height"
        availableSpan = $(if ($null -ne $layoutBudget) { Get-ObjectPropertyValue $layoutBudget "availableSpan" } else { $null })
        minimumRequiredSpan = $(if ($null -ne $layoutBudget) { Get-ObjectPropertyValue $layoutBudget "minimumRequiredSpan" } else { $null })
        shortage = $(if ($null -ne $layoutBudget) { Get-ObjectPropertyValue $layoutBudget "shortage" } else { $null })
        adaptationsExhausted = $adaptationsExhausted
        exhaustedAdaptations = $(if ($adaptationsExhausted) { $adaptationSequence } else { @() })
        remainingAllowedAdaptations = $(if ($adaptationsExhausted) { @() } else { $adaptationSequence })
        blockingConstraints = $issues
        layoutBudget = $layoutBudget
    }
    $dryRun.feasibility = $feasibility
    $dryRunOnlyValue = Get-ObjectPropertyValue $options "dryRunOnly"
    if ($null -ne $dryRunOnlyValue -and [bool]$dryRunOnlyValue) {
        Restore-PptShapeSnapshots $slide $snapshots
        return @{ success = ($issues.Count -eq 0); error = $(if ($issues.Count -gt 0) { "layout dry-run failed" } else { $null }); data = @{ partialMutation = $false; transactional = $true; rolledBack = $true; dryRunOnly = $true; dryRun = $dryRun; feasibility = $feasibility; preOperations = $preOperationResult; targets = @($targets | ForEach-Object { @{ componentId = $_.group.componentId; rowId = $_.rowId; left = [Math]::Round($_.left, 2); top = [Math]::Round($_.top, 2); width = [Math]::Round($_.width, 2); height = [Math]::Round($_.height, 2) } }) } }
    }
    if ($issues.Count -gt 0) {
        Restore-PptShapeSnapshots $slide $snapshots
        return @{ success = $false; error = "normalizePptComponentGrid dry-run failed; all pre-operations were rolled back"; data = @{ partialMutation = $false; transactional = $true; rolledBack = $true; wroteToWps = $false; dryRun = $dryRun; feasibility = $feasibility; preOperations = $preOperationResult } }
    }

    $changed = @($preOperationResult.changed)
    $changedObjectIds = @()
    $postIssues = @()
    try {
        foreach ($target in $targets) {
            $group = $target.group
            $internalLayoutMode = Resolve-PptGridInternalLayoutMode $group
            $background = $group.background
            $oldLeft = [double]$background.Left
            $oldTop = [double]$background.Top
            $oldWidth = [double]$background.Width
            $oldHeight = [double]$background.Height
            $scaleX = if ($oldWidth -gt 0) { [double]$target.width / $oldWidth } else { 1 }
            $scaleY = if ($oldHeight -gt 0) { [double]$target.height / $oldHeight } else { 1 }
            $translated = $false
            if ($externalOnly) {
                $deltaX = [double]$target.left - $oldLeft
                $deltaY = [double]$target.top - $oldTop
                foreach ($part in @($group.parts)) {
                    $shape = $part.shape
                    if ([Math]::Abs($deltaX) -gt 0.01) { $shape.Left = [single]([double]$shape.Left + $deltaX) }
                    if ([Math]::Abs($deltaY) -gt 0.01) { $shape.Top = [single]([double]$shape.Top + $deltaY) }
                    if ([Math]::Abs($deltaX) -gt 0.01 -or [Math]::Abs($deltaY) -gt 0.01) {
                        $translated = $true
                        try {
                            $nativeId = [int]$shape.Id
                            if ($changedObjectIds -notcontains $nativeId) { $changedObjectIds += $nativeId }
                        } catch {}
                    }
                }
            }
            $shellOnly = -not [string]::IsNullOrWhiteSpace([string]$target.shellToken)
            if ($externalOnly) {
                # External spacing/alignment owns only rigid translation.
                # Width, height, internal offsets, text, typography, and style
                # remain byte-for-byte/point-for-point under the snapshot.
            } elseif ($internalOnly) {
                # Internal repair retains the component envelope and delegates
                # only to the topology-aware internal solver below.
            } elseif ($shellOnly) {
                foreach ($part in @($group.parts)) {
                    $partName = [string]$part.descriptor.part
                    if ($part.shape -eq $background -or $partName -match 'accent|rule|strip') { continue }
                    $hasText = $false
                    try { $hasText = [bool]$part.shape.HasTextFrame -and [bool]$part.shape.TextFrame.HasText } catch {}
                    if (-not $hasText) { $shellOnly = $false; break }
                }
            }
            if ($externalOnly) {
                # The rigid translation above is the complete external-only
                # write. Do not resize the shell or any internal part.
            } elseif ($internalOnly) {
                # Internal-only layout must keep the component envelope
                # byte-for-byte/point-for-point unchanged. The topology-aware
                # internal solver below owns only child-part geometry.
            } elseif ($shellOnly) {
                $background.Left = [double]$target.left
                $background.Top = [double]$target.top
                $background.Width = [double]$target.width
                $background.Height = [double]$target.height
            } else {
                foreach ($part in @($group.parts)) {
                    $shape = $part.shape
                    $relativeLeft = [double]$shape.Left - $oldLeft
                    $relativeTop = [double]$shape.Top - $oldTop
                    $shape.Left = [single]([double]$target.left + ($relativeLeft * $scaleX))
                    $shape.Top = [single]([double]$target.top + ($relativeTop * $scaleY))
                    $shape.Width = [single]([Math]::Max(2, [double]$shape.Width * $scaleX))
                    $shape.Height = [single]([Math]::Max(2, [double]$shape.Height * $scaleY))
                }
            }
            if (-not $externalOnly -and $internalLayoutMode -eq "repeated_items") {
                $changedObjectIds += @(Set-PptGridRepeatedItemsLayout $group $padding $minFontSize)
            } elseif (-not $externalOnly -and $internalLayoutMode -eq "atomic") {
                Set-PptGridUnifiedShell $group $visual ([string]$target.shellToken) ([string]$target.decorationToken) $padding $target.roleTypography $preserveExistingStyle
            }
            foreach ($part in @($group.parts)) {
                $shape = $part.shape
                $nativeId = $null
                try { $nativeId = [int]$shape.Id } catch {}
                if (-not $externalOnly -and $null -ne $nativeId -and $changedObjectIds -notcontains $nativeId) { $changedObjectIds += $nativeId }
                if ($externalOnly) { continue }
                $hasText = $false
                try { $hasText = [bool]$shape.HasTextFrame -and [bool]$shape.TextFrame.HasText } catch {}
                if (-not $hasText) { continue }
                $textRole = Get-PptGridTextRole ([string]$part.descriptor.part)
                $roleMinFontSize = Get-PptGridRoleMinimumFontSize $textRole $minFontSize
                try { $shape.TextFrame.WordWrap = -1; $shape.TextFrame.AutoSize = 0 } catch {}
                try { $shape.TextFrame2.WordWrap = -1; $shape.TextFrame2.AutoSize = 0 } catch {}
                $fit = Test-PptShapeTextOverflow $shape
                if ($fit.overflow) {
                    $fontSize = $null
                    try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
                    $boundHeight = [double](Get-ObjectPropertyValue $fit "boundHeight")
                    $availableHeight = [double](Get-ObjectPropertyValue $fit "availableHeight")
                    if ($null -ne $fontSize -and $fontSize -gt $roleMinFontSize -and $boundHeight -gt 0 -and $availableHeight -gt 0) {
                        $scaledFontSize = [Math]::Floor(($fontSize * $availableHeight / $boundHeight) * 2) / 2
                        Set-PptGridShapeFontSize $shape ([Math]::Max($roleMinFontSize, $scaledFontSize))
                        $fit = Test-PptShapeTextOverflow $shape
                    }
                }
                while ($fit.overflow) {
                    $fontSize = $null
                    try { $fontSize = [double]$shape.TextFrame.TextRange.Font.Size } catch {}
                    if ($null -eq $fontSize -or $fontSize -le $roleMinFontSize) { break }
                    try { Set-PptGridShapeFontSize $shape ([Math]::Max($roleMinFontSize, $fontSize - 0.5)) } catch { break }
                    $fit = Test-PptShapeTextOverflow $shape
                }
                if ($fit.overflow) { $postIssues += @{ issueType = "text_overflow"; severity = "error"; componentId = $group.componentId; shapeName = [string]$shape.Name; metrics = $fit } }
            }
            if (-not $externalOnly -or $translated) {
                $changed += @{ componentId = $group.componentId; rowId = $target.rowId; left = [Math]::Round($target.left, 2); top = [Math]::Round($target.top, 2); width = [Math]::Round($target.width, 2); height = [Math]::Round($target.height, 2); shellToken = $target.shellToken; decorationToken = $target.decorationToken; layoutAspect = $layoutAspect; internalGeometryPreserved = $externalOnly }
            }
        }
        foreach ($target in $targets) {
            $group = $target.group
            $background = $group.background
            $backgroundLeft = [double]$background.Left
            $backgroundTop = [double]$background.Top
            $backgroundRight = $backgroundLeft + [double]$background.Width
            $backgroundBottom = $backgroundTop + [double]$background.Height
            foreach ($region in $planProtectedRegions) {
                $regionBounds = Get-ObjectPropertyValue $region "bounds"
                if ($null -eq $regionBounds) { continue }
                $regionLeft = Get-PptBoundsNumber $regionBounds "left"
                $regionTop = Get-PptBoundsNumber $regionBounds "top"
                $regionRight = $regionLeft + (Get-PptBoundsNumber $regionBounds "width")
                $regionBottom = $regionTop + (Get-PptBoundsNumber $regionBounds "height")
                $xOverlap = [Math]::Max(0, [Math]::Min($backgroundRight, $regionRight) - [Math]::Max($backgroundLeft, $regionLeft))
                $yOverlap = [Math]::Max(0, [Math]::Min($backgroundBottom, $regionBottom) - [Math]::Max($backgroundTop, $regionTop))
                if ($xOverlap -gt 0 -and $yOverlap -gt 0) {
                    $postIssues += @{ issueType = "protected_region_overlap"; severity = "error"; componentId = $group.componentId; protectedRegionId = [string](Get-ObjectPropertyValue $region "id"); protectedKind = [string](Get-ObjectPropertyValue $region "kind"); metrics = @{ horizontalOverlap = $xOverlap; verticalOverlap = $yOverlap; overlapArea = $xOverlap * $yOverlap }; message = "Component overlaps an explicit protected region." }
                    continue
                }
                $regionGapValue = Get-ObjectPropertyValue $region "minGap"
                $regionGap = if ($null -ne $regionGapValue) { [double]$regionGapValue } else { $minimumProtectedGap }
                $axisGap = [double]::PositiveInfinity
                if ($xOverlap -gt 0) { $axisGap = [Math]::Max(0, [Math]::Max($regionTop - $backgroundBottom, $backgroundTop - $regionBottom)) }
                elseif ($yOverlap -gt 0) { $axisGap = [Math]::Max(0, [Math]::Max($regionLeft - $backgroundRight, $backgroundLeft - $regionRight)) }
                if (-not [double]::IsPositiveInfinity($axisGap) -and $axisGap -lt ($regionGap - 0.25)) {
                    $postIssues += @{ issueType = "protected_region_gap_too_small"; severity = "error"; componentId = $group.componentId; protectedRegionId = [string](Get-ObjectPropertyValue $region "id"); protectedKind = [string](Get-ObjectPropertyValue $region "kind"); metrics = @{ actualGap = $axisGap; requiredGap = $regionGap }; message = "Component is too close to an explicit protected region." }
                }
            }
            foreach ($part in @($group.parts)) {
                $shape = $part.shape
                if ([double]$shape.Left -lt ($safeLeft - 2) -or [double]$shape.Top -lt ($safeTop - 2) -or ([double]$shape.Left + [double]$shape.Width) -gt ($safeRight + 2) -or ([double]$shape.Top + [double]$shape.Height) -gt ($safeBottom + 2)) {
                    $postIssues += @{ issueType = "protected_region_gap_too_small"; severity = "error"; componentId = $group.componentId; shapeName = [string]$shape.Name }
                }
                $partName = [string]$part.descriptor.part
                if ($partName -match '(^|_)(bg|band|background)($|_)') { continue }
                $partRight = [double]$shape.Left + [double]$shape.Width
                $partBottom = [double]$shape.Top + [double]$shape.Height
                if ([double]$shape.Left -lt ($backgroundLeft - 2) -or [double]$shape.Top -lt ($backgroundTop - 2) -or $partRight -gt ($backgroundRight + 2) -or $partBottom -gt ($backgroundBottom + 2)) {
                    $postIssues += @{ issueType = "component_internal_layout_inconsistent"; severity = "error"; componentId = $group.componentId; shapeName = [string]$shape.Name; metrics = @{ part = $partName; partBounds = @{ left = [double]$shape.Left; top = [double]$shape.Top; right = $partRight; bottom = $partBottom }; backgroundBounds = @{ left = $backgroundLeft; top = $backgroundTop; right = $backgroundRight; bottom = $backgroundBottom } }; message = "Component part extends outside its own background." }
                }
            }
            if ((Resolve-PptGridInternalLayoutMode $group) -eq "repeated_items") {
                foreach ($role in @("title", "body")) {
                    $roleParts = @($group.parts | Where-Object {
                        $descriptor = Get-PptRepeatedItemPartDescriptor ([string]$_.descriptor.part)
                        $null -ne $descriptor -and [string]$descriptor.role -eq $role
                    })
                    for ($leftIndex = 0; $leftIndex -lt $roleParts.Count; $leftIndex++) {
                        for ($rightIndex = $leftIndex + 1; $rightIndex -lt $roleParts.Count; $rightIndex++) {
                            $leftShape = $roleParts[$leftIndex].shape
                            $rightShape = $roleParts[$rightIndex].shape
                            $overlapArea = Get-PptRectOverlapArea ([double]$leftShape.Left) ([double]$leftShape.Top) ([double]$leftShape.Width) ([double]$leftShape.Height) ([double]$rightShape.Left) ([double]$rightShape.Top) ([double]$rightShape.Width) ([double]$rightShape.Height)
                            if ($overlapArea -gt 0.01) {
                                $postIssues += @{ issueType = "component_internal_layout_inconsistent"; severity = "error"; componentId = $group.componentId; shapeName = [string]$leftShape.Name; otherShapeName = [string]$rightShape.Name; metrics = @{ role = $role; overlapArea = [Math]::Round($overlapArea, 2) }; message = "Repeated item text boxes overlap each other." }
                            }
                        }
                    }
                }
            }
        }
    } catch {
        $postIssues += @{ issueType = "mutation_exception"; severity = "error"; message = $_.Exception.Message; position = $_.InvocationInfo.PositionMessage; scriptStackTrace = $_.ScriptStackTrace }
    }
    for ($i = 0; $i -lt $targets.Count; $i++) {
        $leftGroup = $targets[$i].group
        $leftBackground = $leftGroup.background
        for ($j = $i + 1; $j -lt $targets.Count; $j++) {
            $rightGroup = $targets[$j].group
            $rightBackground = $rightGroup.background
            $overlapArea = Get-PptRectOverlapArea ([double]$leftBackground.Left) ([double]$leftBackground.Top) ([double]$leftBackground.Width) ([double]$leftBackground.Height) ([double]$rightBackground.Left) ([double]$rightBackground.Top) ([double]$rightBackground.Width) ([double]$rightBackground.Height)
            if ($overlapArea -gt 0.01) {
                $postIssues += @{ issueType = "overlap"; severity = "error"; componentId = $leftGroup.componentId; otherComponentId = $rightGroup.componentId; metrics = @{ overlapArea = [Math]::Round($overlapArea, 2) }; message = "Target component backgrounds overlap after normalization." }
            }
        }
    }
    $errorCount = @($postIssues | Where-Object { [string]$_.severity -eq 'error' }).Count
    $warningCount = @($postIssues | Where-Object { [string]$_.severity -eq 'warning' }).Count
    $verification = @{
        compact = $true
        scope = "mutation_targets"
        slideIndex = $slideIndex
        ok = ($errorCount -eq 0 -and $warningCount -eq 0)
        issueCount = $postIssues.Count
        errorCount = $errorCount
        warningCount = $warningCount
        issues = $postIssues
    }
    $rolledBack = $postIssues.Count -gt 0
    $rollbackVerification = @{ ok = $true; issues = @(); issueCount = 0 }
    if ($rolledBack) {
        Restore-PptShapeSnapshots $slide $snapshots
        $rollbackVerification = Test-PptShapeSnapshotsRestored $slide $snapshots
    }
    $postWriteReadback = $null
    $postWriteReadbackTargets = @((Get-ObjectPropertyValue $options "postWriteReadbackTargets"))
    if (-not $rolledBack -and $postWriteReadbackTargets.Count -gt 0) {
        try {
            $postWriteReadback = Get-PptSceneTargetsReadbackData `
                $pres `
                $slide `
                ([int]$slideIndex) `
                $postWriteReadbackTargets `
                $false
        } catch {
            $postWriteReadback = @{
                success = $false
                error = "Embedded post-write readback failed: $($_.Exception.Message)"
            }
        }
    }
    $responseData = @{
        partialMutation = ($rolledBack -and -not [bool]$rollbackVerification.ok)
        transactional = $true
        rolledBack = $rolledBack
        rollbackVerified = [bool]$rollbackVerification.ok
        rollbackVerification = $rollbackVerification
        wroteToWps = (-not $rolledBack -and $changed.Count -gt 0)
        operationId = [string](Get-ObjectPropertyValue $options "operationId")
        compiledPlanFingerprint = [string](Get-ObjectPropertyValue $options "compiledPlanFingerprint")
        slideIndex = $slideIndex
        layoutAspect = $layoutAspect
        internalGeometryPreserved = $externalOnly
        visibleTextPreserved = $externalOnly
        stylesPreserved = $externalOnly
        dryRun = $dryRun
        changed = $(if ($rolledBack) { @() } else { $changed })
        changedObjectIds = $(if ($rolledBack) { @() } else { @($changedObjectIds | Select-Object -Unique) })
        postCheck = @{ ok = (-not $rolledBack); issues = $postIssues; issueCount = $postIssues.Count }
        verification = $verification
    }
    if ($null -ne $postWriteReadback) {
        $responseData["postWriteReadback"] = $postWriteReadback
    }
    return @{
        success = (-not $rolledBack)
        error = $(if ($rolledBack) { "normalizePptComponentGrid failed post-check and was rolled back" } else { $null })
        data = $responseData
    }
}

function Get-RangeFromAddress($workbook, [string]$address) {
    if ($address -match "^(?<sheet>[^!]+)!(?<range>.+)$") {
        $sheetName = $matches.sheet.Trim("'")
        return $workbook.Sheets.Item($sheetName).Range($matches.range)
    }
    return $workbook.ActiveSheet.Range($address)
}

function Get-AppTypeByExtension([string]$filePath) {
    $ext = [System.IO.Path]::GetExtension($filePath).ToLower().Trim('.')
    $wordExts = @('doc', 'docx', 'docm', 'dot', 'dotx', 'dotm', 'rtf', 'txt', 'html', 'htm', 'xml', 'wps', 'wpt')
    $excelExts = @('xls', 'xlsx', 'xlsm', 'xlsb', 'xlt', 'xltx', 'xltm', 'csv', 'html', 'htm', 'et', 'ett')
    $pptExts = @('ppt', 'pptx', 'pptm', 'pot', 'potx', 'potm', 'pps', 'ppsx', 'ppsm', 'dps', 'dpt')
    if ($wordExts -contains $ext) { return 'word' }
    if ($excelExts -contains $ext) { return 'excel' }
    if ($pptExts -contains $ext) { return 'ppt' }
    return $null
}

function Get-WordSaveFormat([string]$format) {
    if (-not $format) { return $null }
    $f = $format.ToLower().Trim('.')
    # Word WdSaveFormat: doc=0, docx=16, pdf=17, rtf=6, xps=18, html=8, txt=2, xml=11
    $map = @{ doc = 0; docx = 16; pdf = 17; rtf = 6; xps = 18; html = 8; htm = 8; txt = 2; xml = 11 }
    return $map[$f]
}

function Get-ExcelFileFormat([string]$format) {
    if (-not $format) { return $null }
    $f = $format.ToLower().Trim('.')
    # Excel XlFileFormat: xls=-4143, xlsx=51, xlsm=52, xlsb=50, csv=6, html=44, xlt=17, xltx=54, xltm=53
    $map = @{ xls = -4143; xlsx = 51; xlsm = 52; xlsb = 50; csv = 6; html = 44; htm = 44; xlt = 17; xltx = 54; xltm = 53 }
    return $map[$f]
}

function Get-PptSaveFormat([string]$format) {
    if (-not $format) { return $null }
    $f = $format.ToLower().Trim('.')
    # PowerPoint PpSaveAsFileType: ppt=1, pptx=24, pptm=25, pdf=32, png=18, jpg=17, gif=16, bmp=19
    $map = @{ ppt = 1; pptx = 24; pptm = 25; pdf = 32; png = 18; jpg = 17; jpeg = 17; gif = 16; bmp = 19 }
    return $map[$f]
}

function Get-PptSceneTargetsReadbackData(
    $pres,
    $slide,
    [int]$slideIndex,
    $targets,
    [bool]$includeRollbackSnapshot,
    $diagnostics = $null
) {
    $readbackTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $objects = @()
    $resolvedTargets = @()
    $targetResolveTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $targetResolveBreakdown = @{
        resolveShape = 0
        protection = 0
        unifiedObject = 0
        projection = 0
    }
    $protection = $null
    $objectKeys = @{}
    foreach ($target in @($targets)) {
        $targetPhaseTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $resolvedShape = Resolve-PptShape $slide $target "readPptSceneTargets"
        $targetResolveBreakdown.resolveShape += $targetPhaseTimer.ElapsedMilliseconds
        if (-not $resolvedShape.ok) {
            return @{
                success = $false
                error = [string]$resolvedShape.result.error
                data = $resolvedShape.result.data
            }
        }
        $groupPath = @(
            (Get-ObjectPropertyValue $resolvedShape "groupPath") |
                Where-Object { $null -ne $_ }
        )
        $objectShape = $resolvedShape.shape
        $objectShapeIndex = $resolvedShape.shapeIndex
        if ($groupPath.Count -gt 1) {
            $objectShapeIndex = [int]$groupPath[0]
            $objectShape = $slide.Shapes.Item($objectShapeIndex)
        }
        $objectKey = "shapeIndex:$objectShapeIndex"
        if (-not $objectKeys.ContainsKey($objectKey)) {
            if ($null -eq $protection) {
                $targetPhaseTimer.Restart()
                $protection = Get-PptPresentationProtectionState $pres
                $targetResolveBreakdown.protection += $targetPhaseTimer.ElapsedMilliseconds
            }
            $targetPhaseTimer.Restart()
            $objects += Get-PptUnifiedObject `
                $objectShape `
                $slideIndex `
                $objectShapeIndex `
                $true `
                ([bool]$protection.readOnly) `
                ([bool]$protection.protectMode)
            $targetResolveBreakdown.unifiedObject += $targetPhaseTimer.ElapsedMilliseconds
            $objectKeys[$objectKey] = $true
        }
        $targetPhaseTimer.Restart()
        $resolvedTargets += @{
            nativeShapeId = $resolvedShape.nativeShapeId
            expectedShapeName = [string]$resolvedShape.shape.Name
            shapeIndex = $resolvedShape.shapeIndex
            groupPath = $groupPath
        }
        $targetResolveBreakdown.projection += $targetPhaseTimer.ElapsedMilliseconds
    }
    if ($null -ne $diagnostics) {
        $diagnostics.targetResolve = $targetResolveTimer.ElapsedMilliseconds
        $diagnostics.targetResolveBreakdown = $targetResolveBreakdown
    }

    $durableRefsTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $durableShapeRefs = @()
    for ($index = 1; $index -le $slide.Shapes.Count; $index++) {
        $shape = $slide.Shapes.Item($index)
        $durableShapeRefs += @{
            nativeShapeId = $(try { [int]$shape.Id } catch { $null })
            expectedShapeName = [string]$shape.Name
        }
    }
    if ($null -ne $diagnostics) {
        $diagnostics.durableShapeRefs = $durableRefsTimer.ElapsedMilliseconds
    }

    $rollbackSnapshot = $null
    $rollbackTimer = [System.Diagnostics.Stopwatch]::StartNew()
    if ($includeRollbackSnapshot) {
        $rollbackSnapshot = Get-PptMutationRollbackSnapshot $pres @($slideIndex) @(@{
            slideIndex = $slideIndex
            nativeShapeIds = @($resolvedTargets | Where-Object { @($_.groupPath).Count -eq 0 } | ForEach-Object { $_.nativeShapeId })
            shapeIndexes = @()
            shapeNames = @()
            componentIds = @()
            groupPaths = @($resolvedTargets | Where-Object { @($_.groupPath).Count -gt 1 } | ForEach-Object { ,@($_.groupPath) })
        })
    }
    if ($null -ne $diagnostics) {
        $diagnostics.rollbackSnapshot = $rollbackTimer.ElapsedMilliseconds
    }

    $metadataTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $slideWidth = $null
    $slideHeight = $null
    try { $slideWidth = [double]$pres.PageSetup.SlideWidth } catch {}
    try { $slideHeight = [double]$pres.PageSetup.SlideHeight } catch {}
    if ($null -ne $diagnostics) {
        $diagnostics.metadata = $metadataTimer.ElapsedMilliseconds
        $diagnostics.total = $readbackTimer.ElapsedMilliseconds
    }
    $summaryFingerprint = [string](Get-PptSlideSummaryResult $slide $slideIndex).fingerprint
    return @{
        success = $true
        data = @{
            presentation = @{
                name = [string]$pres.Name
                path = $(try { [string]$pres.FullName } catch { "" })
            }
            slide = @{
                slideIndex = $slideIndex
                nativeSlideId = $(try { [int]$slide.SlideID } catch { $slideIndex })
                width = $slideWidth
                height = $slideHeight
                objectCount = [int]$slide.Shapes.Count
                fingerprint = $summaryFingerprint
            }
            objects = @($objects)
            resolvedTargets = @($resolvedTargets)
            durableShapeRefs = @($durableShapeRefs)
            rollbackSnapshot = $rollbackSnapshot
        }
    }
}

function Resolve-PptCreationPlanSlide($pres, $parent, $createdSlidesByClientRef, [string]$actionName) {
    $parentKind = [string](Get-ObjectPropertyValue $parent "kind")
    if ($parentKind -eq "created_slide") {
        $clientRef = [string](Get-ObjectPropertyValue $parent "clientRef")
        if ([string]::IsNullOrWhiteSpace($clientRef) -or -not $createdSlidesByClientRef.ContainsKey($clientRef)) {
            throw "$actionName parent created slide is unavailable: $clientRef"
        }
        $nativeSlideId = [int]$createdSlidesByClientRef[$clientRef]
        $resolved = Resolve-PptSlideBinding $pres $null $nativeSlideId $actionName
        if (-not $resolved.ok) { throw $resolved.result.error }
        return $resolved
    }
    if ($parentKind -ne "existing_slide") {
        throw "$actionName requires an existing_slide or created_slide parent"
    }
    $nativeSlideId = Get-ObjectPropertyValue $parent "nativeSlideId"
    $slideIndex = Get-ObjectPropertyValue $parent "slideIndex"
    $resolved = Resolve-PptSlideBinding $pres $slideIndex $nativeSlideId $actionName
    if (-not $resolved.ok) { throw $resolved.result.error }
    return $resolved
}

function Test-PptCreationShapeKind($shape, [string]$kind) {
    $nativeTypeCode = $(try { [int]$shape.Type } catch { -1 })
    switch ($kind) {
        "text_box" { return $nativeTypeCode -eq 17 }
        "auto_shape" { return $nativeTypeCode -eq 1 }
        "picture" { return $nativeTypeCode -eq 13 }
        "graphic" { return $nativeTypeCode -eq 28 }
        "table" { return $nativeTypeCode -eq 19 -and [bool]$shape.HasTable }
        "chart" { return $nativeTypeCode -eq 3 -and $null -ne $shape.Chart }
        "connector" {
            $isConnector = $false
            try { $isConnector = [int]$shape.Connector -ne 0 } catch {}
            return $isConnector
        }
        default { return $false }
    }
}

function Add-PptSceneCreationShapeTracking($tracker, $slide, $shape) {
    if ($null -eq $tracker -or $null -eq $slide -or $null -eq $shape) {
        throw "Scene creation tracking requires slide and shape COM objects"
    }
    $tracker.createdShapes.Add(@{
        slide = $slide
        shape = $shape
        nativeSlideId = $(try { [int]$slide.SlideID } catch { $null })
        nativeShapeId = $(try { [int]$shape.Id } catch { $null })
    }) | Out-Null
}

function New-PptSceneCreationShape($slide, $action, $tracker) {
    $adapterAction = [string](Get-ObjectPropertyValue $action "adapterAction")
    $kind = [string](Get-ObjectPropertyValue $action "kind")
    $bounds = Get-ObjectPropertyValue $action "bounds"
    $facets = Get-ObjectPropertyValue $action "facets"
    $shape = $null
    switch ($adapterAction) {
        "add_text_box" {
            $shape = $slide.Shapes.AddTextbox(
                1,
                [double](Get-ObjectPropertyValue $bounds "left"),
                [double](Get-ObjectPropertyValue $bounds "top"),
                [double](Get-ObjectPropertyValue $bounds "width"),
                [double](Get-ObjectPropertyValue $bounds "height")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            $textFacet = Get-ObjectPropertyValue $facets "text"
            $shape.TextFrame.TextRange.Text = [string](Get-ObjectPropertyValue $textFacet "content")
            $textStyle = Get-ObjectPropertyValue $textFacet "style"
            if ($null -ne $textStyle) { $null = Set-PptTextFrameStyleValues $shape $textStyle }
            break
        }
        "add_shape" {
            $shapeFacet = Get-ObjectPropertyValue $facets "shape"
            $geometry = [string](Get-ObjectPropertyValue $shapeFacet "geometry")
            if ([string]::IsNullOrWhiteSpace($geometry)) { throw "add_shape requires explicit geometry" }
            $shape = $slide.Shapes.AddShape(
                (Get-PptShapeTypeValue $geometry),
                [double](Get-ObjectPropertyValue $bounds "left"),
                [double](Get-ObjectPropertyValue $bounds "top"),
                [double](Get-ObjectPropertyValue $bounds "width"),
                [double](Get-ObjectPropertyValue $bounds "height")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            $shapeStyle = Get-ObjectPropertyValue $shapeFacet "style"
            if ($null -ne $shapeStyle) { $null = Set-PptShapeStyleValues $shape $shapeStyle }
            $textFacet = Get-ObjectPropertyValue $facets "text"
            if ($null -ne $textFacet) {
                $shape.TextFrame.TextRange.Text = [string](Get-ObjectPropertyValue $textFacet "content")
                $textStyle = Get-ObjectPropertyValue $textFacet "style"
                if ($null -ne $textStyle) { $null = Set-PptTextFrameStyleValues $shape $textStyle }
            }
            break
        }
        { $_ -in @("insert_picture", "insert_graphic") } {
            $asset = Get-ObjectPropertyValue $action "asset"
            $localPath = [string](Get-ObjectPropertyValue $asset "localPath")
            if ([string]::IsNullOrWhiteSpace($localPath) -or -not (Test-Path -LiteralPath $localPath)) {
                throw "$adapterAction requires an existing trusted asset path"
            }
            $shape = $slide.Shapes.AddPicture(
                $localPath,
                $false,
                $true,
                [double](Get-ObjectPropertyValue $bounds "left"),
                [double](Get-ObjectPropertyValue $bounds "top"),
                [double](Get-ObjectPropertyValue $bounds "width"),
                [double](Get-ObjectPropertyValue $bounds "height")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            break
        }
        "create_table" {
            $tableFacet = Get-ObjectPropertyValue $facets "table"
            $rows = [int](Get-ObjectPropertyValue $tableFacet "rows")
            $columns = [int](Get-ObjectPropertyValue $tableFacet "columns")
            $shape = $slide.Shapes.AddTable(
                $rows,
                $columns,
                [double](Get-ObjectPropertyValue $bounds "left"),
                [double](Get-ObjectPropertyValue $bounds "top"),
                [double](Get-ObjectPropertyValue $bounds "width"),
                [double](Get-ObjectPropertyValue $bounds "height")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            $dataResult = Set-PptTableDataValues $shape (Get-ObjectPropertyValue $tableFacet "data") 1 1
            if (@($dataResult.failed).Count -gt 0) { throw "create_table failed to write one or more cells" }
            $tableStyle = Get-ObjectPropertyValue $tableFacet "style"
            if ($null -ne $tableStyle) {
                for ($row = 1; $row -le $shape.Table.Rows.Count; $row++) {
                    for ($column = 1; $column -le $shape.Table.Columns.Count; $column++) {
                        $null = Set-PptTableCellShapeStyle $shape.Table.Cell($row, $column).Shape $tableStyle
                    }
                }
            }
            break
        }
        "create_chart" {
            $chartFacet = Get-ObjectPropertyValue $facets "chart"
            $nativeChartType = [int](Get-ObjectPropertyValue $action "nativeChartType")
            $shape = $slide.Shapes.AddChart(
                $nativeChartType,
                [double](Get-ObjectPropertyValue $bounds "left"),
                [double](Get-ObjectPropertyValue $bounds "top"),
                [double](Get-ObjectPropertyValue $bounds "width"),
                [double](Get-ObjectPropertyValue $bounds "height")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            $title = Get-ObjectPropertyValue $chartFacet "title"
            if ($null -ne $title) {
                $shape.Chart.HasTitle = -1
                $shape.Chart.ChartTitle.Text = [string]$title
            }
            $hasLegend = Get-ObjectPropertyValue $chartFacet "hasLegend"
            if ($null -ne $hasLegend) { $shape.Chart.HasLegend = [bool]$hasLegend }
            $legendPosition = Get-ObjectPropertyValue $chartFacet "legendPosition"
            if ($null -ne $legendPosition) {
                $legendMap = @{ top = -4160; right = -4152; bottom = -4107; left = -4131 }
                $nativeLegendPosition = $legendMap[[string]$legendPosition]
                if ($null -eq $nativeLegendPosition) { throw "Unsupported chart legend position" }
                $shape.Chart.HasLegend = -1
                $shape.Chart.Legend.Position = [int]$nativeLegendPosition
            }
            $chartData = Get-ObjectPropertyValue $chartFacet "data"
            if ($null -ne $chartData) {
                $null = Set-PptChartSemanticData $shape $chartData
            }
            break
        }
        "add_connector" {
            $connectorFacet = Get-ObjectPropertyValue $facets "connector"
            $shape = $slide.Shapes.AddConnector(
                1,
                [double](Get-ObjectPropertyValue $connectorFacet "beginX"),
                [double](Get-ObjectPropertyValue $connectorFacet "beginY"),
                [double](Get-ObjectPropertyValue $connectorFacet "endX"),
                [double](Get-ObjectPropertyValue $connectorFacet "endY")
            )
            Add-PptSceneCreationShapeTracking $tracker $slide $shape
            $null = Set-PptConnectorStyleValues $shape $connectorFacet
            break
        }
        default { throw "Unsupported Scene creation adapter action '$adapterAction'" }
    }
    if ($null -eq $shape) { throw "$adapterAction returned no shape" }
    $rotation = Get-ObjectPropertyValue $action "rotation"
    if ($null -ne $rotation -and $adapterAction -ne "add_connector") {
        $shape.Rotation = [double]$rotation
    }
    if (-not (Test-PptCreationShapeKind $shape $kind)) {
        $actualType = $(try { [int]$shape.Type } catch { -1 })
        throw "Scene creation kind mismatch: expected=$kind actualNativeTypeCode=$actualType"
    }
    return $shape
}

function Get-PptSceneCreationReceipt($slide, $shape, $action) {
    $nativeSlideId = $(try { [int]$slide.SlideID } catch { throw "Created slide identity unavailable" })
    $nativeShapeId = $(try { [int]$shape.Id } catch { throw "Created shape identity unavailable" })
    $resolvedIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
    if ($null -eq $resolvedIndex) { throw "Created shape is missing from immediate readback" }
    $readbackShape = $slide.Shapes.Item($resolvedIndex)
    $kind = [string](Get-ObjectPropertyValue $action "kind")
    if (-not (Test-PptCreationShapeKind $readbackShape $kind)) {
        throw "Created shape kind changed during immediate readback"
    }
    $assetInput = Get-ObjectPropertyValue $action "asset"
    $asset = $null
    if ($null -ne $assetInput) {
        $asset = @{
            assetRef = [string](Get-ObjectPropertyValue $assetInput "assetRef")
            contentHash = [string](Get-ObjectPropertyValue $assetInput "contentHash")
            mimeType = [string](Get-ObjectPropertyValue $assetInput "mimeType")
        }
    }
    $chartData = $null
    $actionFacets = Get-ObjectPropertyValue $action "facets"
    $chartFacet = Get-ObjectPropertyValue $actionFacets "chart"
    $expectedChartData = Get-ObjectPropertyValue $chartFacet "data"
    if ($null -ne $expectedChartData) {
        $chartData = Get-PptChartSemanticData $readbackShape $expectedChartData
    }
    $receipt = @{
        operationId = [string](Get-ObjectPropertyValue $action "operationId")
        resultIndex = [int](Get-ObjectPropertyValue $action "resultIndex")
        clientRef = [string](Get-ObjectPropertyValue $action "clientRef")
        entityClass = "element"
        kind = $kind
        nativeSlideId = $nativeSlideId
        slideIndex = [int]$slide.SlideIndex
        nativeShapeId = $nativeShapeId
        name = [string]$readbackShape.Name
        nativeTypeCode = $(try { [int]$readbackShape.Type } catch { -1 })
        actualBounds = @{
            left = [double]$readbackShape.Left
            top = [double]$readbackShape.Top
            width = [double]$readbackShape.Width
            height = [double]$readbackShape.Height
        }
        sourceRefs = @((Get-ObjectPropertyValue $action "sourceRefs"))
        evidenceRefs = @((Get-ObjectPropertyValue $action "evidenceRefs"))
    }
    if ($null -ne $asset) {
        $receipt.asset = $asset
    }
    # Optional chartData must be absent for ordinary shapes. PowerShell's
    # ConvertTo-Json serializes a null hashtable value, while the Scene
    # adapter treats presence of chartData as a chart receipt.
    if ($null -ne $chartData) {
        $receipt.chartData = $chartData
    }
    return $receipt
}

function Get-PptNativeSlideOrder($pres) {
    $ids = @()
    for ($index = 1; $index -le $pres.Slides.Count; $index++) {
        $ids += [int]$pres.Slides.Item($index).SlideID
    }
    return @($ids)
}

function Get-PptNativeShapeOrder($slide) {
    $items = @()
    for ($index = 1; $index -le $slide.Shapes.Count; $index++) {
        $shape = $slide.Shapes.Item($index)
        $items += @{
            nativeShapeId = [int]$shape.Id
            zOrderPosition = $(try { [int]$shape.ZOrderPosition } catch { $index })
        }
    }
    return @(
        $items |
            Sort-Object { [int](Get-ObjectPropertyValue $_ "zOrderPosition") } |
            ForEach-Object { [int](Get-ObjectPropertyValue $_ "nativeShapeId") }
    )
}

function Test-PptIntegerOrderEqual($left, $right) {
    return ((@($left | ForEach-Object { [int]$_ }) -join ",") -eq (@($right | ForEach-Object { [int]$_ }) -join ","))
}

function Convert-PptSceneHexToRgbInt([string]$hex) {
    if ($hex -notmatch '^#[0-9A-Fa-f]{6}$') { throw "invalid Scene color: $hex" }
    $red = [Convert]::ToInt32($hex.Substring(1, 2), 16)
    $green = [Convert]::ToInt32($hex.Substring(3, 2), 16)
    $blue = [Convert]::ToInt32($hex.Substring(5, 2), 16)
    return [int]($red + ($green * 256) + ($blue * 65536))
}

function Move-PptSlideToExactIndex($pres, $slide, [int]$targetIndex) {
    $count = [int]$pres.Slides.Count
    if ($targetIndex -lt 1 -or $targetIndex -gt $count) { throw "slide targetIndex is out of range: $targetIndex" }
    $currentIndex = [int]$slide.SlideIndex
    if ($currentIndex -eq $targetIndex) { return }
    $moveArgument = if ($currentIndex -lt $targetIndex) { $targetIndex + 1 } else { $targetIndex }
    $slide.MoveTo($moveArgument)
    if ([int]$slide.SlideIndex -ne $targetIndex) {
        throw "slide reorder readback mismatch: expected=$targetIndex actual=$([int]$slide.SlideIndex)"
    }
}

function Restore-PptNativeSlideOrder($pres, $baselineNativeSlideIds) {
    $expected = @(
        $baselineNativeSlideIds |
            Where-Object { $null -ne $_ } |
            ForEach-Object { [int]$_ }
    )
    for ($targetIndex = 1; $targetIndex -le $expected.Count; $targetIndex++) {
        $resolved = Resolve-PptSlideBinding $pres $null $expected[$targetIndex - 1] "restorePptSceneStructuralSlideOrder"
        if (-not $resolved.ok) { throw $resolved.result.error }
        Move-PptSlideToExactIndex $pres $resolved.slide $targetIndex
    }
}

function Set-PptNativeShapeOrder($slide, $nativeShapeIds) {
    $expected = @($nativeShapeIds | ForEach-Object { [int]$_ })
    foreach ($nativeShapeId in $expected) {
        $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
        if ($null -eq $shapeIndex) { throw "shape unavailable while setting z-order: $nativeShapeId" }
        # msoBringToFront = 0. Applying it in bottom-to-top order preserves the
        # requested sequence while leaving no hidden coordinate calculation.
        $slide.Shapes.Item([int]$shapeIndex).ZOrder(0)
    }
}

function Resolve-PptStructuralSlideTarget($pres, $target, [string]$actionName) {
    $resolved = Resolve-PptSlideBinding $pres (Get-ObjectPropertyValue $target "slideIndex") (Get-ObjectPropertyValue $target "nativeSlideId") $actionName
    if (-not $resolved.ok) { throw $resolved.result.error }
    return $resolved
}

function Resolve-PptStructuralShapeTargets($pres, $target, [string]$actionName) {
    $resolvedSlide = Resolve-PptStructuralSlideTarget $pres $target $actionName
    $nativeShapeIds = @((Get-ObjectPropertyValue $target "nativeShapeIds") | ForEach-Object { [int]$_ })
    $expectedNames = @((Get-ObjectPropertyValue $target "expectedShapeNames") | ForEach-Object { [string]$_ })
    if ($nativeShapeIds.Count -lt 1) { throw "$actionName requires nativeShapeIds" }
    $shapes = @()
    for ($index = 0; $index -lt $nativeShapeIds.Count; $index++) {
        $shapeIndex = Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeIds[$index]
        if ($null -eq $shapeIndex) { throw "$actionName target shape is stale: $($nativeShapeIds[$index])" }
        $shape = $resolvedSlide.slide.Shapes.Item([int]$shapeIndex)
        if ($index -lt $expectedNames.Count -and -not [string]::IsNullOrWhiteSpace($expectedNames[$index]) -and [string]$shape.Name -ne $expectedNames[$index]) {
            throw "$actionName target shape name changed: nativeShapeId=$($nativeShapeIds[$index])"
        }
        $shapes += $shape
    }
    return @{ slide = $resolvedSlide.slide; slideIndex = $resolvedSlide.slideIndex; shapes = @($shapes); nativeShapeIds = @($nativeShapeIds) }
}

function Invoke-PptUndo([int]$count, $application) {
    for ($index = 0; $index -lt $count; $index++) {
        $application.CommandBars.ExecuteMso("Undo")
    }
}

function Get-PptSceneStructuralPlanResult($pres, $options) {
    $action = Get-ObjectPropertyValue $options "action"
    if ($null -eq $action) {
        return (New-PptRecoverableError "PPT_SCENE_STRUCTURAL_PLAN_EMPTY" "Scene structural plan requires one compiled action." @{})
    }
    $actionName = [string](Get-ObjectPropertyValue $action "action")
    if (@("delete_entities", "reorder_slide", "reorder_shapes", "set_presentation_properties", "set_slide_properties") -notcontains $actionName) {
        return (New-PptRecoverableError "PPT_SCENE_STRUCTURAL_ACTION_UNSUPPORTED" "Unsupported Scene structural action." @{ action = $actionName })
    }
    $beforeResult = Get-PptPresentationSceneResult $pres
    if (-not $beforeResult.success) { return $beforeResult }
    $beforeFingerprint = [string]$beforeResult.data.fingerprint
    $baselineSlideOrder = @(Get-PptNativeSlideOrder $pres)
    $testControl = Get-ObjectPropertyValue $options "testControl"
    $wroteToWps = $false
    $undoCount = 0
    $rollbackKind = "none"
    $rollbackState = $null
    $readback = @{}
    $failureReason = ""
    try {
        switch ($actionName) {
            "delete_entities" {
                $targets = @((Get-ObjectPropertyValue $action "targets"))
                if ($targets.Count -lt 1) { throw "delete_entities requires exact targets" }
                foreach ($target in $targets) {
                    $targetKind = [string](Get-ObjectPropertyValue $target "targetKind")
                    if ($targetKind -eq "slide") {
                        $resolvedSlide = Resolve-PptStructuralSlideTarget $pres $target "executePptSceneStructuralPlan"
                        $resolvedSlide.slide.Delete()
                        $undoCount++
                        $wroteToWps = $true
                    } elseif (@("node", "aggregate") -contains $targetKind) {
                        $resolvedShapes = Resolve-PptStructuralShapeTargets $pres $target "executePptSceneStructuralPlan"
                        foreach ($shape in @($resolvedShapes.shapes)) {
                            $shape.Delete()
                            $undoCount++
                            $wroteToWps = $true
                        }
                    } else {
                        throw "unsupported delete targetKind: $targetKind"
                    }
                }
                $rollbackKind = "undo"
                foreach ($target in $targets) {
                    $targetKind = [string](Get-ObjectPropertyValue $target "targetKind")
                    if ($targetKind -eq "slide") {
                        $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $target "nativeSlideId") "verifyPptSceneStructuralDelete"
                        if ($resolved.ok) { throw "delete readback mismatch: slide still exists" }
                    } else {
                        $resolvedSlide = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $target "nativeSlideId") "verifyPptSceneStructuralDelete"
                        if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
                        foreach ($nativeShapeId in @((Get-ObjectPropertyValue $target "nativeShapeIds"))) {
                            if ($null -ne (Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId)) {
                                throw "delete readback mismatch: shape still exists: $nativeShapeId"
                            }
                        }
                    }
                }
                $readback = @{ deleted = $true; targetCount = $targets.Count }
            }
            "reorder_slide" {
                $baseline = @((Get-ObjectPropertyValue $action "baselineNativeSlideIds") | ForEach-Object { [int]$_ })
                if (-not (Test-PptIntegerOrderEqual $baseline $baselineSlideOrder)) { throw "stale_scene: slide order changed after capture" }
                $target = Get-ObjectPropertyValue $action "target"
                $resolvedSlide = Resolve-PptStructuralSlideTarget $pres $target "executePptSceneStructuralPlan"
                $rollbackKind = "slide_order"
                $rollbackState = @{ baselineNativeSlideIds = @($baseline) }
                Move-PptSlideToExactIndex $pres $resolvedSlide.slide ([int](Get-ObjectPropertyValue $action "targetIndex"))
                $wroteToWps = $true
                $expected = @($baseline | Where-Object { $_ -ne [int](Get-ObjectPropertyValue $target "nativeSlideId") })
                $insertIndex = [int](Get-ObjectPropertyValue $action "targetIndex") - 1
                $before = if ($insertIndex -gt 0) { @($expected[0..($insertIndex - 1)]) } else { @() }
                $after = if ($insertIndex -lt $expected.Count) { @($expected[$insertIndex..($expected.Count - 1)]) } else { @() }
                $expected = @($before) + @([int](Get-ObjectPropertyValue $target "nativeSlideId")) + @($after)
                $actual = @(Get-PptNativeSlideOrder $pres)
                if (-not (Test-PptIntegerOrderEqual $expected $actual)) { throw "slide order readback mismatch" }
                $readback = @{ orderedNativeSlideIds = @($actual); targetIndex = [int]$resolvedSlide.slide.SlideIndex }
            }
            "reorder_shapes" {
                $target = Get-ObjectPropertyValue $action "target"
                $resolvedShapes = Resolve-PptStructuralShapeTargets $pres $target "executePptSceneStructuralPlan"
                $baseline = @((Get-ObjectPropertyValue $action "baselineNativeShapeIds") | ForEach-Object { [int]$_ })
                $actualBefore = @(Get-PptNativeShapeOrder $resolvedShapes.slide)
                if (-not (Test-PptIntegerOrderEqual $baseline $actualBefore)) {
                    throw "stale_scene: z-order changed after capture; expected=$($baseline -join ','); actual=$($actualBefore -join ',')"
                }
                $movingSet = @{}
                foreach ($id in @($resolvedShapes.nativeShapeIds)) { $movingSet[[string][int]$id] = $true }
                $moving = @($baseline | Where-Object { $movingSet.ContainsKey([string][int]$_) })
                $remaining = @($baseline | Where-Object { -not $movingSet.ContainsKey([string][int]$_) })
                $targetIndex = [int](Get-ObjectPropertyValue $action "targetIndex")
                if ($targetIndex -lt 1 -or $targetIndex -gt ($remaining.Count + 1)) { throw "z-order targetIndex is out of range" }
                $before = if ($targetIndex -gt 1) { @($remaining[0..($targetIndex - 2)]) } else { @() }
                $after = if ($targetIndex -le $remaining.Count) { @($remaining[($targetIndex - 1)..($remaining.Count - 1)]) } else { @() }
                $expected = @($before) + @($moving) + @($after)
                $rollbackKind = "shape_order"
                $rollbackState = @{ nativeSlideId = [int](Get-ObjectPropertyValue $target "nativeSlideId"); baselineNativeShapeIds = @($baseline) }
                Set-PptNativeShapeOrder $resolvedShapes.slide $expected
                $wroteToWps = $true
                $actual = @(Get-PptNativeShapeOrder $resolvedShapes.slide)
                if (-not (Test-PptIntegerOrderEqual $expected $actual)) { throw "z-order readback mismatch" }
                $readback = @{ nativeSlideId = [int](Get-ObjectPropertyValue $target "nativeSlideId"); orderedNativeShapeIds = @($actual); targetIndex = $targetIndex }
            }
            "set_presentation_properties" {
                $baselineWidth = [double]$pres.PageSetup.SlideWidth
                $baselineHeight = [double]$pres.PageSetup.SlideHeight
                $rollbackKind = "page_size"
                $rollbackState = @{ width = $baselineWidth; height = $baselineHeight }
                $pageSize = Get-ObjectPropertyValue $action "pageSize"
                $pres.PageSetup.SlideWidth = [double](Get-ObjectPropertyValue $pageSize "width")
                $pres.PageSetup.SlideHeight = [double](Get-ObjectPropertyValue $pageSize "height")
                $wroteToWps = $true
                $actualWidth = [double]$pres.PageSetup.SlideWidth
                $actualHeight = [double]$pres.PageSetup.SlideHeight
                if ([Math]::Abs($actualWidth - [double](Get-ObjectPropertyValue $pageSize "width")) -gt 0.01 -or [Math]::Abs($actualHeight - [double](Get-ObjectPropertyValue $pageSize "height")) -gt 0.01) { throw "page size readback mismatch" }
                $readback = @{ pageSize = @{ width = $actualWidth; height = $actualHeight } }
            }
            "set_slide_properties" {
                $target = Get-ObjectPropertyValue $action "target"
                $resolvedSlide = Resolve-PptStructuralSlideTarget $pres $target "executePptSceneStructuralPlan"
                $slide = $resolvedSlide.slide
                $baselineHidden = $(try { [int]$slide.SlideShowTransition.Hidden -ne 0 } catch { $false })
                $baselineFollow = $(try { [int]$slide.FollowMasterBackground -ne 0 } catch { $true })
                $baselineFillType = $(try { [int]$slide.Background.Fill.Type } catch { -1 })
                $baselineFillColor = $(try { [int]$slide.Background.Fill.ForeColor.RGB } catch { $null })
                $rollbackKind = "slide_properties"
                $rollbackState = @{ nativeSlideId = [int]$slide.SlideID; hidden = $baselineHidden; followMasterBackground = $baselineFollow; fillType = $baselineFillType; fillColor = $baselineFillColor }
                $hidden = Get-ObjectPropertyValue $action "hidden"
                if ($null -ne $hidden) { $slide.SlideShowTransition.Hidden = [bool]$hidden }
                $background = Get-ObjectPropertyValue $action "background"
                if ($null -ne $background) {
                    $mode = [string](Get-ObjectPropertyValue $background "mode")
                    if ($mode -eq "follow_master") {
                        $slide.FollowMasterBackground = $true
                    } elseif ($mode -eq "solid") {
                        $slide.FollowMasterBackground = $false
                        $slide.Background.Fill.Solid()
                        $slide.Background.Fill.ForeColor.RGB = Convert-PptSceneHexToRgbInt ([string](Get-ObjectPropertyValue $background "color"))
                    } else { throw "unsupported slide background mode: $mode" }
                }
                $wroteToWps = $true
                $actualHidden = $(try { [int]$slide.SlideShowTransition.Hidden -ne 0 } catch { $false })
                $actualFollow = $(try { [int]$slide.FollowMasterBackground -ne 0 } catch { $true })
                $actualFillColor = $(try { [int]$slide.Background.Fill.ForeColor.RGB } catch { $null })
                if ($null -ne $hidden -and $actualHidden -ne [bool]$hidden) { throw "slide hidden readback mismatch" }
                if ($null -ne $background) {
                    $expectedFollow = ([string](Get-ObjectPropertyValue $background "mode") -eq "follow_master")
                    if ($actualFollow -ne $expectedFollow) { throw "slide background mode readback mismatch" }
                    if (-not $expectedFollow -and $actualFillColor -ne (Convert-PptSceneHexToRgbInt ([string](Get-ObjectPropertyValue $background "color"))) ) { throw "slide background color readback mismatch" }
                }
                $readback = @{ nativeSlideId = [int]$slide.SlideID; hidden = $actualHidden; background = @{ followMasterBackground = $actualFollow; fillColor = $actualFillColor } }
            }
        }
        if ($null -ne $testControl -and [bool](Get-ObjectPropertyValue $testControl "failAfterWrite")) { throw "scene_structural_injected_failure_after_write" }
        $afterResult = Get-PptPresentationSceneResult $pres
        if (-not $afterResult.success) { throw $afterResult.error }
        return @{ success = $true; data = @{ transactional = $true; wroteToWps = $wroteToWps; rolledBack = $false; rollbackVerified = $false; action = $actionName; presentationFingerprintBefore = $beforeFingerprint; presentationFingerprintAfter = [string]$afterResult.data.fingerprint; readback = $readback; rollbackIssues = @() } }
    } catch {
        $failureReason = $_.Exception.Message
    }

    $rollbackIssues = @()
    if ($wroteToWps) {
        try {
            switch ($rollbackKind) {
                "undo" { Invoke-PptUndo $undoCount $pres.Application }
                "slide_order" { Restore-PptNativeSlideOrder $pres (Get-ObjectPropertyValue $rollbackState "baselineNativeSlideIds") }
                "shape_order" {
                    $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $rollbackState "nativeSlideId") "rollbackPptSceneStructuralPlan"
                    if (-not $resolved.ok) { throw $resolved.result.error }
                    Set-PptNativeShapeOrder $resolved.slide (Get-ObjectPropertyValue $rollbackState "baselineNativeShapeIds")
                }
                "page_size" {
                    $pres.PageSetup.SlideWidth = [double](Get-ObjectPropertyValue $rollbackState "width")
                    $pres.PageSetup.SlideHeight = [double](Get-ObjectPropertyValue $rollbackState "height")
                }
                "slide_properties" {
                    $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $rollbackState "nativeSlideId") "rollbackPptSceneStructuralPlan"
                    if (-not $resolved.ok) { throw $resolved.result.error }
                    $slide = $resolved.slide
                    $slide.SlideShowTransition.Hidden = [bool](Get-ObjectPropertyValue $rollbackState "hidden")
                    if ([bool](Get-ObjectPropertyValue $rollbackState "followMasterBackground")) {
                        $slide.FollowMasterBackground = $true
                    } else {
                        $slide.FollowMasterBackground = $false
                        if ([int](Get-ObjectPropertyValue $rollbackState "fillType") -eq 1) { $slide.Background.Fill.Solid() }
                        if ($null -ne (Get-ObjectPropertyValue $rollbackState "fillColor")) { $slide.Background.Fill.ForeColor.RGB = [int](Get-ObjectPropertyValue $rollbackState "fillColor") }
                    }
                }
            }
        } catch {
            $rollbackIssues += @{ code = "structural_rollback_failed"; message = $_.Exception.Message }
        }
    }
    $afterRollback = Get-PptPresentationSceneResult $pres
    $afterFingerprint = $(if ($afterRollback.success) { [string]$afterRollback.data.fingerprint } else { "" })
    if (-not $afterRollback.success) {
        $rollbackIssues += @{ code = "rollback_presentation_readback_failed"; message = [string]$afterRollback.error }
    } elseif ($afterFingerprint -ne $beforeFingerprint) {
        $rollbackIssues += @{ code = "rollback_presentation_fingerprint_mismatch"; expected = $beforeFingerprint; actual = $afterFingerprint }
    }
    if ($wroteToWps -and $rollbackKind -eq "slide_properties") {
        try {
            $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $rollbackState "nativeSlideId") "verifyPptSceneStructuralRollback"
            if (-not $resolved.ok) { throw $resolved.result.error }
            $slide = $resolved.slide
            $actualHidden = $(try { [int]$slide.SlideShowTransition.Hidden -ne 0 } catch { $false })
            $actualFollow = $(try { [int]$slide.FollowMasterBackground -ne 0 } catch { $true })
            $expectedHidden = [bool](Get-ObjectPropertyValue $rollbackState "hidden")
            $expectedFollow = [bool](Get-ObjectPropertyValue $rollbackState "followMasterBackground")
            if ($actualHidden -ne $expectedHidden) {
                $rollbackIssues += @{ code = "rollback_slide_hidden_mismatch"; expected = $expectedHidden; actual = $actualHidden }
            }
            if ($actualFollow -ne $expectedFollow) {
                $rollbackIssues += @{ code = "rollback_slide_background_mode_mismatch"; expected = $expectedFollow; actual = $actualFollow }
            } elseif (-not $expectedFollow) {
                $expectedFillColor = Get-ObjectPropertyValue $rollbackState "fillColor"
                $actualFillColor = $(try { [int]$slide.Background.Fill.ForeColor.RGB } catch { $null })
                if ($null -ne $expectedFillColor -and $actualFillColor -ne [int]$expectedFillColor) {
                    $rollbackIssues += @{ code = "rollback_slide_background_color_mismatch"; expected = [int]$expectedFillColor; actual = $actualFillColor }
                }
            }
        } catch {
            $rollbackIssues += @{ code = "rollback_slide_properties_readback_failed"; message = $_.Exception.Message }
        }
    }
    if ($wroteToWps -and $rollbackKind -eq "shape_order") {
        try {
            $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $rollbackState "nativeSlideId") "verifyPptSceneStructuralRollback"
            if (-not $resolved.ok) { throw $resolved.result.error }
            $expectedOrder = @((Get-ObjectPropertyValue $rollbackState "baselineNativeShapeIds") | ForEach-Object { [int]$_ })
            $actualOrder = @(Get-PptNativeShapeOrder $resolved.slide)
            $readback.rollbackOrderedNativeShapeIds = @($actualOrder)
            if (-not (Test-PptIntegerOrderEqual $expectedOrder $actualOrder)) {
                $rollbackIssues += @{ code = "rollback_shape_order_mismatch"; expected = @($expectedOrder); actual = @($actualOrder) }
            }
        } catch {
            $rollbackIssues += @{ code = "rollback_shape_order_readback_failed"; message = $_.Exception.Message }
        }
    }
    $rollbackVerified = ($wroteToWps -and $rollbackIssues.Count -eq 0)
    return @{ success = $false; error = $failureReason; data = @{ transactional = $true; wroteToWps = $wroteToWps; rolledBack = $wroteToWps; rollbackVerified = $rollbackVerified; action = $actionName; presentationFingerprintBefore = $beforeFingerprint; presentationFingerprintAfter = $afterFingerprint; reason = $failureReason; rollbackIssues = @($rollbackIssues); readback = $readback } }
}

function Resolve-PptSpecializedShapeTarget($slide, $target, [string]$actionName) {
    $nativeSlideId = [int](Get-ObjectPropertyValue $target "nativeSlideId")
    if ([int]$slide.SlideID -ne $nativeSlideId) {
        throw "$actionName target belongs to another slide: $nativeSlideId"
    }
    $nativeShapeId = [int](Get-ObjectPropertyValue $target "nativeShapeId")
    $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
    if ($null -eq $shapeIndex) { throw "$actionName target shape is stale: $nativeShapeId" }
    $shape = $slide.Shapes.Item([int]$shapeIndex)
    $expectedName = [string](Get-ObjectPropertyValue $target "expectedShapeName")
    if (-not [string]::IsNullOrWhiteSpace($expectedName) -and [string]$shape.Name -ne $expectedName) {
        throw "$actionName target shape name changed: nativeShapeId=$nativeShapeId"
    }
    return $shape
}

function Get-PptSpecializedSnapshotIssues($expected, $actual, [double]$tolerance = 0.25) {
    $issues = @()
    foreach ($property in @("nativeShapeId", "name", "nativeType", "placeholderType", "text", "fontName", "fontBold", "fontItalic", "fontColor", "alignment", "verticalAnchor", "fillVisible", "fillColor", "lineVisible", "lineColor", "lineDashStyle", "wordWrap", "autoSize", "lockAspectRatio", "groupMemberCount")) {
        $expectedValue = Get-ObjectPropertyValue $expected $property
        if ($null -eq $expectedValue) { continue }
        $actualValue = Get-ObjectPropertyValue $actual $property
        if ([string]$actualValue -ne [string]$expectedValue) {
            $issues += @{ property = $property; expected = $expectedValue; actual = $actualValue }
        }
    }
    foreach ($property in @("left", "top", "width", "height", "fontSize", "fillTransparency", "lineTransparency", "marginLeft", "marginRight", "marginTop", "marginBottom", "lineWeight", "rotation")) {
        $expectedValue = Get-ObjectPropertyValue $expected $property
        if ($null -eq $expectedValue) { continue }
        $actualValue = Get-ObjectPropertyValue $actual $property
        if ($null -eq $actualValue -or [Math]::Abs([double]$actualValue - [double]$expectedValue) -gt $tolerance) {
            $issues += @{ property = $property; expected = $expectedValue; actual = $actualValue }
        }
    }
    foreach ($property in @("textFormatting", "textParagraphs", "tableCells", "tableRowCount", "tableColumnCount", "tableRowHeights", "tableColumnWidths", "chart", "picture", "connector")) {
        $expectedValue = Get-ObjectPropertyValue $expected $property
        if ($null -eq $expectedValue) { continue }
        $actualValue = Get-ObjectPropertyValue $actual $property
        $expectedJson = $expectedValue | ConvertTo-Json -Compress -Depth 30
        $actualJson = $actualValue | ConvertTo-Json -Compress -Depth 30
        if ($expectedJson -ne $actualJson) {
            $issues += @{ property = $property; expected = $expectedJson; actual = $actualJson }
        }
    }
    return @($issues)
}

function Get-PptObjectLinkEvidence($shape) {
    $setting = $shape.ActionSettings.Item(1)
    return @{
        nativeShapeId = [int]$shape.Id
        action = $(try { [int]$setting.Action } catch { -1 })
        address = $(try { [string]$setting.Hyperlink.Address } catch { "" })
        subAddress = $(try { [string]$setting.Hyperlink.SubAddress } catch { "" })
    }
}

function Set-PptObjectLinkEvidence($shape, $evidence) {
    $setting = $shape.ActionSettings.Item(1)
    $setting.Hyperlink.Address = [string](Get-ObjectPropertyValue $evidence "address")
    $setting.Hyperlink.SubAddress = [string](Get-ObjectPropertyValue $evidence "subAddress")
    $setting.Action = [int](Get-ObjectPropertyValue $evidence "action")
}

function Test-PptObjectLinkEvidenceEqual($left, $right) {
    return (
        [int](Get-ObjectPropertyValue $left "action") -eq [int](Get-ObjectPropertyValue $right "action") -and
        [string](Get-ObjectPropertyValue $left "address") -eq [string](Get-ObjectPropertyValue $right "address") -and
        [string](Get-ObjectPropertyValue $left "subAddress") -eq [string](Get-ObjectPropertyValue $right "subAddress")
    )
}

function Get-PptTableTopologyEvidence($shape) {
    if (-not [bool]$shape.HasTable) { throw "specialized table target no longer has a table" }
    $cells = @()
    for ($row = 1; $row -le $shape.Table.Rows.Count; $row++) {
        for ($column = 1; $column -le $shape.Table.Columns.Count; $column++) {
            $cellShape = $shape.Table.Cell($row, $column).Shape
            $cells += @{
                row = $row
                column = $column
                text = $(try { [string]$cellShape.TextFrame.TextRange.Text } catch { "" })
                left = [double]$cellShape.Left
                top = [double]$cellShape.Top
                width = [double]$cellShape.Width
                height = [double]$cellShape.Height
            }
        }
    }
    return @{ rows = [int]$shape.Table.Rows.Count; columns = [int]$shape.Table.Columns.Count; cells = @($cells) }
}

function Test-PptTableTopologyEvidenceEqual($left, $right, [double]$tolerance = 0.25) {
    if ([int](Get-ObjectPropertyValue $left "rows") -ne [int](Get-ObjectPropertyValue $right "rows") -or [int](Get-ObjectPropertyValue $left "columns") -ne [int](Get-ObjectPropertyValue $right "columns")) { return $false }
    $leftCells = @((Get-ObjectPropertyValue $left "cells"))
    $rightCells = @((Get-ObjectPropertyValue $right "cells"))
    if ($leftCells.Count -ne $rightCells.Count) { return $false }
    foreach ($expected in $leftCells) {
        $actual = @($rightCells | Where-Object { [int](Get-ObjectPropertyValue $_ "row") -eq [int](Get-ObjectPropertyValue $expected "row") -and [int](Get-ObjectPropertyValue $_ "column") -eq [int](Get-ObjectPropertyValue $expected "column") })[0]
        if ($null -eq $actual -or [string](Get-ObjectPropertyValue $actual "text") -ne [string](Get-ObjectPropertyValue $expected "text")) { return $false }
        foreach ($property in @("left", "top", "width", "height")) {
            if ([Math]::Abs([double](Get-ObjectPropertyValue $actual $property) - [double](Get-ObjectPropertyValue $expected $property)) -gt $tolerance) { return $false }
        }
    }
    return $true
}

function Get-PptTableRegionSignatureCount($shape, [int]$firstRow, [int]$firstColumn, [int]$lastRow, [int]$lastColumn) {
    $signatures = @{}
    for ($row = $firstRow; $row -le $lastRow; $row++) {
        for ($column = $firstColumn; $column -le $lastColumn; $column++) {
            $cellShape = $shape.Table.Cell($row, $column).Shape
            $signature = "{0:F3}|{1:F3}|{2:F3}|{3:F3}" -f [double]$cellShape.Left, [double]$cellShape.Top, [double]$cellShape.Width, [double]$cellShape.Height
            $signatures[$signature] = $true
        }
    }
    return [int]$signatures.Count
}

function Get-PptChartDataSheet($chart) {
    $lastError = ""
    for ($attempt = 1; $attempt -le 10; $attempt++) {
        try {
            $chart.ChartData.Activate()
            $sheet = $chart.ChartData.Workbook.Worksheets.Item(1)
            if ($null -ne $sheet) { return $sheet }
        } catch { $lastError = $_.Exception.Message }
        Start-Sleep -Milliseconds 100
    }
    throw "ChartData worksheet unavailable after retries: $lastError"
}

function Get-PptChartSemanticData($shape, $expectedData) {
    if ($null -eq $expectedData) { throw "chart semantic data is required" }
    $categories = @((Get-ObjectPropertyValue $expectedData "categories"))
    $seriesDefinitions = @((Get-ObjectPropertyValue $expectedData "series"))
    if ($categories.Count -lt 1 -or $seriesDefinitions.Count -lt 1) { throw "chart semantic data is empty" }
    $sheet = Get-PptChartDataSheet $shape.Chart
    $seriesCollection = $shape.Chart.SeriesCollection()
    if ([int]$seriesCollection.Count -ne $seriesDefinitions.Count) {
        $observedHeaders = @()
        for ($headerIndex = 2; $headerIndex -le ([int]$seriesCollection.Count + 1); $headerIndex++) {
            $observedHeaders += [string]$(try { $sheet.Cells.Item(1, $headerIndex).Value2 } catch { "<unreadable>" })
        }
        throw "chart semantic series count readback mismatch: expected=$($seriesDefinitions.Count) actual=$([int]$seriesCollection.Count) headers=$($observedHeaders -join '|')"
    }
    $actualCategories = @()
    for ($row = 2; $row -le ($categories.Count + 1); $row++) {
        $value = $sheet.Cells.Item($row, 1).Value2
        if ($null -eq $value -or [string]$value -eq "") { throw "chart semantic category readback missing: $row" }
        $actualCategories += [string]$value
    }
    $actualSeries = @()
    for ($seriesIndex = 0; $seriesIndex -lt $seriesDefinitions.Count; $seriesIndex++) {
        $column = $seriesIndex + 2
        $header = $sheet.Cells.Item(1, $column).Value2
        if ($null -eq $header -or [string]$header -eq "") { throw "chart semantic series name readback missing: $column" }
        $values = @()
        for ($row = 2; $row -le ($categories.Count + 1); $row++) {
            $rawValue = $sheet.Cells.Item($row, $column).Value2
            try { $number = [double]$rawValue } catch { throw "chart semantic value readback is not numeric: row=$row column=$column" }
            if ([double]::IsNaN($number) -or [double]::IsInfinity($number)) { throw "chart semantic value readback is not finite: row=$row column=$column" }
            $values += $number
        }
        $actualSeries += @{ name = [string]$header; values = @($values) }
        $formula = $(try { [string]$seriesCollection.Item($seriesIndex + 1).Formula } catch { "" })
        if ([string]::IsNullOrWhiteSpace($formula)) { throw "chart semantic series formula readback missing: $($seriesIndex + 1)" }
    }
    return @{ categories = @($actualCategories); series = @($actualSeries) }
}

function Set-PptChartSemanticData($shape, $data) {
    if ($null -eq $data) { return $null }
    $categories = @((Get-ObjectPropertyValue $data "categories"))
    $seriesDefinitions = @((Get-ObjectPropertyValue $data "series"))
    if ($categories.Count -lt 1 -or $seriesDefinitions.Count -lt 1) { throw "chart semantic data is empty" }
    $rowCount = $categories.Count + 1
    $columnCount = $seriesDefinitions.Count + 1
    $sheet = Get-PptChartDataSheet $shape.Chart
    try { $sheet.UsedRange.ClearContents() | Out-Null } catch {}
    $matrix = [System.Array]::CreateInstance([object], @([int]$rowCount, [int]$columnCount))
    $matrix[0, 0] = "Category"
    for ($seriesIndex = 0; $seriesIndex -lt $seriesDefinitions.Count; $seriesIndex++) {
        $seriesName = Get-ObjectPropertyValue $seriesDefinitions[$seriesIndex] "name"
        $matrix[0, ($seriesIndex + 1)] = $(if ($null -eq $seriesName -or [string]$seriesName -eq "") { "Series $($seriesIndex + 1)" } else { [string]$seriesName })
    }
    for ($categoryIndex = 0; $categoryIndex -lt $categories.Count; $categoryIndex++) {
        $matrix[($categoryIndex + 1), 0] = [string]$categories[$categoryIndex]
        for ($seriesIndex = 0; $seriesIndex -lt $seriesDefinitions.Count; $seriesIndex++) {
            $values = @((Get-ObjectPropertyValue $seriesDefinitions[$seriesIndex] "values"))
            $matrix[($categoryIndex + 1), ($seriesIndex + 1)] = [double]$values[$categoryIndex]
        }
    }
    $range = $sheet.Range($sheet.Cells.Item(1, 1), $sheet.Cells.Item($rowCount, $columnCount))
    $range.Value2 = $matrix
    try { $shape.Chart.PlotBy = 2 } catch {}
    try { $shape.Chart.SetSourceData($range, 2) } catch { $shape.Chart.SetSourceData($range) }
    $boundSeries = $shape.Chart.SeriesCollection()
    while ([int]$boundSeries.Count -gt $seriesDefinitions.Count) {
        $lastSeries = $boundSeries.Item([int]$boundSeries.Count)
        $lastHeader = [string]$(try { $sheet.Cells.Item(1, ([int]$boundSeries.Count + 1)).Value2 } catch { "" })
        if (-not [string]::IsNullOrWhiteSpace($lastHeader) -and $lastHeader -notmatch '^(Series\s*\d+)?$') {
            throw "chart semantic binding produced an unexpected extra series: $lastHeader"
        }
        $lastSeries.Delete()
        $boundSeries = $shape.Chart.SeriesCollection()
    }
    $actual = Get-PptChartSemanticData $shape $data
    $expectedCategories = @($categories | ForEach-Object { [string]$_ })
    if ((@((Get-ObjectPropertyValue $actual "categories")) -join "`u{001f}") -ne ($expectedCategories -join "`u{001f}")) { throw "chart semantic category readback mismatch" }
    $actualSeries = @((Get-ObjectPropertyValue $actual "series"))
    for ($seriesIndex = 0; $seriesIndex -lt $seriesDefinitions.Count; $seriesIndex++) {
        $expectedValues = @((Get-ObjectPropertyValue $seriesDefinitions[$seriesIndex] "values"))
        $actualValues = @((Get-ObjectPropertyValue $actualSeries[$seriesIndex] "values"))
        if ($actualValues.Count -ne $expectedValues.Count) { throw "chart semantic value count readback mismatch" }
        for ($valueIndex = 0; $valueIndex -lt $expectedValues.Count; $valueIndex++) {
            if ([Math]::Abs([double]$actualValues[$valueIndex] - [double]$expectedValues[$valueIndex]) -gt 0.000001) { throw "chart semantic value readback mismatch" }
        }
    }
    return $actual
}

function Get-PptSceneChartSemanticDataResult($pres, $options) {
    $resolvedSlide = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $options "nativeSlideId") "readPptSceneChartData"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $nativeShapeId = [int](Get-ObjectPropertyValue $options "nativeShapeId")
    $shapeIndex = Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId
    if ($null -eq $shapeIndex) { return (New-PptRecoverableError "PPT_CHART_SHAPE_NOT_FOUND" "Chart native shape was not found." @{ nativeShapeId = $nativeShapeId }) }
    $shape = $resolvedSlide.slide.Shapes.Item([int]$shapeIndex)
    if ([int]$shape.Type -ne 3) { return (New-PptRecoverableError "PPT_CHART_SHAPE_TYPE_MISMATCH" "Target native shape is not a chart." @{ nativeShapeId = $nativeShapeId }) }
    $expectedData = Get-ObjectPropertyValue $options "expectedData"
    if ($null -eq $expectedData) { return (New-PptRecoverableError "PPT_CHART_EXPECTED_DATA_REQUIRED" "Chart semantic readback requires expected category and series dimensions." @{}) }
    $data = Get-PptChartSemanticData $shape $expectedData
    return @{ success = $true; data = @{ nativeSlideId = [int]$resolvedSlide.slide.SlideID; nativeShapeId = $nativeShapeId; chartData = $data } }
}

function Get-PptChartWorkbookEvidence($shape, $cellDefinitions) {
    $sheet = Get-PptChartDataSheet $shape.Chart
    $cells = @()
    foreach ($definition in @($cellDefinitions)) {
        $row = [int](Get-ObjectPropertyValue $definition "row")
        $column = [int](Get-ObjectPropertyValue $definition "column")
        $cell = $sheet.Cells.Item($row, $column)
        $formula = $(try { [string]$cell.Formula } catch { "" })
        $value = $(try { $cell.Value2 } catch { $null })
        $cells += @{
            row = $row
            column = $column
            value = $(if ($null -eq $value -or [string]$value -eq "") { $null } else { $value })
            formula = $formula
            hasFormula = [bool]($formula.StartsWith("="))
        }
    }
    $seriesFormulas = @()
    $series = $shape.Chart.SeriesCollection()
    for ($index = 1; $index -le $series.Count; $index++) {
        $seriesFormulas += @{ index = $index; formula = $(try { [string]$series.Item($index).Formula } catch { "" }) }
    }
    return @{ nativeShapeId = [int]$shape.Id; cells = @($cells); seriesFormulas = @($seriesFormulas) }
}

function Restore-PptChartWorkbookEvidence($shape, $evidence) {
    $sheet = Get-PptChartDataSheet $shape.Chart
    foreach ($entry in @((Get-ObjectPropertyValue $evidence "cells"))) {
        $cell = $sheet.Cells.Item([int](Get-ObjectPropertyValue $entry "row"), [int](Get-ObjectPropertyValue $entry "column"))
        if ([bool](Get-ObjectPropertyValue $entry "hasFormula")) {
            $cell.Formula = [string](Get-ObjectPropertyValue $entry "formula")
        } elseif ($null -eq (Get-ObjectPropertyValue $entry "value")) {
            $cell.ClearContents() | Out-Null
        } else {
            $cell.Value2 = Get-ObjectPropertyValue $entry "value"
        }
    }
}

function Test-PptChartWorkbookEvidenceEqual($left, $right) {
    $leftCells = @((Get-ObjectPropertyValue $left "cells"))
    $rightCells = @((Get-ObjectPropertyValue $right "cells"))
    if ($leftCells.Count -ne $rightCells.Count) { return $false }
    for ($index = 0; $index -lt $leftCells.Count; $index++) {
        foreach ($property in @("row", "column", "formula", "hasFormula", "value")) {
            if ([string](Get-ObjectPropertyValue $leftCells[$index] $property) -ne [string](Get-ObjectPropertyValue $rightCells[$index] $property)) { return $false }
        }
    }
    $leftSeries = @((Get-ObjectPropertyValue $left "seriesFormulas"))
    $rightSeries = @((Get-ObjectPropertyValue $right "seriesFormulas"))
    if ($leftSeries.Count -ne $rightSeries.Count) { return $false }
    for ($index = 0; $index -lt $leftSeries.Count; $index++) {
        if ([string](Get-ObjectPropertyValue $leftSeries[$index] "formula") -ne [string](Get-ObjectPropertyValue $rightSeries[$index] "formula")) { return $false }
    }
    return $true
}

function Get-PptSceneSpecializedPlanResult($pres, $options) {
    $action = Get-ObjectPropertyValue $options "action"
    $actionName = [string](Get-ObjectPropertyValue $action "action")
    $operationId = [string](Get-ObjectPropertyValue $options "operationId")
    $operation = [string](Get-ObjectPropertyValue $options "operation")
    $compiledPlanFingerprint = [string](Get-ObjectPropertyValue $options "compiledPlanFingerprint")
    $supported = @("group_shapes", "ungroup_shape", "set_object_link", "clear_object_link", "merge_table_cells", "split_table_cell", "set_chart_workbook_cells")
    if ($null -eq $action -or $supported -notcontains $actionName) {
        return (New-PptRecoverableError "PPT_SCENE_SPECIALIZED_ACTION_UNSUPPORTED" "Unsupported Scene specialized action." @{ action = $actionName })
    }
    $resolvedSlide = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $options "nativeSlideId") "executePptSceneSpecializedPlan"
    if (-not $resolvedSlide.ok) { return $resolvedSlide.result }
    $slide = $resolvedSlide.slide
    $beforeResult = Get-PptPresentationSceneResult $pres
    if (-not $beforeResult.success) { return $beforeResult }
    $beforeFingerprint = [string]$beforeResult.data.fingerprint
    $testControl = Get-ObjectPropertyValue $options "testControl"
    $wroteToWps = $false
    $rollbackKind = "none"
    $rollbackState = $null
    $readback = @{}
    $failureReason = ""
    try {
        switch ($actionName) {
            "group_shapes" {
                $targets = @((Get-ObjectPropertyValue $action "targets"))
                if ($targets.Count -lt 2) { throw "group_shapes requires at least two targets" }
                $names = @()
                $baselineSnapshots = @()
                foreach ($target in $targets) {
                    $shape = Resolve-PptSpecializedShapeTarget $slide $target $actionName
                    $names += [string]$shape.Name
                    $baselineSnapshots += Get-PptShapeSnapshot $shape
                }
                $rollbackKind = "ungroup_created_group"
                $rollbackState = @{ baselineSnapshots = @($baselineSnapshots) }
                $group = $slide.Shapes.Range($names).Group()
                $wroteToWps = $true
                $groupName = [string](Get-ObjectPropertyValue $action "groupName")
                if (-not [string]::IsNullOrWhiteSpace($groupName)) { $group.Name = $groupName }
                $rollbackState.groupNativeShapeId = [int]$group.Id
                $actualMemberIds = @()
                $nativePropertiesPreserved = $true
                for ($index = 1; $index -le $group.GroupItems.Count; $index++) {
                    $member = $group.GroupItems.Item($index)
                    $actualMemberIds += [int]$member.Id
                    $baseline = @($baselineSnapshots | Where-Object { [int](Get-ObjectPropertyValue $_ "nativeShapeId") -eq [int]$member.Id })[0]
                    if ($null -eq $baseline -or @(Get-PptSpecializedSnapshotIssues $baseline (Get-PptShapeSnapshot $member)).Count -gt 0) { $nativePropertiesPreserved = $false }
                }
                if (-not $nativePropertiesPreserved) { throw "group_shapes changed member native properties" }
                $readback = @{ groupExists = $true; groupNativeShapeId = [int]$group.Id; groupName = [string]$group.Name; memberNativeShapeIds = @($actualMemberIds); nativePropertiesPreserved = $true }
            }
            "ungroup_shape" {
                $target = Get-ObjectPropertyValue $action "target"
                $group = Resolve-PptSpecializedShapeTarget $slide $target $actionName
                if ([int]$group.Type -ne 6) { throw "ungroup_shape target is not a native Group" }
                $groupTopIndex = Get-PptShapeIndexByNativeId $slide ([int]$group.Id)
                $expectedMembers = @((Get-ObjectPropertyValue $action "members"))
                if ($expectedMembers.Count -ne [int]$group.GroupItems.Count) { throw "stale_scene: native Group member count changed" }
                $baselineMembers = @()
                for ($index = 1; $index -le $group.GroupItems.Count; $index++) {
                    $member = $group.GroupItems.Item($index)
                    $expected = @($expectedMembers | Where-Object { [int](Get-ObjectPropertyValue $_ "nativeShapeId") -eq [int]$member.Id })[0]
                    if ($null -eq $expected -or [string](Get-ObjectPropertyValue $expected "expectedShapeName") -ne [string]$member.Name) { throw "stale_scene: native Group member identity changed" }
                    $path = @((Get-ObjectPropertyValue $expected "relativeMemberPath"))
                    if ($path.Count -ne 1 -or [int]$path[0] -ne $index) { throw "stale_scene: native Group member order changed" }
                    $baselineMembers += @{ index = $index; snapshot = (Get-PptShapeSnapshot $member @([int]$groupTopIndex, $index)) }
                }
                $rollbackKind = "undo_ungroup"
                $rollbackState = @{ groupNativeShapeId = [int]$group.Id; groupName = [string]$group.Name; baselineMembers = @($baselineMembers) }
                $removedGroupNativeShapeId = [int]$group.Id
                $null = $group.Ungroup()
                $wroteToWps = $true
                if ($null -ne (Get-PptShapeIndexByNativeId $slide $removedGroupNativeShapeId)) { throw "ungroup_shape readback still contains Group" }
                $actualMembers = @()
                $actualMemberIds = @()
                $nativePropertiesPreserved = $true
                foreach ($entry in $baselineMembers) {
                    $baseline = Get-ObjectPropertyValue $entry "snapshot"
                    $nativeShapeId = [int](Get-ObjectPropertyValue $baseline "nativeShapeId")
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide $nativeShapeId
                    if ($null -eq $shapeIndex) { throw "ungroup_shape member missing after write: $nativeShapeId" }
                    $member = $slide.Shapes.Item([int]$shapeIndex)
                    $actualSnapshot = Get-PptShapeSnapshot $member
                    if (@(Get-PptSpecializedSnapshotIssues $baseline $actualSnapshot).Count -gt 0) { $nativePropertiesPreserved = $false }
                    $actualMemberIds += $nativeShapeId
                    $actualMembers += @{ nativeShapeId = $nativeShapeId; expectedShapeName = [string]$member.Name; relativeMemberPath = @([int](Get-ObjectPropertyValue $entry "index")); nativeTypeCode = [int]$member.Type; geometry = @{ left = [double]$member.Left; top = [double]$member.Top; width = [double]$member.Width; height = [double]$member.Height; rotation = [double]$member.Rotation; zOrder = $(try { [int]$member.ZOrderPosition } catch { $null }) } }
                }
                if (-not $nativePropertiesPreserved) { throw "ungroup_shape changed member native properties" }
                $readback = @{ groupRemoved = $true; removedGroupNativeShapeId = $removedGroupNativeShapeId; memberNativeShapeIds = @($actualMemberIds); members = @($actualMembers); nativePropertiesPreserved = $true }
            }
            "set_object_link" {
                $shape = Resolve-PptSpecializedShapeTarget $slide (Get-ObjectPropertyValue $action "target") $actionName
                $baseline = Get-PptObjectLinkEvidence $shape
                $rollbackKind = "link"
                $rollbackState = @{ nativeShapeId = [int]$shape.Id; baseline = $baseline }
                $setting = $shape.ActionSettings.Item(1)
                $setting.Action = 7
                $setting.Hyperlink.Address = [string](Get-ObjectPropertyValue $action "url")
                $setting.Hyperlink.SubAddress = ""
                $wroteToWps = $true
                $readback = Get-PptObjectLinkEvidence $shape
                if ([int]$readback.action -ne 7 -or [string]$readback.address -ne [string](Get-ObjectPropertyValue $action "url") -or [string]$readback.subAddress -ne "") { throw "set_object_link readback mismatch" }
            }
            "clear_object_link" {
                $shape = Resolve-PptSpecializedShapeTarget $slide (Get-ObjectPropertyValue $action "target") $actionName
                $baseline = Get-PptObjectLinkEvidence $shape
                $rollbackKind = "link"
                $rollbackState = @{ nativeShapeId = [int]$shape.Id; baseline = $baseline }
                $setting = $shape.ActionSettings.Item(1)
                $setting.Hyperlink.Address = ""
                $setting.Hyperlink.SubAddress = ""
                $setting.Action = -1
                $wroteToWps = $true
                $readback = Get-PptObjectLinkEvidence $shape
                if (@(-1, 0) -notcontains [int]$readback.action -or [string]$readback.address -ne "" -or [string]$readback.subAddress -ne "") { throw "clear_object_link readback mismatch" }
            }
            "merge_table_cells" {
                $shape = Resolve-PptSpecializedShapeTarget $slide (Get-ObjectPropertyValue $action "target") $actionName
                $baselineTopology = Get-PptTableTopologyEvidence $shape
                $baselineSnapshot = Get-PptShapeSnapshot $shape
                if ([int]$baselineTopology.rows -ne [int](Get-ObjectPropertyValue (Get-ObjectPropertyValue $action "baseline") "rows") -or [int]$baselineTopology.columns -ne [int](Get-ObjectPropertyValue (Get-ObjectPropertyValue $action "baseline") "columns")) { throw "stale_scene: table dimensions changed" }
                $first = Get-ObjectPropertyValue $action "firstCell"
                $last = Get-ObjectPropertyValue $action "lastCell"
                $rollbackKind = "undo_table"
                $rollbackState = @{ nativeShapeId = [int]$shape.Id; baselineTopology = $baselineTopology; baselineSnapshot = $baselineSnapshot }
                $shape.Table.Cell([int](Get-ObjectPropertyValue $first "row"), [int](Get-ObjectPropertyValue $first "column")).Merge($shape.Table.Cell([int](Get-ObjectPropertyValue $last "row"), [int](Get-ObjectPropertyValue $last "column")))
                $wroteToWps = $true
                $signatureCount = Get-PptTableRegionSignatureCount $shape ([int](Get-ObjectPropertyValue $first "row")) ([int](Get-ObjectPropertyValue $first "column")) ([int](Get-ObjectPropertyValue $last "row")) ([int](Get-ObjectPropertyValue $last "column"))
                if ($signatureCount -ne 1) { throw "merge_table_cells topology readback mismatch" }
                $readback = @{ merged = $true; nativeShapeId = [int]$shape.Id; rows = [int]$shape.Table.Rows.Count; columns = [int]$shape.Table.Columns.Count; firstCell = $first; lastCell = $last; observedCellRegions = $signatureCount }
            }
            "split_table_cell" {
                $shape = Resolve-PptSpecializedShapeTarget $slide (Get-ObjectPropertyValue $action "target") $actionName
                $baselineTopology = Get-PptTableTopologyEvidence $shape
                $baselineSnapshot = Get-PptShapeSnapshot $shape
                if ([int]$baselineTopology.rows -ne [int](Get-ObjectPropertyValue (Get-ObjectPropertyValue $action "baseline") "rows") -or [int]$baselineTopology.columns -ne [int](Get-ObjectPropertyValue (Get-ObjectPropertyValue $action "baseline") "columns")) { throw "stale_scene: table dimensions changed" }
                $cell = Get-ObjectPropertyValue $action "cell"
                $splitRows = [int](Get-ObjectPropertyValue $action "rows")
                $splitColumns = [int](Get-ObjectPropertyValue $action "columns")
                $row = [int](Get-ObjectPropertyValue $cell "row")
                $column = [int](Get-ObjectPropertyValue $cell "column")
                if ($splitRows -ne 1 -or $splitColumns -ne 2 -or $column -ge [int]$shape.Table.Columns.Count) { throw "split_table_cell only qualifies a 1x2 horizontal split within the current table" }
                $mergedWidthBefore = [double]$shape.Table.Cell($row, $column).Shape.Width
                $mergedHeightBefore = [double]$shape.Table.Cell($row, $column).Shape.Height
                $rollbackKind = "undo_table"
                $rollbackState = @{ nativeShapeId = [int]$shape.Id; baselineTopology = $baselineTopology; baselineSnapshot = $baselineSnapshot }
                $shape.Table.Cell($row, $column).Split($splitRows, $splitColumns)
                $wroteToWps = $true
                $firstWidth = [double]$shape.Table.Cell($row, $column).Shape.Width
                $secondWidth = [double]$shape.Table.Cell($row, $column + 1).Shape.Width
                $firstHeight = [double]$shape.Table.Cell($row, $column).Shape.Height
                $secondHeight = [double]$shape.Table.Cell($row, $column + 1).Shape.Height
                if ([Math]::Abs(($firstWidth + $secondWidth) - $mergedWidthBefore) -gt 0.25 -or [Math]::Abs($firstHeight - $mergedHeightBefore) -gt 0.25 -or [Math]::Abs($secondHeight - $mergedHeightBefore) -gt 0.25) { throw "split_table_cell topology readback mismatch" }
                $readback = @{ split = $true; nativeShapeId = [int]$shape.Id; rows = [int]$shape.Table.Rows.Count; columns = [int]$shape.Table.Columns.Count; cell = $cell; splitRows = $splitRows; splitColumns = $splitColumns; mergedWidthBefore = $mergedWidthBefore; splitWidths = @($firstWidth, $secondWidth) }
            }
            "set_chart_workbook_cells" {
                $shape = Resolve-PptSpecializedShapeTarget $slide (Get-ObjectPropertyValue $action "target") $actionName
                if ([int]$shape.Type -ne 3) { throw "set_chart_workbook_cells target is not a Chart" }
                $cellDefinitions = @((Get-ObjectPropertyValue $action "cells"))
                $baseline = Get-PptChartWorkbookEvidence $shape $cellDefinitions
                $rollbackKind = "chart_workbook"
                $rollbackState = @{ nativeShapeId = [int]$shape.Id; baseline = $baseline; cellDefinitions = @($cellDefinitions) }
                $sheet = Get-PptChartDataSheet $shape.Chart
                foreach ($definition in $cellDefinitions) {
                    $cell = $sheet.Cells.Item([int](Get-ObjectPropertyValue $definition "row"), [int](Get-ObjectPropertyValue $definition "column"))
                    $valueKind = [string](Get-ObjectPropertyValue $definition "valueKind")
                    if ($valueKind -eq "clear") {
                        $cell.ClearContents() | Out-Null
                    } elseif ($valueKind -eq "number") {
                        $cell.Formula = [Convert]::ToString(
                            [double](Get-ObjectPropertyValue $definition "value"),
                            [System.Globalization.CultureInfo]::InvariantCulture
                        )
                    } else {
                        $cell.Value2 = [string](Get-ObjectPropertyValue $definition "value")
                    }
                    $wroteToWps = $true
                }
                $actual = Get-PptChartWorkbookEvidence $shape $cellDefinitions
                $cells = @()
                for ($index = 0; $index -lt $cellDefinitions.Count; $index++) {
                    $definition = $cellDefinitions[$index]
                    $actualCell = @((Get-ObjectPropertyValue $actual "cells"))[$index]
                    $actualValue = Get-ObjectPropertyValue $actualCell "value"
                    $actualKind = if ($null -eq $actualValue) { "clear" } elseif ($actualValue -is [byte] -or $actualValue -is [int16] -or $actualValue -is [int32] -or $actualValue -is [int64] -or $actualValue -is [single] -or $actualValue -is [double] -or $actualValue -is [decimal]) { "number" } else { "text" }
                    if ($actualKind -ne [string](Get-ObjectPropertyValue $definition "valueKind")) { throw "set_chart_workbook_cells value kind readback mismatch" }
                    if ($actualKind -ne "clear" -and [string]$actualValue -ne [string](Get-ObjectPropertyValue $definition "value")) { throw "set_chart_workbook_cells value readback mismatch" }
                    $cells += @{ row = [int](Get-ObjectPropertyValue $definition "row"); column = [int](Get-ObjectPropertyValue $definition "column"); valueKind = $actualKind; value = $actualValue }
                }
                $readback = @{
                    nativeShapeId = [int]$shape.Id
                    cells = @($cells)
                    seriesFormulas = @((Get-ObjectPropertyValue $actual "seriesFormulas"))
                }
            }
        }
        if ($null -ne $testControl -and [bool](Get-ObjectPropertyValue $testControl "failAfterWrite")) { throw "scene_specialized_injected_failure_after_write" }
        $afterResult = Get-PptPresentationSceneResult $pres
        if (-not $afterResult.success) { throw $afterResult.error }
        return @{ success = $true; data = @{ transactional = $true; wroteToWps = $wroteToWps; rolledBack = $false; rollbackVerified = $false; operationId = $operationId; operation = $operation; action = $actionName; compiledPlanFingerprint = $compiledPlanFingerprint; presentationFingerprintBefore = $beforeFingerprint; presentationFingerprintAfter = [string]$afterResult.data.fingerprint; readback = $readback; rollbackIssues = @() } }
    } catch { $failureReason = $_.Exception.Message }

    $rollbackIssues = @()
    if ($wroteToWps) {
        try {
            switch ($rollbackKind) {
                "ungroup_created_group" {
                    $groupIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "groupNativeShapeId")
                    if ($null -eq $groupIndex) { throw "created Group rollback target missing" }
                    $null = $slide.Shapes.Item([int]$groupIndex).Ungroup()
                }
                "undo_ungroup" { Invoke-PptUndo 1 $pres.Application }
                "link" {
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "nativeShapeId")
                    if ($null -eq $shapeIndex) { throw "link rollback target missing" }
                    Set-PptObjectLinkEvidence ($slide.Shapes.Item([int]$shapeIndex)) (Get-ObjectPropertyValue $rollbackState "baseline")
                }
                "undo_table" { Invoke-PptUndo 1 $pres.Application }
                "chart_workbook" {
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "nativeShapeId")
                    if ($null -eq $shapeIndex) { throw "chart rollback target missing" }
                    Restore-PptChartWorkbookEvidence ($slide.Shapes.Item([int]$shapeIndex)) (Get-ObjectPropertyValue $rollbackState "baseline")
                }
            }
        } catch { $rollbackIssues += @{ code = "specialized_rollback_failed"; message = $_.Exception.Message } }
    }
    $afterRollback = Get-PptPresentationSceneResult $pres
    $afterFingerprint = $(if ($afterRollback.success) { [string]$afterRollback.data.fingerprint } else { "" })
    if (-not $afterRollback.success) {
        $rollbackIssues += @{ code = "rollback_presentation_readback_failed"; message = [string]$afterRollback.error }
    } elseif ($afterFingerprint -ne $beforeFingerprint) {
        $rollbackIssues += @{ code = "rollback_presentation_fingerprint_mismatch"; expected = $beforeFingerprint; actual = $afterFingerprint }
    }
    if ($wroteToWps) {
        try {
            switch ($rollbackKind) {
                "ungroup_created_group" {
                    $baselineSnapshots = @((Get-ObjectPropertyValue $rollbackState "baselineSnapshots"))
                    foreach ($baseline in $baselineSnapshots) {
                        $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $baseline "nativeShapeId")
                        if ($null -eq $shapeIndex -or @(Get-PptSpecializedSnapshotIssues $baseline (Get-PptShapeSnapshot ($slide.Shapes.Item([int]$shapeIndex)))).Count -gt 0) { throw "group rollback member mismatch" }
                    }
                }
                "undo_ungroup" {
                    $groupIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "groupNativeShapeId")
                    if ($null -eq $groupIndex) { throw "ungroup rollback did not restore the original Group" }
                    $group = $slide.Shapes.Item([int]$groupIndex)
                    $baselineMembers = @((Get-ObjectPropertyValue $rollbackState "baselineMembers"))
                    if ([int]$group.GroupItems.Count -ne $baselineMembers.Count) { throw "ungroup rollback member count mismatch" }
                    $restoredMembers = @()
                    foreach ($entry in $baselineMembers) {
                        $baseline = Get-ObjectPropertyValue $entry "snapshot"
                        $member = Find-PptShapeByNativeIdRecursive $group.GroupItems (Get-ObjectPropertyValue $baseline "nativeShapeId")
                        if ($null -eq $member -or @(Get-PptSpecializedSnapshotIssues $baseline (Get-PptShapeSnapshot $member)).Count -gt 0) { throw "ungroup rollback member mismatch" }
                        $restoredMembers += @{ nativeShapeId = [int]$member.Id; expectedShapeName = [string]$member.Name; relativeMemberPath = @([int](Get-ObjectPropertyValue $entry "index")); nativeTypeCode = [int]$member.Type; geometry = @{ left = [double]$member.Left; top = [double]$member.Top; width = [double]$member.Width; height = [double]$member.Height; rotation = [double]$member.Rotation; zOrder = $(try { [int]$member.ZOrderPosition } catch { $null }) } }
                    }
                    $readback = @{ groupRestored = $true; groupNativeShapeId = [int]$group.Id; nativePropertiesRestored = $true; members = @($restoredMembers) }
                }
                "link" {
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "nativeShapeId")
                    if ($null -eq $shapeIndex -or -not (Test-PptObjectLinkEvidenceEqual (Get-ObjectPropertyValue $rollbackState "baseline") (Get-PptObjectLinkEvidence ($slide.Shapes.Item([int]$shapeIndex))))) { throw "link rollback readback mismatch" }
                }
                "undo_table" {
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "nativeShapeId")
                    if ($null -eq $shapeIndex) { throw "table rollback target missing" }
                    $shape = $slide.Shapes.Item([int]$shapeIndex)
                    if (-not (Test-PptTableTopologyEvidenceEqual (Get-ObjectPropertyValue $rollbackState "baselineTopology") (Get-PptTableTopologyEvidence $shape))) { throw "table rollback topology mismatch" }
                    if (@(Get-PptSpecializedSnapshotIssues (Get-ObjectPropertyValue $rollbackState "baselineSnapshot") (Get-PptShapeSnapshot $shape)).Count -gt 0) { throw "table rollback property mismatch" }
                }
                "chart_workbook" {
                    $shapeIndex = Get-PptShapeIndexByNativeId $slide (Get-ObjectPropertyValue $rollbackState "nativeShapeId")
                    if ($null -eq $shapeIndex) { throw "chart rollback target missing" }
                    $actual = Get-PptChartWorkbookEvidence ($slide.Shapes.Item([int]$shapeIndex)) (Get-ObjectPropertyValue $rollbackState "cellDefinitions")
                    if (-not (Test-PptChartWorkbookEvidenceEqual (Get-ObjectPropertyValue $rollbackState "baseline") $actual)) { throw "chart workbook rollback readback mismatch" }
                }
            }
        } catch { $rollbackIssues += @{ code = "specialized_rollback_readback_failed"; message = $_.Exception.Message } }
    }
    $rollbackVerified = ($wroteToWps -and $rollbackIssues.Count -eq 0)
    return @{ success = $false; error = $failureReason; data = @{ transactional = $true; wroteToWps = $wroteToWps; rolledBack = $wroteToWps; rollbackVerified = $rollbackVerified; operationId = $operationId; operation = $operation; action = $actionName; compiledPlanFingerprint = $compiledPlanFingerprint; presentationFingerprintBefore = $beforeFingerprint; presentationFingerprintAfter = $afterFingerprint; reason = $failureReason; readback = $readback; rollbackIssues = @($rollbackIssues) } }
}

function Get-PptSceneCreationPlanResult($pres, $options) {
    $actions = @((Get-ObjectPropertyValue $options "actions"))
    if ($actions.Count -lt 1) {
        return (New-PptRecoverableError "PPT_SCENE_CREATION_PLAN_EMPTY" "Scene creation plan requires at least one action." @{})
    }
    $beforeResult = Get-PptPresentationSceneResult $pres
    if (-not $beforeResult.success) { return $beforeResult }
    $beforeFingerprint = [string]$beforeResult.data.fingerprint
    # The opening readback is the transaction's verified native snapshot.
    # Re-reading Slides.Count for every draft can produce a transiently stale
    # COM value under host pressure even though the full readback just passed.
    $authoritativeSlideCount = [int]$beforeResult.data.presentation.slideCount
    $createdSlidesByClientRef = @{}
    $createdSlides = New-Object System.Collections.ArrayList
    $creationTracker = @{
        createdShapes = (New-Object System.Collections.ArrayList)
    }
    $receipts = @()
    $wroteToWps = $false
    $testControl = Get-ObjectPropertyValue $options "testControl"
    $failureReason = ""
    try {
        foreach ($action in $actions) {
            $resultIndex = [int](Get-ObjectPropertyValue $action "resultIndex")
            $operationId = [string](Get-ObjectPropertyValue $action "operationId")
            if ($null -ne $testControl -and -not [string]::IsNullOrWhiteSpace([string](Get-ObjectPropertyValue $testControl "failBeforeOperationId")) -and $operationId -eq [string](Get-ObjectPropertyValue $testControl "failBeforeOperationId")) {
                throw "scene_creation_injected_failure_before_operation:$operationId"
            }
            if ($null -ne $testControl -and $null -ne (Get-ObjectPropertyValue $testControl "failBeforeResultIndex") -and $resultIndex -eq [int](Get-ObjectPropertyValue $testControl "failBeforeResultIndex")) {
                throw "scene_creation_injected_failure_before:$resultIndex"
            }
            $entityClass = [string](Get-ObjectPropertyValue $action "entityClass")
            $adapterAction = [string](Get-ObjectPropertyValue $action "adapterAction")
            if ($entityClass -eq "slide") {
                if (@("add_slide", "duplicate_slide") -notcontains $adapterAction) {
                    throw "Slide entity does not support adapter action '$adapterAction'"
                }
                $insertAt = [int](Get-ObjectPropertyValue $action "insertAt")
                if ($insertAt -lt 1 -or $insertAt -gt ($authoritativeSlideCount + 1)) {
                    throw "Slide insertAt is out of range: $insertAt"
                }
                $slide = $null
                if ($adapterAction -eq "add_slide") {
                    if ($null -ne (Get-ObjectPropertyValue $action "layoutRef")) {
                        throw "creation_layout_ref_adapter_unavailable"
                    }
                    $slide = $pres.Slides.Add($insertAt, 12)
                    $createdSlides.Add(@{
                        clientRef = [string](Get-ObjectPropertyValue $action "clientRef")
                        slide = $slide
                        nativeSlideId = $(try { [int]$slide.SlideID } catch { $null })
                    }) | Out-Null
                } else {
                    $source = Get-ObjectPropertyValue $action "sourceSlide"
                    $resolvedSource = Resolve-PptSlideBinding $pres (Get-ObjectPropertyValue $source "slideIndex") (Get-ObjectPropertyValue $source "nativeSlideId") "executePptSceneCreationPlan"
                    if (-not $resolvedSource.ok) { throw $resolvedSource.result.error }
                    $slide = $resolvedSource.slide.Duplicate().Item(1)
                    $createdSlides.Add(@{
                        clientRef = [string](Get-ObjectPropertyValue $action "clientRef")
                        slide = $slide
                        nativeSlideId = $(try { [int]$slide.SlideID } catch { $null })
                    }) | Out-Null
                    if ([int]$slide.SlideIndex -ne $insertAt) { $slide.MoveTo($insertAt) }
                }
                $nativeSlideId = $(try { [int]$slide.SlideID } catch { throw "Created slide identity unavailable" })
                $clientRef = [string](Get-ObjectPropertyValue $action "clientRef")
                $createdSlidesByClientRef[$clientRef] = $nativeSlideId
                $authoritativeSlideCount += 1
                $wroteToWps = $true
                $receipts += @{
                    operationId = [string](Get-ObjectPropertyValue $action "operationId")
                    resultIndex = $resultIndex
                    clientRef = $clientRef
                    entityClass = "slide"
                    kind = "slide"
                    nativeSlideId = $nativeSlideId
                    slideIndex = [int]$slide.SlideIndex
                    sourceRefs = @((Get-ObjectPropertyValue $action "sourceRefs"))
                    evidenceRefs = @((Get-ObjectPropertyValue $action "evidenceRefs"))
                }
            } elseif ($entityClass -eq "element") {
                $resolvedParent = Resolve-PptCreationPlanSlide $pres (Get-ObjectPropertyValue $action "parent") $createdSlidesByClientRef "executePptSceneCreationPlan"
                $shape = New-PptSceneCreationShape $resolvedParent.slide $action $creationTracker
                $nativeShapeId = $(try { [int]$shape.Id } catch { throw "Created shape identity unavailable" })
                $wroteToWps = $true
                if ($null -ne $testControl -and $null -ne (Get-ObjectPropertyValue $testControl "corruptReadbackResultIndex") -and $resultIndex -eq [int](Get-ObjectPropertyValue $testControl "corruptReadbackResultIndex")) {
                    $shape.Name = "SceneV2_Injected_Readback_Mismatch"
                    throw "scene_creation_injected_readback_mismatch:$resultIndex"
                }
                $receipts += Get-PptSceneCreationReceipt $resolvedParent.slide $shape $action
            } else {
                throw "Unsupported Scene creation entityClass '$entityClass'"
            }
            if ($null -ne $testControl -and $null -ne (Get-ObjectPropertyValue $testControl "failAfterResultIndex") -and $resultIndex -eq [int](Get-ObjectPropertyValue $testControl "failAfterResultIndex")) {
                throw "scene_creation_injected_failure_after:$resultIndex"
            }
        }
        $afterResult = Get-PptPresentationSceneResult $pres
        if (-not $afterResult.success) { throw $afterResult.error }
        return @{
            success = $true
            data = @{
                transactional = $true
                wroteToWps = $true
                rolledBack = $false
                rollbackVerified = $false
                presentationFingerprintBefore = $beforeFingerprint
                presentationFingerprintAfter = [string]$afterResult.data.fingerprint
                receipts = @($receipts)
            }
        }
    } catch {
        $failureReason = $_.Exception.Message
    }

    $effectiveWroteToWps = (
        $wroteToWps -or
        $createdSlides.Count -gt 0 -or
        $creationTracker.createdShapes.Count -gt 0
    )
    $rollbackIssues = @()
    for ($createdShapeIndex = $creationTracker.createdShapes.Count - 1; $createdShapeIndex -ge 0; $createdShapeIndex--) {
        $createdShape = $creationTracker.createdShapes[$createdShapeIndex]
        try {
            $trackedShape = Get-ObjectPropertyValue $createdShape "shape"
            $trackedShape.Delete()
        } catch {
            $rollbackIssues += @{ code = "rollback_created_shape_delete_failed"; nativeSlideId = Get-ObjectPropertyValue $createdShape "nativeSlideId"; nativeShapeId = Get-ObjectPropertyValue $createdShape "nativeShapeId"; message = $_.Exception.Message }
        }
    }
    for ($createdSlideIndex = $createdSlides.Count - 1; $createdSlideIndex -ge 0; $createdSlideIndex--) {
        $createdSlide = $createdSlides[$createdSlideIndex]
        try {
            $trackedSlide = Get-ObjectPropertyValue $createdSlide "slide"
            $trackedSlide.Delete()
        } catch {
            $rollbackIssues += @{ code = "rollback_created_slide_delete_failed"; nativeSlideId = Get-ObjectPropertyValue $createdSlide "nativeSlideId"; message = $_.Exception.Message }
        }
    }
    foreach ($createdSlide in $createdSlides) {
        $nativeSlideId = Get-ObjectPropertyValue $createdSlide "nativeSlideId"
        $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "verifyPptSceneCreationRollback"
        if ($resolvedSlide.ok) {
            $rollbackIssues += @{ code = "rollback_created_slide_still_exists"; nativeSlideId = $nativeSlideId }
        }
    }
    foreach ($createdShape in $creationTracker.createdShapes) {
        $nativeSlideId = Get-ObjectPropertyValue $createdShape "nativeSlideId"
        $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "verifyPptSceneCreationRollback"
        if (-not $resolvedSlide.ok) { continue }
        $nativeShapeId = Get-ObjectPropertyValue $createdShape "nativeShapeId"
        if ($null -ne (Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId)) {
            $rollbackIssues += @{ code = "rollback_created_shape_still_exists"; nativeSlideId = $nativeSlideId; nativeShapeId = $nativeShapeId }
        }
    }
    $afterRollback = Get-PptPresentationSceneResult $pres
    $afterFingerprint = $(if ($afterRollback.success) { [string]$afterRollback.data.fingerprint } else { "" })
    if (-not $afterRollback.success) {
        $rollbackIssues += @{ code = "rollback_presentation_readback_failed"; message = [string]$afterRollback.error }
    } elseif ($afterFingerprint -ne $beforeFingerprint) {
        $rollbackIssues += @{ code = "rollback_presentation_fingerprint_mismatch"; expected = $beforeFingerprint; actual = $afterFingerprint }
    }
    $rollbackVerified = $rollbackIssues.Count -eq 0
    return @{
        success = $false
        error = $failureReason
        data = @{
            transactional = $true
            wroteToWps = $effectiveWroteToWps
            rolledBack = $effectiveWroteToWps
            rollbackVerified = $rollbackVerified
            presentationFingerprintBefore = $beforeFingerprint
            presentationFingerprintAfter = $afterFingerprint
            reason = $failureReason
            rollbackIssues = @($rollbackIssues)
            receipts = @($receipts)
        }
    }
}

function Get-PptSceneCreationCommitRollbackResult($pres, $options) {
    $beforeFingerprint = [string](Get-ObjectPropertyValue $options "presentationFingerprintBefore")
    $receipts = @((Get-ObjectPropertyValue $options "receipts"))
    if ([string]::IsNullOrWhiteSpace($beforeFingerprint) -or $receipts.Count -lt 1) {
        return (New-PptRecoverableError "PPT_SCENE_CREATION_ROLLBACK_INPUT_INVALID" "Creation rollback requires the write-before fingerprint and at least one receipt." @{})
    }
    $rollbackIssues = @()

    for ($receiptIndex = $receipts.Count - 1; $receiptIndex -ge 0; $receiptIndex--) {
        $receipt = $receipts[$receiptIndex]
        if ([string](Get-ObjectPropertyValue $receipt "entityClass") -ne "element") { continue }
        $nativeSlideId = [int](Get-ObjectPropertyValue $receipt "nativeSlideId")
        $nativeShapeId = [int](Get-ObjectPropertyValue $receipt "nativeShapeId")
        try {
            $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "rollbackPptSceneCreationCommit"
            if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
            $shapeIndex = Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId
            if ($null -eq $shapeIndex) { throw "Created shape is unavailable: $nativeShapeId" }
            $shape = $resolvedSlide.slide.Shapes.Item([int]$shapeIndex)
            $expectedName = [string](Get-ObjectPropertyValue $receipt "name")
            if (-not [string]::IsNullOrWhiteSpace($expectedName) -and [string]$shape.Name -ne $expectedName) {
                throw "Created shape name mismatch: expected '$expectedName', got '$($shape.Name)'"
            }
            $expectedTypeCode = Get-ObjectPropertyValue $receipt "nativeTypeCode"
            if ($null -ne $expectedTypeCode -and [int]$shape.Type -ne [int]$expectedTypeCode) {
                throw "Created shape type mismatch: expected '$expectedTypeCode', got '$($shape.Type)'"
            }
            $shape.Delete()
        } catch {
            $rollbackIssues += @{
                code = "creation_commit_rollback_shape_delete_failed"
                nativeSlideId = $nativeSlideId
                nativeShapeId = $nativeShapeId
                message = $_.Exception.Message
            }
        }
    }

    for ($receiptIndex = $receipts.Count - 1; $receiptIndex -ge 0; $receiptIndex--) {
        $receipt = $receipts[$receiptIndex]
        if ([string](Get-ObjectPropertyValue $receipt "entityClass") -ne "slide") { continue }
        $nativeSlideId = [int](Get-ObjectPropertyValue $receipt "nativeSlideId")
        try {
            $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "rollbackPptSceneCreationCommit"
            if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
            $resolvedSlide.slide.Delete()
        } catch {
            $rollbackIssues += @{
                code = "creation_commit_rollback_slide_delete_failed"
                nativeSlideId = $nativeSlideId
                message = $_.Exception.Message
            }
        }
    }

    foreach ($receipt in $receipts) {
        $nativeSlideId = [int](Get-ObjectPropertyValue $receipt "nativeSlideId")
        if ([string](Get-ObjectPropertyValue $receipt "entityClass") -eq "slide") {
            $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "verifyPptSceneCreationCommitRollback"
            if ($resolvedSlide.ok) {
                $rollbackIssues += @{
                    code = "creation_commit_rollback_slide_still_exists"
                    nativeSlideId = $nativeSlideId
                }
            }
            continue
        }
        $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "verifyPptSceneCreationCommitRollback"
        if (-not $resolvedSlide.ok) { continue }
        $nativeShapeId = [int](Get-ObjectPropertyValue $receipt "nativeShapeId")
        if ($null -ne (Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId)) {
            $rollbackIssues += @{
                code = "creation_commit_rollback_shape_still_exists"
                nativeSlideId = $nativeSlideId
                nativeShapeId = $nativeShapeId
            }
        }
    }

    $afterRollback = Get-PptPresentationSceneResult $pres
    $afterFingerprint = $(if ($afterRollback.success) { [string]$afterRollback.data.fingerprint } else { "" })
    if (-not $afterRollback.success) {
        $rollbackIssues += @{
            code = "creation_commit_rollback_readback_failed"
            message = [string]$afterRollback.error
        }
    } elseif ($afterFingerprint -ne $beforeFingerprint) {
        $rollbackIssues += @{
            code = "creation_commit_rollback_fingerprint_mismatch"
            expected = $beforeFingerprint
            actual = $afterFingerprint
        }
    }
    $rollbackVerified = $rollbackIssues.Count -eq 0
    return @{
        success = $rollbackVerified
        error = $(if ($rollbackVerified) { $null } else { "PPT Scene creation commit rollback could not be verified" })
        data = @{
            transactional = $true
            wroteToWps = $true
            rolledBack = $true
            rollbackVerified = $rollbackVerified
            presentationFingerprintBefore = $beforeFingerprint
            presentationFingerprintAfter = $afterFingerprint
            rollbackIssues = @($rollbackIssues)
        }
    }
}

function Get-PptSceneMixedRollbackState($pres) {
    $slides = @()
    for ($slideIndex = 1; $slideIndex -le $pres.Slides.Count; $slideIndex++) {
        $slide = $pres.Slides.Item($slideIndex)
        $slides += @{
            nativeSlideId = [int]$slide.SlideID
            hidden = $(try { [int]$slide.SlideShowTransition.Hidden -ne 0 } catch { $false })
            followMasterBackground = $(try { [int]$slide.FollowMasterBackground -ne 0 } catch { $true })
            fillType = $(try { [int]$slide.Background.Fill.Type } catch { -1 })
            fillColor = $(try { [int]$slide.Background.Fill.ForeColor.RGB } catch { $null })
            nativeShapeIds = @(Get-PptNativeShapeOrder $slide)
        }
    }
    return @{
        nativeSlideIds = @(Get-PptNativeSlideOrder $pres)
        pageSize = @{
            width = [double]$pres.PageSetup.SlideWidth
            height = [double]$pres.PageSetup.SlideHeight
        }
        slides = @($slides)
    }
}

function Restore-PptSceneMixedRollbackState($pres, $state, $creationReceipts) {
    $issues = @()
    $receipts = @($creationReceipts)
    for ($receiptIndex = $receipts.Count - 1; $receiptIndex -ge 0; $receiptIndex--) {
        $receipt = $receipts[$receiptIndex]
        if ([string](Get-ObjectPropertyValue $receipt "entityClass") -ne "element") { continue }
        try {
            $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $receipt "nativeSlideId") "rollbackPptSceneMixedCreatedShape"
            if (-not $resolved.ok) { continue }
            $nativeShapeId = [int](Get-ObjectPropertyValue $receipt "nativeShapeId")
            $shapeIndex = Get-PptShapeIndexByNativeId $resolved.slide $nativeShapeId
            if ($null -ne $shapeIndex) { $resolved.slide.Shapes.Item([int]$shapeIndex).Delete() }
        } catch {
            $issues += @{ code = "mixed_rollback_created_shape_delete_failed"; message = $_.Exception.Message; nativeShapeId = Get-ObjectPropertyValue $receipt "nativeShapeId" }
        }
    }
    for ($receiptIndex = $receipts.Count - 1; $receiptIndex -ge 0; $receiptIndex--) {
        $receipt = $receipts[$receiptIndex]
        if ([string](Get-ObjectPropertyValue $receipt "entityClass") -ne "slide") { continue }
        try {
            $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $receipt "nativeSlideId") "rollbackPptSceneMixedCreatedSlide"
            if ($resolved.ok) { $resolved.slide.Delete() }
        } catch {
            $issues += @{ code = "mixed_rollback_created_slide_delete_failed"; message = $_.Exception.Message; nativeSlideId = Get-ObjectPropertyValue $receipt "nativeSlideId" }
        }
    }

    try {
        $pageSize = Get-ObjectPropertyValue $state "pageSize"
        $pres.PageSetup.SlideWidth = [double](Get-ObjectPropertyValue $pageSize "width")
        $pres.PageSetup.SlideHeight = [double](Get-ObjectPropertyValue $pageSize "height")
    } catch {
        $issues += @{ code = "mixed_rollback_page_size_failed"; message = $_.Exception.Message }
    }

    foreach ($slideState in @((Get-ObjectPropertyValue $state "slides"))) {
        try {
            $resolved = Resolve-PptSlideBinding $pres $null (Get-ObjectPropertyValue $slideState "nativeSlideId") "rollbackPptSceneMixedSlide"
            if (-not $resolved.ok) { throw $resolved.result.error }
            $slide = $resolved.slide
            $slide.SlideShowTransition.Hidden = [bool](Get-ObjectPropertyValue $slideState "hidden")
            if ([bool](Get-ObjectPropertyValue $slideState "followMasterBackground")) {
                $slide.FollowMasterBackground = $true
            } else {
                $slide.FollowMasterBackground = $false
                if ([int](Get-ObjectPropertyValue $slideState "fillType") -eq 1) { $slide.Background.Fill.Solid() }
                if ($null -ne (Get-ObjectPropertyValue $slideState "fillColor")) {
                    $slide.Background.Fill.ForeColor.RGB = [int](Get-ObjectPropertyValue $slideState "fillColor")
                }
            }
            $baselineShapeIds = @((Get-ObjectPropertyValue $slideState "nativeShapeIds") | Where-Object { $null -ne $_ })
            if ($baselineShapeIds.Count -gt 0) {
                Set-PptNativeShapeOrder $slide $baselineShapeIds
            }
        } catch {
            $issues += @{ code = "mixed_rollback_slide_state_failed"; message = $_.Exception.Message; nativeSlideId = Get-ObjectPropertyValue $slideState "nativeSlideId" }
        }
    }
    try {
        Restore-PptNativeSlideOrder $pres (Get-ObjectPropertyValue $state "nativeSlideIds")
    } catch {
        $issues += @{ code = "mixed_rollback_slide_order_failed"; message = $_.Exception.Message }
    }
    return @($issues)
}

function Get-PptSceneMixedCreationReceipt($creationReceipts, $creationRef) {
    $operationId = [string](Get-ObjectPropertyValue $creationRef "operationId")
    $resultIndex = [int](Get-ObjectPropertyValue $creationRef "resultIndex")
    $matches = @($creationReceipts | Where-Object {
        [string](Get-ObjectPropertyValue $_ "operationId") -eq $operationId -and
        [int](Get-ObjectPropertyValue $_ "resultIndex") -eq $resultIndex
    })
    if ($matches.Count -ne 1) {
        throw "scene_creation_ref_result_unavailable:$operationId#$resultIndex"
    }
    $receipt = $matches[0]
    if ([string](Get-ObjectPropertyValue $receipt "entityClass") -ne "element") {
        throw "scene_creation_ref_requires_element_result:$operationId#$resultIndex"
    }
    return $receipt
}

function Assert-PptSceneMixedNearlyEqual($actual, $expected, [double]$tolerance, [string]$field) {
    if ($null -eq $actual -or [Math]::Abs([double]$actual - [double]$expected) -gt $tolerance) {
        throw "scene_creation_result_edit_readback_mismatch:$field expected=$expected actual=$actual"
    }
}

function Assert-PptSceneMixedCreationResultReadback($step, $summary) {
    $adapterOperations = @((Get-ObjectPropertyValue $step "adapterOperations"))
    foreach ($adapterOperation in $adapterOperations) {
        $type = [string](Get-ObjectPropertyValue $adapterOperation "type")
        switch ($type) {
            "setTextboxText" {
                $expected = [string](Get-ObjectPropertyValue $adapterOperation "text")
                $actual = [string](Get-ObjectPropertyValue $summary "text")
                if ($actual -cne $expected) {
                    throw "scene_creation_result_edit_readback_mismatch:text expected=$expected actual=$actual"
                }
                break
            }
            "setShapePosition" {
                foreach ($field in @("left", "top", "width", "height")) {
                    $expected = Get-ObjectPropertyValue $adapterOperation $field
                    if ($null -eq $expected) { continue }
                    Assert-PptSceneMixedNearlyEqual (Get-ObjectPropertyValue $summary $field) $expected 0.5 "geometry.$field"
                }
                break
            }
            "setShapeStyle" {
                $style = Get-ObjectPropertyValue $adapterOperation "style"
                $summaryStyle = Get-ObjectPropertyValue $summary "style"
                $fill = Get-ObjectPropertyValue $summaryStyle "fill"
                $line = Get-ObjectPropertyValue $summaryStyle "line"
                $fillColor = Get-ObjectPropertyValue $style "fillColor"
                if ($null -ne $fillColor -and [string](Get-ObjectPropertyValue $fill "colorHex") -ine [string]$fillColor) {
                    throw "scene_creation_result_edit_readback_mismatch:fillColor"
                }
                $lineColor = Get-ObjectPropertyValue $style "lineColor"
                if ($null -ne $lineColor -and [string](Get-ObjectPropertyValue $line "colorHex") -ine [string]$lineColor) {
                    throw "scene_creation_result_edit_readback_mismatch:lineColor"
                }
                foreach ($pair in @(
                    @{ source = "lineWidth"; target = "width"; tolerance = 0.25 },
                    @{ source = "transparency"; target = "transparency"; tolerance = 0.01 },
                    @{ source = "lineTransparency"; target = "transparency"; tolerance = 0.01 }
                )) {
                    $expected = Get-ObjectPropertyValue $style ([string]$pair.source)
                    if ($null -eq $expected) { continue }
                    $container = if ([string]$pair.source -eq "transparency") { $fill } else { $line }
                    Assert-PptSceneMixedNearlyEqual (Get-ObjectPropertyValue $container ([string]$pair.target)) $expected ([double]$pair.tolerance) ([string]$pair.source)
                }
                $dash = Get-ObjectPropertyValue $style "lineDashStyle"
                if ($null -ne $dash -and [string](Get-ObjectPropertyValue $line "dashStyle") -ne [string]$dash) {
                    throw "scene_creation_result_edit_readback_mismatch:lineDashStyle"
                }
                break
            }
            "setTextBoxStyle" {
                $style = Get-ObjectPropertyValue $adapterOperation "style"
                $summaryStyle = Get-ObjectPropertyValue (Get-ObjectPropertyValue $summary "style") "text"
                $alignmentMap = @{ left = 1; center = 2; right = 3 }
                $verticalMap = @{ top = 1; middle = 3; bottom = 4 }
                foreach ($field in @("fontSize", "marginLeft", "marginRight", "marginTop", "marginBottom")) {
                    $expected = Get-ObjectPropertyValue $style $field
                    if ($null -eq $expected) { continue }
                    Assert-PptSceneMixedNearlyEqual (Get-ObjectPropertyValue $summaryStyle $field) $expected 0.25 "text.$field"
                }
                foreach ($field in @("fontName", "bold", "italic")) {
                    $expected = Get-ObjectPropertyValue $style $field
                    if ($null -eq $expected) { continue }
                    if ((Get-ObjectPropertyValue $summaryStyle $field) -ne $expected) {
                        throw "scene_creation_result_edit_readback_mismatch:text.$field"
                    }
                }
                $fontColor = Get-ObjectPropertyValue $style "fontColor"
                if ($null -ne $fontColor -and [string](Get-ObjectPropertyValue $summaryStyle "fontColorHex") -ine [string]$fontColor) {
                    throw "scene_creation_result_edit_readback_mismatch:text.fontColor"
                }
                $alignment = Get-ObjectPropertyValue $style "alignment"
                if ($null -ne $alignment -and [int](Get-ObjectPropertyValue $summaryStyle "alignment") -ne [int]$alignmentMap[[string]$alignment]) {
                    throw "scene_creation_result_edit_readback_mismatch:text.alignment"
                }
                $vertical = Get-ObjectPropertyValue $style "verticalAlignment"
                if ($null -ne $vertical -and [int](Get-ObjectPropertyValue $summaryStyle "verticalAnchor") -ne [int]$verticalMap[[string]$vertical]) {
                    throw "scene_creation_result_edit_readback_mismatch:text.verticalAlignment"
                }
                break
            }
        }
    }
    $requiresContentFit = @((Get-ObjectPropertyValue $step "assertions") | Where-Object {
        [string](Get-ObjectPropertyValue $_ "predicate") -eq "content_fits"
    }).Count -gt 0
    if ($requiresContentFit -and [bool](Get-ObjectPropertyValue $summary "textOverflow")) {
        throw "scene_creation_result_edit_readback_mismatch:content_fits"
    }
}

function Invoke-PptSceneMixedCreationResultEdit($pres, $step, $creationReceipts) {
    $receipt = Get-PptSceneMixedCreationReceipt $creationReceipts (Get-ObjectPropertyValue $step "creationRef")
    $nativeSlideId = [int](Get-ObjectPropertyValue $receipt "nativeSlideId")
    $nativeShapeId = [int](Get-ObjectPropertyValue $receipt "nativeShapeId")
    $resolvedSlide = Resolve-PptSlideBinding $pres $null $nativeSlideId "executePptSceneMixedCreationResultEdit"
    if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
    $shapeIndex = Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId
    if ($null -eq $shapeIndex) {
        throw "scene_creation_ref_created_object_missing:$nativeSlideId#$nativeShapeId"
    }
    $shape = $resolvedSlide.slide.Shapes.Item([int]$shapeIndex)
    $expectedName = [string](Get-ObjectPropertyValue $receipt "name")
    if (-not [string]::IsNullOrWhiteSpace($expectedName) -and [string]$shape.Name -ne $expectedName) {
        throw "scene_creation_ref_created_object_name_mismatch:$nativeShapeId"
    }
    $adapterOperations = @((Get-ObjectPropertyValue $step "adapterOperations"))
    if ($adapterOperations.Count -lt 1) {
        throw "scene_creation_result_edit_adapter_operations_missing"
    }
    $changed = @()
    foreach ($adapterOperation in $adapterOperations) {
        $type = [string](Get-ObjectPropertyValue $adapterOperation "type")
        $operationId = [string](Get-ObjectPropertyValue $adapterOperation "operationId")
        $applied = @()
        switch ($type) {
            "setTextboxText" {
                if (-not [bool]($shape.HasTextFrame -ne 0)) { throw "Target is not text-capable" }
                $text = Get-ObjectPropertyValue $adapterOperation "text"
                if ($null -eq $text) { $text = "" }
                $shape.TextFrame.TextRange.Text = [string]$text
                $applied += "text"
                break
            }
            "setShapePosition" {
                $applied = @(Set-PptShapePositionValues $shape $adapterOperation)
                if ($applied.Count -eq 0) { throw "setShapePosition did not apply left/top/width/height" }
                break
            }
            "setShapeStyle" {
                $style = Get-ObjectPropertyValue $adapterOperation "style"
                if ($null -eq $style) { throw "setShapeStyle requires style" }
                $applied = @(Set-PptShapeStyleValues $shape $style)
                if ($applied.Count -eq 0) { throw "setShapeStyle did not apply any supported property" }
                break
            }
            "setTextBoxStyle" {
                if (-not [bool]($shape.HasTextFrame -ne 0)) { throw "Target is not text-capable" }
                $style = Get-ObjectPropertyValue $adapterOperation "style"
                if ($null -eq $style) { throw "setTextBoxStyle requires style" }
                $geometrySnapshot = Get-PptShapeGeometrySnapshot $shape
                $applied = @(Set-PptTextFrameStyleValues $shape $style)
                if ($applied.Count -eq 0) { throw "setTextBoxStyle did not apply any supported property" }
                if ([bool](Get-ObjectPropertyValue $adapterOperation "preserveGeometry")) {
                    Restore-PptShapeGeometrySnapshot $shape $geometrySnapshot
                }
                break
            }
            default {
                throw "unsupported mixed creation-result adapter type:$type"
            }
        }
        $changed += @{
            operationId = $operationId
            type = $type
            nativeSlideId = $nativeSlideId
            nativeShapeId = $nativeShapeId
            name = [string]$shape.Name
            applied = @($applied)
        }
    }
    $readbackIndex = Get-PptShapeIndexByNativeId $resolvedSlide.slide $nativeShapeId
    if ($null -eq $readbackIndex) { throw "scene_creation_result_edit_readback_missing:$nativeShapeId" }
    $summary = Get-PptShapeSummary ($resolvedSlide.slide.Shapes.Item([int]$readbackIndex)) ([int]$readbackIndex) 10000
    Assert-PptSceneMixedCreationResultReadback $step $summary
    return @{
        changed = @($changed)
        readback = $summary
        nativeSlideId = $nativeSlideId
        nativeShapeId = $nativeShapeId
    }
}

function Get-PptSceneMixedPlanResult($pres, $options) {
    $steps = @((Get-ObjectPropertyValue $options "steps"))
    if ($steps.Count -lt 1) {
        return (New-PptRecoverableError "PPT_SCENE_MIXED_PLAN_TOO_SMALL" "Scene mixed plan requires at least one compiled step." @{})
    }
    $beforeResult = Get-PptPresentationSceneResult $pres
    if (-not $beforeResult.success) { return $beforeResult }
    $beforeFingerprint = [string]$beforeResult.data.fingerprint
    $rollbackState = Get-PptSceneMixedRollbackState $pres
    $testControl = Get-ObjectPropertyValue $options "testControl"
    $creationReceipts = @()
    $stepReadbacks = @()
    $successfulDeleteUndoCount = 0
    $wroteToWps = $false
    $failureReason = ""
    try {
        for ($stepIndex = 0; $stepIndex -lt $steps.Count; $stepIndex++) {
            if ($null -ne $testControl -and $null -ne (Get-ObjectPropertyValue $testControl "failBeforeStepIndex") -and $stepIndex -eq [int](Get-ObjectPropertyValue $testControl "failBeforeStepIndex")) {
                throw "scene_mixed_injected_failure_before_step:$stepIndex"
            }
            $step = $steps[$stepIndex]
            $stepKind = [string](Get-ObjectPropertyValue $step "stepKind")
            $operationId = [string](Get-ObjectPropertyValue $step "operationId")
            if ($stepKind -eq "creation") {
                $stepResult = Get-PptSceneCreationPlanResult $pres @{ actions = @((Get-ObjectPropertyValue $step "actions")) }
                $stepData = Get-ObjectPropertyValue $stepResult "data"
                if ($null -ne $stepData -and [bool](Get-ObjectPropertyValue $stepData "wroteToWps")) { $wroteToWps = $true }
                if (-not [bool](Get-ObjectPropertyValue $stepResult "success")) {
                    throw ([string](Get-ObjectPropertyValue $stepResult "error"))
                }
                $receipts = @((Get-ObjectPropertyValue $stepData "receipts"))
                $creationReceipts += @($receipts)
                $stepReadbacks += @{ stepIndex = $stepIndex; operationId = $operationId; stepKind = $stepKind; creationCount = $receipts.Count }
            } elseif ($stepKind -eq "creation_result_edit") {
                $editResult = Invoke-PptSceneMixedCreationResultEdit $pres $step $creationReceipts
                $wroteToWps = $true
                $stepReadbacks += @{
                    stepIndex = $stepIndex
                    operationId = $operationId
                    stepKind = $stepKind
                    changed = @((Get-ObjectPropertyValue $editResult "changed"))
                    readback = Get-ObjectPropertyValue $editResult "readback"
                    nativeSlideId = Get-ObjectPropertyValue $editResult "nativeSlideId"
                    nativeShapeId = Get-ObjectPropertyValue $editResult "nativeShapeId"
                }
            } elseif ($stepKind -eq "structural") {
                $action = Get-ObjectPropertyValue $step "action"
                $structuralActionName = [string](Get-ObjectPropertyValue $action "action")
                if ($structuralActionName -eq "delete_entities" -and $stepIndex -ne ($steps.Count - 1)) {
                    throw "mixed_delete_entities_must_be_final_operation"
                }
                $stepResult = Get-PptSceneStructuralPlanResult $pres @{ action = $action }
                $stepData = Get-ObjectPropertyValue $stepResult "data"
                if ($null -ne $stepData -and [bool](Get-ObjectPropertyValue $stepData "wroteToWps")) { $wroteToWps = $true }
                if (-not [bool](Get-ObjectPropertyValue $stepResult "success")) {
                    throw ([string](Get-ObjectPropertyValue $stepResult "error"))
                }
                if ($structuralActionName -eq "delete_entities") {
                    foreach ($target in @((Get-ObjectPropertyValue $action "targets"))) {
                        if ([string](Get-ObjectPropertyValue $target "targetKind") -eq "slide") {
                            $successfulDeleteUndoCount++
                        } else {
                            $successfulDeleteUndoCount += @((Get-ObjectPropertyValue $target "nativeShapeIds") | Where-Object { $null -ne $_ }).Count
                        }
                    }
                }
                $stepReadbacks += @{ stepIndex = $stepIndex; operationId = $operationId; stepKind = $stepKind; readback = Get-ObjectPropertyValue $stepData "readback" }
            } else {
                throw "unsupported mixed step kind: $stepKind"
            }
            if ($null -ne $testControl -and $null -ne (Get-ObjectPropertyValue $testControl "failAfterStepIndex") -and $stepIndex -eq [int](Get-ObjectPropertyValue $testControl "failAfterStepIndex")) {
                throw "scene_mixed_injected_failure_after_step:$stepIndex"
            }
        }
        $afterResult = Get-PptPresentationSceneResult $pres
        if (-not $afterResult.success) { throw $afterResult.error }
        return @{
            success = $true
            data = @{
                transactional = $true
                wroteToWps = $wroteToWps
                rolledBack = $false
                rollbackVerified = $false
                presentationFingerprintBefore = $beforeFingerprint
                presentationFingerprintAfter = [string]$afterResult.data.fingerprint
                creationReceipts = @($creationReceipts)
                stepReadbacks = @($stepReadbacks)
                rollbackIssues = @()
            }
        }
    } catch {
        $failureReason = $_.Exception.Message
    }

    $rollbackIssues = @()
    if ($wroteToWps) {
        if ($successfulDeleteUndoCount -gt 0) {
            try {
                Invoke-PptUndo $successfulDeleteUndoCount $pres.Application
            } catch {
                $rollbackIssues += @{ code = "mixed_rollback_delete_undo_failed"; message = $_.Exception.Message; undoCount = $successfulDeleteUndoCount }
            }
        }
        $rollbackIssues += @(Restore-PptSceneMixedRollbackState $pres $rollbackState $creationReceipts)
    }
    $afterRollback = Get-PptPresentationSceneResult $pres
    $afterFingerprint = $(if ($afterRollback.success) { [string]$afterRollback.data.fingerprint } else { "" })
    if (-not $afterRollback.success) {
        $rollbackIssues += @{ code = "mixed_rollback_presentation_readback_failed"; message = [string]$afterRollback.error }
    } elseif ($afterFingerprint -ne $beforeFingerprint) {
        $rollbackIssues += @{ code = "mixed_rollback_presentation_fingerprint_mismatch"; expected = $beforeFingerprint; actual = $afterFingerprint }
    }
    if ($null -ne $testControl -and [bool](Get-ObjectPropertyValue $testControl "forceRollbackUnverified")) {
        $rollbackIssues += @{ code = "test_injected_rollback_verification_failure" }
    }
    $rollbackVerified = ($wroteToWps -and $rollbackIssues.Count -eq 0)
    return @{
        success = $false
        error = $failureReason
        data = @{
            transactional = $true
            wroteToWps = $wroteToWps
            rolledBack = $wroteToWps
            rollbackVerified = $rollbackVerified
            presentationFingerprintBefore = $beforeFingerprint
            presentationFingerprintAfter = $afterFingerprint
            reason = $failureReason
            creationReceipts = @($creationReceipts)
            stepReadbacks = @($stepReadbacks)
            rollbackIssues = @($rollbackIssues)
        }
    }
}

if ($ParamsFromStdin) {
    try {
        $reader = [System.IO.StreamReader]::new(
            [Console]::OpenStandardInput(),
            [System.Text.Encoding]::UTF8,
            $false
        )
        try { $Params = $reader.ReadToEnd() } finally { $reader.Dispose() }
        if ([string]::IsNullOrWhiteSpace($Params)) { $Params = "{}" }
    } catch {
        Output-Json (New-PptRecoverableError `
            "PARAMS_STDIN_READ_FAILED" `
            "Failed to read UTF-8 parameters from stdin: $($_.Exception.Message)" `
            @{ suggestedAction = "retry_transport" })
        exit
    }
}

if (-not [string]::IsNullOrWhiteSpace($ParamsFromFile)) {
    try {
        $Params = [System.IO.File]::ReadAllText(
            [System.IO.Path]::GetFullPath($ParamsFromFile),
            [System.Text.Encoding]::UTF8
        )
    } catch {
        Output-Json (New-PptRecoverableError `
            "PARAMS_FILE_READ_FAILED" `
            "Failed to read UTF-8 parameter file: $($_.Exception.Message)" `
            @{ suggestedAction = "retry_transport" })
        exit
    } finally {
        try {
            if (Test-Path -LiteralPath $ParamsFromFile) {
                Remove-Item -LiteralPath $ParamsFromFile -Force -ErrorAction SilentlyContinue
            }
        } catch {}
    }
}

try {
    $p = $Params | ConvertFrom-Json
} catch {
    Output-Json (New-PptRecoverableError `
        "INVALID_PARAMS_JSON" `
        "Invalid -Params JSON: $($_.Exception.Message). Pass a valid JSON string, for example: '{`"slideIndex`":1}'." `
        @{ rawParams = $Params; suggestedAction = "fix_params_json_then_retry" })
    exit
}

if ([string]$env:WPS_PS_ACTION_DISPATCH_MARKER -eq "1") {
    [Console]::Error.WriteLine("__WPS_ACTION_DISPATCHED__")
}

# A complete deck is emitted through multiple short-lived PowerShell
# processes. Bind the requested presentation inside this same process before
# executing the native action so ActivePresentation cannot drift between
# calls. Callers that do not provide presentationId retain legacy behavior.
if ($null -ne $p.presentationId -and -not [string]::IsNullOrWhiteSpace([string]$p.presentationId)) {
    try {
        $boundPpt = Get-WpsPpt
        if ($null -eq $boundPpt) { throw "WPS PPT not running" }
        $boundPresentation = Get-WpsPptPresentationById $boundPpt ([string]$p.presentationId)
        if ($null -eq $boundPresentation) { throw "Presentation not found: $($p.presentationId)" }
        $boundName = [string]$boundPresentation.Name
        $boundFullName = ""
        $boundRuntimeLocator = Get-PptRuntimePresentationLocator $boundPresentation
        try { $boundFullName = [string]$boundPresentation.FullName } catch {}
        if (
            $boundName -ne [string]$p.presentationId -and
            $boundFullName -ne [string]$p.presentationId -and
            $boundRuntimeLocator -ne [string]$p.presentationId
        ) {
            throw "Presentation binding mismatch: expected=$($p.presentationId), actualName=$boundName, actualFullName=$boundFullName"
        }
        $skipBindingActivation = (
            [string]$Action -eq "managePptPresentation" -and
            @("save", "save_as", "close") -contains [string]$p.lifecycleAction
        )
        if (-not $skipBindingActivation) {
            $boundPresentation.Windows.Item(1).Activate()
        }
        # ActivePresentation is process-global UI state and another WPS window
        # may take focus immediately after Activate(). The direct COM object is
        # the authority for this action; do not turn a harmless focus race into
        # a false binding failure.
        $script:BoundPptPresentation = $boundPresentation
    } catch {
        Output-Json @{ success = $false; error = "bound_presentation_unavailable: $($_.Exception.Message)" }
        exit
    }
}

switch ($Action) {

    # ==================== Common ====================
    "ping" {
        Output-Json @{ success = $true; data = @{ message = "pong"; timestamp = [DateTimeOffset]::Now.ToUnixTimeMilliseconds() } }
    }

    "wireCheck" {
        Output-Json @{ success = $true; data = @{ message = "WPS MCP Bridge 已连接" } }
    }

    "getAppInfo" {
        $excel = Get-WpsExcel
        if ($null -ne $excel) {
            $hasSelection = $false
            try { $hasSelection = ($null -ne $excel.Selection) } catch {}
            Output-Json @{ success = $true; data = @{ appType = "excel"; appName = $excel.Name; hasSelection = $hasSelection } }
            exit
        }
        $word = Get-WpsWord
        if ($null -ne $word) {
            $hasSelection = $false
            try { $hasSelection = ($null -ne $word.Selection) } catch {}
            Output-Json @{ success = $true; data = @{ appType = "word"; appName = $word.Name; hasSelection = $hasSelection } }
            exit
        }
        $ppt = Get-WpsPpt
        if ($null -ne $ppt) {
            $hasSelection = $false
            try { $hasSelection = ($null -ne $ppt.ActiveWindow.Selection) } catch {}
            Output-Json @{ success = $true; data = @{ appType = "ppt"; appName = $ppt.Name; hasSelection = $hasSelection } }
            exit
        }
        Output-Json @{ success = $false; error = "No WPS application running" }
    }

    "getSelectedText" {
        $word = Get-WpsWord
        if ($null -ne $word) {
            try {
                $text = $word.Selection.Text
                Output-Json @{ success = $true; data = @{ text = $text.Trim() } }
            } catch {
                Output-Json @{ success = $false; error = "Word selection not available" }
            }
            exit
        }
        $excel = Get-WpsExcel
        if ($null -ne $excel) {
            try {
                $sel = $excel.Selection
                $text = if ($sel -is [string]) { $sel } else { $sel.Text }
                Output-Json @{ success = $true; data = @{ text = [string]$text } }
            } catch {
                Output-Json @{ success = $false; error = "Excel selection not available" }
            }
            exit
        }
        $ppt = Get-WpsPpt
        if ($null -ne $ppt) {
            try {
                $sel = $ppt.ActiveWindow.Selection
                if ($sel -and $sel.TextRange) {
                    $text = $sel.TextRange.Text
                    Output-Json @{ success = $true; data = @{ text = [string]$text } }
                } else {
                    Output-Json @{ success = $false; error = "PPT selection has no text" }
                }
            } catch {
                Output-Json @{ success = $false; error = "PPT selection not available" }
            }
            exit
        }
        Output-Json @{ success = $false; error = "No WPS application running" }
    }

    "setSelectedText" {
        $text = if ($null -ne $p.text) { [string]$p.text } else { "" }
        $word = Get-WpsWord
        if ($null -ne $word) {
            try {
                $word.Selection.Text = $text
                Output-Json @{ success = $true }
            } catch {
                Output-Json @{ success = $false; error = "Word selection not available" }
            }
            exit
        }
        $excel = Get-WpsExcel
        if ($null -ne $excel) {
            try {
                $sel = $excel.Selection
                $sel.Value2 = $text
                Output-Json @{ success = $true }
            } catch {
                Output-Json @{ success = $false; error = "Excel selection not available" }
            }
            exit
        }
        $ppt = Get-WpsPpt
        if ($null -ne $ppt) {
            try {
                $sel = $ppt.ActiveWindow.Selection
                if ($sel -and $sel.TextRange) {
                    $sel.TextRange.Text = $text
                    Output-Json @{ success = $true }
                } else {
                    Output-Json @{ success = $false; error = "PPT selection has no text" }
                }
            } catch {
                Output-Json @{ success = $false; error = "PPT selection not available" }
            }
            exit
        }
        Output-Json @{ success = $false; error = "No WPS application running" }
    }

    "save" {
        $excel = Get-WpsExcel
        if ($null -ne $excel -and $null -ne $excel.ActiveWorkbook) {
            $excel.ActiveWorkbook.Save()
            Output-Json @{ success = $true; app = "excel" }
            exit
        }
        $word = Get-WpsWord
        if ($null -ne $word -and $null -ne $word.ActiveDocument) {
            $word.ActiveDocument.Save()
            Output-Json @{ success = $true; app = "word" }
            exit
        }
        $ppt = Get-WpsPpt
        $pres = if ($null -ne $ppt) { Get-WpsPptPresentation $ppt } else { $null }
        if ($null -ne $pres) {
            $pres.Save()
            Output-Json @{ success = $true; app = "ppt" }
            exit
        }
        Output-Json @{ success = $false; error = "No active document" }
    }

    "saveAs" {
        $path = $p.path
        if (-not $path) { Output-Json @{ success = $false; error = "Path required" }; exit }
        $appType = if ($p.appType) { $p.appType } else { Get-AppTypeByExtension $path }
        if ($appType -eq 'excel') {
            $excel = Get-WpsExcel
            if ($null -eq $excel -or $null -eq $excel.ActiveWorkbook) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
            $format = Get-ExcelFileFormat $p.format
            if ($null -ne $format) { $excel.ActiveWorkbook.SaveAs($path, $format) }
            else { $excel.ActiveWorkbook.SaveAs($path) }
            Output-Json @{ success = $true; data = @{ path = $path; appType = "excel" } }
            exit
        }
        if ($appType -eq 'word') {
            $word = Get-WpsWord
            if ($null -eq $word -or $null -eq $word.ActiveDocument) { Output-Json @{ success = $false; error = "No active document" }; exit }
            $format = Get-WordSaveFormat $p.format
            if ($null -ne $format) { $word.ActiveDocument.SaveAs($path, $format) }
            else { $word.ActiveDocument.SaveAs($path) }
            Output-Json @{ success = $true; data = @{ path = $path; appType = "word" } }
            exit
        }
        if ($appType -eq 'ppt') {
            $ppt = Get-WpsPpt
            $pres = if ($null -ne $ppt) { Get-WpsPptPresentation $ppt } else { $null }
            if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
            $format = Get-PptSaveFormat $p.format
            if ($null -ne $format) { $pres.SaveAs($path, $format) }
            else { $pres.SaveAs($path) }
            Output-Json @{ success = $true; data = @{ path = $path; appType = "ppt" } }
            exit
        }
        Output-Json @{ success = $false; error = "Unknown app type" }
    }

    "openFile" {
        $path = $p.path
        if (-not $path) { Output-Json @{ success = $false; error = "Path required" }; exit }
        $appType = if ($p.appType) { $p.appType } else { Get-AppTypeByExtension $path }
        if ($appType -eq 'excel') {
            $excel = Get-WpsExcel
            if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
            $excel.Workbooks.Open($path)
            Output-Json @{ success = $true; data = @{ path = $path; appType = "excel" } }
            exit
        }
        if ($appType -eq 'word') {
            $word = Get-WpsWord
            if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
            $word.Documents.Open($path)
            Output-Json @{ success = $true; data = @{ path = $path; appType = "word" } }
            exit
        }
        if ($appType -eq 'ppt') {
            $ppt = Get-WpsPpt
            if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
            $ppt.Presentations.Open($path)
            Output-Json @{ success = $true; data = @{ path = $path; appType = "ppt" } }
            exit
        }
        Output-Json @{ success = $false; error = "Unknown app type" }
    }

    "createDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $word.Documents.Add() | Out-Null
        Output-Json @{ success = $true }
    }

    "createPresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $beforeCount = 0
        try { $beforeCount = [int]$ppt.Presentations.Count } catch {}
        $pres = $null
        try { $pres = $ppt.Presentations.Add() } catch {
            Output-Json @{ success = $false; error = "Failed to create presentation: $($_.Exception.Message)" }
            exit
        }
        for ($attempt = 0; $attempt -lt 20 -and $null -eq $pres; $attempt++) {
            Start-Sleep -Milliseconds 50
            try { $pres = Get-WpsPptPresentation $ppt } catch {}
            if ($null -eq $pres) {
                try {
                    if ([int]$ppt.Presentations.Count -gt $beforeCount) {
                        $pres = $ppt.Presentations.Item($ppt.Presentations.Count)
                    }
                } catch {}
            }
        }
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "Presentation was created but WPS did not expose it as an active COM object" }; exit }
        try { $pres.Windows.Item(1).Activate() } catch {}
        $name = ""
        $slideCount = 0
        try { $name = [string]$pres.Name } catch {}
        try { $slideCount = [int]$pres.Slides.Count } catch {}
        Output-Json @{ success = $true; data = @{
            name = $name
            runtimeLocator = Get-PptRuntimePresentationLocator $pres
            slideCount = $slideCount
        } }
    }

    "convertToPDF" {
        $excel = Get-WpsExcel
        if ($null -ne $excel -and $null -ne $excel.ActiveWorkbook) {
            $wb = $excel.ActiveWorkbook
            $sourcePath = $wb.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, 'pdf') }
            $wb.ExportAsFixedFormat(0, $outputPath)
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "excel" } }
            exit
        }
        $word = Get-WpsWord
        if ($null -ne $word -and $null -ne $word.ActiveDocument) {
            $doc = $word.ActiveDocument
            $sourcePath = $doc.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, 'pdf') }
            $doc.ExportAsFixedFormat($outputPath, 17)
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "word" } }
            exit
        }
        $ppt = Get-WpsPpt
        if ($null -ne $ppt -and $null -ne (Get-WpsPptPresentation $ppt)) {
            $pres = Get-WpsPptPresentation $ppt
            $sourcePath = $pres.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, 'pdf') }
            $pres.SaveAs($outputPath, 32)
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "ppt" } }
            exit
        }
        Output-Json @{ success = $false; error = "No active document" }
    }

    "convertFormat" {
        $targetFormat = $p.targetFormat
        if (-not $targetFormat) { Output-Json @{ success = $false; error = "targetFormat required" }; exit }
        $excel = Get-WpsExcel
        if ($null -ne $excel -and $null -ne $excel.ActiveWorkbook) {
            $wb = $excel.ActiveWorkbook
            $sourcePath = $wb.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, $targetFormat) }
            $format = Get-ExcelFileFormat $targetFormat
            if ($null -ne $format) { $wb.SaveAs($outputPath, $format) } else { $wb.SaveAs($outputPath) }
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "excel"; targetFormat = $targetFormat } }
            exit
        }
        $word = Get-WpsWord
        if ($null -ne $word -and $null -ne $word.ActiveDocument) {
            $doc = $word.ActiveDocument
            $sourcePath = $doc.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, $targetFormat) }
            $format = Get-WordSaveFormat $targetFormat
            if ($null -ne $format) { $doc.SaveAs($outputPath, $format) } else { $doc.SaveAs($outputPath) }
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "word"; targetFormat = $targetFormat } }
            exit
        }
        $ppt = Get-WpsPpt
        if ($null -ne $ppt -and $null -ne (Get-WpsPptPresentation $ppt)) {
            $pres = Get-WpsPptPresentation $ppt
            $sourcePath = $pres.FullName
            $outputPath = if ($p.outputPath) { $p.outputPath } else { [System.IO.Path]::ChangeExtension($sourcePath, $targetFormat) }
            $format = Get-PptSaveFormat $targetFormat
            if ($null -ne $format) { $pres.SaveAs($outputPath, $format) } else { $pres.SaveAs($outputPath) }
            Output-Json @{ success = $true; data = @{ sourcePath = $sourcePath; outputPath = $outputPath; appType = "ppt"; targetFormat = $targetFormat } }
            exit
        }
        Output-Json @{ success = $false; error = "No active document" }
    }

    # ==================== Excel Basic ====================
    "getActiveWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheets = @()
        for ($i = 1; $i -le $wb.Sheets.Count; $i++) { $sheets += $wb.Sheets.Item($i).Name }
        Output-Json @{ success = $true; data = @{ name = $wb.Name; path = $wb.FullName; sheetCount = $wb.Sheets.Count; sheets = $sheets } }
    }

    "getCellValue" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $cell = $sheet.Cells.Item($p.row, $p.col)
        Output-Json @{ success = $true; data = @{ value = $cell.Value2; text = $cell.Text; formula = $cell.Formula } }
    }

    "setCellValue" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $sheet.Cells.Item($p.row, $p.col).Value2 = $p.value
        Output-Json @{ success = $true }
    }

    "getRangeData" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $range = $sheet.Range($p.range)
        $data = @()
        for ($r = 1; $r -le $range.Rows.Count; $r++) {
            $row = @()
            for ($c = 1; $c -le $range.Columns.Count; $c++) { $row += $range.Cells.Item($r, $c).Value2 }
            $data += ,@($row)
        }
        Output-Json @{ success = $true; data = @{ data = $data } }
    }

    "setRangeData" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $range = $sheet.Range($p.range)
        for ($r = 0; $r -lt $p.data.Count; $r++) {
            for ($c = 0; $c -lt $p.data[$r].Count; $c++) { $range.Cells.Item($r + 1, $c + 1).Value2 = $p.data[$r][$c] }
        }
        Output-Json @{ success = $true }
    }

    "diagnoseFormula" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $excel.ActiveSheet
        $cell = $sheet.Range($p.cell)
        $value = $cell.Value2
        $formula = $cell.Formula
        $errorType = $null
        $diagnosis = ""
        $suggestion = ""
        $precedents = @()
        if ($value -is [string] -and $value.StartsWith('#')) {
            $errorType = $value
            switch ($errorType) {
                "#REF!" { $diagnosis = "引用了不存在的单元格或区域"; $suggestion = "检查引用区域是否被删除或移动" }
                "#N/A" { $diagnosis = "查找函数未找到匹配值"; $suggestion = "确认查找值存在，或检查匹配条件" }
                "#VALUE!" { $diagnosis = "参数类型不正确或运算类型不匹配"; $suggestion = "检查函数参数类型和引用单元格" }
                "#NAME?" { $diagnosis = "函数名或名称拼写错误"; $suggestion = "检查函数名是否正确" }
                "#DIV/0!" { $diagnosis = "除数为零"; $suggestion = "检查除数单元格，避免除以零" }
                "#NUM!" { $diagnosis = "数值无效或超出范围"; $suggestion = "检查函数参数范围" }
                "#NULL!" { $diagnosis = "交集为空"; $suggestion = "检查引用区域的交集是否存在" }
                default { $diagnosis = "未知错误"; $suggestion = "检查公式与引用" }
            }
        }
        try {
            $refs = $cell.DirectPrecedents
            if ($refs -ne $null) {
                foreach ($area in $refs.Areas) { $precedents += $area.Address() }
            }
        } catch {}
        Output-Json @{ success = $true; data = @{ cell = $p.cell; formula = $formula; currentValue = $value; errorType = $errorType; diagnosis = $diagnosis; suggestion = $suggestion; precedents = $precedents } }
    }

    "cleanData" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $range = $sheet.Range($p.range)
        $opsResult = @()
        foreach ($op in $p.operations) {
            $success = $true
            $message = ""
            switch ($op) {
                "trim" {
                    foreach ($cell in $range) {
                        if ($cell.Value2 -is [string]) { $cell.Value2 = $cell.Value2.Trim() }
                    }
                    $message = "已去除前后空格"
                }
                "remove_duplicates" {
                    $colCount = $range.Columns.Count
                    $cols = @()
                    for ($i = 1; $i -le $colCount; $i++) { $cols += $i }
                    $range.RemoveDuplicates($cols, 1)
                    $message = "已删除重复行"
                }
                "unify_date" {
                    foreach ($cell in $range) {
                        try {
                            if ($cell.Value2) {
                                $dt = [DateTime]::FromOADate($cell.Value2)
                                $cell.Value2 = $dt.ToString("yyyy-MM-dd")
                            }
                        } catch {}
                    }
                    $message = "已统一日期格式"
                }
                "remove_empty_rows" {
                    for ($i = $range.Rows.Count; $i -ge 1; $i--) {
                        $row = $range.Rows.Item($i)
                        $isEmpty = $true
                        foreach ($cell in $row.Cells) { if ($cell.Value2) { $isEmpty = $false; break } }
                        if ($isEmpty) { $row.Delete() }
                    }
                    $message = "已删除空行"
                }
                default { $success = $false; $message = "不支持的操作" }
            }
            $opsResult += @{ operation = $op; success = $success; message = $message }
        }
        Output-Json @{ success = $true; data = @{ range = $p.range; operations = $opsResult; message = "cleanData completed" } }
    }

    "createPivotTable" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sourceRange = Get-RangeFromAddress $wb $p.sourceRange
        $destSheet = if ($p.destinationSheet) { $wb.Sheets.Item($p.destinationSheet) } else { $excel.ActiveSheet }
        $destCell = $destSheet.Range($p.destinationCell)
        $pivotName = if ($p.tableName) { $p.tableName } else { "PivotTable" + [Guid]::NewGuid().ToString("N").Substring(0, 6) }
        $cache = $wb.PivotCaches().Create(1, $sourceRange)
        $table = $cache.CreatePivotTable($destCell, $pivotName)
        foreach ($fieldName in $p.rowFields) {
            $field = $table.PivotFields($fieldName)
            $field.Orientation = 1
            $field.Position = 1
        }
        if ($p.columnFields) {
            foreach ($fieldName in $p.columnFields) {
                $field = $table.PivotFields($fieldName)
                $field.Orientation = 2
                $field.Position = 1
            }
        }
        if ($p.filterFields) {
            foreach ($fieldName in $p.filterFields) {
                $field = $table.PivotFields($fieldName)
                $field.Orientation = 3
                $field.Position = 1
            }
        }
        foreach ($vf in $p.valueFields) {
            $field = $table.PivotFields($vf.field)
            $funcMap = @{ SUM = -4157; COUNT = -4112; AVERAGE = -4106; MAX = -4136; MIN = -4139 }
            $func = $funcMap[$vf.aggregation]
            if ($null -eq $func) { $func = -4157 }
            $table.AddDataField($field, $vf.field, $func) | Out-Null
        }
        Output-Json @{ success = $true; data = @{ pivotTableName = $pivotName; location = $destCell.Address(); rowCount = $table.RowRange.Rows.Count; columnCount = $table.TableRange1.Columns.Count } }
    }

    "updatePivotTable" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $excel.ActiveSheet
        $table = $null
        if ($p.pivotTableName) {
            try { $table = $sheet.PivotTables($p.pivotTableName) } catch {}
        }
        if ($null -eq $table -and $p.pivotTableCell) {
            try { $table = $sheet.Range($p.pivotTableCell).PivotTable } catch {}
        }
        if ($null -eq $table) { Output-Json @{ success = $false; error = "PivotTable not found" }; exit }
        $ops = @()
        if ($p.addRowFields) {
            foreach ($f in $p.addRowFields) {
                $field = $table.PivotFields($f); $field.Orientation = 1; $field.Position = 1
                $ops += @{ operation = "addRowFields"; success = $true; message = $f }
            }
        }
        if ($p.removeRowFields) {
            foreach ($f in $p.removeRowFields) {
                $field = $table.PivotFields($f); $field.Orientation = 0
                $ops += @{ operation = "removeRowFields"; success = $true; message = $f }
            }
        }
        if ($p.addColumnFields) {
            foreach ($f in $p.addColumnFields) {
                $field = $table.PivotFields($f); $field.Orientation = 2; $field.Position = 1
                $ops += @{ operation = "addColumnFields"; success = $true; message = $f }
            }
        }
        if ($p.removeColumnFields) {
            foreach ($f in $p.removeColumnFields) {
                $field = $table.PivotFields($f); $field.Orientation = 0
                $ops += @{ operation = "removeColumnFields"; success = $true; message = $f }
            }
        }
        if ($p.addFilterFields) {
            foreach ($f in $p.addFilterFields) {
                $field = $table.PivotFields($f); $field.Orientation = 3; $field.Position = 1
                $ops += @{ operation = "addFilterFields"; success = $true; message = $f }
            }
        }
        if ($p.removeFilterFields) {
            foreach ($f in $p.removeFilterFields) {
                $field = $table.PivotFields($f); $field.Orientation = 0
                $ops += @{ operation = "removeFilterFields"; success = $true; message = $f }
            }
        }
        if ($p.addValueFields) {
            foreach ($vf in $p.addValueFields) {
                $field = $table.PivotFields($vf.field)
                $funcMap = @{ SUM = -4157; COUNT = -4112; AVERAGE = -4106; MAX = -4136; MIN = -4139 }
                $func = $funcMap[$vf.aggregation]
                if ($null -eq $func) { $func = -4157 }
                $table.AddDataField($field, $vf.field, $func) | Out-Null
                $ops += @{ operation = "addValueFields"; success = $true; message = $vf.field }
            }
        }
        if ($p.updateValueFields) {
            foreach ($vf in $p.updateValueFields) {
                $field = $table.PivotFields($vf.field)
                $funcMap = @{ SUM = -4157; COUNT = -4112; AVERAGE = -4106; MAX = -4136; MIN = -4139 }
                $func = $funcMap[$vf.aggregation]
                if ($null -eq $func) { $func = -4157 }
                $field.Function = $func
                $ops += @{ operation = "updateValueFields"; success = $true; message = $vf.field }
            }
        }
        if ($p.removeValueFields) {
            foreach ($vf in $p.removeValueFields) {
                try { $table.DataFields($vf).Orientation = 0 } catch {}
                $ops += @{ operation = "removeValueFields"; success = $true; message = $vf }
            }
        }
        if ($p.refresh) { try { $table.RefreshTable() | Out-Null; $ops += @{ operation = "refresh"; success = $true; message = "refreshed" } } catch {} }
        Output-Json @{ success = $true; data = @{ pivotTableName = $table.Name; operations = $ops } }
    }

    "setFormula" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        $sheet = if ($p.sheet -is [int]) { $wb.Sheets.Item($p.sheet) } else { $wb.Sheets.Item($p.sheet) }
        $range = if ($p.range) { $sheet.Range($p.range) } else { $sheet.Cells.Item($p.row, $p.col) }
        $range.Formula = $p.formula
        Output-Json @{ success = $true }
    }

    "setCellFormat" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        if ($p.numberFormat) { $range.NumberFormat = $p.numberFormat }
        Output-Json @{ success = $true; data = @{ range = $p.range; format = $p.numberFormat } }
    }

    "setCellStyle" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        if ($p.fontSize) { $range.Font.Size = $p.fontSize }
        if ($null -ne $p.bold) { $range.Font.Bold = [bool]$p.bold }
        if ($null -ne $p.italic) { $range.Font.Italic = [bool]$p.italic }
        if ($p.fontName) { $range.Font.Name = $p.fontName }
        if ($p.backgroundColor) {
            $bg = Convert-HexColorToRgbInt([string]$p.backgroundColor)
            if ($null -ne $bg) { $range.Interior.Color = $bg }
        }
        if ($p.fontColor) {
            $fc = Convert-HexColorToRgbInt([string]$p.fontColor)
            if ($null -ne $fc) { $range.Font.Color = $fc }
        }
        if ($p.horizontalAlignment) {
            $hAlignMap = @{ left = -4131; center = -4108; right = -4152 }
            $hAlign = $hAlignMap[$p.horizontalAlignment]
            if ($null -ne $hAlign) { $range.HorizontalAlignment = $hAlign }
        }
        if ($p.verticalAlignment) {
            $vAlignMap = @{ top = -4160; center = -4108; bottom = -4107 }
            $vAlign = $vAlignMap[$p.verticalAlignment]
            if ($null -ne $vAlign) { $range.VerticalAlignment = $vAlign }
        }
        if ($null -ne $p.border -and $p.border) {
            $range.Borders.LineStyle = 1
            if ($p.borderColor) {
                $bc = Convert-HexColorToRgbInt([string]$p.borderColor)
                if ($null -ne $bc) { $range.Borders.Color = $bc }
            }
        }
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "setBorder" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $styleMap = @{ thin = 1; medium = 2; thick = 4; double = 6; none = 0 }
        $style = $styleMap[$p.style]
        if ($null -eq $style) { $style = 1 }
        $position = if ($p.position) { $p.position } else { "all" }
        $borders = @()
        if ($position -eq "all" -or $position -eq "outside") { $borders += 7, 8, 9, 10 }
        if ($position -eq "all" -or $position -eq "inside") { $borders += 11, 12 }
        if ($position -eq "left") { $borders += 7 }
        if ($position -eq "top") { $borders += 8 }
        if ($position -eq "bottom") { $borders += 9 }
        if ($position -eq "right") { $borders += 10 }
        $colorValue = $null
        if ($p.color) { $colorValue = Convert-HexColorToRgbInt([string]$p.color) }
        foreach ($b in $borders) {
            $border = $range.Borders.Item($b)
            if ($style -eq 0) {
                $border.LineStyle = -4142
            } else {
                $border.LineStyle = 1
                $border.Weight = $style
            }
            if ($null -ne $colorValue) { $border.Color = $colorValue }
        }
        Output-Json @{ success = $true; data = @{ range = $p.range; style = $p.style; position = $position } }
    }

    "copyFormat" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $sourceRange = $sheet.Range($p.source)
        $targetRange = $sheet.Range($p.target)
        $sourceRange.Copy()
        $targetRange.PasteSpecial(-4122)
        $excel.CutCopyMode = $false
        Output-Json @{ success = $true; data = @{ source = $p.source; target = $p.target } }
    }

    "clearFormats" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $range.ClearFormats()
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "addConditionalFormat" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $formatType = if ($p.type) { $p.type } else { "cellValue" }
        if ($formatType -eq "cellValue") {
            $operatorMap = @{ greater = 5; greaterThan = 5; less = 6; lessThan = 6; equal = 3; notEqual = 4; greaterEqual = 7; greaterThanOrEqual = 7; lessEqual = 8; lessThanOrEqual = 8; between = 1 }
            $op = $operatorMap[$p.operator]
            if ($null -eq $op) { $op = 3 }
            $val1 = if ($null -ne $p.value1) { $p.value1 } else { $p.value }
            $val2 = $p.value2
            $cf = $range.FormatConditions.Add(1, $op, $val1, $val2)
            if ($null -ne $cf -and $p.backgroundColor) {
                $bg = Convert-HexColorToRgbInt([string]$p.backgroundColor)
                if ($null -ne $bg) { $cf.Interior.Color = $bg }
            }
            if ($null -ne $cf -and $p.fontColor) {
                $fc = Convert-HexColorToRgbInt([string]$p.fontColor)
                if ($null -ne $fc) { $cf.Font.Color = $fc }
            }
        } elseif ($formatType -eq "colorScale") {
            $scaleType = if ($p.colorScaleType) { $p.colorScaleType } else { 3 }
            $range.FormatConditions.AddColorScale($scaleType)
        } elseif ($formatType -eq "dataBar") {
            $range.FormatConditions.AddDatabar() | Out-Null
        }
        Output-Json @{ success = $true; data = @{ range = $p.range; type = $formatType } }
    }

    "removeConditionalFormat" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        if ($p.index) {
            $range.FormatConditions.Item([int]$p.index).Delete()
        } else {
            $range.FormatConditions.Delete()
        }
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "getConditionalFormats" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $formats = @()
        $count = $range.FormatConditions.Count
        for ($i = 1; $i -le $count; $i++) {
            $cf = $range.FormatConditions.Item($i)
            $formats += @{ index = $i; type = $cf.Type }
        }
        Output-Json @{ success = $true; data = @{ range = $p.range; formats = $formats; count = $count } }
    }

    "addDataValidation" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $typeMap = @{ list = 3; whole = 1; decimal = 2; date = 4; time = 5; textLength = 6; custom = 7 }
        $validationType = $typeMap[$p.validationType]
        if ($null -eq $validationType) { $validationType = 3 }
        $range.Validation.Delete()
        if ($p.validationType -eq "list") {
            $listFormula = if ($p.formula1) { $p.formula1 } elseif ($p.list) { ($p.list -join ",") } else { "" }
            $range.Validation.Add($validationType, 1, 1, $listFormula)
            if ($null -ne $p.showDropdown -and -not [bool]$p.showDropdown) {
                $range.Validation.InCellDropdown = $false
            } else {
                $range.Validation.InCellDropdown = $true
            }
        } else {
            $operatorMap = @{ between = 1; notBetween = 2; equal = 3; notEqual = 4; greater = 5; less = 6; greaterEqual = 7; lessEqual = 8 }
            $op = $operatorMap[$p.operator]
            if ($null -eq $op) { $op = 1 }
            $range.Validation.Add($validationType, 1, $op, $p.formula1, $p.formula2)
        }
        if ($p.inputTitle -or $p.inputMessage) {
            $range.Validation.InputTitle = if ($p.inputTitle) { $p.inputTitle } else { "" }
            $range.Validation.InputMessage = if ($p.inputMessage) { $p.inputMessage } else { "" }
        }
        if ($p.errorTitle -or $p.errorMessage) {
            $range.Validation.ErrorTitle = if ($p.errorTitle) { $p.errorTitle } else { "" }
            $range.Validation.ErrorMessage = if ($p.errorMessage) { $p.errorMessage } else { "" }
        }
        Output-Json @{ success = $true; data = @{ range = $p.range; type = $p.validationType } }
    }

    "removeDataValidation" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $range.Validation.Delete()
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "getDataValidations" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $validation = $range.Validation
        Output-Json @{ success = $true; data = @{ range = $p.range; type = $validation.Type; formula1 = $validation.Formula1; formula2 = $validation.Formula2; inputTitle = $validation.InputTitle; inputMessage = $validation.InputMessage } }
    }

    "getFormula" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cell = $sheet.Range($p.cell)
        $formula = if ($cell.Formula) { $cell.Formula } else { "" }
        $formulaLocal = ""
        try { $formulaLocal = $cell.FormulaLocal } catch { $formulaLocal = "" }
        Output-Json @{ success = $true; data = @{ cell = $p.cell; formula = $formula; formulaLocal = $formulaLocal; hasFormula = ($formula -like "=*") } }
    }

    "setArrayFormula" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $range.FormulaArray = $p.formula
        Output-Json @{ success = $true; data = @{ range = $p.range; formula = $p.formula } }
    }

    "getCellInfo" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cell = $sheet.Range($p.cell)
        $value = $cell.Value2
        $formula = if ($cell.Formula) { $cell.Formula } else { "" }
        $numberFormat = if ($cell.NumberFormat) { $cell.NumberFormat } else { "" }
        $fontName = if ($cell.Font.Name) { $cell.Font.Name } else { "" }
        $fontSize = if ($cell.Font.Size) { $cell.Font.Size } else { 0 }
        $bold = if ($null -ne $cell.Font.Bold) { [bool]$cell.Font.Bold } else { $false }
        $bgColor = if ($null -ne $cell.Interior.Color) { $cell.Interior.Color } else { 0 }
        Output-Json @{ success = $true; data = @{ cell = $p.cell; value = $value; formula = $formula; numberFormat = $numberFormat; font = @{ name = $fontName; size = $fontSize; bold = $bold }; backgroundColor = $bgColor } }
    }

    "refreshLinks" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $links = $wb.LinkSources(1)
        if ($links) {
            for ($i = 1; $i -le $links.Length; $i++) {
                $wb.UpdateLink($links[$i - 1], 1)
            }
            Output-Json @{ success = $true; data = @{ refreshed = $links.Length } }
        } else {
            Output-Json @{ success = $true; data = @{ refreshed = 0; message = "没有外部链接" } }
        }
    }

    "consolidate" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $destRange = $sheet.Range($p.destination)
        $funcMap = @{ sum = 9; count = 2; average = 1; max = 4; min = 5 }
        $func = $funcMap[$p.function]
        if ($null -eq $func) { $func = 9 }
        $destRange.Consolidate($p.sources, $func, $p.topRow, $p.leftColumn, $p.createLinks)
        Output-Json @{ success = $true; data = @{ destination = $p.destination; sources = $p.sources } }
    }

    "calculateSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        if ($p.all) {
            $excel.Calculate()
            Output-Json @{ success = $true; data = @{ calculated = "all" } }
        } else {
            $sheet = $excel.ActiveSheet
            $sheet.Calculate()
            Output-Json @{ success = $true; data = @{ calculated = $sheet.Name } }
        }
    }

    # ==================== Excel Advanced ====================
    "getExcelContext" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $excel.ActiveSheet
        $usedRange = $sheet.UsedRange
        $headers = @()
        if ($usedRange.Rows.Count -gt 0) {
            $headerRow = $usedRange.Rows.Item(1)
            for ($i = 1; $i -le [Math]::Min($headerRow.Columns.Count, 26); $i++) {
                $headers += @{ column = [char](64 + $i); value = $headerRow.Cells.Item(1, $i).Value2 }
            }
        }
        $sheets = @(); for ($i = 1; $i -le $wb.Sheets.Count; $i++) { $sheets += $wb.Sheets.Item($i).Name }
        Output-Json @{ success = $true; data = @{
            workbookName = $wb.Name; currentSheet = $sheet.Name; allSheets = $sheets
            selectedCell = $excel.Selection.Address(); headers = $headers; usedRange = $usedRange.Address(); usedRangeAddress = $usedRange.Address()
        }}
    }

    "getContext" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $excel.ActiveSheet
        $usedRange = $sheet.UsedRange
        $headers = @()
        if ($usedRange.Rows.Count -gt 0) {
            $headerRow = $usedRange.Rows.Item(1)
            for ($i = 1; $i -le [Math]::Min($headerRow.Columns.Count, 26); $i++) {
                $headers += @{ column = [char](64 + $i); value = $headerRow.Cells.Item(1, $i).Value2 }
            }
        }
        $sheets = @(); for ($i = 1; $i -le $wb.Sheets.Count; $i++) { $sheets += $wb.Sheets.Item($i).Name }
        Output-Json @{ success = $true; data = @{
            workbookName = $wb.Name; currentSheet = $sheet.Name; allSheets = $sheets
            selectedCell = $excel.Selection.Address(); headers = $headers; usedRangeAddress = $usedRange.Address(); usedRange = $usedRange.Address()
        }}
    }

    "sortRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $keyCol = $sheet.Range($p.keyColumn)
        $order = if ($p.order -eq "desc") { 2 } else { 1 }
        $range.Sort($keyCol, $order)
        Output-Json @{ success = $true }
    }

    "autoFilter" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        if ($p.criteria) {
            $range.AutoFilter($p.field, $p.criteria)
        } else {
            $range.AutoFilter()
        }
        Output-Json @{ success = $true }
    }

    "createChart" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.dataRange)
        $chartType = $p.chartType
        if ($null -eq $chartType) {
            $chartTypes = @{ column = 51; column_clustered = 51; column_stacked = 52; bar = 57; bar_clustered = 57; line = 4; line_markers = 65; pie = 5; doughnut = -4120; area = 1; scatter = -4169; radar = -4151 }
            $chartType = $chartTypes[$p.chartTypeName]
        }
        if ($null -eq $chartType) { $chartType = 51 }
        $chartTypeName = if ($p.chartTypeName) { $p.chartTypeName } else { $null }
        $left = if ($p.position -and $p.position.left) { $p.position.left } elseif ($p.left) { $p.left } else { $range.Left + $range.Width + 20 }
        $top = if ($p.position -and $p.position.top) { $p.position.top } elseif ($p.top) { $p.top } else { $range.Top }
        $width = if ($p.position -and $p.position.width) { $p.position.width } else { 400 }
        $height = if ($p.position -and $p.position.height) { $p.position.height } else { 300 }
        $chartObj = $sheet.ChartObjects().Add($left, $top, $width, $height)
        $chartObj.Chart.SetSourceData($range)
        $chartObj.Chart.ChartType = $chartType
        if ($p.title) { $chartObj.Chart.HasTitle = $true; $chartObj.Chart.ChartTitle.Text = $p.title }
        if ($null -ne $p.showLegend) { $chartObj.Chart.HasLegend = [bool]$p.showLegend }
        if ($p.showDataLabels) { $chartObj.Chart.ApplyDataLabels() }
        Output-Json @{ success = $true; data = @{ chartName = $chartObj.Name; chartIndex = $chartObj.Index; dataRange = $p.dataRange; chartType = $chartTypeName; position = @{ left = $left; top = $top; width = $width; height = $height } } }
    }

    "updateChart" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = if ($p.sheet) { $excel.ActiveWorkbook.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $chartObj = $null
        if ($p.chartName) {
            try { $chartObj = $sheet.ChartObjects($p.chartName) } catch {}
        }
        if ($null -eq $chartObj -and $p.chartIndex) {
            try { $chartObj = $sheet.ChartObjects().Item([int]$p.chartIndex) } catch {}
        }
        if ($null -eq $chartObj) { Output-Json @{ success = $false; error = "Chart not found" }; exit }
        $updated = @()
        if ($null -ne $p.title) {
            if ($p.title -eq "") { $chartObj.Chart.HasTitle = $false }
            else { $chartObj.Chart.HasTitle = $true; $chartObj.Chart.ChartTitle.Text = $p.title }
            $updated += "title"
        }
        if ($null -ne $p.chartType) {
            $chartObj.Chart.ChartType = $p.chartType
            $updated += "chartType"
        }
        if ($null -ne $p.showLegend) {
            $chartObj.Chart.HasLegend = [bool]$p.showLegend
            $updated += "showLegend"
        }
        if ($null -ne $p.legendPosition) {
            $legendMap = @{ bottom = -4107; top = -4160; left = -4131; right = -4152 }
            $pos = $legendMap[$p.legendPosition]
            if ($pos) { $chartObj.Chart.Legend.Position = $pos; $updated += "legendPosition" }
        }
        if ($null -ne $p.showDataLabels) {
            if ($p.showDataLabels) {
                $chartObj.Chart.ApplyDataLabels()
            } else {
                try {
                    $series = $chartObj.Chart.SeriesCollection()
                    for ($i = 1; $i -le $series.Count; $i++) {
                        try { $series.Item($i).DataLabels().Delete() } catch {}
                    }
                } catch {}
            }
            $updated += "showDataLabels"
        }
        if ($p.dataRange) {
            $chartObj.Chart.SetSourceData($sheet.Range($p.dataRange))
            $updated += "dataRange"
        }
        if ($p.colors -and $p.colors.Count -gt 0) {
            $series = $chartObj.Chart.SeriesCollection()
            for ($i = 1; $i -le $series.Count -and $i -le $p.colors.Count; $i++) {
                $color = Convert-HexColorToRgbInt($p.colors[$i - 1])
                if ($null -ne $color) { $series.Item($i).Format.Fill.ForeColor.RGB = $color }
            }
            $updated += "colors"
        }
        Output-Json @{ success = $true; data = @{ chartName = $chartObj.Name; updatedProperties = $updated } }
    }

    "exportChartAsImage" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = if ($p.sheet) { $excel.ActiveWorkbook.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $outputPath = if ($p.outputPath) { $p.outputPath } else { $p.path }
        if ([string]::IsNullOrEmpty($outputPath)) { Output-Json @{ success = $false; error = "Missing outputPath" }; exit }
        $chartName = $p.chartName
        if ([string]::IsNullOrEmpty($chartName)) { Output-Json @{ success = $false; error = "Missing chartName" }; exit }
        $rawFormat = if ($p.format) { $p.format.ToString().ToUpper() } else { "PNG" }
        # JPEG 在 Excel COM 中按 JPG 滤镜处理
        $filterName = if ($rawFormat -eq "JPEG") { "JPG" } else { $rawFormat }
        $chartObj = $sheet.ChartObjects($chartName)
        $chartObj.Chart.Export($outputPath, $filterName)
        Output-Json @{ success = $true; data = @{ chartName = $chartName; outputPath = $outputPath; format = $filterName } }
    }

    "exportRangeAsImage" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = if ($p.sheet) { $excel.ActiveWorkbook.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $outputPath = if ($p.outputPath) { $p.outputPath } else { $p.path }
        if ([string]::IsNullOrEmpty($outputPath)) { Output-Json @{ success = $false; error = "Missing outputPath" }; exit }
        if ([string]::IsNullOrEmpty($p.range)) { Output-Json @{ success = $false; error = "Missing range" }; exit }
        $rawFormat = if ($p.format) { $p.format.ToString().ToUpper() } else { "PNG" }
        $filterName = if ($rawFormat -eq "JPEG") { "JPG" } else { $rawFormat }
        $range = $sheet.Range($p.range)
        # xlScreen=1 (Appearance), xlBitmap=2 (Format)
        $tempChart = $null
        try {
            $range.CopyPicture(1, 2)
            $tempChart = $sheet.ChartObjects().Add(0, 0, $range.Width, $range.Height)
            $tempChart.Activate()
            $tempChart.Chart.Paste()
            $tempChart.Chart.Export($outputPath, $filterName)
            $tempChart.Delete()
            $tempChart = $null
            Output-Json @{ success = $true; data = @{ range = $p.range; outputPath = $outputPath; format = $filterName } }
        } catch {
            # 异常清理：剪贴板冲突时回滚临时图表
            if ($null -ne $tempChart) { try { $tempChart.Delete() } catch {} }
            Output-Json @{ success = $false; error = "导出区域为图片失败: $($_.Exception.Message)" }
        }
    }

    "removeDuplicates" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $originalCount = $range.Rows.Count
        $cols = @()
        if ($p.columns -and $p.columns.Count -gt 0) {
            foreach ($col in $p.columns) {
                if ($col -is [int]) { $cols += $col }
                else {
                    $num = Convert-ColumnLetterToNumber([string]$col)
                    if ($num) { $cols += $num }
                }
            }
        }
        if ($cols.Count -eq 0) { $cols = @(1) }
        $hasHeader = if ($null -ne $p.hasHeader) { [int]([bool]$p.hasHeader) } else { 1 }
        $range.RemoveDuplicates($cols, $hasHeader)
        $remainingCount = $range.Rows.Count
        $removedCount = $originalCount - $remainingCount
        Output-Json @{ success = $true; data = @{ originalCount = $originalCount; removedCount = $removedCount; remainingCount = $remainingCount } }
    }

    "createSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $wb.Sheets.Add()
        if ($p.name) { $sheet.Name = $p.name }
        Output-Json @{ success = $true; data = @{ sheetName = $sheet.Name; sheetIndex = $sheet.Index } }
    }

    "deleteSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet) { $wb.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $name = $sheet.Name
        $excel.DisplayAlerts = $false
        $sheet.Delete()
        $excel.DisplayAlerts = $true
        Output-Json @{ success = $true; data = @{ deletedSheet = $name } }
    }

    "renameSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet) { $wb.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $oldName = $sheet.Name
        $sheet.Name = $p.newName
        Output-Json @{ success = $true; data = @{ oldName = $oldName; newName = $p.newName } }
    }

    "copySheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet) { $wb.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        if ($p.before) {
            $sheet.Copy($wb.Sheets.Item($p.before))
        } elseif ($p.after) {
            $sheet.Copy($null, $wb.Sheets.Item($p.after))
        } else {
            $sheet.Copy($null, $wb.Sheets.Item($wb.Sheets.Count))
        }
        Output-Json @{ success = $true; data = @{ copiedFrom = $sheet.Name } }
    }

    "getSheetList" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheets = @()
        for ($i = 1; $i -le $wb.Sheets.Count; $i++) {
            $sheet = $wb.Sheets.Item($i)
            $sheets += @{ name = $sheet.Name; index = $i; visible = $sheet.Visible }
        }
        Output-Json @{ success = $true; data = @{ sheets = $sheets; count = $sheets.Count; activeSheet = $excel.ActiveSheet.Name } }
    }

    "switchSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $wb.Sheets.Item($p.sheet)
        $sheet.Activate()
        Output-Json @{ success = $true; data = @{ activeSheet = $sheet.Name } }
    }

    "moveSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = if ($p.sheet) { $wb.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        if ($p.before) {
            $sheet.Move($wb.Sheets.Item($p.before))
        } elseif ($p.after) {
            $sheet.Move($null, $wb.Sheets.Item($p.after))
        }
        Output-Json @{ success = $true; data = @{ movedSheet = $sheet.Name } }
    }

    "mergeCells" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $across = if ($null -ne $p.across) { [bool]$p.across } else { $false }
        $range.Merge($across)
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "unmergeCells" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $range.UnMerge()
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "setColumnWidth" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $col = $p.column
        if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
        $sheet.Range("${col}:${col}").ColumnWidth = $p.width
        Output-Json @{ success = $true; data = @{ column = $col; width = $p.width } }
    }

    "setRowHeight" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $sheet.Range("$($p.row):$($p.row)").RowHeight = $p.height
        Output-Json @{ success = $true; data = @{ row = $p.row; height = $p.height } }
    }

    "autoFitColumn" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if ($p.range) {
            $sheet.Range($p.range).Columns.AutoFit()
        } elseif ($p.column) {
            $col = $p.column
            if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
            $sheet.Range("${col}:${col}").AutoFit()
        } else {
            $sheet.UsedRange.Columns.AutoFit()
        }
        Output-Json @{ success = $true; data = @{ message = "列宽已自动调整" } }
    }

    "autoFitRow" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if ($p.range) {
            $sheet.Range($p.range).Rows.AutoFit()
        } elseif ($p.row) {
            $sheet.Range("$($p.row):$($p.row)").AutoFit()
        } else {
            $sheet.UsedRange.Rows.AutoFit()
        }
        Output-Json @{ success = $true; data = @{ message = "行高已自动调整" } }
    }

    "autoFitAll" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = if ($p.range) { $sheet.Range($p.range) } else { $sheet.UsedRange }
        $range.Columns.AutoFit()
        $range.Rows.AutoFit()
        Output-Json @{ success = $true; data = @{ message = "列宽行高已自动调整" } }
    }

    "setNumberFormat" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        if ($p.format) { $range.NumberFormat = $p.format }
        Output-Json @{ success = $true; data = @{ range = $p.range; format = $p.format } }
    }

    "wrapText" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $wrap = if ($null -ne $p.wrap) { [bool]$p.wrap } else { $true }
        $range.WrapText = $wrap
        Output-Json @{ success = $true; data = @{ range = $p.range; wrapText = $wrap } }
    }

    "setPrintArea" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if ($p.range) { $sheet.PageSetup.PrintArea = $p.range } else { $sheet.PageSetup.PrintArea = "" }
        Output-Json @{ success = $true; data = @{ printArea = if ($p.range) { $p.range } else { "cleared" } } }
    }

    "getSelection" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sel = $excel.Selection
        if ($null -eq $sel) { Output-Json @{ success = $false; error = "No selection" }; exit }
        $addr = $sel.Address()
        Output-Json @{ success = $true; data = @{ address = $addr; rows = $sel.Rows.Count; columns = $sel.Columns.Count } }
    }

    "clearRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $clearType = if ($p.type) { $p.type } else { "all" }
        if ($clearType -eq "contents") { $range.ClearContents() }
        elseif ($clearType -eq "formats") { $range.ClearFormats() }
        elseif ($clearType -eq "comments") { $range.ClearComments() }
        else { $range.Clear() }
        Output-Json @{ success = $true; data = @{ range = $p.range; clearType = $clearType } }
    }

    "insertRows" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $startRow = if ($p.row) { [int]$p.row } elseif ($p.startRow) { [int]$p.startRow } else { $null }
        if ($null -eq $startRow) { Output-Json @{ success = $false; error = "row/startRow required" }; exit }
        $count = if ($p.count) { [int]$p.count } else { 1 }
        $endRow = $startRow + $count - 1
        $sheet.Range("${startRow}:${endRow}").Insert()
        Output-Json @{ success = $true; data = @{ insertedAt = $startRow; count = $count } }
    }

    "insertColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $col = if ($p.column) { $p.column } elseif ($p.startColumn) { $p.startColumn } else { $null }
        if ($null -eq $col) { Output-Json @{ success = $false; error = "column/startColumn required" }; exit }
        if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
        $count = if ($p.count) { [int]$p.count } else { 1 }
        for ($i = 0; $i -lt $count; $i++) {
            $sheet.Range("${col}:${col}").Insert()
        }
        Output-Json @{ success = $true; data = @{ insertedAt = $col; count = $count } }
    }

    "deleteRows" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $startRow = if ($p.row) { [int]$p.row } elseif ($p.startRow) { [int]$p.startRow } else { $null }
        if ($null -eq $startRow) { Output-Json @{ success = $false; error = "row/startRow required" }; exit }
        $count = if ($p.count) { [int]$p.count } else { 1 }
        $endRow = $startRow + $count - 1
        $sheet.Range("${startRow}:${endRow}").Delete()
        Output-Json @{ success = $true; data = @{ deletedFrom = $startRow; count = $count } }
    }

    "deleteColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $col = if ($p.column) { $p.column } elseif ($p.startColumn) { $p.startColumn } else { $null }
        if ($null -eq $col) { Output-Json @{ success = $false; error = "column/startColumn required" }; exit }
        if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
        $count = if ($p.count) { [int]$p.count } else { 1 }
        for ($i = 0; $i -lt $count; $i++) {
            $sheet.Range("${col}:${col}").Delete()
        }
        Output-Json @{ success = $true; data = @{ deletedFrom = $col; count = $count } }
    }

    "hideRows" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $rows = if ($p.rows) { $p.rows } elseif ($p.row) { @($p.row) } else { @() }
        if ($rows.Count -eq 0) { Output-Json @{ success = $false; error = "row/rows required" }; exit }
        foreach ($r in $rows) { $sheet.Range("${r}:${r}").Hidden = $true }
        Output-Json @{ success = $true; data = @{ hiddenRows = $rows } }
    }

    "hideColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cols = if ($p.columns) { $p.columns } elseif ($p.column) { @($p.column) } else { @() }
        if ($cols.Count -eq 0) { Output-Json @{ success = $false; error = "column/columns required" }; exit }
        $hidden = @()
        foreach ($c in $cols) {
            $col = $c
            if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
            $sheet.Range("${col}:${col}").Hidden = $true
            $hidden += $col
        }
        Output-Json @{ success = $true; data = @{ hiddenColumns = $hidden } }
    }

    "showRows" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $rows = if ($p.rows) { $p.rows } elseif ($p.row) { @($p.row) } else { @() }
        if ($rows.Count -eq 0) { Output-Json @{ success = $false; error = "row/rows required" }; exit }
        foreach ($r in $rows) { $sheet.Range("${r}:${r}").Hidden = $false }
        Output-Json @{ success = $true; data = @{ shownRows = $rows } }
    }

    "showColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cols = if ($p.columns) { $p.columns } elseif ($p.column) { @($p.column) } else { @() }
        if ($cols.Count -eq 0) { Output-Json @{ success = $false; error = "column/columns required" }; exit }
        $shown = @()
        foreach ($c in $cols) {
            $col = $c
            if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
            $sheet.Range("${col}:${col}").Hidden = $false
            $shown += $col
        }
        Output-Json @{ success = $true; data = @{ shownColumns = $shown } }
    }

    "groupRows" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if (-not $p.startRow -or -not $p.endRow) { Output-Json @{ success = $false; error = "startRow/endRow required" }; exit }
        $sheet.Range("$($p.startRow):$($p.endRow)").Group()
        Output-Json @{ success = $true; data = @{ grouped = "$($p.startRow):$($p.endRow)" } }
    }

    "groupColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if (-not $p.startColumn -or -not $p.endColumn) { Output-Json @{ success = $false; error = "startColumn/endColumn required" }; exit }
        $startCol = $p.startColumn
        $endCol = $p.endColumn
        if ($startCol -is [int]) { $startCol = Convert-ColumnNumberToLetter([int]$startCol) }
        if ($endCol -is [int]) { $endCol = Convert-ColumnNumberToLetter([int]$endCol) }
        $sheet.Range("${startCol}:${endCol}").Group()
        Output-Json @{ success = $true; data = @{ grouped = "${startCol}:${endCol}" } }
    }

    "freezePanes" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        if ($p.cell) {
            $sheet.Range($p.cell).Select()
        } elseif ($p.row -and $p.column) {
            $col = $p.column
            if ($col -is [int]) { $col = Convert-ColumnNumberToLetter([int]$col) }
            $sheet.Range("$col$($p.row)").Select()
        }
        $excel.ActiveWindow.FreezePanes = $true
        Output-Json @{ success = $true; data = @{ message = "窗格已冻结" } }
    }

    "unfreezePanes" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $excel.ActiveWindow.FreezePanes = $false
        Output-Json @{ success = $true; data = @{ message = "窗格冻结已取消" } }
    }

    "findInSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $searchRange = if ($p.range) { $sheet.Range($p.range) } else { $sheet.UsedRange }
        $results = @()
        $lookAt = if ($p.matchCase) { 1 } else { 2 }
        $found = $searchRange.Find($p.searchText, $null, -4163, $lookAt)
        if ($found) {
            $firstAddr = $found.Address()
            do {
                $addr = $found.Address()
                $results += @{ address = ($addr -replace "\$", ""); value = $found.Value2 }
                $found = $searchRange.FindNext($found)
                if ($null -eq $found) { break }
                $currAddr = $found.Address()
            } while ($currAddr -ne $firstAddr)
        }
        Output-Json @{ success = $true; data = @{ searchText = $p.searchText; results = $results; count = $results.Count } }
    }

    "replaceInSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $searchRange = if ($p.range) { $sheet.Range($p.range) } else { $sheet.UsedRange }
        $lookAt = if ($p.matchCase) { 1 } else { 2 }
        $replaced = $searchRange.Replace($p.searchText, $p.replaceText, $lookAt)
        Output-Json @{ success = $true; data = @{ searchText = $p.searchText; replaceText = $p.replaceText; success = $replaced } }
    }

    "copyRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $range.Copy()
        Output-Json @{ success = $true; data = @{ range = $p.range; message = "已复制到剪贴板" } }
    }

    "pasteRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $destRange = $sheet.Range($p.destination)
        if ($p.pasteType -eq "values") {
            $destRange.PasteSpecial(-4163)
        } elseif ($p.pasteType -eq "formats") {
            $destRange.PasteSpecial(-4122)
        } elseif ($p.pasteType -eq "formulas") {
            $destRange.PasteSpecial(-4123)
        } else {
            $sheet.Paste($destRange)
        }
        Output-Json @{ success = $true; data = @{ destination = $p.destination } }
    }

    "fillSeries" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $startCell = $range.Cells.Item(1, 1)
        $startCell.Value2 = if ($null -ne $p.startValue) { $p.startValue } else { 1 }
        $typeMap = @{ linear = 0; growth = 1; date = 2; autoFill = 3 }
        $fillType = $typeMap[$p.type]
        if ($null -eq $fillType) { $fillType = 0 }
        $step = if ($null -ne $p.step) { $p.step } else { 1 }
        $range.DataSeries($null, -4132, $fillType, $step)
        Output-Json @{ success = $true; data = @{ range = $p.range; type = $p.type } }
    }

    "transpose" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $sourceRange = $sheet.Range($p.sourceRange)
        $destCell = if ($p.destinationCell) { $p.destinationCell } elseif ($p.targetCell) { $p.targetCell } else { $null }
        if ($null -eq $destCell) { Output-Json @{ success = $false; error = "destinationCell/targetCell required" }; exit }
        $destRange = $sheet.Range($destCell)
        $sourceRange.Copy()
        $destRange.PasteSpecial(-4163, -4142, $false, $true)
        $excel.CutCopyMode = $false
        Output-Json @{ success = $true; data = @{ source = $p.sourceRange; destination = $destCell } }
    }

    "textToColumns" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $delimiter = if ($p.delimiter) { $p.delimiter } else { "," }
        $tab = $false; $semicolon = $false; $comma = $false; $space = $false; $other = $false; $otherChar = $null
        if ($delimiter -eq "`t") { $tab = $true }
        elseif ($delimiter -eq ";") { $semicolon = $true }
        elseif ($delimiter -eq ",") { $comma = $true }
        elseif ($delimiter -eq " ") { $space = $true }
        else { $other = $true; $otherChar = $delimiter }
        $range.TextToColumns($null, 1, 1, $false, $tab, $semicolon, $comma, $space, $other, $otherChar)
        Output-Json @{ success = $true; data = @{ range = $p.range; delimiter = $delimiter } }
    }

    "subtotal" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $funcMap = @{ sum = 9; count = 2; average = 1; max = 4; min = 5 }
        $func = $funcMap[$p.function]
        if ($null -eq $func) { $func = 9 }
        $totalCols = $p.totalColumns
        if ($null -eq $totalCols) { $totalCols = $p.totalColumn }
        if ($totalCols -isnot [System.Array]) { $totalCols = @($totalCols) }
        $replace = if ($null -ne $p.replace) { [bool]$p.replace } else { $true }
        $range.Subtotal([int]$p.groupBy, $func, $totalCols, $replace, $false, $true)
        Output-Json @{ success = $true; data = @{ range = $p.range } }
    }

    "createNamedRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $addr = $range.Address()
        $wb.Names.Add($p.name, "=" + $sheet.Name + "!" + $addr)
        Output-Json @{ success = $true; data = @{ name = $p.name; range = $p.range } }
    }

    "deleteNamedRange" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $wb.Names.Item($p.name).Delete()
        Output-Json @{ success = $true; data = @{ deletedName = $p.name } }
    }

    "getNamedRanges" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $names = @()
        for ($i = 1; $i -le $wb.Names.Count; $i++) {
            $n = $wb.Names.Item($i)
            $names += @{ name = $n.Name; refersTo = $n.RefersTo; visible = $n.Visible }
        }
        Output-Json @{ success = $true; data = @{ names = $names; count = $names.Count } }
    }

    "addCellComment" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cell = $sheet.Range($p.cell)
        if ($cell.Comment) { $cell.Comment.Delete() }
        $cell.AddComment($p.text)
        if ($p.visible) { $cell.Comment.Visible = $true }
        Output-Json @{ success = $true; data = @{ cell = $p.cell; text = $p.text } }
    }

    "deleteCellComment" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $cell = $sheet.Range($p.cell)
        if ($cell.Comment) { $cell.Comment.Delete() }
        Output-Json @{ success = $true; data = @{ cell = $p.cell } }
    }

    "getCellComments" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $comments = @()
        for ($i = 1; $i -le $sheet.Comments.Count; $i++) {
            $c = $sheet.Comments.Item($i)
            $addr = $c.Parent.Address()
            $comments += @{ cell = ($addr -replace "\$", ""); text = $c.Text(); author = if ($c.Author) { $c.Author } else { "" } }
        }
        Output-Json @{ success = $true; data = @{ comments = $comments; count = $comments.Count } }
    }

    "protectSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = if ($p.sheet) { $excel.ActiveWorkbook.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $password = if ($p.password) { $p.password } else { "" }
        $sheet.Protect($password, $p.drawingObjects, $p.contents, $p.scenarios)
        Output-Json @{ success = $true; data = @{ sheet = $sheet.Name; protected = $true } }
    }

    "unprotectSheet" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = if ($p.sheet) { $excel.ActiveWorkbook.Sheets.Item($p.sheet) } else { $excel.ActiveSheet }
        $password = if ($p.password) { $p.password } else { "" }
        $sheet.Unprotect($password)
        Output-Json @{ success = $true; data = @{ sheet = $sheet.Name; protected = $false } }
    }

    "protectWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.ActiveWorkbook
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No active workbook" }; exit }
        $password = if ($p.password) { $p.password } else { "" }
        $structure = if ($null -ne $p.structure) { [bool]$p.structure } else { $true }
        $wb.Protect($password, $structure, $p.windows)
        Output-Json @{ success = $true; data = @{ workbook = $wb.Name; protected = $true } }
    }

    "insertExcelImage" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $left = if ($null -ne $p.left) { $p.left } else { 100 }
        $top = if ($null -ne $p.top) { $p.top } else { 100 }
        $width = if ($null -ne $p.width) { $p.width } else { -1 }
        $height = if ($null -ne $p.height) { $p.height } else { -1 }
        $pic = $sheet.Shapes.AddPicture($p.path, $false, $true, $left, $top, $width, $height)
        Output-Json @{ success = $true; data = @{ name = $pic.Name; path = $p.path } }
    }

    "setHyperlink" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.cell)
        $address = if ($p.address) { $p.address } else { "" }
        $subAddress = if ($p.subAddress) { $p.subAddress } else { "" }
        $screenTip = if ($p.screenTip) { $p.screenTip } else { "" }
        $textToDisplay = if ($p.textToDisplay) { $p.textToDisplay } else { "" }
        $sheet.Hyperlinks.Add($range, $address, $subAddress, $screenTip, $textToDisplay)
        Output-Json @{ success = $true; data = @{ cell = $p.cell; address = $address } }
    }

    "lockCells" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $sheet = $excel.ActiveSheet
        $range = $sheet.Range($p.range)
        $locked = if ($null -ne $p.locked) { [bool]$p.locked } else { $true }
        $range.Locked = $locked
        Output-Json @{ success = $true; data = @{ range = $p.range; locked = $locked } }
    }

    "openWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.Workbooks.Open($p.path, $p.updateLinks, $p.readOnly)
        Output-Json @{ success = $true; data = @{ name = $wb.Name; path = $wb.FullName; sheets = $wb.Sheets.Count } }
    }

    "getOpenWorkbooks" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $workbooks = @()
        for ($i = 1; $i -le $excel.Workbooks.Count; $i++) {
            $wb = $excel.Workbooks.Item($i)
            $workbooks += @{ name = $wb.Name; path = $wb.FullName; sheets = $wb.Sheets.Count; active = ($wb.Name -eq $excel.ActiveWorkbook.Name) }
        }
        Output-Json @{ success = $true; data = @{ workbooks = $workbooks; count = $workbooks.Count } }
    }

    "switchWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.Workbooks.Item($(if ($p.name) { $p.name } else { $p.index }))
        $wb.Activate()
        Output-Json @{ success = $true; data = @{ name = $wb.Name; path = $wb.FullName } }
    }

    "closeWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = if ($p.name) { $excel.Workbooks.Item($p.name) } else { $excel.ActiveWorkbook }
        if ($null -eq $wb) { Output-Json @{ success = $false; error = "No workbook" }; exit }
        $name = $wb.Name
        $saveChanges = if ($null -ne $p.saveChanges) { [bool]$p.saveChanges } else { $true }
        $wb.Close($saveChanges)
        Output-Json @{ success = $true; data = @{ closed = $name } }
    }

    "createWorkbook" {
        $excel = Get-WpsExcel
        if ($null -eq $excel) { Output-Json @{ success = $false; error = "WPS Excel not running" }; exit }
        $wb = $excel.Workbooks.Add()
        if ($p.name) { $wb.SaveAs($p.name) }
        Output-Json @{ success = $true; data = @{ name = $wb.Name; path = $wb.FullName; sheets = $wb.Sheets.Count } }
    }

    # ==================== Word ====================
    "getActiveDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        Output-Json @{ success = $true; data = @{
            name = $doc.Name; path = $doc.FullName
            paragraphCount = $doc.Paragraphs.Count; wordCount = $doc.Words.Count; characterCount = $doc.Characters.Count
        }}
    }

    "generateTOC" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $position = if ($p.position) { $p.position } else { "start" }
        $levels = if ($p.levels) { [int]$p.levels } else { 3 }
        $includePageNumbers = if ($null -ne $p.includePageNumbers) { [bool]$p.includePageNumbers } else { $true }
        $range = if ($position -eq "cursor") { $word.Selection.Range } else { $doc.Range(0, 0) }
        $doc.TablesOfContents.Add($range, $true, 1, $levels, $false, "", $true, $true, $includePageNumbers, $true)
        Output-Json @{ success = $true; data = @{ levels = $levels; position = $position; includePageNumbers = $includePageNumbers } }
    }

    "getDocumentText" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $text = $doc.Content.Text
        if ($text.Length -gt 10000) { $text = $text.Substring(0, 10000) + "...(truncated)" }
        Output-Json @{ success = $true; data = @{ text = $text; length = $doc.Content.Text.Length } }
    }

    "getOpenDocuments" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $documents = @()
        for ($i = 1; $i -le $word.Documents.Count; $i++) {
            $docItem = $word.Documents.Item($i)
            $documents += @{ name = $docItem.Name; path = $docItem.FullName; paragraphs = $docItem.Paragraphs.Count; active = ($word.ActiveDocument.Name -eq $docItem.Name) }
        }
        Output-Json @{ success = $true; data = @{ documents = $documents; count = $documents.Count } }
    }

    "switchDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $docItem = $word.Documents.Item($(if ($p.name) { $p.name } else { $p.index }))
        $docItem.Activate()
        Output-Json @{ success = $true; data = @{ name = $docItem.Name; path = $docItem.FullName } }
    }

    "openDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        if (-not $p.path) { Output-Json @{ success = $false; error = "path required" }; exit }
        $docItem = $word.Documents.Open($p.path)
        Output-Json @{ success = $true; data = @{ name = $docItem.Name; path = $docItem.FullName; paragraphs = $docItem.Paragraphs.Count } }
    }

    "closeDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $docItem = if ($p.name) { $word.Documents.Item($p.name) } else { $word.ActiveDocument }
        if ($null -eq $docItem) { Output-Json @{ success = $false; error = "No document" }; exit }
        $name = $docItem.Name
        $saveChanges = if ($null -ne $p.saveChanges) { [bool]$p.saveChanges } else { $true }
        $docItem.Close($saveChanges)
        Output-Json @{ success = $true; data = @{ closed = $name } }
    }

    "insertText" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $position = if ($p.position) { $p.position } else { "cursor" }
        switch ($position) {
            "start" { $range = $doc.Range(0, 0); $range.InsertBefore($p.text) }
            "end" { $range = $doc.Range($doc.Content.End - 1, $doc.Content.End - 1); $range.InsertAfter($p.text) }
            default { $word.Selection.TypeText($p.text) }
        }
        if ($p.style) {
            try { $word.Selection.Range.Style = $p.style } catch {}
        }
        Output-Json @{ success = $true; data = @{ position = $position; textLength = $p.text.Length } }
    }

    "setFont" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $range = if ($p.range -eq "all") { $doc.Content } else { $word.Selection.Range }
        if ($p.fontName) { $range.Font.Name = $p.fontName }
        if ($p.fontSize) { $range.Font.Size = $p.fontSize }
        if ($null -ne $p.bold) { $range.Font.Bold = $p.bold }
        if ($null -ne $p.italic) { $range.Font.Italic = $p.italic }
        if ($null -ne $p.underline) { $range.Font.Underline = $p.underline }
        if ($p.color) {
            $colorMap = @{ red = 255; blue = 16711680; green = 65280; black = 0 }
            $colorValue = $colorMap[$p.color.ToLower()]
            if ($null -eq $colorValue) { $colorValue = Convert-HexColorToRgbInt([string]$p.color) }
            if ($null -ne $colorValue) { $range.Font.Color = $colorValue }
        }
        Output-Json @{ success = $true; data = @{ settings = @{ fontName = $p.fontName; fontSize = $p.fontSize; bold = $p.bold; italic = $p.italic; underline = $p.underline; color = $p.color } } }
    }

    "findReplace" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $find = $doc.Content.Find
        $find.ClearFormatting()
        $find.Replacement.ClearFormatting()
        $find.Text = $p.findText
        $find.Replacement.Text = $p.replaceText
        $matchCase = if ($null -ne $p.matchCase) { [bool]$p.matchCase } else { $false }
        $matchWholeWord = if ($null -ne $p.matchWholeWord) { [bool]$p.matchWholeWord } else { $false }
        $replaceAll = if ($null -ne $p.replaceAll) { [bool]$p.replaceAll } else { $true }
        $replaceType = if ($replaceAll) { 2 } else { 1 }
        $result = $find.Execute($p.findText, $matchCase, $matchWholeWord, $false, $false, $false, $true, 1, $false, $p.replaceText, $replaceType)
        Output-Json @{ success = $true; data = @{ replaced = $result } }
    }

    "insertTable" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $rows = if ($p.rows) { [int]$p.rows } else { 3 }
        $cols = if ($p.cols) { [int]$p.cols } else { 3 }
        $range = $word.Selection.Range
        $table = $doc.Tables.Add($range, $rows, $cols)
        if ($p.data) {
            for ($r = 0; $r -lt [Math]::Min($p.data.Count, $rows); $r++) {
                for ($c = 0; $c -lt [Math]::Min($p.data[$r].Count, $cols); $c++) {
                    $table.Cell($r + 1, $c + 1).Range.Text = [string]$p.data[$r][$c]
                }
            }
        }
        $table.Borders.Enable = $true
        Output-Json @{ success = $true }
    }

    "setParagraph" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $range = if ($p.range -eq "all") { $doc.Content } else { $word.Selection.Range }
        $para = $range.ParagraphFormat
        if ($null -ne $p.alignment) {
            $alignMap = @{ left = 0; center = 1; right = 2; justify = 3 }
            $align = $alignMap[$p.alignment]
            if ($null -eq $align) { $align = 0 }
            $para.Alignment = $align
        }
        if ($p.lineSpacing) {
            $para.LineSpacingRule = 4
            $para.LineSpacing = [double]$p.lineSpacing * 12
        }
        if ($null -ne $p.spaceBefore) { $para.SpaceBefore = $p.spaceBefore }
        if ($null -ne $p.spaceAfter) { $para.SpaceAfter = $p.spaceAfter }
        if ($null -ne $p.firstLineIndent) { $para.FirstLineIndent = [double]$p.firstLineIndent * 28.35 }
        if ($null -ne $p.leftIndent) { $para.LeftIndent = [double]$p.leftIndent * 28.35 }
        if ($null -ne $p.rightIndent) { $para.RightIndent = [double]$p.rightIndent * 28.35 }
        Output-Json @{ success = $true }
    }

    "setPageSetup" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $ps = $doc.PageSetup
        if ($null -ne $p.topMargin) { $ps.TopMargin = [double]$p.topMargin * 28.35 }
        if ($null -ne $p.bottomMargin) { $ps.BottomMargin = [double]$p.bottomMargin * 28.35 }
        if ($null -ne $p.leftMargin) { $ps.LeftMargin = [double]$p.leftMargin * 28.35 }
        if ($null -ne $p.rightMargin) { $ps.RightMargin = [double]$p.rightMargin * 28.35 }
        if ($null -ne $p.orientation) {
            $ps.Orientation = if ($p.orientation -eq "landscape") { 1 } else { 0 }
        }
        if ($null -ne $p.paperSize) {
            $sizeMap = @{ A4 = 7; A3 = 6; Letter = 1; Legal = 5 }
            $size = $sizeMap[$p.paperSize]
            if ($null -eq $size) { $size = 7 }
            $ps.PaperSize = $size
        }
        Output-Json @{ success = $true }
    }

    "insertPageBreak" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $breakType = if ($p.type) { $p.type } else { "page" }
        $breakTypeMap = @{ page = 7; column = 8; section = 2; sectionContinuous = 3 }
        $bt = $breakTypeMap[$breakType]
        if ($null -eq $bt) { $bt = 7 }
        $word.Selection.InsertBreak($bt)
        Output-Json @{ success = $true; data = @{ type = $breakType } }
    }

    "insertHeader" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $section = $doc.Sections.Item(1)
        $header = $section.Headers.Item(1)
        $header.Range.Text = if ($p.text) { $p.text } else { "" }
        if ($p.alignment) {
            $alignMap = @{ left = 0; center = 1; right = 2 }
            $header.Range.ParagraphFormat.Alignment = $alignMap[$p.alignment]
        }
        Output-Json @{ success = $true }
    }

    "insertFooter" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $section = $doc.Sections.Item(1)
        $footer = $section.Footers.Item(1)
        $footer.Range.Text = if ($p.text) { $p.text } else { "" }
        if ($p.alignment) {
            $alignMap = @{ left = 0; center = 1; right = 2 }
            $footer.Range.ParagraphFormat.Alignment = $alignMap[$p.alignment]
        }
        if ($p.includePageNumber) {
            $footer.Range.InsertAfter(" - 第 ")
            $footer.Range.Fields.Add($footer.Range, -1, "PAGE", $false)
            $footer.Range.InsertAfter(" 页 ")
        }
        Output-Json @{ success = $true }
    }

    "insertHyperlink" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $range = $word.Selection.Range
        $url = if ($p.url) { $p.url } else { $p.address }
        $text = if ($p.text) { $p.text } elseif ($p.displayText) { $p.displayText } else { $url }
        if ($range.Text -and $range.Text.Trim() -ne "") {
            $doc.Hyperlinks.Add($range, $url)
        } else {
            $range.Text = $text
            $doc.Hyperlinks.Add($doc.Range($range.Start, $range.Start + $text.Length), $url)
        }
        Output-Json @{ success = $true; data = @{ url = $url; text = $text } }
    }

    "insertBookmark" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if (-not $p.name) { Output-Json @{ success = $false; error = "name required" }; exit }
        $range = $word.Selection.Range
        $doc.Bookmarks.Add($p.name, $range)
        Output-Json @{ success = $true; data = @{ name = $p.name } }
    }

    "getBookmarks" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $bookmarks = @()
        for ($i = 1; $i -le $doc.Bookmarks.Count; $i++) {
            $bm = $doc.Bookmarks.Item($i)
            $bookmarks += @{ name = $bm.Name; start = $bm.Start; end = $bm.End }
        }
        Output-Json @{ success = $true; data = @{ bookmarks = $bookmarks; count = $bookmarks.Count } }
    }

    "getDocumentParagraphs" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $startIdx = if ($null -ne $p.startParagraph) { [int]$p.startParagraph } else { 1 }
        $endIdx = if ($null -ne $p.endParagraph) { [int]$p.endParagraph } else { [Math]::Min($doc.Paragraphs.Count, $startIdx + 49) }
        if ($endIdx -gt $doc.Paragraphs.Count) { $endIdx = $doc.Paragraphs.Count }
        $paragraphs = @()
        for ($i = $startIdx; $i -le $endIdx; $i++) {
            $para = $doc.Paragraphs.Item($i)
            $text = $para.Range.Text
            $text = $text.TrimEnd("`r`n", "`r", "`n")
            if ($text.Length -gt 200) { $text = $text.Substring(0, 200) + "..." }
            $styleName = ""
            try { $styleName = $para.Range.Style.NameLocal } catch { $styleName = "" }
            $paragraphs += @{ index = $i; text = $text; style = $styleName; start = $para.Range.Start; end = $para.Range.End }
        }
        Output-Json @{ success = $true; data = @{ paragraphs = $paragraphs; totalCount = $doc.Paragraphs.Count; returnedCount = $paragraphs.Count } }
    }

    "findInDocument" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        if (-not $p.findText) { Output-Json @{ success = $false; error = "findText required" }; exit }
        $matchCase = if ($null -ne $p.matchCase) { [bool]$p.matchCase } else { $false }
        $matchWholeWord = if ($null -ne $p.matchWholeWord) { [bool]$p.matchWholeWord } else { $false }
        $maxResults = if ($null -ne $p.maxResults) { [int]$p.maxResults } else { 20 }
        $results = @()
        $searchRange = $doc.Content.Duplicate
        $searchRange.Find.ClearFormatting()
        $searchRange.Find.Text = $p.findText
        $found = $searchRange.Find.Execute($p.findText, $matchCase, $matchWholeWord, $false, $false, $false, $true, 1, $false, "", 0)
        while ($found -and $results.Count -lt $maxResults) {
            $matchStart = $searchRange.Start
            $matchEnd = $searchRange.End
            $matchText = $searchRange.Text
            $paraIdx = 0
            for ($pi = 1; $pi -le $doc.Paragraphs.Count; $pi++) {
                $pr = $doc.Paragraphs.Item($pi).Range
                if ($matchStart -ge $pr.Start -and $matchStart -le $pr.End) { $paraIdx = $pi; break }
            }
            $ctxStart = [Math]::Max(0, $matchStart - 50)
            $ctxEnd = [Math]::Min($doc.Content.End, $matchEnd + 50)
            $ctxRange = $doc.Range($ctxStart, $ctxEnd)
            $context = $ctxRange.Text
            $results += @{ text = $matchText; start = $matchStart; end = $matchEnd; paragraphIndex = $paraIdx; context = $context }
            $searchRange = $doc.Range($matchEnd, $doc.Content.End)
            $searchRange.Find.ClearFormatting()
            $searchRange.Find.Text = $p.findText
            $found = $searchRange.Find.Execute($p.findText, $matchCase, $matchWholeWord, $false, $false, $false, $true, 1, $false, "", 0)
        }
        Output-Json @{ success = $true; data = @{ results = $results; count = $results.Count; findText = $p.findText } }
    }

    "smartFillField" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        if (-not $p.keyword) { Output-Json @{ success = $false; error = "keyword required" }; exit }
        if ($null -eq $p.value) { Output-Json @{ success = $false; error = "value required（空字符串将清除该字段内容）" }; exit }
        $fillMode = if ($p.fillMode) { $p.fillMode.ToLower() } else { "auto" }

        $searchRange = $doc.Content.Duplicate
        $searchRange.Find.ClearFormatting()
        $searchRange.Find.Text = $p.keyword
        $found = $searchRange.Find.Execute($p.keyword, $false, $false, $false, $false, $false, $true, 1, $false, "", 0)
        if (-not $found) { Output-Json @{ success = $false; error = "Keyword '$($p.keyword)' not found" }; exit }

        $matchStart = $searchRange.Start
        $matchEnd = $searchRange.End
        $paraRange = $searchRange.Paragraphs.Item(1).Range
        $paraText = $paraRange.Text
        $detectedMode = $fillMode

        if ($fillMode -eq "auto") {
            if ($paraText -match '[\{\【\[]' + [regex]::Escape($p.keyword) + '[\}\】\]]') {
                $detectedMode = "placeholder"
            }
            elseif ($paraText -match [regex]::Escape($p.keyword) + '\s*[：:]\s*_+') {
                $detectedMode = "underline"
            }
            elseif ($paraText -match [regex]::Escape($p.keyword) + '\s*[：:]') {
                $detectedMode = "afterColon"
            }
            else {
                $afterKeyword = $paraText.Substring([Math]::Min($paraText.IndexOf($p.keyword) + $p.keyword.Length, $paraText.Length))
                $afterKeyword = $afterKeyword.TrimStart().TrimEnd("`r`n", "`r", "`n").TrimEnd()
                if ($afterKeyword.Length -eq 0 -or $afterKeyword -match '^[\s\r\n]*$') {
                    $detectedMode = "afterLabel"
                } else {
                    $detectedMode = "afterColon"
                }
            }
        }

        $fillResult = ""
        switch ($detectedMode) {
            "placeholder" {
                $fullPlaceholder = ""
                if ($paraText -match '([\{\【\[])' + [regex]::Escape($p.keyword) + '([\}\】\]])') {
                    $fullPlaceholder = $Matches[0]
                } else {
                    $fullPlaceholder = $p.keyword
                }
                $replaceRange = $doc.Content.Duplicate
                $replaceRange.Find.ClearFormatting()
                $replaceRange.Find.Text = $fullPlaceholder
                $found2 = $replaceRange.Find.Execute($fullPlaceholder, $false, $false, $false, $false, $false, $true, 1, $false, $p.value, 1)
                if ($found2) { $fillResult = "Replaced placeholder '$fullPlaceholder' with '$($p.value)'" }
                else { $fillResult = "Failed to replace placeholder" }
            }
            "underline" {
                $keywordEndPos = $matchEnd
                $fillDone = $false
                for ($ri = 1; $ri -le $paraRange.Words.Count; $ri++) {
                    $wordObj = $paraRange.Words.Item($ri)
                    if ($wordObj.Start -gt $keywordEndPos -and $wordObj.Font.Underline -ne 0 -and $wordObj.Text -match '_+') {
                        $wordObj.Text = $p.value
                        $wordObj.Font.Underline = 1
                        $fillDone = $true
                        $fillResult = "Filled underlined field after '$($p.keyword)' with '$($p.value)'"
                        break
                    }
                }
                if (-not $fillDone) {
                    $underscorePattern = "_+"
                    $afterKeyRange = $doc.Range($keywordEndPos, $paraRange.End)
                    $afterKeyRange.Find.ClearFormatting()
                    $afterKeyRange.Find.Text = $underscorePattern
                    $afterKeyRange.Find.MatchWildcards = $true
                    $foundUl = $afterKeyRange.Find.Execute($underscorePattern, $false, $false, $false, $false, $false, $true, 1, $false, $p.value, 1)
                    if ($foundUl) {
                        $fillResult = "Filled underline after '$($p.keyword)' with '$($p.value)'"
                    } else {
                        $insertRange = $doc.Range($keywordEndPos, $keywordEndPos)
                        $insertRange.InsertAfter($p.value)
                        $fillResult = "Inserted '$($p.value)' after keyword '$($p.keyword)' (no underline found)"
                    }
                }
            }
            "afterColon" {
                $afterKeyRange = $doc.Range($matchEnd, $paraRange.End)
                $afterKeyText = $afterKeyRange.Text
                $colonOffset = $afterKeyText.IndexOfAny([char[]]@('：', ':'))
                if ($colonOffset -ge 0) {
                    $insertPos = $matchEnd + $colonOffset + 1
                    $afterColonRange = $doc.Range($insertPos, $paraRange.End - 1)
                    $afterColonText = $afterColonRange.Text.TrimStart().TrimEnd("`r`n", "`r", "`n").TrimEnd()
                    if ($afterColonText.Length -gt 0 -and $afterColonText -notmatch '^[\s\r\n_　]+$') {
                        $afterColonRange.Text = $p.value
                        $fillResult = "Replaced content after colon with '$($p.value)'"
                    } else {
                        $insertRange = $doc.Range($insertPos, $insertPos)
                        $insertRange.InsertAfter($p.value)
                        $fillResult = "Inserted '$($p.value)' after colon following '$($p.keyword)'"
                    }
                } else {
                    $insertRange = $doc.Range($matchEnd, $matchEnd)
                    $insertRange.InsertAfter("：" + $p.value)
                    $fillResult = "No colon found, inserted '：$($p.value)' after '$($p.keyword)'"
                }
            }
            "afterLabel" {
                $insertRange = $doc.Range($matchEnd, $matchEnd)
                $insertRange.InsertAfter($p.value)
                $fillResult = "Inserted '$($p.value)' after label '$($p.keyword)'"
            }
            default {
                $insertRange = $doc.Range($matchEnd, $matchEnd)
                $insertRange.InsertAfter($p.value)
                $fillResult = "Inserted '$($p.value)' after '$($p.keyword)' (default mode)"
            }
        }
        Output-Json @{ success = $true; data = @{ keyword = $p.keyword; value = $p.value; fillMode = $detectedMode; result = $fillResult } }
    }

    "replaceBookmarkContent" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        if (-not $p.name) { Output-Json @{ success = $false; error = "name required" }; exit }
        if ($null -eq $p.text) { Output-Json @{ success = $false; error = "text required" }; exit }
        try {
            $bm = $doc.Bookmarks.Item($p.name)
            $bmStart = $bm.Start
            $bmRange = $bm.Range
            $bmRange.Text = $p.text
            $newEnd = $bmStart + $p.text.Length
            $newRange = $doc.Range($bmStart, $newEnd)
            $doc.Bookmarks.Add($p.name, $newRange) | Out-Null
            Output-Json @{ success = $true; data = @{ name = $p.name; text = $p.text; start = $bmStart; end = $newEnd } }
        } catch {
            Output-Json @{ success = $false; error = "Bookmark '$($p.name)' not found or failed to replace: $($_.Exception.Message)" }
        }
    }

    "addComment" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $text = if ($p.text) { $p.text } else { $p.comment }
        if (-not $text) { Output-Json @{ success = $false; error = "text required" }; exit }
        $range = $word.Selection.Range
        $doc.Comments.Add($range, $text)
        Output-Json @{ success = $true }
    }

    "getComments" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $comments = @()
        for ($i = 1; $i -le $doc.Comments.Count; $i++) {
            $c = $doc.Comments.Item($i)
            $comments += @{ index = $i; text = $c.Range.Text; author = if ($c.Author) { $c.Author } else { "" }; date = if ($c.Date) { $c.Date.ToString() } else { "" } }
        }
        Output-Json @{ success = $true; data = @{ comments = $comments; count = $comments.Count } }
    }

    "getDocumentStats" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $stats = @{ name = $doc.Name; path = $doc.FullName; pages = $doc.ComputeStatistics(2); words = $doc.ComputeStatistics(0); characters = $doc.ComputeStatistics(3); paragraphs = $doc.ComputeStatistics(4); lines = $doc.ComputeStatistics(1) }
        Output-Json @{ success = $true; data = $stats }
    }

    "insertImage" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        $path = if ($p.path) { $p.path } else { $p.filePath }
        if (-not $path) { Output-Json @{ success = $false; error = "path required" }; exit }
        $range = $word.Selection.Range
        $shape = $doc.InlineShapes.AddPicture($path, $false, $true, $range)
        if ($p.width) { $shape.Width = $p.width }
        if ($p.height) { $shape.Height = $p.height }
        if ($p.scale) { $shape.ScaleWidth = $p.scale; $shape.ScaleHeight = $p.scale }
        Output-Json @{ success = $true; data = @{ width = $shape.Width; height = $shape.Height } }
    }

    "applyStyle" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        if ($p.range -and $null -ne $p.range.start -and $null -ne $p.range.end) {
            $range = $doc.Range([int]$p.range.start, [int]$p.range.end)
        } else {
            $range = $word.Selection.Range
        }
        $range.Style = $p.styleName
        Output-Json @{ success = $true; data = @{ affectedText = $range.Text } }
    }

    # ==================== Word: Proofreading ====================
    "enableTrackChanges" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $enable = if ($null -ne $p.enable) { [bool]$p.enable } else { $true }
        $doc.TrackRevisions = $enable
        Output-Json @{ success = $true; data = @{ trackChanges = $enable; active = $doc.TrackRevisions } }
    }

    "getTrackChangesStatus" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        $revisionCount = 0
        try { $revisionCount = $doc.Revisions.Count } catch {}
        Output-Json @{ success = $true; data = @{ trackChanges = [bool]$doc.TrackRevisions; revisionCount = $revisionCount } }
    }

    "replaceRange" {
        $word = Get-WpsWord
        if ($null -eq $word) { Output-Json @{ success = $false; error = "WPS Word not running" }; exit }
        $doc = $word.ActiveDocument
        if ($null -eq $doc) { Output-Json @{ success = $false; error = "No active document" }; exit }
        if ($null -eq $p.startPos -or $null -eq $p.endPos) { Output-Json @{ success = $false; error = "startPos and endPos required" }; exit }
        if ($null -eq $p.text) { Output-Json @{ success = $false; error = "text required" }; exit }
        try {
            $range = $doc.Range([int]$p.startPos, [int]$p.endPos)
            $originalText = $range.Text
            $range.Text = $p.text
            $actualEndPos = $range.End
            Output-Json @{ success = $true; data = @{ startPos = [int]$p.startPos; originalEndPos = [int]$p.endPos; endPos = $actualEndPos; originalText = $originalText.TrimEnd("`r`n"); newText = $p.text } }
        } catch {
            Output-Json @{ success = $false; error = "Failed to replace range: $($_.Exception.Message)" }
        }
    }

    # ==================== PPT ====================
    "readPresentationScene" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        Output-Json (Get-PptPresentationSceneResult $pres)
    }

    "managePptPresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $lifecycleAction = [string]$p.lifecycleAction
        if (@(
            "list",
            "create",
            "open",
            "save",
            "save_as",
            "close",
            "switch",
            "active_presentation_identity",
            "find_open_presentation_by_path"
        ) -notcontains $lifecycleAction) {
            Output-Json (New-PptRecoverableError "PPT_INVALID_LIFECYCLE_ACTION" "Unsupported PPT lifecycle action." @{ lifecycleAction = $lifecycleAction })
            exit
        }
        if ($lifecycleAction -eq "active_presentation_identity") {
            $activePresentation = Get-WpsPptPresentation $ppt
            $activeIdentity = $null
            if ($null -ne $activePresentation) {
                $identityResult = Get-PptPresentationTemplateIdentityResult $activePresentation
                if (-not $identityResult.success) { Output-Json $identityResult; exit }
                $activeIdentity = $identityResult.data
            }
            Output-Json @{ success = $true; data = @{ presentation = $activeIdentity } }
            exit
        }
        if ($lifecycleAction -eq "find_open_presentation_by_path") {
            $filePath = [string]$p.filePath
            if ([string]::IsNullOrWhiteSpace($filePath) -or -not [System.IO.Path]::IsPathRooted($filePath)) {
                Output-Json (New-PptRecoverableError "PPT_FILE_PATH_REQUIRED" "find_open_presentation_by_path requires an absolute filePath." @{})
                exit
            }
            $targetPath = [System.IO.Path]::GetFullPath($filePath)
            $matchedPresentation = $null
            for ($index = 1; $index -le $ppt.Presentations.Count; $index++) {
                $item = $ppt.Presentations.Item($index)
                $itemName = ""
                $itemPath = ""
                try { $itemName = [string]$item.Name } catch {}
                try { $itemPath = [string]$item.FullName } catch {}
                if ([string]::IsNullOrWhiteSpace($itemPath) -or $itemPath -eq $itemName) { continue }
                try { $itemPath = [System.IO.Path]::GetFullPath($itemPath) } catch { continue }
                if ([string]::Equals($itemPath, $targetPath, [System.StringComparison]::OrdinalIgnoreCase)) {
                    $matchedPresentation = $item
                    break
                }
            }
            $matchedIdentity = $null
            if ($null -ne $matchedPresentation) {
                $identityResult = Get-PptPresentationTemplateIdentityResult $matchedPresentation
                if (-not $identityResult.success) { Output-Json $identityResult; exit }
                $matchedIdentity = $identityResult.data
            }
            Output-Json @{ success = $true; data = @{ presentation = $matchedIdentity } }
            exit
        }
        if ($lifecycleAction -eq "list") {
            $items = @()
            $nameCounts = @{}
            for ($index = 1; $index -le $ppt.Presentations.Count; $index++) {
                $item = $ppt.Presentations.Item($index)
                $items += $item
                $itemName = ""
                try { $itemName = [string]$item.Name } catch {}
                $nameKey = $itemName.ToLowerInvariant()
                if ($nameCounts.ContainsKey($nameKey)) {
                    $nameCounts[$nameKey] = [int]$nameCounts[$nameKey] + 1
                } else {
                    $nameCounts[$nameKey] = 1
                }
            }
            $presentations = @()
            $activePresentation = Get-WpsPptPresentation $ppt
            $activeRuntimeLocator = ""
            if ($null -ne $activePresentation) {
                $activeName = ""
                try { $activeName = [string]$activePresentation.Name } catch {}
                $activeNameKey = $activeName.ToLowerInvariant()
                $activeNameAmbiguous = $nameCounts.ContainsKey($activeNameKey) -and [int]$nameCounts[$activeNameKey] -gt 1
                $activeRuntimeLocator = Get-PptRuntimePresentationLocator $activePresentation $activeNameAmbiguous
            }
            foreach ($item in $items) {
                $itemName = ""
                try { $itemName = [string]$item.Name } catch {}
                $nameKey = $itemName.ToLowerInvariant()
                $nameAmbiguous = $nameCounts.ContainsKey($nameKey) -and [int]$nameCounts[$nameKey] -gt 1
                $result = Get-PptPresentationIdentityResult $item $nameAmbiguous $activeRuntimeLocator
                if (-not $result.success) { continue }
                $presentations += $result.data
            }
            Output-Json @{ success = $true; data = @{ presentations = @($presentations); count = $presentations.Count } }
            exit
        }
        if ($lifecycleAction -eq "create") {
            $pres = $ppt.Presentations.Add()
            if ($null -eq $pres) { Output-Json @{ success = $false; error = "Failed to create presentation" }; exit }
            try { $pres.Windows.Item(1).Activate() } catch {}
            Output-Json (Get-PptPresentationIdentityResult $pres)
            exit
        }
        if ($lifecycleAction -eq "open") {
            $filePath = [string]$p.filePath
            if ([string]::IsNullOrWhiteSpace($filePath)) {
                Output-Json (New-PptRecoverableError "PPT_FILE_PATH_REQUIRED" "open requires filePath." @{})
                exit
            }
            if (-not (Test-Path -LiteralPath $filePath)) {
                Output-Json (New-PptRecoverableError "PPT_FILE_NOT_FOUND" "Presentation file does not exist." @{ filePath = $filePath })
                exit
            }
            $readOnly = if ($null -ne $p.readOnly) { [bool]$p.readOnly } else { $false }
            $pres = $ppt.Presentations.Open($filePath, $readOnly, $false, $true)
            try { $pres.Windows.Item(1).Activate() } catch {}
            Output-Json (Get-PptPresentationIdentityResult $pres)
            exit
        }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        if ($lifecycleAction -eq "switch") {
            try { $pres.Windows.Item(1).Activate() } catch {
                Output-Json @{ success = $false; error = "Failed to activate presentation: $($_.Exception.Message)" }
                exit
            }
            Output-Json (Get-PptPresentationIdentityResult $pres)
            exit
        }
        if ($lifecycleAction -eq "save") {
            $protection = Get-PptPresentationProtectionState $pres
            if ([bool]$protection.readOnly) {
                Output-Json (New-PptRecoverableError "PPT_PRESENTATION_READ_ONLY" "Cannot save a read-only presentation." @{})
                exit
            }
            $fullPath = ""
            try { $fullPath = [string]$pres.FullName } catch {}
            $name = ""
            try { $name = [string]$pres.Name } catch {}
            if ([string]::IsNullOrWhiteSpace($fullPath) -or $fullPath -eq $name) {
                Output-Json (New-PptRecoverableError "PPT_SAVE_AS_REQUIRED" "This presentation has no file path. Use save_as with an explicit filePath." @{ retryable = $true })
                exit
            }
            try { $pres.Save() } catch {
                Output-Json @{ success = $false; error = "Failed to save presentation: $($_.Exception.Message)" }
                exit
            }
            Output-Json (Get-PptPresentationIdentityResult $pres)
            exit
        }
        if ($lifecycleAction -eq "save_as") {
            $filePath = [string]$p.filePath
            if ([string]::IsNullOrWhiteSpace($filePath)) {
                Output-Json (New-PptRecoverableError "PPT_FILE_PATH_REQUIRED" "save_as requires filePath." @{})
                exit
            }
            $targetExists = Test-Path -LiteralPath $filePath
            if ($targetExists -and -not [bool]$p.overwrite) {
                Output-Json (New-PptRecoverableError "PPT_SAVE_AS_TARGET_EXISTS" "save_as requires overwrite=true for an existing target." @{ filePath = $filePath; retryable = $true })
                exit
            }
            $backupPath = $null
            try {
                if ($targetExists -and [bool]$p.overwrite) {
                    $backupPath = "$filePath.wps-scene-backup-$([Guid]::NewGuid().ToString('N'))"
                    Move-Item -LiteralPath $filePath -Destination $backupPath
                }
                $pres.SaveAs($filePath)
            } catch {
                if ($null -ne $backupPath -and (Test-Path -LiteralPath $backupPath)) {
                    if (Test-Path -LiteralPath $filePath) { Remove-Item -LiteralPath $filePath -Force }
                    Move-Item -LiteralPath $backupPath -Destination $filePath
                }
                Output-Json @{ success = $false; error = "Failed to save presentation as: $($_.Exception.Message)" }
                exit
            }
            $cleanupWarning = ""
            if ($null -ne $backupPath -and (Test-Path -LiteralPath $backupPath)) {
                try { Remove-Item -LiteralPath $backupPath -Force } catch {
                    $cleanupWarning = "The previous target backup could not be removed after save_as succeeded."
                }
            }
            $identityResult = Get-PptPresentationIdentityResult $pres
            if ($identityResult.success -and -not [string]::IsNullOrWhiteSpace($cleanupWarning)) {
                $identityResult.data.backupCleanupWarning = $cleanupWarning
            }
            Output-Json $identityResult
            exit
        }
        if ($lifecycleAction -eq "close") {
            $identityBeforeClose = Get-PptPresentationIdentityResult $pres
            if (-not $identityBeforeClose.success) {
                Output-Json $identityBeforeClose
                exit
            }
            $saved = [bool]$identityBeforeClose.data.saved
            if (-not $saved -and -not [bool]$p.discardChanges) {
                Output-Json (New-PptRecoverableError "PPT_UNSAVED_CLOSE_REQUIRES_DECISION" "Closing an unsaved presentation requires discardChanges=true or a prior save." @{ retryable = $true })
                exit
            }
            $name = [string]$pres.Name
            $fullPath = ""
            try { $fullPath = [string]$pres.FullName } catch {}
            if (-not $saved -and [bool]$p.discardChanges) {
                try { $pres.Saved = $true } catch {
                    Output-Json @{ success = $false; error = "Failed to mark presentation changes as discarded: $($_.Exception.Message)" }
                    exit
                }
            }
            try { $pres.Close() } catch {
                Output-Json @{ success = $false; error = "Failed to close presentation: $($_.Exception.Message)" }
                exit
            }
            Output-Json @{ success = $true; data = @{ closed = $true; name = $name; fullPath = $fullPath } }
            exit
        }
    }

    "executePptSceneCreationPlan" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneCreationPlanResult $pres $p)
    }

    "readPptSceneChartData" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneChartSemanticDataResult $pres $p)
    }

    "rollbackPptSceneCreationCommit" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneCreationCommitRollbackResult $pres $p)
    }

    "executePptSceneStructuralPlan" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneStructuralPlanResult $pres $p)
    }

    "executePptSceneSpecializedPlan" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneSpecializedPlanResult $pres $p)
    }

    "executePptSceneMixedPlan" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        Output-Json (Get-PptSceneMixedPlanResult $pres $p)
    }

    "getActivePresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $slides = @()
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            $shapes = @()
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                $shapes += Get-PptShapeSummary $shape $j 160
            }
            $slides += @{ index = $i; shapeCount = $slide.Shapes.Count; shapes = $shapes }
        }
        Output-Json @{ success = $true; data = @{ name = $pres.Name; path = $pres.FullName; slideCount = $pres.Slides.Count; slides = $slides } }
    }

    "openPresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        if (-not $p.path) { Output-Json @{ success = $false; error = "path required" }; exit }
        $pres = $ppt.Presentations.Open($p.path)
        Output-Json @{ success = $true; data = @{ name = $pres.Name; path = $pres.FullName; slideCount = $pres.Slides.Count } }
    }

    "closePresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = if ($p.name) { Get-WpsPptPresentationById $ppt ([string]$p.name) } else { Get-WpsPptPresentation $ppt }
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No presentation" }; exit }
        $name = $pres.Name
        $pres.Close()
        Output-Json @{ success = $true; data = @{ closed = $name } }
    }

    "getOpenPresentations" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $presentations = @()
        for ($i = 1; $i -le $ppt.Presentations.Count; $i++) {
            $presItem = $ppt.Presentations.Item($i)
            $presentations += @{ name = $presItem.Name; path = $presItem.FullName; slideCount = $presItem.Slides.Count }
        }
        Output-Json @{ success = $true; data = @{ presentations = $presentations; count = $presentations.Count } }
    }

    "switchPresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $presItem = $ppt.Presentations.Item($(if ($p.name) { $p.name } else { $p.index }))
        $presItem.Windows.Item(1).Activate()
        Output-Json @{ success = $true; data = @{ name = $presItem.Name } }
    }

    "deleteSlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        $pres.Slides.Item($index).Delete()
        Output-Json @{ success = $true; data = @{ deleted = $index } }
    }

    "duplicateSlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        if (-not $index) { $index = 1 }
        $slide = $pres.Slides.Item($index)
        $newSlide = $slide.Duplicate()
        $newIndex = $newSlide.Item(1).SlideIndex
        # WPS activates the copied slide. Restore the source so mutation QA
        # continues against the contract's validated source page.
        $pres.Windows.Item(1).View.GotoSlide($index)
        Output-Json @{ success = $true; data = @{ sourceIndex = $index; newIndex = $newIndex; newSlideIndex = $newIndex } }
    }

    "moveSlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $fromIndex = if ($p.from) { $p.from } else { $p.fromIndex }
        $toIndex = if ($p.to) { $p.to } else { $p.toIndex }
        $pres.Slides.Item($fromIndex).MoveTo($toIndex)
        Output-Json @{ success = $true; data = @{ from = $fromIndex; to = $toIndex } }
    }

    "getSlideCount" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        Output-Json @{ success = $true; data = @{ count = $pres.Slides.Count } }
    }

    "getSlideInfo" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        $resolvedSlide = Resolve-PptSlide $pres $index "getSlideInfo"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $index = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $shapes = @()
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            $shapes += Get-PptShapeSummary $shape $i 160
        }
        Output-Json @{ success = $true; data = @{ index = $index; slideIndex = $index; shapeCount = $slide.Shapes.Count; shapesCount = $slide.Shapes.Count; shapes = $shapes; layout = $slide.Layout } }
    }

    "getSlideStructure" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $mode = if ($p.mode) { [string]$p.mode } elseif ($p.includeContent) { "content" } else { "structure" }
        if (@("structure", "content", "both") -notcontains $mode) {
            Output-Json (New-PptRecoverableError "PPT_INVALID_STRUCTURE_MODE" "getSlideStructure failed: mode must be structure, content, or both." @{ mode = $mode; validModes = @("structure", "content", "both") })
            exit
        }
        Output-Json (Get-PptSlideStructureResult $pres $slideIndex $mode)
    }

    "getCurrentPptContext" {
        $diagnosticsEnabled = [bool](Get-ObjectPropertyValue $p "__includeDiagnostics")
        $actionTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $timing = @{}
        $phaseTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $ppt = Get-WpsPpt
        $timing.getWpsPpt = $phaseTimer.ElapsedMilliseconds
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $phaseTimer.Restart()
        $pres = Get-WpsPptPresentation $ppt
        $timing.getPresentation = $phaseTimer.ElapsedMilliseconds
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $phaseTimer.Restart()
        $result = Get-PptCurrentContextResult $ppt $pres $p
        $timing.contextPayload = $phaseTimer.ElapsedMilliseconds
        if ($diagnosticsEnabled -and $result.success -and $null -ne $result.data) {
            $diagnostics = Get-ObjectPropertyValue $result.data "diagnostics"
            if ($null -eq $diagnostics -or -not ($diagnostics -is [System.Collections.IDictionary])) {
                $diagnostics = @{}
                $result.data.diagnostics = $diagnostics
            }
            $diagnostics.wrapper = @{
                actionInternalMs = $actionTimer.ElapsedMilliseconds
                timingMs = $timing
            }
        }
        Output-Json $result
    }

    "readPptSceneTargets" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlideBinding $pres $slideIndex (Get-ObjectPropertyValue $p "nativeSlideId") "readPptSceneTargets"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slide = $resolvedSlide.slide
        $slideIndex = [int]$resolvedSlide.slideIndex
        $readbackDiagnostics = if ([bool](Get-ObjectPropertyValue $p "__includeDiagnostics")) { @{} } else { $null }
        $readback = Get-PptSceneTargetsReadbackData `
            $pres `
            $slide `
            $slideIndex `
            @((Get-ObjectPropertyValue $p "targets")) `
            ([bool](Get-ObjectPropertyValue $p "includeRollbackSnapshot")) `
            $readbackDiagnostics
        if ($null -ne $readbackDiagnostics -and $readback.success) {
            $readback.data.diagnostics = $readbackDiagnostics
        }
        Output-Json $readback
    }

    "restorePptMutationSnapshot" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $snapshot = Get-ObjectPropertyValue $p "snapshot"
        if ($null -eq $snapshot) {
            Output-Json @{ success = $false; error = "restorePptMutationSnapshot requires snapshot" }
            exit
        }
        $result = Restore-PptMutationRollbackSnapshot $pres $snapshot (Get-ObjectPropertyValue $p "creationReceipts")
        Output-Json @{
            success = [bool]$result.rollbackVerified
            error = $(if ([bool]$result.rollbackVerified) { $null } else { "PPT mutation rollback could not be verified" })
            data = $result
        }
    }

    "uniformPptComponentLayout" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        Output-Json (Get-PptUniformComponentLayoutResult $ppt $pres $p)
    }

    "normalizePptComponentGrid" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        Output-Json (Get-PptNormalizeComponentGridResult $ppt $pres $p)
    }

    "readSlides" {
        $diagnosticsEnabled = [bool](Get-ObjectPropertyValue $p "__includeDiagnostics")
        $actionTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $timing = @{}
        $phaseTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $ppt = Get-WpsPpt
        $timing.getWpsPpt = $phaseTimer.ElapsedMilliseconds
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $phaseTimer.Restart()
        $pres = Get-WpsPptPresentation $ppt
        $timing.getPresentation = $phaseTimer.ElapsedMilliseconds
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $phaseTimer.Restart()
        $mode = if ($p.mode) { [string]$p.mode } elseif ($p.includeContent) { "content" } else { "structure" }
        if (@("structure", "content", "both") -notcontains $mode) {
            Output-Json (New-PptRecoverableError "PPT_INVALID_STRUCTURE_MODE" "readSlides failed: mode must be structure, content, or both." @{ mode = $mode; validModes = @("structure", "content", "both") })
            exit
        }
        $slideIndexes = @()
        if ($p.nativeSlideId) {
            $resolvedSlide = Resolve-PptSlideBinding $pres $p.slideIndex $p.nativeSlideId "readSlides"
            if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
            $slideIndexes += [int]$resolvedSlide.slideIndex
        } elseif ($p.slideIndexes) {
            foreach ($idx in $p.slideIndexes) { $slideIndexes += [int]$idx }
        } else {
            $start = if ($p.startSlide) { [int]$p.startSlide } elseif ($p.start) { [int]$p.start } else { 1 }
            $end = if ($p.endSlide) { [int]$p.endSlide } elseif ($p.end) { [int]$p.end } else { [int]$pres.Slides.Count }
            if ($start -gt $end) {
                Output-Json (New-PptRecoverableError "PPT_INVALID_SLIDE_RANGE" "readSlides failed: start slide is greater than end slide." @{ start = $start; end = $end; slideCount = $pres.Slides.Count })
                exit
            }
            for ($idx = $start; $idx -le $end; $idx++) { $slideIndexes += $idx }
        }
        $maxSlides = if ($p.maxSlides) { [int]$p.maxSlides } else { 50 }
        if ($slideIndexes.Count -gt $maxSlides) { $slideIndexes = $slideIndexes[0..($maxSlides - 1)] }
        $includeScreenshot = if ($null -ne $p.includeScreenshot) { [bool]$p.includeScreenshot } else { $false }
        $timing.resolveSlideSet = $phaseTimer.ElapsedMilliseconds
        $slides = @()
        $structureTimer = [System.Diagnostics.Stopwatch]::StartNew()
        foreach ($idx in $slideIndexes) {
            $result = Get-PptSlideStructureResult $pres $idx $mode
            if (-not $result.success) { Output-Json $result; exit }
            if ($includeScreenshot) {
                $screenshot = Export-PptSlideImageSafe $pres $idx $p "readSlides"
                if (-not $screenshot.success) { Output-Json $screenshot; exit }
                $result.data["screenshot"] = $screenshot.data
            }
            $slides += $result.data
        }
        $timing.slideStructure = $structureTimer.ElapsedMilliseconds
        $phaseTimer.Restart()
        $presentationIdentity = Get-PptPresentationIdentityResult $pres
        $timing.presentationIdentity = $phaseTimer.ElapsedMilliseconds
        if (-not $presentationIdentity.success) { Output-Json $presentationIdentity; exit }
        $timing.internalBeforeJson = $actionTimer.ElapsedMilliseconds
        $data = @{ mode = $mode; includeScreenshot = $includeScreenshot; presentation = $presentationIdentity.data; requestedSlideIndexes = $slideIndexes; slides = $slides; count = $slides.Count }
        if ($diagnosticsEnabled) {
            $data.diagnostics = @{ actionInternalMs = $actionTimer.ElapsedMilliseconds; timingMs = $timing; slideCount = $slides.Count; objectCounts = @($slides | ForEach-Object { [int]$_.slide.objectCount }) }
        }
        Output-Json @{ success = $true; data = $data }
    }

    "readSlideImage" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        Output-Json (Export-PptSlideImageSafe $pres $slideIndex $p "readSlideImage")
    }

    "verifySlides" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }

        $slideIndexes = @()
        if ($p.slideIndex) { $slideIndexes += [int]$p.slideIndex }
        elseif ($p.slideIndexes) { foreach ($idx in $p.slideIndexes) { $slideIndexes += [int]$idx } }
        else {
            $start = if ($p.startSlide) { [int]$p.startSlide } elseif ($p.start) { [int]$p.start } else { 1 }
            $end = if ($p.endSlide) { [int]$p.endSlide } elseif ($p.end) { [int]$p.end } else { [int]$pres.Slides.Count }
            if ($start -gt $end) {
                Output-Json (New-PptRecoverableError "PPT_INVALID_SLIDE_RANGE" "verifySlides failed: start slide is greater than end slide." @{ start = $start; end = $end; slideCount = $pres.Slides.Count })
                exit
            }
            for ($idx = $start; $idx -le $end; $idx++) { $slideIndexes += $idx }
        }

        $maxSlides = if ($p.maxSlides) { [int]$p.maxSlides } else { 50 }
        if ($slideIndexes.Count -gt $maxSlides) { $slideIndexes = $slideIndexes[0..($maxSlides - 1)] }
        $includeScreenshot = if ($null -ne $p.includeScreenshot) { [bool]$p.includeScreenshot } else { $false }

        $slideResults = @()
        $allIssues = @()
        $targets = @()
        foreach ($idx in $slideIndexes) {
            $verify = Test-PptSlideGeometry $pres $idx $p
            if (-not $verify.success) { Output-Json $verify; exit }
            if ($includeScreenshot) {
                $screenshot = Export-PptSlideImageSafe $pres $idx $p "verifySlides"
                if (-not $screenshot.success) { Output-Json $screenshot; exit }
                $verify.data["screenshot"] = $screenshot.data
            }
            $slideResults += $verify.data
            $allIssues += @($verify.data.issues)
            $targets += @($verify.data.suggestedVerificationTargets)
        }

        $errorCount = @($allIssues | Where-Object { $_.severity -eq "error" }).Count
        $warningCount = @($allIssues | Where-Object { $_.severity -eq "warning" }).Count
        $infoCount = @($allIssues | Where-Object { $_.severity -eq "info" }).Count
        Output-Json @{
            success = $true
            data = @{
                ok = ($errorCount -eq 0 -and $warningCount -eq 0)
                checkedSlides = $slideIndexes
                slideCount = $slideResults.Count
                issueCount = $allIssues.Count
                errorCount = $errorCount
                warningCount = $warningCount
                infoCount = $infoCount
                issues = $allIssues
                slides = $slideResults
                suggestedVerificationTargets = $targets
                includeScreenshot = $includeScreenshot
                visualQaPending = @{
                    requiresMultimodal = $true
                    status = "not_implemented"
                    pendingChecks = @(
                        "rendered_text_overflow",
                        "visual_style_quality",
                        "contrast_by_rendered_pixels",
                        "image_relevance",
                        "theme_consistency"
                    )
                }
            }
        }
    }

    "getFullPresentation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $mode = if ($p.mode) { [string]$p.mode } elseif ($p.includeContent) { "content" } else { "structure" }
        $maxSlides = if ($p.maxSlides) { [int]$p.maxSlides } else { [int]$pres.Slides.Count }
        $slides = @()
        $limit = [Math]::Min([int]$pres.Slides.Count, $maxSlides)
        for ($idx = 1; $idx -le $limit; $idx++) {
            $result = Get-PptSlideStructureResult $pres $idx $mode
            if (-not $result.success) { Output-Json $result; exit }
            $slides += $result.data
        }
        Output-Json @{ success = $true; data = @{ mode = $mode; presentation = @{ name = $pres.Name; path = $pres.FullName; slideCount = $pres.Slides.Count; returnedSlideCount = $slides.Count }; slides = $slides } }
    }

    "checkPlaceholderText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $includeEmpty = if ($null -ne $p.includeEmpty) { [bool]$p.includeEmpty } else { $true }
        $patterns = @(
            "单击此处添加标题",
            "单击此处添加副标题",
            "单击此处添加文本",
            "Click to add title",
            "Click to add subtitle",
            "Click to add text",
            "Title",
            "Subtitle"
        )
        if ($p.patterns) {
            $patterns = @()
            foreach ($pattern in $p.patterns) { $patterns += [string]$pattern }
        }
        $slideIndexes = @()
        if ($p.slideIndex) { $slideIndexes += [int]$p.slideIndex }
        elseif ($p.slideIndexes) { foreach ($idx in $p.slideIndexes) { $slideIndexes += [int]$idx } }
        else { for ($idx = 1; $idx -le $pres.Slides.Count; $idx++) { $slideIndexes += $idx } }

        $issues = @()
        foreach ($idx in $slideIndexes) {
            $result = Get-PptSlideStructureResult $pres $idx "content"
            if (-not $result.success) { Output-Json $result; exit }
            foreach ($obj in $result.data.objects) {
                if ($null -eq $obj.placeholderTypeName) { continue }
                $text = if ($obj.text) { [string]$obj.text } else { "" }
                $trimmed = $text.Trim()
                $matchedPattern = $null
                foreach ($pattern in $patterns) {
                    if ($trimmed -eq [string]$pattern -or ($trimmed -and $trimmed.Contains([string]$pattern))) {
                        $matchedPattern = [string]$pattern
                        break
                    }
                }
                if ($matchedPattern) {
                    $issues += @{ slideIndex = $idx; shapeId = $obj.shapeId; shapeIndex = $obj.shapeIndex; shapeName = $obj.shapeName; issueType = "placeholder_text"; text = $trimmed; matchedPattern = $matchedPattern; role = $obj.role; bounds = $obj.bounds }
                } elseif ($includeEmpty -and [string]::IsNullOrWhiteSpace($trimmed)) {
                    $issues += @{ slideIndex = $idx; shapeId = $obj.shapeId; shapeIndex = $obj.shapeIndex; shapeName = $obj.shapeName; issueType = "empty_placeholder"; text = $trimmed; role = $obj.role; bounds = $obj.bounds }
                }
            }
        }
        Output-Json @{ success = $true; data = @{ issueCount = $issues.Count; issues = $issues; checkedSlides = $slideIndexes; includeEmpty = $includeEmpty } }
    }

    "listTemplateSlides" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $candidates = @()
        for ($idx = 1; $idx -le $pres.Slides.Count; $idx++) {
            $result = Get-PptSlideStructureResult $pres $idx "structure"
            if (-not $result.success) { Output-Json $result; exit }
            $candidates += Get-PptTemplateCandidate $result.data
        }
        Output-Json @{ success = $true; data = @{ presentation = @{ name = $pres.Name; path = $pres.FullName; slideCount = $pres.Slides.Count }; candidates = $candidates; count = $candidates.Count } }
    }

    "insertTemplateSlides" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $sourceSlideIndex = Get-ObjectPropertyValue $p "sourceSlideIndex"
        if (-not $sourceSlideIndex) { $sourceSlideIndex = Get-ObjectPropertyValue $p "templateSlideIndex" }
        if (-not $sourceSlideIndex) { $sourceSlideIndex = Get-ObjectPropertyValue $p "slideIndex" }
        if (-not $sourceSlideIndex) {
            Output-Json (New-PptRecoverableError "PPT_TEMPLATE_SOURCE_MISSING" "insertTemplateSlides failed: missing sourceSlideIndex/templateSlideIndex." @{ suggestedAction = "call_list_template_slides_then_retry" })
            exit
        }
        $sourceSlideIndex = [int]$sourceSlideIndex
        $sourceStructureResult = Get-PptSlideStructureResult $pres $sourceSlideIndex "content"
        if (-not $sourceStructureResult.success) { Output-Json $sourceStructureResult; exit }

        $sourceSlide = $pres.Slides.Item($sourceSlideIndex)
        $newSlideRange = $sourceSlide.Duplicate()
        $newSlide = $newSlideRange.Item(1)
        $targetPosition = Get-ObjectPropertyValue $p "position"
        if ($null -eq $targetPosition) { $targetPosition = Get-ObjectPropertyValue $p "targetIndex" }
        if ($null -eq $targetPosition) { $targetPosition = Get-ObjectPropertyValue $p "insertAt" }
        if ($null -eq $targetPosition) { $targetPosition = $pres.Slides.Count }
        $targetPosition = [int]$targetPosition
        if ($targetPosition -lt 1) { $targetPosition = 1 }
        if ($targetPosition -gt $pres.Slides.Count) { $targetPosition = $pres.Slides.Count }
        try { $newSlide.MoveTo($targetPosition) } catch {}
        $newSlideIndex = $newSlide.SlideIndex

        $textItems = @()
        $textInput = Get-ObjectPropertyValue $p "textReplacements"
        if ($null -ne $textInput) { $textItems += @($textInput) }
        $replacementInput = Get-ObjectPropertyValue $p "replacements"
        if ($null -ne $replacementInput) {
            foreach ($item in @($replacementInput)) {
                $kind = Get-ObjectPropertyValue $item "kind"
                if (-not $kind) { $kind = Get-ObjectPropertyValue $item "type" }
                $kindText = if ($kind) { [string]$kind } else { "" }
                if (-not $kindText -or $kindText -in @("text", "title", "subtitle", "body")) { $textItems += $item }
            }
        }
        $title = Get-ObjectPropertyValue $p "title"
        if ($null -ne $title) { $textItems += @{ role = "title"; text = $title } }
        $subtitle = Get-ObjectPropertyValue $p "subtitle"
        if ($null -ne $subtitle) { $textItems += @{ role = "subtitle"; text = $subtitle } }
        $body = Get-ObjectPropertyValue $p "body"
        if ($null -ne $body) { $textItems += @{ role = "body"; text = $body } }

        $tableItems = @()
        $tableInput = Get-ObjectPropertyValue $p "tableReplacements"
        if ($null -ne $tableInput) { $tableItems += @($tableInput) }
        $tableData = Get-ObjectPropertyValue $p "tableData"
        if ($null -ne $tableData) { $tableItems += @{ tableIndex = 1; data = $tableData } }

        $imageItems = @()
        $imageInput = Get-ObjectPropertyValue $p "imageReplacements"
        if ($null -ne $imageInput) { $imageItems += @($imageInput) }

        $textResult = Set-PptTemplateTextReplacements $pres $newSlideIndex $textItems
        $tableResult = Set-PptTemplateTableReplacements $pres $newSlideIndex $tableItems
        $imageResult = Set-PptTemplateImageReplacements $pres $newSlideIndex $imageItems

        $newStructureResult = Get-PptSlideStructureResult $pres $newSlideIndex "content"
        if (-not $newStructureResult.success) { Output-Json $newStructureResult; exit }
        $preservation = Get-PptTemplatePreservationReport $sourceStructureResult.data $newStructureResult.data
        $newSlots = Get-PptTemplateSlots $newStructureResult.data
        $failed = @()
        $failed += @($textResult.failed)
        $failed += @($tableResult.failed)
        $failed += @($imageResult.failed)
        $created = @()
        $created += @($imageResult.created)
        $changed = @()
        $changed += @($textResult.changed)
        $changed += @($tableResult.changed)
        $changed += @($imageResult.changed)

        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "insertTemplateSlides completed with $($failed.Count) failed replacements" } else { $null })
            data = @{
                partialMutation = $true
                sourceSlideIndex = $sourceSlideIndex
                newSlideIndex = $newSlideIndex
                targetPosition = $targetPosition
                created = $created
                changed = $changed
                failed = $failed
                failedCount = $failed.Count
                slots = $newSlots
                preservation = $preservation
                templatePreservation = $preservation
            }
        }
    }

    "checkTemplatePreservation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $sourceSlideIndex = Get-ObjectPropertyValue $p "sourceSlideIndex"
        if (-not $sourceSlideIndex) { $sourceSlideIndex = Get-ObjectPropertyValue $p "templateSlideIndex" }
        $newSlideIndex = Get-ObjectPropertyValue $p "newSlideIndex"
        if (-not $newSlideIndex) { $newSlideIndex = Get-ObjectPropertyValue $p "slideIndex" }
        if (-not $sourceSlideIndex -or -not $newSlideIndex) {
            Output-Json (New-PptRecoverableError "PPT_TEMPLATE_PRESERVATION_TARGET_MISSING" "checkTemplatePreservation failed: sourceSlideIndex and newSlideIndex are required." @{ suggestedAction = "pass_source_and_new_slide_indexes" })
            exit
        }
        $sourceStructureResult = Get-PptSlideStructureResult $pres ([int]$sourceSlideIndex) "structure"
        if (-not $sourceStructureResult.success) { Output-Json $sourceStructureResult; exit }
        $newStructureResult = Get-PptSlideStructureResult $pres ([int]$newSlideIndex) "structure"
        if (-not $newStructureResult.success) { Output-Json $newStructureResult; exit }
        $preservation = Get-PptTemplatePreservationReport $sourceStructureResult.data $newStructureResult.data
        Output-Json @{ success = $true; data = @{ sourceSlideIndex = [int]$sourceSlideIndex; newSlideIndex = [int]$newSlideIndex; preservation = $preservation; templatePreservation = $preservation } }
    }

    "switchSlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        $pres.Windows.Item(1).View.GotoSlide($index)
        Output-Json @{ success = $true; data = @{ currentSlide = $index } }
    }

    "setSlideLayout" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        if (-not $index) { $index = 1 }
        $layoutMap = @{ title = 1; titleContent = 2; blank = 12; twoColumn = 4; comparison = 5; titleOnly = 11 }
        $layout = $layoutMap[$p.layout]
        if ($null -eq $layout) { $layout = if ($p.layout) { $p.layout } else { 2 } }
        $pres.Slides.Item($index).Layout = $layout
        Output-Json @{ success = $true; data = @{ slideIndex = $index; layout = $layout } }
    }

    "getSlideNotes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        if (-not $index) { $index = 1 }
        $slide = $pres.Slides.Item($index)
        $notes = ""
        try { $notes = $slide.NotesPage.Shapes.Item(2).TextFrame.TextRange.Text } catch { $notes = "" }
        Output-Json @{ success = $true; data = @{ slideIndex = $index; notes = $notes } }
    }

    "setSlideNotes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $index = if ($p.index) { $p.index } else { $p.slideIndex }
        if (-not $index) { $index = 1 }
        $slide = $pres.Slides.Item($index)
        $slide.NotesPage.Shapes.Item(2).TextFrame.TextRange.Text = if ($p.notes) { $p.notes } else { "" }
        Output-Json @{ success = $true; data = @{ slideIndex = $index } }
    }

    "slide.add" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres -and $ppt.Presentations.Count -gt 0) {
            $pres = $ppt.Presentations.Item($ppt.Presentations.Count)
            try { $pres.Windows.Item(1).Activate() } catch {}
        }
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $layouts = @{ title = 1; title_content = 2; blank = 12; two_column = 3; comparison = 34 }
        $layoutKey = if ($p.layout) { $p.layout } else { "title_content" }
        $layoutType = $layouts[$layoutKey]
        if ($null -eq $layoutType) { $layoutType = 2 }
        $position = if ($p.position) { $p.position } else { $pres.Slides.Count + 1 }
        $slide = $pres.Slides.Add($position, $layoutType)
        if ($p.title -and $slide.Shapes.HasTitle) { $slide.Shapes.Title.TextFrame.TextRange.Text = $p.title }
        if ($p.content) {
            try {
                foreach ($shape in $slide.Shapes) {
                    try {
                        if ($shape.PlaceholderFormat.Type -eq 2) {
                            $shape.TextFrame.TextRange.Text = $p.content
                        }
                    } catch {}
                }
            } catch {}
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $position; layout = $layoutKey } }
    }

    "addSlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -eq $pres -and $ppt.Presentations.Count -gt 0) {
            $pres = $ppt.Presentations.Item($ppt.Presentations.Count)
            try { $pres.Windows.Item(1).Activate() } catch {}
        }
        if ($null -eq $pres) { Output-Json @{ success = $false; error = "No active presentation" }; exit }
        $layouts = @{ title = 1; title_content = 2; blank = 12; two_column = 3; comparison = 34 }
        $layoutKey = if ($p.layout) { $p.layout } else { "title_content" }
        $layoutType = $layouts[$layoutKey]
        if ($null -eq $layoutType) { $layoutType = 2 }
        $position = if ($p.position) { $p.position } else { $pres.Slides.Count + 1 }
        $slide = $pres.Slides.Add($position, $layoutType)
        if ($p.title -and $slide.Shapes.HasTitle) { $slide.Shapes.Title.TextFrame.TextRange.Text = $p.title }
        if ($p.content) {
            try {
                foreach ($shape in $slide.Shapes) {
                    try {
                        if ($shape.PlaceholderFormat.Type -eq 2) {
                            $shape.TextFrame.TextRange.Text = $p.content
                        }
                    } catch {}
                }
            } catch {}
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $position; nativeSlideId = $(try { [int]$slide.SlideID } catch { [int]$position }); layout = $layoutKey } }
    }

    "addTextBox" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { $pres.Windows.Item(1).Selection.SlideRange.SlideIndex }
        $slide = $pres.Slides.Item($slideIndex)
        $left = if ($null -ne $p.left) { $p.left } else { 100 }
        $top = if ($null -ne $p.top) { $p.top } else { 100 }
        $width = if ($p.width) { $p.width } else { 400 }
        $height = if ($p.height) { $p.height } else { 50 }
        $shape = $slide.Shapes.AddTextbox(1, $left, $top, $width, $height)
        if ($p.name) { $shape.Name = [string]$p.name }
        $shape.TextFrame.TextRange.Text = $p.text
        if ($p.fontSize) { $shape.TextFrame.TextRange.Font.Size = $p.fontSize }
        if ($p.fontName) { $shape.TextFrame.TextRange.Font.Name = $p.fontName }
        Output-Json @{ success = $true; data = @{ shapeName = $shape.Name; nativeShapeId = $(try { [int]$shape.Id } catch { $null }) } }
    }

    "deleteTextBox" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "deleteTextBox"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { $p.shapeIndex } elseif ($p.textboxIndex) { $p.textboxIndex } elseif ($p.textBoxIndex) { $p.textBoxIndex } else { $p.index }
        $resolvedShape = Resolve-PptShape $slide $target "deleteTextBox" "textbox"
        if (-not $resolvedShape.ok) { Output-Json $resolvedShape.result; exit }
        $shape = $resolvedShape.shape
        $shape.Delete()
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; deleted = $target } }
    }

    "getTextBoxes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "getTextBoxes"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $textBoxes = @()
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            if ($shape.HasTextFrame) {
                $hasText = $false
                $fontSize = $null
                $fontName = $null
                $alignment = $null
                $verticalAnchor = $null
                $marginLeft = $null
                $marginRight = $null
                $marginTop = $null
                $marginBottom = $null
                try { $hasText = [bool]$shape.TextFrame.HasText } catch {}
                try { $fontSize = $shape.TextFrame.TextRange.Font.Size } catch {}
                try { $fontName = $shape.TextFrame.TextRange.Font.Name } catch {}
                try { $alignment = $shape.TextFrame.TextRange.ParagraphFormat.Alignment } catch {}
                try { $verticalAnchor = $shape.TextFrame.VerticalAnchor } catch {}
                try { $marginLeft = $shape.TextFrame.MarginLeft } catch {}
                try { $marginRight = $shape.TextFrame.MarginRight } catch {}
                try { $marginTop = $shape.TextFrame.MarginTop } catch {}
                try { $marginBottom = $shape.TextFrame.MarginBottom } catch {}
                $summary = Get-PptShapeSummary $shape $i 160
                $summary["hasText"] = $hasText
                $summary["fontSize"] = $fontSize
                $summary["fontName"] = $fontName
                $summary["alignment"] = $alignment
                $summary["verticalAnchor"] = $verticalAnchor
                $summary["marginLeft"] = $marginLeft
                $summary["marginRight"] = $marginRight
                $summary["marginTop"] = $marginTop
                $summary["marginBottom"] = $marginBottom
                $textBoxes += $summary
            }
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; textBoxes = $textBoxes; count = $textBoxes.Count } }
    }

    "setTextBoxText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setTextBoxText"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { $p.shapeIndex } elseif ($p.textboxIndex) { $p.textboxIndex } elseif ($p.textBoxIndex) { $p.textBoxIndex } else { $p.index }
        $resolvedShape = Resolve-PptShape $slide $target "setTextBoxText" "textbox"
        if (-not $resolvedShape.ok) { Output-Json $resolvedShape.result; exit }
        $shape = $resolvedShape.shape
        $shape.TextFrame.TextRange.Text = if ($p.text) { $p.text } else { "" }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; name = $shape.Name; shapeIndex = $target; text = $p.text } }
    }

    "setTextBoxStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setTextBoxStyle"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { $p.shapeIndex } elseif ($p.textboxIndex) { $p.textboxIndex } elseif ($p.textBoxIndex) { $p.textBoxIndex } else { $p.index }
        $resolvedShape = Resolve-PptShape $slide $target "setTextBoxStyle" "textbox"
        if (-not $resolvedShape.ok) { Output-Json $resolvedShape.result; exit }
        $style = Get-ObjectPropertyValue $p "style"
        if ($null -eq $style) { $style = $p }
        $shape = $resolvedShape.shape
        $tr = $shape.TextFrame.TextRange
        $applied = @()

        $fontSize = Get-ObjectPropertyValue $style "fontSize"
        if ($fontSize) {
            $tr.Font.Size = [double]$fontSize
            $applied += "fontSize"
        }

        $fontName = Get-ObjectPropertyValue $style "fontName"
        if ($fontName) {
            $tr.Font.Name = [string]$fontName
            $applied += "fontName"
        }

        $bold = Get-ObjectPropertyValue $style "bold"
        if ($null -ne $bold) {
            $tr.Font.Bold = if ([bool]$bold) { -1 } else { 0 }
            $applied += "bold"
        }

        $italic = Get-ObjectPropertyValue $style "italic"
        if ($null -ne $italic) {
            $tr.Font.Italic = if ([bool]$italic) { -1 } else { 0 }
            $applied += "italic"
        }

        $color = Get-ObjectPropertyValue $style "fontColor"
        if (-not $color) { $color = Get-ObjectPropertyValue $style "color" }
        if ($color) {
            $colorValue = Convert-HexColorToRgbInt([string]$color)
            if ($null -ne $colorValue) {
                $tr.Font.Color.RGB = $colorValue
                $applied += "fontColor"
            }
        }

        $alignment = Get-ObjectPropertyValue $style "alignment"
        if (-not $alignment) { $alignment = Get-ObjectPropertyValue $style "align" }
        if (-not $alignment) { $alignment = Get-ObjectPropertyValue $style "horizontalAlignment" }
        if ($alignment) {
            $alignMap = @{ left = 1; center = 2; right = 3 }
            $alignmentValue = $alignMap[[string]$alignment]
            if ($null -ne $alignmentValue) {
                $tr.ParagraphFormat.Alignment = $alignmentValue
                $applied += "alignment"
            }
        }

        $verticalAlignment = Get-ObjectPropertyValue $style "verticalAlignment"
        if (-not $verticalAlignment) { $verticalAlignment = Get-ObjectPropertyValue $style "verticalAlign" }
        if ($verticalAlignment) {
            $verticalMap = @{ top = 1; middle = 3; center = 3; bottom = 4 }
            $verticalValue = $verticalMap[[string]$verticalAlignment]
            if ($null -ne $verticalValue) {
                $shape.TextFrame.VerticalAnchor = $verticalValue
                $applied += "verticalAlignment"
            }
        }

        $marginLeft = Get-ObjectPropertyValue $style "marginLeft"
        if ($null -eq $marginLeft) { $marginLeft = Get-ObjectPropertyValue $style "leftMargin" }
        if ($null -ne $marginLeft) {
            try {
                $shape.TextFrame.MarginLeft = [double]$marginLeft
                $applied += "marginLeft"
            } catch {}
        }

        $marginRight = Get-ObjectPropertyValue $style "marginRight"
        if ($null -eq $marginRight) { $marginRight = Get-ObjectPropertyValue $style "rightMargin" }
        if ($null -ne $marginRight) {
            try {
                $shape.TextFrame.MarginRight = [double]$marginRight
                $applied += "marginRight"
            } catch {}
        }

        $marginTop = Get-ObjectPropertyValue $style "marginTop"
        if ($null -eq $marginTop) { $marginTop = Get-ObjectPropertyValue $style "topMargin" }
        if ($null -ne $marginTop) {
            try {
                $shape.TextFrame.MarginTop = [double]$marginTop
                $applied += "marginTop"
            } catch {}
        }

        $marginBottom = Get-ObjectPropertyValue $style "marginBottom"
        if ($null -eq $marginBottom) { $marginBottom = Get-ObjectPropertyValue $style "bottomMargin" }
        if ($null -ne $marginBottom) {
            try {
                $shape.TextFrame.MarginBottom = [double]$marginBottom
                $applied += "marginBottom"
            } catch {}
        }

        Output-Json @{ success = $true; data = @{ name = $shape.Name; applied = $applied; left = $shape.Left; top = $shape.Top; width = $shape.Width; height = $shape.Height } }
    }

    "setSlideTitle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setSlideTitle"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $titleShape = $null
        $mode = "placeholder"
        if ($slide.Shapes.HasTitle) {
            $titleShape = $slide.Shapes.Title
        } else {
            $requestedTitle = if ($p.title) { ([string]$p.title).Trim() } else { "" }
            if ($requestedTitle) {
                for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
                    $candidate = $slide.Shapes.Item($shapeIndex)
                    $candidateText = ""
                    try {
                        if ($candidate.HasTextFrame -and $candidate.TextFrame.HasText) {
                            $candidateText = ([string]$candidate.TextFrame.TextRange.Text).Trim()
                        }
                    } catch {}
                    if ($candidateText -and $candidateText -eq $requestedTitle) {
                        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; title = $p.title; mode = "existing_visible_title"; shapeName = $candidate.Name; hasTitlePlaceholder = $false; changed = $false } }
                        exit
                    }
                }
            }
            $mode = "fallback_textbox"
            $fallbackName = "WPS_Title_Fallback_$slideIndex"
            try { $titleShape = $slide.Shapes.Item($fallbackName) } catch {}
            if ($null -eq $titleShape) {
                $slideWidth = 960
                try { $slideWidth = [double]$pres.PageSetup.SlideWidth } catch {}
                $titleShape = $slide.Shapes.AddTextbox(1, 60, 36, [Math]::Max(120, $slideWidth - 120), 64)
                try { $titleShape.Name = $fallbackName } catch {}
                try {
                    $titleShape.TextFrame.TextRange.Font.Size = 32
                    $titleShape.TextFrame.TextRange.Font.Bold = -1
                } catch {}
            }
        }
        $titleShape.TextFrame.TextRange.Text = if ($p.title) { $p.title } else { "" }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; title = $p.title; mode = $mode; shapeName = $titleShape.Name; hasTitlePlaceholder = [bool]$slide.Shapes.HasTitle; changed = $true } }
    }

    "getSlideTitle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "getSlideTitle"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $title = ""
        $mode = "none"
        $shapeName = $null
        if ($slide.Shapes.HasTitle) {
            $title = $slide.Shapes.Title.TextFrame.TextRange.Text
            $mode = "placeholder"
            $shapeName = $slide.Shapes.Title.Name
        } else {
            $fallbackName = "WPS_Title_Fallback_$slideIndex"
            try {
                $fallbackShape = $slide.Shapes.Item($fallbackName)
                $title = $fallbackShape.TextFrame.TextRange.Text
                $mode = "fallback_textbox"
                $shapeName = $fallbackShape.Name
            } catch {}
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; title = $title; mode = $mode; shapeName = $shapeName } }
    }

    "setSlideSubtitle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            $placeholderType = $null
            try { $placeholderType = $shape.PlaceholderFormat.Type } catch {}
            if ($placeholderType -eq 2) {
                $shape.TextFrame.TextRange.Text = if ($p.subtitle) { $p.subtitle } else { "" }
                Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; subtitle = $p.subtitle } }
                return
            }
        }
        Output-Json @{ success = $false; error = "Subtitle placeholder not found" }
    }

    "setSlideContent" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            $placeholderType = $null
            try { $placeholderType = $shape.PlaceholderFormat.Type } catch {}
            if ($placeholderType -eq 7) {
                $shape.TextFrame.TextRange.Text = if ($p.content) { $p.content } else { "" }
                Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex } }
                return
            }
        }
        Output-Json @{ success = $false; error = "Content placeholder not found" }
    }

    "addShape" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $requestedType = if ($p.type) { [string]$p.type } else { "rectangle" }
        $shapeType = Get-PptShapeTypeValue $requestedType
        $left = if ($null -ne $p.left) { $p.left } else { 100 }
        $top = if ($null -ne $p.top) { $p.top } else { 100 }
        $width = if ($p.width) { $p.width } else { 100 }
        $height = if ($p.height) { $p.height } else { 100 }
        $shape = $slide.Shapes.AddShape($shapeType, $left, $top, $width, $height)
        if ($p.name) { $shape.Name = [string]$p.name }
        if ($p.text) { $shape.TextFrame.TextRange.Text = $p.text }
        if ($p.fillColor) {
            $fillColor = Convert-HexColorToRgbInt([string]$p.fillColor)
            if ($null -ne $fillColor) { $shape.Fill.ForeColor.RGB = $fillColor }
        }
        $actualShapeType = $null
        try { $actualShapeType = $shape.AutoShapeType } catch {}
        Output-Json @{ success = $true; data = @{ name = $shape.Name; nativeShapeId = $(try { [int]$shape.Id } catch { $null }); slideIndex = $slideIndex; requestedType = $requestedType; shapeType = $shapeType; autoShapeType = $actualShapeType } }
    }

    "deleteShape" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }
        if ($null -eq $target -or [string]::IsNullOrWhiteSpace([string]$target)) {
            Output-Json @{ success = $false; error = "Missing shape target. Use name/shapeName from getShapes, or shapeIndex with expectedAutoShapeType/expectedFillColor/expectedTextContains." }
            exit
        }
        if (-not $p.name -and -not $p.shapeName -and -not $p.expectedAutoShapeType -and -not $p.expectedFillColor -and -not $p.expectedTextContains) {
            Output-Json @{ success = $false; error = "Refusing to delete by shapeIndex without expected target checks. Call getShapes first and pass name/shapeName, or include expectedAutoShapeType/expectedFillColor/expectedTextContains." }
            exit
        }

        $shape = $slide.Shapes.Item($target)
        $actualAutoShapeType = $null
        $actualFillColor = $null
        $actualFillColorHex = $null
        $actualText = ""
        try { $actualAutoShapeType = $shape.AutoShapeType } catch {}
        try {
            $actualFillColor = [int]$shape.Fill.ForeColor.RGB
            $actualFillColorHex = Convert-RgbIntToHex $actualFillColor
        } catch {}
        try {
            if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                $actualText = [string]$shape.TextFrame.TextRange.Text
            }
        } catch {}

        if ($p.expectedAutoShapeType -and $null -ne $actualAutoShapeType -and ([int]$actualAutoShapeType -ne [int]$p.expectedAutoShapeType)) {
            Output-Json @{ success = $false; error = "Shape target check failed: expectedAutoShapeType=$($p.expectedAutoShapeType), actualAutoShapeType=$actualAutoShapeType"; data = @{ name = $shape.Name; index = $target; autoShapeType = $actualAutoShapeType; fillColorHex = $actualFillColorHex; text = $actualText } }
            exit
        }
        if ($p.expectedFillColor) {
            $expectedFillColor = Convert-HexColorToRgbInt([string]$p.expectedFillColor)
            if ($null -ne $expectedFillColor -and $null -ne $actualFillColor -and ([int]$expectedFillColor -ne [int]$actualFillColor)) {
                Output-Json @{ success = $false; error = "Shape target check failed: expectedFillColor=$($p.expectedFillColor), actualFillColor=$actualFillColorHex"; data = @{ name = $shape.Name; index = $target; autoShapeType = $actualAutoShapeType; fillColorHex = $actualFillColorHex; text = $actualText } }
                exit
            }
        }
        if ($p.expectedTextContains -and (-not $actualText.Contains([string]$p.expectedTextContains))) {
            Output-Json @{ success = $false; error = "Shape target check failed: expectedTextContains=$($p.expectedTextContains)"; data = @{ name = $shape.Name; index = $target; autoShapeType = $actualAutoShapeType; fillColorHex = $actualFillColorHex; text = $actualText } }
            exit
        }

        $deletedName = $shape.Name
        $shape.Delete()
        Output-Json @{ success = $true; data = @{ deleted = $target; name = $deletedName; slideIndex = $slideIndex; autoShapeType = $actualAutoShapeType; fillColorHex = $actualFillColorHex; text = $actualText } }
    }

    "getShapes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "getShapes"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $shapes = @()
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            $shapes += Get-PptShapeSummary $shape $i 160
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; shapes = $shapes; count = $shapes.Count } }
    }

    "setShapeStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($p.fillColor) {
            $fillColor = Convert-HexColorToRgbInt([string]$p.fillColor)
            if ($null -ne $fillColor) { $shape.Fill.ForeColor.RGB = $fillColor }
        }
        if ($p.lineColor) {
            $lineColor = Convert-HexColorToRgbInt([string]$p.lineColor)
            if ($null -ne $lineColor) { $shape.Line.ForeColor.RGB = $lineColor }
        }
        if ($p.lineWidth) { $shape.Line.Weight = $p.lineWidth }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "setShapeFill" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setShapeFill"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }
        if ($null -eq $target -or [string]::IsNullOrWhiteSpace([string]$target)) {
            Output-Json @{ success = $false; error = "setShapeFill requires name, shapeName, or shapeIndex." }
            exit
        }
        $resolvedShape = Resolve-PptShape $resolvedSlide.slide $target "setShapeFill"
        if (-not $resolvedShape.ok) { Output-Json $resolvedShape.result; exit }
        $fillColor = Convert-HexColorToRgbInt([string]$p.color)
        if ($null -eq $fillColor) {
            Output-Json @{ success = $false; error = "setShapeFill requires a valid hex color such as #FF0000." }
            exit
        }
        $shape = $resolvedShape.shape
        try {
            $shape.Fill.Visible = $true
            $shape.Fill.Solid()
            $shape.Fill.ForeColor.RGB = $fillColor
        } catch {
            Output-Json @{ success = $false; error = "setShapeFill failed: $($_.Exception.Message)" }
            exit
        }
        $resolvedShapeIndex = Get-PptShapeIndexByName $resolvedSlide.slide ([string]$shape.Name)
        Output-Json @{ success = $true; data = @{ slideIndex = [int]$resolvedSlide.slideIndex; shapeIndex = [int]$resolvedShapeIndex; name = [string]$shape.Name; color = [string]$p.color } }
    }

    "setShapeText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $shape.TextFrame.TextRange.Text = if ($p.text) { $p.text } else { "" }
        Output-Json @{ success = $true; data = @{ name = $shape.Name; text = $p.text } }
    }

    "duplicatePptComponentForFixture" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $sourceComponentId = [string]$p.componentId
        if ([string]::IsNullOrWhiteSpace($sourceComponentId)) {
            Output-Json @{ success = $false; error = "duplicatePptComponentForFixture requires componentId" }
            exit
        }
        $leftDelta = if ($null -ne $p.leftDelta) { [double]$p.leftDelta } else { 0 }
        $topDelta = if ($null -ne $p.topDelta) { [double]$p.topDelta } else { 0 }
        $sourceShapes = @()
        for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
            $shape = $slide.Shapes.Item($shapeIndex)
            $descriptor = Get-PptComponentDescriptor ([string]$shape.Name)
            if ($null -ne $descriptor -and [string]$descriptor.componentId -eq $sourceComponentId) {
                $sourceShapes += @{ shape = $shape; descriptor = $descriptor }
            }
        }
        if ($sourceShapes.Count -eq 0) {
            Output-Json @{ success = $false; error = "Component not found: $sourceComponentId" }
            exit
        }
        $created = @()
        try {
            foreach ($source in $sourceShapes) {
                $copy = Copy-PptShapeAndResolveClone $slide $source.shape
                # Reproduce the normal WPS user-copy condition: copied objects
                # may retain the same visible name. Runtime identity must not
                # depend on that name.
                $copy.Name = [string]$source.shape.Name
                $copy.Left = [double]$source.shape.Left + $leftDelta
                $copy.Top = [double]$source.shape.Top + $topDelta
                $copyIndex = Get-PptShapeIndexByNativeId $slide ([int]$copy.Id)
                $created += @{
                    shapeIndex = [int]$copyIndex
                    nativeShapeId = [int]$copy.Id
                    shapeName = [string]$copy.Name
                    part = [string]$source.descriptor.part
                    objectId = "slide:${slideIndex}:shape:$copyIndex"
                    bounds = @{ left = [double]$copy.Left; top = [double]$copy.Top; width = [double]$copy.Width; height = [double]$copy.Height }
                }
            }
        } catch {
            Output-Json @{ success = $false; error = "duplicatePptComponentForFixture failed: $($_.Exception.Message)" }
            exit
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; sourceComponentId = $sourceComponentId; created = $created } }
    }

    "setShapePosition" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $target = if ($p.name) { $p.name } elseif ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }
        if ($null -eq $target -or [string]::IsNullOrWhiteSpace([string]$target)) {
            Output-Json @{ success = $false; error = "Missing shape target. Use name/shapeName from getShapes, or shapeIndex." }
            exit
        }
        $shape = $slide.Shapes.Item($target)
        if ($null -ne $p.left) { $shape.Left = $p.left }
        if ($null -ne $p.top) { $shape.Top = $p.top }
        if ($null -ne $p.width) { $shape.Width = $p.width }
        if ($null -ne $p.height) { $shape.Height = $p.height }
        Output-Json @{ success = $true; data = @{ name = $shape.Name; left = $shape.Left; top = $shape.Top; width = $shape.Width; height = $shape.Height } }
    }

    "insertPptImage" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $left = if ($null -ne $p.left) { $p.left } else { 100 }
        $top = if ($null -ne $p.top) { $p.top } else { 100 }
        $width = if ($null -ne $p.width) { $p.width } else { -1 }
        $height = if ($null -ne $p.height) { $p.height } else { -1 }
        $pic = $slide.Shapes.AddPicture($p.path, $false, $true, $left, $top, $width, $height)
        if ($p.name) { $pic.Name = [string]$p.name }
        Output-Json @{ success = $true; data = @{ name = $pic.Name; nativeShapeId = $(try { [int]$pic.Id } catch { $null }); path = $p.path } }
    }

    "deletePptImage" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $shape.Delete()
        Output-Json @{ success = $true; data = @{ deleted = $(if ($p.name) { $p.name } else { $p.shapeIndex }) } }
    }

    "setImageStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($null -ne $p.left) { $shape.Left = $p.left }
        if ($null -ne $p.top) { $shape.Top = $p.top }
        if ($null -ne $p.width) { $shape.Width = $p.width }
        if ($null -ne $p.height) { $shape.Height = $p.height }
        if ($null -ne $p.rotation) { $shape.Rotation = $p.rotation }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "exportSlideAsImage" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $outputPath = if ($p.outputPath) { $p.outputPath } else { $p.path }
        if ([string]::IsNullOrEmpty($outputPath)) { Output-Json @{ success = $false; error = "Missing outputPath" }; exit }
        $rawFormat = if ($p.format) { $p.format.ToString().ToUpper() } else { "PNG" }
        # JPEG 在 PowerPoint COM 中按 JPG 滤镜处理
        $filterName = if ($rawFormat -eq "JPEG") { "JPG" } else { $rawFormat }
        $width = if ($p.width) { $p.width } else { 1280 }
        $height = if ($p.height) { $p.height } else { 720 }
        $slide.Export($outputPath, $filterName, $width, $height)
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; outputPath = $outputPath; format = $filterName; width = $width; height = $height } }
    }

    "insertPptTable" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $rows = if ($p.rows) { $p.rows } else { 3 }
        $cols = if ($p.cols) { $p.cols } else { 3 }
        $left = if ($p.left) { $p.left } else { 100 }
        $top = if ($p.top) { $p.top } else { 100 }
        $width = if ($p.width) { $p.width } else { 400 }
        $height = if ($p.height) { $p.height } else { 200 }
        $table = $slide.Shapes.AddTable($rows, $cols, $left, $top, $width, $height)
        Output-Json @{ success = $true; data = @{ name = $table.Name; rows = $rows; cols = $cols } }
    }

    "setPptTableCell" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found" }; exit }
        $cell = $shape.Table.Cell($p.row, $p.col)
        $textValue = if ($p.text) { $p.text } elseif ($p.value) { $p.value } else { "" }
        $cell.Shape.TextFrame.TextRange.Text = $textValue
        Output-Json @{ success = $true; data = @{ row = $p.row; col = $p.col; text = $textValue } }
    }

    "getPptTableCell" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found" }; exit }
        $cell = $shape.Table.Cell($p.row, $p.col)
        $value = $cell.Shape.TextFrame.TextRange.Text
        Output-Json @{ success = $true; data = @{ row = $p.row; col = $p.col; value = $value } }
    }

    "setPptTableStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found" }; exit }
        $style = if ($p.style) { $p.style } else { $p }
        $applied = @()
        for ($r = 1; $r -le $shape.Table.Rows.Count; $r++) {
            for ($c = 1; $c -le $shape.Table.Columns.Count; $c++) {
                $applied += Set-PptTableCellShapeStyle $shape.Table.Cell($r, $c).Shape $style
            }
        }
        $headerBackground = Get-ObjectPropertyValue $style "headerBackground"
        if ($headerBackground) {
            $headerStyle = @{ backgroundColor = $headerBackground }
            for ($c = 1; $c -le $shape.Table.Columns.Count; $c++) {
                $applied += Set-PptTableCellShapeStyle $shape.Table.Cell(1, $c).Shape $headerStyle
            }
        }
        $alternateRowColor = Get-ObjectPropertyValue $style "alternateRowColor"
        if ($alternateRowColor) {
            $alternateStyle = @{ backgroundColor = $alternateRowColor }
            for ($r = 2; $r -le $shape.Table.Rows.Count; $r += 2) {
                for ($c = 1; $c -le $shape.Table.Columns.Count; $c++) {
                    $applied += Set-PptTableCellShapeStyle $shape.Table.Cell($r, $c).Shape $alternateStyle
                }
            }
        }
        if ($null -ne $p.left) { $shape.Left = $p.left }
        if ($null -ne $p.top) { $shape.Top = $p.top }
        if ($null -ne $p.width) { $shape.Width = $p.width }
        if ($null -ne $p.height) { $shape.Height = $p.height }
        Output-Json @{ success = $true; data = @{ name = $shape.Name; applied = @($applied | Select-Object -Unique) } }
    }

    "setPptTableCellStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found" }; exit }
        $cell = $shape.Table.Cell($p.row, $p.col)
        $cellShape = $cell.Shape
        $style = if ($p.style) { $p.style } else { $p }
        $applied = Set-PptTableCellShapeStyle $cellShape $style
        Output-Json @{ success = $true; data = @{ row = $p.row; col = $p.col; applied = @($applied | Select-Object -Unique) } }
    }

    "setPptTableRowStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found" }; exit }
        $rowIndex = if ($p.row) { $p.row } else { 1 }
        $row = $shape.Table.Rows.Item($rowIndex)
        $style = if ($p.style) { $p.style } else { $p }
        $applied = @()
        for ($c = 1; $c -le $row.Cells.Count; $c++) {
            $cellShape = $row.Cells.Item($c).Shape
            $applied += Set-PptTableCellShapeStyle $cellShape $style
        }
        $height = Get-ObjectPropertyValue $style "height"
        if ($height) {
            $row.Height = [double]$height
            $applied += "height"
        }
        Output-Json @{ success = $true; data = @{ row = $rowIndex; applied = @($applied | Select-Object -Unique) } }
    }

    "createPptTable" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "createPptTable"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $rows = if ($p.rows) { [int]$p.rows } else { 3 }
        $cols = if ($p.cols) { [int]$p.cols } else { 3 }
        $left = if ($p.left) { [double]$p.left } else { 100 }
        $top = if ($p.top) { [double]$p.top } else { 100 }
        $width = if ($p.width) { [double]$p.width } else { 400 }
        $height = if ($p.height) { [double]$p.height } else { 200 }
        $table = $slide.Shapes.AddTable($rows, $cols, $left, $top, $width, $height)
        $written = @()
        $failed = @()
        $data = Get-ObjectPropertyValue $p "data"
        if ($null -ne $data) {
            $dataResult = Set-PptTableDataValues $table $data 1 1
            $written = $dataResult.written
            $failed = $dataResult.failed
        }
        $style = Get-ObjectPropertyValue $p "style"
        $applied = @()
        if ($style) {
            for ($r = 1; $r -le $table.Table.Rows.Count; $r++) {
                for ($c = 1; $c -le $table.Table.Columns.Count; $c++) {
                    $applied += Set-PptTableCellShapeStyle $table.Table.Cell($r, $c).Shape $style
                }
            }
        }
        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "createPptTable completed with $($failed.Count) failed cells" } else { $null })
            data = @{
                partialMutation = $true
                slideIndex = $slideIndex
                tableName = $table.Name
                nativeShapeId = $(try { [int]$table.Id } catch { $null })
                rows = $rows
                cols = $cols
                created = @(@{ kind = "table"; name = $table.Name; objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $table.Name)" })
                changed = $written
                failed = $failed
                applied = @($applied | Select-Object -Unique)
            }
        }
    }

    "setPptTableData" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setPptTableData"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $shape = Get-PptTableShape $slide $p.tableIndex $p.tableName
        if ($null -eq $shape -or -not $shape.HasTable) { Output-Json @{ success = $false; error = "Table not found"; data = @{ partialMutation = $true; failed = @(@{ error = "Table not found" }) } }; exit }
        $startRow = if ($p.startRow) { [int]$p.startRow } else { 1 }
        $startCol = if ($p.startCol) { [int]$p.startCol } else { 1 }
        $dataResult = Set-PptTableDataValues $shape (Get-ObjectPropertyValue $p "data") $startRow $startCol
        Output-Json @{
            success = ($dataResult.failed.Count -eq 0)
            error = $(if ($dataResult.failed.Count -gt 0) { "setPptTableData completed with $($dataResult.failed.Count) failed cells" } else { $null })
            data = @{
                partialMutation = $true
                slideIndex = $slideIndex
                tableName = $shape.Name
                tableIndex = $p.tableIndex
                startRow = $startRow
                startCol = $startCol
                changed = $dataResult.written
                failed = $dataResult.failed
                succeeded = $dataResult.written.Count
                failedCount = $dataResult.failed.Count
            }
        }
    }

    "insertPptImages" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $imageItems = Get-ObjectPropertyValue $p "images"
        $genericItems = Get-ObjectPropertyValue $p "items"
        $items = @()
        if ($null -ne $imageItems) { $items += @($imageItems) }
        elseif ($null -ne $genericItems) { $items += @($genericItems) }
        else { $items += $p }
        $created = @()
        $failed = @()
        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            try {
                $slideIndex = Get-ObjectPropertyValue $item "slideIndex"
                if (-not $slideIndex) { $slideIndex = $p.slideIndex }
                if (-not $slideIndex) { $slideIndex = 1 }
                $resolvedSlide = Resolve-PptSlide $pres $slideIndex "insertPptImages"
                if (-not $resolvedSlide.ok) { throw $resolvedSlide.result.error }
                $imageResult = Add-PptBatchImage $resolvedSlide.slide $item
                $created += @{
                    operationIndex = $i
                    kind = "picture"
                    slideIndex = $resolvedSlide.slideIndex
                    name = $imageResult.shape.Name
                    path = $imageResult.path
                    objectId = "slide:$($resolvedSlide.slideIndex):shape:$(Get-PptShapeIndexByName $resolvedSlide.slide $imageResult.shape.Name)"
                }
            } catch {
                $failed += @{ operationIndex = $i; error = $_.Exception.Message }
            }
        }
        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "insertPptImages completed with $($failed.Count) failed images" } else { $null })
            data = @{
                partialMutation = $true
                created = $created
                changed = @()
                failed = $failed
                succeeded = $created.Count
                failedCount = $failed.Count
            }
        }
    }

    "setPptShapesStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setPptShapesStyle"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $defaultStyle = Get-ObjectPropertyValue $p "style"
        if ($null -eq $defaultStyle) { $defaultStyle = $p }
        $items = @()
        $inputItems = Get-ObjectPropertyValue $p "items"
        $targets = Get-ObjectPropertyValue $p "targets"
        $names = Get-ObjectPropertyValue $p "names"
        $shapeIndices = Get-ObjectPropertyValue $p "shapeIndices"
        if ($null -ne $inputItems) {
            $items += @($inputItems)
        } elseif ($null -ne $targets) {
            foreach ($target in @($targets)) { $items += @{ target = $target; style = $defaultStyle } }
        } elseif ($null -ne $names) {
            foreach ($target in @($names)) { $items += @{ name = $target; style = $defaultStyle } }
        } elseif ($null -ne $shapeIndices) {
            foreach ($target in @($shapeIndices)) { $items += @{ shapeIndex = $target; style = $defaultStyle } }
        } elseif ($p.shapeIndex -or $p.name -or $p.shapeName) {
            $items = @($p)
        }
        $changed = @()
        $failed = @()
        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            try {
                $target = Get-PptBatchTarget $item
                $resolvedShape = Resolve-PptShape $slide $target "setPptShapesStyle"
                if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                $style = Get-ObjectPropertyValue $item "style"
                if ($null -eq $style) { $style = $defaultStyle }
                $applied = Set-PptShapeStyleValues $resolvedShape.shape $style
                $changed += @{
                    operationIndex = $i
                    kind = "shape"
                    slideIndex = $slideIndex
                    name = $resolvedShape.shape.Name
                    target = $target
                    applied = $applied
                }
            } catch {
                $failed += @{ operationIndex = $i; target = (Get-PptBatchTarget $item); error = $_.Exception.Message }
            }
        }
        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "setPptShapesStyle completed with $($failed.Count) failed shapes" } else { $null })
            data = @{
                partialMutation = $true
                slideIndex = $slideIndex
                created = @()
                changed = $changed
                failed = $failed
                succeeded = $changed.Count
                failedCount = $failed.Count
            }
        }
    }

    "setPptTextboxTexts" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "setPptTextboxTexts"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $inputItems = Get-ObjectPropertyValue $p "items"
        $textsInput = Get-ObjectPropertyValue $p "texts"
        $items = @()
        if ($null -ne $inputItems) { $items += @($inputItems) }
        elseif ($null -ne $textsInput) { $items += @($textsInput) }
        else { $items += $p }
        $changed = @()
        $failed = @()
        $formatIssues = @()
        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            try {
                $target = Get-PptBatchTarget $item
                $resolvedShape = Resolve-PptShape $slide $target "setPptTextboxTexts" "textbox"
                if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                $textValue = Get-ObjectPropertyValue $item "text"
                if ($null -eq $textValue) { $textValue = "" }
                $resolvedShape.shape.TextFrame.TextRange.Text = [string]$textValue
                try { $resolvedShape.shape.TextFrame.WordWrap = -1 } catch {}
                $textFit = Test-PptShapeTextOverflow $resolvedShape.shape
                if ([bool]$textFit.overflow) {
                    $formatIssues += @{
                        operationIndex = $i
                        issueType = "text_overflow"
                        name = [string]$resolvedShape.shape.Name
                        shapeIndex = Get-PptShapeIndexByNativeId $slide ([int]$resolvedShape.shape.Id)
                        textLength = ([string]$textValue).Length
                        metrics = $textFit
                    }
                }
                $changed += @{
                    operationIndex = $i
                    kind = "textbox"
                    slideIndex = $slideIndex
                    name = $resolvedShape.shape.Name
                    target = $target
                    text = [string]$textValue
                    textFit = $textFit
                }
            } catch {
                $failed += @{ operationIndex = $i; target = (Get-PptBatchTarget $item); error = $_.Exception.Message }
            }
        }
        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "setPptTextboxTexts completed with $($failed.Count) failed textboxes" } else { $null })
            data = @{
                partialMutation = $true
                slideIndex = $slideIndex
                created = @()
                changed = $changed
                failed = $failed
                succeeded = $changed.Count
                failedCount = $failed.Count
                textFitRequired = ($formatIssues.Count -gt 0)
                formatIssues = $formatIssues
                nextRequiredAction = $(if ($formatIssues.Count -gt 0) { "Call wps_ppt_uniform_component_layout for the affected target components with the same content_edit mutationContractId, then run wps_ppt_verify_slides again before ending the mutation." } else { "Run wps_ppt_verify_slides before ending the mutation." })
            }
        }
    }

    "editSlideBatch" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "editSlideBatch"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $operationInput = Get-ObjectPropertyValue $p "operations"
        $operations = @()
        if ($null -ne $operationInput) { $operations += @($operationInput) }
        $created = @()
        $changed = @()
        $failed = @()
        $stopOnError = if ($null -ne $p.stopOnError) { [bool]$p.stopOnError } else { $false }
        $compiledTransaction = -not [string]::IsNullOrWhiteSpace([string](Get-ObjectPropertyValue $p "compiledPlanFingerprint"))
        $transactionSnapshots = @()
        if ($compiledTransaction) {
            $stopOnError = $true
            $providedSnapshots = @((Get-ObjectPropertyValue $p "transactionSnapshots"))
            if ($providedSnapshots.Count -gt 0) {
                $transactionSnapshots = $providedSnapshots
            } else {
                for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
                    $transactionSnapshots += Get-PptShapeSnapshot ($slide.Shapes.Item($shapeIndex))
                }
            }
        }
        $blockedTypes = @("delete", "deleteShape", "deleteTextbox", "deleteImage", "deleteSlide", "remove", "save", "saveAs", "replace", "replaceText", "open", "close", "moveSlide", "copySlide", "export")

        for ($i = 0; $i -lt $operations.Count; $i++) {
            $op = $operations[$i]
            $opType = Get-ObjectPropertyValue $op "type"
            if (-not $opType) { $opType = Get-ObjectPropertyValue $op "action" }
            if (-not $opType) { $opType = Get-ObjectPropertyValue $op "method" }
            $opTypeText = if ($opType) { [string]$opType } else { "" }
            try {
                if ($blockedTypes -contains $opTypeText) {
                    throw "High-risk operation '$opTypeText' is not allowed in editSlideBatch"
                }
                switch ($opTypeText) {
                    { $_ -in @("addShape", "add_shape", "shape") } {
                        $result = Add-PptBatchShape $slide $op
                        $created += @{ operationIndex = $i; kind = "shape"; name = $result.shape.Name; objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $result.shape.Name)"; applied = $result.applied }
                        break
                    }
                    { $_ -in @("addTextbox", "addTextBox", "add_textbox", "textbox") } {
                        $result = Add-PptBatchTextbox $slide $op
                        $created += @{ operationIndex = $i; kind = "textbox"; name = $result.shape.Name; objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $result.shape.Name)"; applied = $result.applied }
                        break
                    }
                    { $_ -in @("insertImage", "insertPptImage", "insert_image", "image") } {
                        $result = Add-PptBatchImage $slide $op
                        $created += @{ operationIndex = $i; kind = "picture"; name = $result.shape.Name; path = $result.path; objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $result.shape.Name)" }
                        break
                    }
                    { $_ -in @("createTable", "insertTable", "insertPptTable", "table") } {
                        $rows = if (Get-ObjectPropertyValue $op "rows") { [int](Get-ObjectPropertyValue $op "rows") } else { 3 }
                        $cols = if (Get-ObjectPropertyValue $op "cols") { [int](Get-ObjectPropertyValue $op "cols") } else { 3 }
                        $left = if ($null -ne (Get-ObjectPropertyValue $op "left")) { [double](Get-ObjectPropertyValue $op "left") } else { 100 }
                        $top = if ($null -ne (Get-ObjectPropertyValue $op "top")) { [double](Get-ObjectPropertyValue $op "top") } else { 100 }
                        $width = if ($null -ne (Get-ObjectPropertyValue $op "width")) { [double](Get-ObjectPropertyValue $op "width") } else { 400 }
                        $height = if ($null -ne (Get-ObjectPropertyValue $op "height")) { [double](Get-ObjectPropertyValue $op "height") } else { 200 }
                        $table = $slide.Shapes.AddTable($rows, $cols, $left, $top, $width, $height)
                        $data = Get-ObjectPropertyValue $op "data"
                        $written = @()
                        if ($data) {
                            $dataResult = Set-PptTableDataValues $table $data 1 1
                            if ($dataResult.failed.Count -gt 0) { throw "Table created but $($dataResult.failed.Count) cells failed" }
                            $written = $dataResult.written
                        }
                        $created += @{ operationIndex = $i; kind = "table"; name = $table.Name; rows = $rows; cols = $cols; objectId = "slide:${slideIndex}:shape:$(Get-PptShapeIndexByName $slide $table.Name)"; cells = $written }
                        break
                    }
                    { $_ -in @("setShapeStyle", "set_shape_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $style = Get-ObjectPropertyValue $op "style"
                        if ($null -eq $style) { $style = $op }
                        $applied = Set-PptShapeStyleValues $resolvedShape.shape $style
                        if (@($applied).Count -eq 0) { throw "setShapeStyle did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "shape"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setShapePosition", "set_shape_position") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $applied = Set-PptShapePositionValues $resolvedShape.shape $op
                        if (@($applied).Count -eq 0) { throw "setShapePosition did not apply left/top/width/height" }
                        $changed += @{ operationIndex = $i; kind = "shape"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setShapeText", "set_shape_text", "setTextboxText", "setTextBoxText", "set_textbox_text") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "textbox"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $preserveGeometry = [bool](Get-ObjectPropertyValue $op "preserveGeometry")
                        $geometrySnapshot = if ($preserveGeometry) { Get-PptShapeGeometrySnapshot $resolvedShape.shape } else { $null }
                        $textValue = Get-ObjectPropertyValue $op "text"
                        if ($null -eq $textValue) { $textValue = "" }
                        $resolvedShape.shape.TextFrame.TextRange.Text = [string]$textValue
                        if ($preserveGeometry) { Restore-PptShapeGeometrySnapshot $resolvedShape.shape $geometrySnapshot }
                        $changed += @{ operationIndex = $i; kind = "textbox"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; text = [string]$textValue }
                        break
                    }
                    { $_ -in @("setTextBoxStyle", "setTextboxStyle", "set_textbox_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "textbox"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $style = Get-ObjectPropertyValue $op "style"
                        if ($null -eq $style) { $style = $op }
                        $preserveGeometry = [bool](Get-ObjectPropertyValue $op "preserveGeometry")
                        $geometrySnapshot = if ($preserveGeometry) { Get-PptShapeGeometrySnapshot $resolvedShape.shape } else { $null }
                        $applied = Set-PptTextFrameStyleValues $resolvedShape.shape $style
                        if (@($applied).Count -eq 0) { throw "setTextBoxStyle did not apply any supported property" }
                        if ($preserveGeometry) { Restore-PptShapeGeometrySnapshot $resolvedShape.shape $geometrySnapshot }
                        $changed += @{ operationIndex = $i; kind = "textbox"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setTextRangeStyle", "set_text_range_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "text-capable object"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        if (-not [bool]($resolvedShape.shape.HasTextFrame -ne 0)) { throw "Target is not text-capable" }
                        $preserveGeometry = [bool](Get-ObjectPropertyValue $op "preserveGeometry")
                        $geometrySnapshot = if ($preserveGeometry) { Get-PptShapeGeometrySnapshot $resolvedShape.shape } else { $null }
                        $applied = Set-PptTextRangeStyleValues $resolvedShape.shape (Get-ObjectPropertyValue $op "ranges")
                        if (@($applied).Count -eq 0) { throw "setTextRangeStyle did not apply any supported property" }
                        if ($preserveGeometry) { Restore-PptShapeGeometrySnapshot $resolvedShape.shape $geometrySnapshot }
                        $changed += @{ operationIndex = $i; kind = "text"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setParagraphStyle", "set_paragraph_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "text-capable object"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        if (-not [bool]($resolvedShape.shape.HasTextFrame -ne 0)) { throw "Target is not text-capable" }
                        $preserveGeometry = [bool](Get-ObjectPropertyValue $op "preserveGeometry")
                        $geometrySnapshot = if ($preserveGeometry) { Get-PptShapeGeometrySnapshot $resolvedShape.shape } else { $null }
                        $applied = Set-PptParagraphStyleValues $resolvedShape.shape (Get-ObjectPropertyValue $op "paragraphs")
                        if (@($applied).Count -eq 0) { throw "setParagraphStyle did not apply any supported property" }
                        if ($preserveGeometry) { Restore-PptShapeGeometrySnapshot $resolvedShape.shape $geometrySnapshot }
                        $changed += @{ operationIndex = $i; kind = "text"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setTextFrame", "set_text_frame") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "text-capable object"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        if (-not [bool]($resolvedShape.shape.HasTextFrame -ne 0)) { throw "Target is not text-capable" }
                        $preserveGeometry = [bool](Get-ObjectPropertyValue $op "preserveGeometry")
                        $geometrySnapshot = if ($preserveGeometry) { Get-PptShapeGeometrySnapshot $resolvedShape.shape } else { $null }
                        $applied = Set-PptTextFrameValues $resolvedShape.shape (Get-ObjectPropertyValue $op "frame")
                        if (@($applied).Count -eq 0) { throw "setTextFrame did not apply any supported property" }
                        if ($preserveGeometry) { Restore-PptShapeGeometrySnapshot $resolvedShape.shape $geometrySnapshot }
                        $changed += @{ operationIndex = $i; kind = "text"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setPictureStyle", "set_picture_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "picture"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $style = Get-ObjectPropertyValue $op "style"
                        if ($null -eq $style) { $style = $op }
                        $applied = Set-PptPictureStyleValues $resolvedShape.shape $style
                        if (@($applied).Count -eq 0) { throw "setPictureStyle did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "picture"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setConnectorStyle", "set_connector_style") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch" "connector"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $style = Get-ObjectPropertyValue $op "style"
                        if ($null -eq $style) { $style = $op }
                        $applied = Set-PptConnectorStyleValues $resolvedShape.shape $style
                        if (@($applied).Count -eq 0) { throw "setConnectorStyle did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "connector"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setConnectorRoute", "set_connector_route") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $applied = Set-PptConnectorRouteValues $slide $resolvedShape.shape $op
                        if (@($applied).Count -eq 0) { throw "setConnectorRoute did not apply any endpoint or route field" }
                        $changed += @{ operationIndex = $i; kind = "connector"; name = $resolvedShape.shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setTableData", "set_table_data") } {
                        $shape = Get-PptTableShape $slide (Get-ObjectPropertyValue $op "tableIndex") (Get-ObjectPropertyValue $op "tableName")
                        if ($null -eq $shape -or -not $shape.HasTable) { throw "Table not found" }
                        $dataResult = Set-PptTableDataValues $shape (Get-ObjectPropertyValue $op "data") (Get-ObjectPropertyValue $op "startRow") (Get-ObjectPropertyValue $op "startCol")
                        if ($dataResult.failed.Count -gt 0) { throw "setTableData completed with $($dataResult.failed.Count) failed cells" }
                        $changed += @{ operationIndex = $i; kind = "table"; name = $shape.Name; changed = $dataResult.written }
                        break
                    }
                    { $_ -in @("setTableCells", "set_table_cells") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if (-not [bool]$shape.HasTable) { throw "Target is not a native PPT table" }
                        $applied = @()
                        foreach ($cell in @((Get-ObjectPropertyValue $op "cells"))) {
                            $row = [int](Get-ObjectPropertyValue $cell "row")
                            $col = [int](Get-ObjectPropertyValue $cell "col")
                            if ($row -lt 1 -or $row -gt $shape.Table.Rows.Count -or $col -lt 1 -or $col -gt $shape.Table.Columns.Count) {
                                throw "Table cell out of range: row=$row, col=$col"
                            }
                            $textValue = [string](Get-ObjectPropertyValue $cell "text")
                            $shape.Table.Cell($row, $col).Shape.TextFrame.TextRange.Text = $textValue
                            $applied += "cells[$row,$col].text"
                        }
                        if ($applied.Count -eq 0) { throw "setTableCells did not receive any cells" }
                        $changed += @{ operationIndex = $i; kind = "table"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setTableCellStyles", "set_table_cell_styles") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if (-not [bool]$shape.HasTable) { throw "Target is not a native PPT table" }
                        $applied = @()
                        foreach ($cell in @((Get-ObjectPropertyValue $op "cells"))) {
                            $row = [int](Get-ObjectPropertyValue $cell "row")
                            $col = [int](Get-ObjectPropertyValue $cell "col")
                            if ($row -lt 1 -or $row -gt $shape.Table.Rows.Count -or $col -lt 1 -or $col -gt $shape.Table.Columns.Count) { throw "Table cell out of range: row=$row, col=$col" }
                            $style = Get-ObjectPropertyValue $cell "style"
                            $cellShape = $shape.Table.Cell($row, $col).Shape
                            $cellApplied = @()
                            $fillColor = Get-ObjectPropertyValue $style "fillColor"
                            if ($null -ne $fillColor) { $rgb = Convert-HexColorToRgbInt([string]$fillColor); if ($null -eq $rgb) { throw "Invalid fillColor" }; $cellShape.Fill.Solid(); $cellShape.Fill.ForeColor.RGB = $rgb; $cellApplied += "fillColor" }
                            $fontColor = Get-ObjectPropertyValue $style "fontColor"
                            if ($null -ne $fontColor) { $rgb = Convert-HexColorToRgbInt([string]$fontColor); if ($null -eq $rgb) { throw "Invalid fontColor" }; $cellShape.TextFrame.TextRange.Font.Color.RGB = $rgb; $cellApplied += "fontColor" }
                            $fontName = Get-ObjectPropertyValue $style "fontName"
                            if ($null -ne $fontName) { $cellShape.TextFrame.TextRange.Font.Name = [string]$fontName; $cellApplied += "fontName" }
                            $fontSize = Get-ObjectPropertyValue $style "fontSize"
                            if ($null -ne $fontSize) { $cellShape.TextFrame.TextRange.Font.Size = [double]$fontSize; $cellApplied += "fontSize" }
                            $bold = Get-ObjectPropertyValue $style "bold"
                            if ($null -ne $bold) { $cellShape.TextFrame.TextRange.Font.Bold = $(if ([bool]$bold) { -1 } else { 0 }); $cellApplied += "bold" }
                            $alignment = Get-ObjectPropertyValue $style "alignment"
                            if ($null -ne $alignment) { $map = @{ left = 1; center = 2; right = 3 }; $value = $map[[string]$alignment]; if ($null -eq $value) { throw "Invalid table alignment" }; $cellShape.TextFrame.TextRange.ParagraphFormat.Alignment = $value; $cellApplied += "alignment" }
                            $paragraph = Get-ObjectPropertyValue $style "paragraph"
                            if ($null -ne $paragraph) {
                                $paragraphFormat = $cellShape.TextFrame.TextRange.ParagraphFormat
                                $paragraphAlignment = Get-ObjectPropertyValue $paragraph "alignment"
                                if ($null -ne $paragraphAlignment) {
                                    $paragraphMap = @{ left = 1; center = 2; right = 3; justify = 4 }
                                    $paragraphValue = $paragraphMap[[string]$paragraphAlignment]
                                    if ($null -eq $paragraphValue) { throw "Invalid table paragraph alignment" }
                                    $paragraphFormat.Alignment = [int]$paragraphValue
                                    $cellApplied += "paragraph.alignment"
                                }
                                $spaceBefore = Get-ObjectPropertyValue $paragraph "spaceBefore"
                                if ($null -ne $spaceBefore) { $paragraphFormat.SpaceBefore = [double]$spaceBefore; $cellApplied += "paragraph.spaceBefore" }
                                $spaceAfter = Get-ObjectPropertyValue $paragraph "spaceAfter"
                                if ($null -ne $spaceAfter) { $paragraphFormat.SpaceAfter = [double]$spaceAfter; $cellApplied += "paragraph.spaceAfter" }
                                $lineSpacing = Get-ObjectPropertyValue $paragraph "lineSpacing"
                                if ($null -ne $lineSpacing) { $paragraphFormat.SpaceWithin = [double]$lineSpacing; $cellApplied += "paragraph.lineSpacing" }
                            }
                            $borders = Get-ObjectPropertyValue $style "borders"
                            if ($null -ne $borders) {
                                foreach ($definition in @(
                                    @{ name = "top"; value = 1 },
                                    @{ name = "left"; value = 2 },
                                    @{ name = "bottom"; value = 3 },
                                    @{ name = "right"; value = 4 }
                                )) {
                                    $borderStyle = Get-ObjectPropertyValue $borders ([string]$definition.name)
                                    if ($null -eq $borderStyle) { continue }
                                    $border = $shape.Table.Cell($row, $col).Borders.Item([int]$definition.value)
                                    $borderColor = Get-ObjectPropertyValue $borderStyle "color"
                                    if ($null -ne $borderColor) {
                                        $rgb = Convert-HexColorToRgbInt ([string]$borderColor)
                                        if ($null -eq $rgb) { throw "Invalid table border color" }
                                        $border.ForeColor.RGB = [int]$rgb
                                        $cellApplied += "borders.$($definition.name).color"
                                    }
                                    $borderWidth = Get-ObjectPropertyValue $borderStyle "width"
                                    if ($null -ne $borderWidth) { $border.Weight = [double]$borderWidth; $cellApplied += "borders.$($definition.name).width" }
                                }
                            }
                            if ($cellApplied.Count -eq 0) { throw "Table cell style is empty" }
                            $applied += "cells[$row,$col].style"
                        }
                        $changed += @{ operationIndex = $i; kind = "table"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("appendTableRows", "append_table_rows") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if (-not [bool]$shape.HasTable) { throw "Target is not a native PPT table" }
                        $rows = @((Get-ObjectPropertyValue $op "rows"))
                        if ($rows.Count -eq 0) { throw "appendTableRows did not receive any rows" }
                        $columnCount = [int]$shape.Table.Columns.Count
                        $applied = @()
                        foreach ($rowDefinition in $rows) {
                            $cells = @((Get-ObjectPropertyValue $rowDefinition "cells"))
                            if ($cells.Count -ne $columnCount) {
                                throw "Appended table row must contain exactly $columnCount cells"
                            }
                            $null = $shape.Table.Rows.Add()
                            $rowIndex = [int]$shape.Table.Rows.Count
                            for ($columnIndex = 1; $columnIndex -le $columnCount; $columnIndex++) {
                                $shape.Table.Cell($rowIndex, $columnIndex).Shape.TextFrame.TextRange.Text = [string]$cells[$columnIndex - 1]
                                $applied += "cells[$rowIndex,$columnIndex].text"
                            }
                        }
                        $changed += @{ operationIndex = $i; kind = "table"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setTableDimensions", "set_table_dimensions") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if (-not [bool]$shape.HasTable) { throw "Target is not a native PPT table" }
                        $applied = @()
                        foreach ($rowUpdate in @((Get-ObjectPropertyValue $op "rows"))) {
                            $rowIndex = [int](Get-ObjectPropertyValue $rowUpdate "index")
                            if ($rowIndex -lt 1 -or $rowIndex -gt $shape.Table.Rows.Count) { throw "Table row out of range: index=$rowIndex" }
                            $shape.Table.Rows.Item($rowIndex).Height = [double](Get-ObjectPropertyValue $rowUpdate "height")
                            $applied += "rows[$rowIndex].height"
                        }
                        foreach ($columnUpdate in @((Get-ObjectPropertyValue $op "columns"))) {
                            $columnIndex = [int](Get-ObjectPropertyValue $columnUpdate "index")
                            if ($columnIndex -lt 1 -or $columnIndex -gt $shape.Table.Columns.Count) { throw "Table column out of range: index=$columnIndex" }
                            $shape.Table.Columns.Item($columnIndex).Width = [double](Get-ObjectPropertyValue $columnUpdate "width")
                            $applied += "columns[$columnIndex].width"
                        }
                        if ($applied.Count -eq 0) { throw "setTableDimensions did not apply any dimensions" }
                        $changed += @{ operationIndex = $i; kind = "table"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setChartProperties", "set_chart_properties") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if ([int]$shape.Type -ne 3) { throw "Target is not a native PPT chart" }
                        $applied = @()
                        if ($null -ne (Get-ObjectPropertyValue $op "title")) {
                            $title = [string](Get-ObjectPropertyValue $op "title")
                            if ([string]::IsNullOrEmpty($title)) {
                                $shape.Chart.HasTitle = $false
                            } else {
                                $shape.Chart.HasTitle = $true
                                $shape.Chart.ChartTitle.Text = $title
                            }
                            $applied += "title"
                        }
                        if ($null -ne (Get-ObjectPropertyValue $op "hasLegend")) {
                            $shape.Chart.HasLegend = [bool](Get-ObjectPropertyValue $op "hasLegend")
                            $applied += "hasLegend"
                        }
                        $legendPosition = Get-ObjectPropertyValue $op "legendPosition"
                        if ($null -ne $legendPosition) {
                            $legendMap = @{ top = -4160; right = -4152; bottom = -4107; left = -4131 }
                            $position = $legendMap[[string]$legendPosition]
                            if ($null -eq $position) { throw "Invalid chart legend position" }
                            $shape.Chart.HasLegend = $true
                            $shape.Chart.Legend.Position = [int]$position
                            $applied += "legendPosition"
                        }
                        if ($null -ne (Get-ObjectPropertyValue $op "chartType")) {
                            $shape.Chart.ChartType = [int](Get-ObjectPropertyValue $op "chartType")
                            $applied += "chartType"
                        }
                        if ($applied.Count -eq 0) { throw "setChartProperties did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "chart"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setChartAxisProperties", "set_chart_axis_properties") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if ([int]$shape.Type -ne 3) { throw "Target is not a native PPT chart" }
                        $applied = @()
                        foreach ($axisUpdate in @((Get-ObjectPropertyValue $op "axes"))) {
                            $kind = [string](Get-ObjectPropertyValue $axisUpdate "kind")
                            $axisType = if ($kind -eq "category") { 1 } elseif ($kind -eq "value") { 2 } else { throw "Unsupported chart axis kind: $kind" }
                            try { $axis = $shape.Chart.Axes($axisType, 1) } catch { throw "Chart axis is unavailable: $kind" }
                            $title = Get-ObjectPropertyValue $axisUpdate "title"
                            if ($null -ne $title) {
                                $axis.HasTitle = -not [string]::IsNullOrEmpty([string]$title)
                                if (-not [string]::IsNullOrEmpty([string]$title)) { $axis.AxisTitle.Text = [string]$title }
                                $applied += "axes[$kind].title"
                            }
                            $hasMajorGridlines = Get-ObjectPropertyValue $axisUpdate "hasMajorGridlines"
                            if ($null -ne $hasMajorGridlines) {
                                $axis.HasMajorGridlines = [bool]$hasMajorGridlines
                                $applied += "axes[$kind].hasMajorGridlines"
                            }
                            $minimumScale = Get-ObjectPropertyValue $axisUpdate "minimumScale"
                            if ($null -ne $minimumScale) {
                                if ($kind -ne "value") { throw "Chart scale range is supported only for the value axis" }
                                $axis.MinimumScale = [double]$minimumScale
                                $applied += "axes[$kind].minimumScale"
                            }
                            $maximumScale = Get-ObjectPropertyValue $axisUpdate "maximumScale"
                            if ($null -ne $maximumScale) {
                                if ($kind -ne "value") { throw "Chart scale range is supported only for the value axis" }
                                $axis.MaximumScale = [double]$maximumScale
                                $applied += "axes[$kind].maximumScale"
                            }
                        }
                        if ($applied.Count -eq 0) { throw "setChartAxisProperties did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "chart"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    { $_ -in @("setChartSeriesProperties", "set_chart_series_properties") } {
                        $target = Get-PptBatchTarget $op
                        $resolvedShape = Resolve-PptShape $slide $target "editSlideBatch"
                        if (-not $resolvedShape.ok) { throw $resolvedShape.result.error }
                        $shape = $resolvedShape.shape
                        if ([int]$shape.Type -ne 3) { throw "Target is not a native PPT chart" }
                        $collection = $shape.Chart.SeriesCollection()
                        $applied = @()
                        foreach ($seriesUpdate in @((Get-ObjectPropertyValue $op "series"))) {
                            $seriesIndex = [int](Get-ObjectPropertyValue $seriesUpdate "index")
                            if ($seriesIndex -lt 1 -or $seriesIndex -gt $collection.Count) { throw "Chart series out of range: index=$seriesIndex" }
                            $series = $collection.Item($seriesIndex)
                            $hasDataLabels = Get-ObjectPropertyValue $seriesUpdate "hasDataLabels"
                            if ($null -ne $hasDataLabels) {
                                if ([bool]$hasDataLabels) { $series.ApplyDataLabels() } else { try { $series.DataLabels().Delete() } catch {} }
                                $applied += "series[$seriesIndex].hasDataLabels"
                            }
                        }
                        if ($applied.Count -eq 0) { throw "setChartSeriesProperties did not apply any supported property" }
                        $changed += @{ operationIndex = $i; kind = "chart"; name = $shape.Name; nativeShapeId = $resolvedShape.nativeShapeId; shapeIndex = $resolvedShape.shapeIndex; target = $target; applied = $applied }
                        break
                    }
                    default {
                        throw "Unsupported batch operation type '$opTypeText'"
                    }
                }
            } catch {
                $failed += @{ operationIndex = $i; type = $opTypeText; error = $_.Exception.Message }
                if ($stopOnError) { break }
            }
        }

        $rolledBack = $compiledTransaction -and $failed.Count -gt 0
        if ($rolledBack) {
            Restore-PptShapeSnapshots $slide $transactionSnapshots
            $created = @()
            $changed = @()
        }
        $postWriteReadback = $null
        $postWriteReadbackTargets = @((Get-ObjectPropertyValue $p "postWriteReadbackTargets"))
        if (
            $failed.Count -eq 0 -and
            $created.Count -eq 0 -and
            $postWriteReadbackTargets.Count -gt 0
        ) {
            try {
                $postWriteReadback = Get-PptSceneTargetsReadbackData `
                    $pres `
                    $slide `
                    ([int]$slideIndex) `
                    $postWriteReadbackTargets `
                    $false
            } catch {
                $postWriteReadback = @{
                    success = $false
                    error = "Embedded post-write readback failed: $($_.Exception.Message)"
                }
            }
        }
        $responseData = @{
            partialMutation = (-not $compiledTransaction)
            transactional = $compiledTransaction
            rolledBack = $rolledBack
            wroteToWps = (-not $rolledBack -and ($created.Count + $changed.Count) -gt 0)
            presentationId = [string]$pres.Name
            slideIndex = $slideIndex
            total = $operations.Count
            created = $created
            changed = $changed
            failed = $failed
            succeeded = $created.Count + $changed.Count
            failedCount = $failed.Count
        }
        if ($null -ne $postWriteReadback) {
            $responseData["postWriteReadback"] = $postWriteReadback
        }
        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "editSlideBatch completed with $($failed.Count) failed operations" } else { $null })
            data = $responseData
        }
    }

    "createSlideComponents" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $resolvedSlide = Resolve-PptSlide $pres $slideIndex "createSlideComponents"
        if (-not $resolvedSlide.ok) { Output-Json $resolvedSlide.result; exit }
        $slideIndex = $resolvedSlide.slideIndex
        $slide = $resolvedSlide.slide
        $componentInput = Get-ObjectPropertyValue $p "components"
        $components = @()
        if ($null -ne $componentInput) { $components += @($componentInput) }
        $visualInput = Get-ObjectPropertyValue $p "visualSystem"
        if ($null -eq $visualInput) { $visualInput = Get-ObjectPropertyValue $p "theme" }
        $visual = Get-PptR4VisualSystem $visualInput
        $created = @()
        $failed = @()
        $componentResults = @()

        if ($components.Count -eq 0) {
            Output-Json @{
                success = $false
                error = "createSlideComponents requires at least one component"
                data = @{ partialMutation = $true; slideIndex = $slideIndex; created = @(); failed = @(@{ error = "Missing components" }) }
            }
            exit
        }

        for ($i = 0; $i -lt $components.Count; $i++) {
            try {
                $componentResult = Add-PptR4Component $slide $slideIndex $components[$i] $visual $i
                $componentResults += $componentResult
                $created += @($componentResult.created)
            } catch {
                $typeValue = Get-ObjectPropertyValue $components[$i] "type"
                if (-not $typeValue) { $typeValue = Get-ObjectPropertyValue $components[$i] "componentType" }
                $failed += @{ operationIndex = $i; componentType = $typeValue; error = $_.Exception.Message }
            }
        }

        $verification = $null
        $verifyAfter = Get-ObjectPropertyValue $p "verifyAfter"
        if ($null -ne $verifyAfter -and [bool]$verifyAfter) {
            $verificationResult = Test-PptSlideGeometry $pres $slideIndex @{ margin = 8; overlapThreshold = 0.35; ignoreBackgrounds = $true; requireTitle = $false; maxObjects = 35 }
            if ($verificationResult.success) { $verification = $verificationResult.data }
        }

        Output-Json @{
            success = ($failed.Count -eq 0)
            error = $(if ($failed.Count -gt 0) { "createSlideComponents completed with $($failed.Count) failed components" } else { $null })
            data = @{
                partialMutation = $true
                slideIndex = $slideIndex
                visualSystem = $visual
                components = $componentResults
                created = $created
                changed = @()
                failed = $failed
                succeeded = $created.Count
                failedCount = $failed.Count
                verification = $verification
            }
        }
    }

    "setShapeShadow" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $shape.Shadow.Visible = $true
        if ($p.color) {
            $shadowColor = Convert-HexColorToRgbInt([string]$p.color)
            if ($null -ne $shadowColor) { $shape.Shadow.ForeColor.RGB = $shadowColor }
        }
        if ($null -ne $p.transparency) { $shape.Shadow.Transparency = $p.transparency }
        if ($null -ne $p.blur) { $shape.Shadow.Blur = $p.blur }
        if ($null -ne $p.offsetX) { $shape.Shadow.OffsetX = $p.offsetX }
        if ($null -ne $p.offsetY) { $shape.Shadow.OffsetY = $p.offsetY }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "setBackgroundGradient" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $bg = $slide.Background.Fill
        $bg.Visible = $true
        $bg.TwoColorGradient(1, 1)
        if ($p.color1) {
            $c1 = Convert-HexColorToRgbInt([string]$p.color1)
            if ($null -ne $c1) { $bg.ForeColor.RGB = $c1 }
        }
        if ($p.color2) {
            $c2 = Convert-HexColorToRgbInt([string]$p.color2)
            if ($null -ne $c2) { $bg.BackColor.RGB = $c2 }
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex } }
    }

    "setShapeGradient" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $shape.Fill.TwoColorGradient(1, 1)
        if ($p.color1) {
            $c1 = Convert-HexColorToRgbInt([string]$p.color1)
            if ($null -ne $c1) { $shape.Fill.ForeColor.RGB = $c1 }
        }
        if ($p.color2) {
            $c2 = Convert-HexColorToRgbInt([string]$p.color2)
            if ($null -ne $c2) { $shape.Fill.BackColor.RGB = $c2 }
        }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "setShapeBorder" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($p.color) {
            $borderColor = Convert-HexColorToRgbInt([string]$p.color)
            if ($null -ne $borderColor) { $shape.Line.ForeColor.RGB = $borderColor }
        }
        if ($p.width) { $shape.Line.Weight = $p.width }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "setShapeTransparency" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($null -ne $p.transparency) {
            $transparency = [double]$p.transparency
            if ($transparency -gt 1.0) { $transparency = $transparency / 100.0 }
            $transparency = [Math]::Max(0.0, [Math]::Min(1.0, $transparency))
            $shape.Fill.Transparency = $transparency
        }
        Output-Json @{ success = $true; data = @{ name = $shape.Name; transparency = [double]$shape.Fill.Transparency } }
    }

    "setShapeRoundness" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($null -ne $p.roundness) { $shape.Adjustments.Item(1) = $p.roundness }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "setShapeFullStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        if ($p.fillColor) { $shape.Fill.ForeColor.RGB = Convert-HexColorToRgbInt([string]$p.fillColor) }
        if ($p.lineColor) { $shape.Line.ForeColor.RGB = Convert-HexColorToRgbInt([string]$p.lineColor) }
        if ($p.lineWidth) { $shape.Line.Weight = $p.lineWidth }
        if ($null -ne $p.transparency) { $shape.Fill.Transparency = $p.transparency }
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "alignShapes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $alignMap = @{ left = 1; center = 2; right = 3; top = 4; middle = 5; bottom = 6 }
        $align = $alignMap[$p.alignment]
        if ($null -eq $align) { $align = 1 }
        $range = $slide.Shapes.Range($p.names)
        $range.Align($align, 1)
        Output-Json @{ success = $true; data = @{ alignment = $p.alignment } }
    }

    "distributeShapes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $distMap = @{ horizontal = 0; vertical = 1 }
        $dist = $distMap[$p.direction]
        if ($null -eq $dist) { $dist = 0 }
        $range = $slide.Shapes.Range($p.names)
        $range.Distribute($dist, 1)
        Output-Json @{ success = $true; data = @{ direction = $p.direction } }
    }

    "groupShapes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $range = $slide.Shapes.Range($p.names)
        $group = $range.Group()
        if ($p.name) { $group.Name = [string]$p.name }
        Output-Json @{ success = $true; data = @{ name = $group.Name; nativeShapeId = $(try { [int]$group.Id } catch { $null }) } }
    }

    "ungroupShapes" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $target = if ($p.name) { [string]$p.name } else { $p.shapeIndex }
        if ($null -eq $target -or [string]::IsNullOrWhiteSpace([string]$target)) {
            Output-Json @{ success = $false; error = "ungroupShapes requires name or shapeIndex." }
            exit
        }
        try {
            $group = $slide.Shapes.Item($target)
            $memberNames = @()
            try {
                for ($index = 1; $index -le $group.GroupItems.Count; $index++) {
                    $memberNames += [string]$group.GroupItems.Item($index).Name
                }
            } catch {}
            $range = $group.Ungroup()
            $nativeShapeIds = @()
            for ($index = 1; $index -le $range.Count; $index++) {
                try { $nativeShapeIds += [int]$range.Item($index).Id } catch {}
            }
            Output-Json @{ success = $true; data = @{ ungrouped = [string]$target; memberNames = $memberNames; nativeShapeIds = $nativeShapeIds } }
        } catch {
            Output-Json @{ success = $false; error = "ungroupShapes failed: $($_.Exception.Message)" }
        }
    }

    "duplicateShape" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $beforeShapeCount = [int]$slide.Shapes.Count
        $dup = Copy-PptShapeAndResolveClone $slide $shape
        $dupNativeShapeId = $(try { [int]$dup.Id } catch { $null })
        if ($null -ne $dupNativeShapeId) {
            $dup.Name = "$([string]$shape.Name)_copy_$dupNativeShapeId"
        }
        Output-Json @{ success = $true; data = @{ name = $dup.Name; nativeShapeId = $dupNativeShapeId; shapeCountBefore = $beforeShapeCount; shapeCountAfter = [int]$slide.Shapes.Count } }
    }

    "duplicatePptComponent" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        Output-Json (Get-PptDuplicateComponentResult $ppt $pres $p)
    }

    "duplicatePptObject" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        Output-Json (Get-PptDuplicateObjectResult $ppt $pres $p)
    }

    "rollbackPptDuplicateWrite" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        Output-Json (Get-PptRollbackDuplicateWriteResult $ppt $pres $p)
    }

    "setShapeZOrder" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.name) { $p.name } else { $p.shapeIndex }))
        $zMap = @{ front = 0; forward = 2; backward = 3; back = 1 }
        $z = $zMap[$p.zOrder]
        if ($null -eq $z) { $z = 0 }
        $shape.ZOrder($z)
        Output-Json @{ success = $true; data = @{ name = $shape.Name; zOrder = $p.zOrder } }
    }

    "insertPptChart" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $left = if ($p.left) { $p.left } else { 100 }
        $top = if ($p.top) { $p.top } else { 100 }
        $width = if ($p.width) { $p.width } else { 400 }
        $height = if ($p.height) { $p.height } else { 300 }
        $shape = $slide.Shapes.AddChart($p.type, $left, $top, $width, $height)
        Output-Json @{ success = $true; data = @{ name = $shape.Name; nativeShapeId = $(try { [int]$shape.Id } catch { $null }) } }
    }

    "addAnimation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($p.shapeName)
        $slide.TimeLine.MainSequence.AddEffect($shape, $p.effect, 1)
        Output-Json @{ success = $true }
    }

    "setSlideTransition" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $slide.SlideShowTransition.EntryEffect = $p.effect
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; effect = $p.effect } }
    }

    "setSlideBackground" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        if ($p.color) {
            $colorValue = Convert-HexColorToRgbInt([string]$p.color)
            if ($null -ne $colorValue) { $slide.Background.Fill.ForeColor.RGB = $colorValue }
        }
        if ($p.imagePath) {
            $slide.FollowMasterBackground = $false
            $slide.Background.Fill.UserPicture($p.imagePath)
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex } }
    }

    "slide.unifyFont" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $fontName = if ($p.fontName) { $p.fontName } else { "微软雅黑" }
        $count = 0
        $includeTitle = if ($null -ne $p.includeTitle) { [bool]$p.includeTitle } else { $true }
        $includeBody = if ($null -ne $p.includeBody) { [bool]$p.includeBody } else { $true }
        $start = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $end = if ($p.slideIndex) { [int]$p.slideIndex } else { $pres.Slides.Count }
        for ($i = $start; $i -le $end; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $isTitle = $false
                        try { $isTitle = $shape.PlaceholderFormat.Type -eq 1 -or $shape.PlaceholderFormat.Type -eq 3 } catch {}
                        if (($isTitle -and $includeTitle) -or (-not $isTitle -and $includeBody)) {
                            $shape.TextFrame.TextRange.Font.Name = $fontName
                            $count++
                        }
                    }
                } catch {}
            }
        }
        $slideCount = if ($p.slideIndex) { 1 } else { $pres.Slides.Count }
        Output-Json @{ success = $true; data = @{ font = $fontName; count = $count; slideCount = $slideCount } }
    }

    "addConnector" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $beginX = if ($null -ne $p.x1) { [double]$p.x1 } elseif ($null -ne $p.left) { [double]$p.left } else { 100 }
        $beginY = if ($null -ne $p.y1) { [double]$p.y1 } elseif ($null -ne $p.top) { [double]$p.top } else { 100 }
        $endX = if ($null -ne $p.x2) { [double]$p.x2 } elseif ($null -ne $p.width) { [double]$p.width } else { 200 }
        $endY = if ($null -ne $p.y2) { [double]$p.y2 } elseif ($null -ne $p.height) { [double]$p.height } else { 0 }
        $connector = $slide.Shapes.AddConnector(1, $beginX, $beginY, $endX, $endY)
        if ($null -ne $p.lineColor) {
            $connector.Line.Visible = -1
            $connector.Line.ForeColor.RGB = Convert-HexColorToRgbInt ([string]$p.lineColor)
        }
        if ($null -ne $p.lineWidth) {
            $connector.Line.Visible = -1
            $connector.Line.Weight = [double]$p.lineWidth
        }
        if ($p.name) { $connector.Name = [string]$p.name }
        Output-Json @{ success = $true; data = @{ name = $connector.Name; nativeShapeId = $(try { [int]$connector.Id } catch { $null }) } }
    }

    "addArrow" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $left = if ($p.left) { $p.left } else { 100 }
        $top = if ($p.top) { $p.top } else { 100 }
        $width = if ($p.width) { $p.width } else { 120 }
        $height = if ($p.height) { $p.height } else { 60 }
        $shape = $slide.Shapes.AddShape(13, $left, $top, $width, $height)
        Output-Json @{ success = $true; data = @{ name = $shape.Name } }
    }

    "applyColorScheme" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $schemeKey = if ($p.scheme) { $p.scheme } elseif ($p.colorScheme) { $p.colorScheme } else { "business" }
        $schemes = @{ business = @{ title = 0x2F5496; body = 0x333333 }; tech = @{ title = 0x00B0F0; body = 0x404040 }; creative = @{ title = 0xFF6B6B; body = 0x4A4A4A }; minimal = @{ title = 0x000000; body = 0x666666 } }
        $scheme = $schemes[$schemeKey]
        if ($null -eq $scheme) { $scheme = $schemes["business"] }
        $count = 0
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $textRange = $shape.TextFrame.TextRange
                        if ($textRange.Font.Size -ge 24) { $textRange.Font.Color.RGB = $scheme.title } else { $textRange.Font.Color.RGB = $scheme.body }
                        $count++
                    }
                } catch {}
            }
        }
        Output-Json @{ success = $true; data = @{ scheme = $schemeKey; count = $count } }
    }

    "autoBeautifySlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { $pres.Windows.Item(1).Selection.SlideRange.SlideIndex }
        $slide = $pres.Slides.Item($slideIndex)
        $schemes = @{ business = @{ title = 0x2F5496; body = 0x333333 }; tech = @{ title = 0x00B0F0; body = 0x404040 }; creative = @{ title = 0xFF6B6B; body = 0x4A4A4A }; minimal = @{ title = 0x000000; body = 0x666666 } }
        $schemeKey = if ($p.style) { $p.style } else { "business" }
        $scheme = $schemes[$schemeKey]
        if ($null -eq $scheme) { $scheme = $schemes["business"] }
        $count = 0
        for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
            $shape = $slide.Shapes.Item($j)
            try {
                if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                    $textRange = $shape.TextFrame.TextRange
                    if ($textRange.Font.Size -ge 24) { $textRange.Font.Color.RGB = $scheme.title } else { $textRange.Font.Color.RGB = $scheme.body }
                    $count++
                }
            } catch {}
        }
        Output-Json @{ success = $true; data = @{ style = $schemeKey; count = $count } }
    }

    "createKpiCards" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $cards = if ($p.cards) { $p.cards } else { @() }
        $startX = if ($p.startX) { $p.startX } else { 50 }
        $startY = if ($p.startY) { $p.startY } else { 350 }
        $cardWidth = if ($p.cardWidth) { $p.cardWidth } else { 150 }
        $cardHeight = if ($p.cardHeight) { $p.cardHeight } else { 80 }
        $gap = if ($p.gap) { $p.gap } else { 20 }

        $colors = @("#28a745", "#17a2b8", "#ffc107", "#dc3545", "#6f42c1", "#fd7e14")
        $created = @()

        for ($i = 0; $i -lt $cards.Count; $i++) {
            $card = $cards[$i]
            $x = $startX + ($i * ($cardWidth + $gap))
            $color = if ($card.color) { $card.color } else { $colors[$i % $colors.Count] }
            $shape = $slide.Shapes.AddShape(5, $x, $startY, $cardWidth, $cardHeight)
            $colorValue = Convert-HexColorToRgbInt([string]$color)
            if ($null -ne $colorValue) { $shape.Fill.Solid(); $shape.Fill.ForeColor.RGB = $colorValue }
            $shape.Line.Visible = $false
            $shape.Shadow.Visible = $true
            $shape.Shadow.Blur = 10
            $shape.Shadow.OffsetX = 3
            $shape.Shadow.OffsetY = 3
            $shape.Shadow.Transparency = 0.6
            $title = if ($card.title) { $card.title } else { "" }
            $value = if ($card.value) { $card.value } else { "" }
            $shape.TextFrame.TextRange.Text = ($title + "`n" + $value)
            $shape.TextFrame.TextRange.Font.Color.RGB = 16777215
            $shape.TextFrame.TextRange.Font.Size = 14
            $shape.TextFrame.TextRange.Font.Bold = $true
            $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 2
            $created += $shape.Name
        }

        Output-Json @{ success = $true; data = @{ count = $created.Count; cards = $created } }
    }

    "createStyledTable" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $rows = if ($p.rows) { $p.rows } else { 5 }
        $cols = if ($p.cols) { $p.cols } else { 4 }
        $left = if ($p.left) { $p.left } else { 50 }
        $top = if ($p.top) { $p.top } else { 150 }
        $width = if ($p.width) { $p.width } else { 620 }
        $height = if ($p.height) { $p.height } else { 200 }

        $tableShape = $slide.Shapes.AddTable($rows, $cols, $left, $top, $width, $height)
        $table = $tableShape.Table

        $styleKey = if ($p.style) { $p.style } else { "business" }
        $styles = @{
            business = @{ header = "#1a365d"; headerText = "#ffffff"; oddRow = "#f8f9fa"; evenRow = "#ffffff" }
            tech = @{ header = "#0d47a1"; headerText = "#ffffff"; oddRow = "#e3f2fd"; evenRow = "#ffffff" }
            elegant = @{ header = "#37474f"; headerText = "#ffffff"; oddRow = "#eceff1"; evenRow = "#ffffff" }
        }
        $style = $styles[$styleKey]
        if ($null -eq $style) { $style = $styles["business"] }

        for ($c = 1; $c -le $cols; $c++) {
            $headerCell = $table.Cell(1, $c)
            $headerColor = Convert-HexColorToRgbInt([string]$style.header)
            if ($null -ne $headerColor) { $headerCell.Shape.Fill.Solid(); $headerCell.Shape.Fill.ForeColor.RGB = $headerColor }
            $headerTextColor = Convert-HexColorToRgbInt([string]$style.headerText)
            if ($null -ne $headerTextColor) { $headerCell.Shape.TextFrame.TextRange.Font.Color.RGB = $headerTextColor }
            $headerCell.Shape.TextFrame.TextRange.Font.Bold = $true
            $headerCell.Shape.TextFrame.TextRange.Font.Size = 12
        }

        for ($r = 2; $r -le $rows; $r++) {
            $rowColor = if ($r % 2 -eq 0) { $style.evenRow } else { $style.oddRow }
            $rowColorValue = Convert-HexColorToRgbInt([string]$rowColor)
            for ($c = 1; $c -le $cols; $c++) {
                $cell = $table.Cell($r, $c)
                if ($null -ne $rowColorValue) { $cell.Shape.Fill.Solid(); $cell.Shape.Fill.ForeColor.RGB = $rowColorValue }
                $cell.Shape.TextFrame.TextRange.Font.Size = 11
            }
        }

        if ($p.data) {
            for ($r = 0; $r -lt $p.data.Count; $r++) {
                $rowData = $p.data[$r]
                for ($c = 0; $c -lt $rowData.Count; $c++) {
                    if (($r + 1) -le $rows -and ($c + 1) -le $cols) {
                        $table.Cell($r + 1, $c + 1).Shape.TextFrame.TextRange.Text = [string]$rowData[$c]
                    }
                }
            }
        }

        Output-Json @{ success = $true; data = @{ name = $tableShape.Name; rows = $rows; cols = $cols } }
    }

    "addTitleDecoration" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $left = if ($p.left) { $p.left } else { 50 }
        $top = if ($p.top) { $p.top } else { 130 }
        $width = if ($p.width) { $p.width } else { 200 }
        $height = if ($p.height) { $p.height } else { 5 }
        $colorValue = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#1a365d" }))
        $bar = $slide.Shapes.AddShape(1, $left, $top, $width, $height)
        if ($null -ne $colorValue) { $bar.Fill.Solid(); $bar.Fill.ForeColor.RGB = $colorValue }
        $bar.Line.Visible = $false
        Output-Json @{ success = $true; data = @{ name = $bar.Name } }
    }

    "addPageIndicator" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $total = $pres.Slides.Count
        $current = $slideIndex
        $text = "$current / $total"
        $left = if ($p.left) { $p.left } else { 880 }
        $top = if ($p.top) { $p.top } else { 500 }
        $box = $slide.Shapes.AddTextbox(1, $left, $top, 80, 30)
        $box.TextFrame.TextRange.Text = $text
        $box.TextFrame.TextRange.Font.Size = 12
        $box.TextFrame.TextRange.Font.Color.RGB = if ($p.dark) { 0 } else { 16777215 }
        $box.TextFrame.TextRange.ParagraphFormat.Alignment = 3
        Output-Json @{ success = $true; data = @{ name = $box.Name; page = $text } }
    }

    "beautifyAllSlides" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $schemeKey = if ($p.style) { $p.style } else { "business" }
        $schemes = @{ business = @{ title = 0x2F5496; body = 0x333333 }; tech = @{ title = 0x00B0F0; body = 0x404040 }; creative = @{ title = 0xFF6B6B; body = 0x4A4A4A }; minimal = @{ title = 0x000000; body = 0x666666 } }
        $scheme = $schemes[$schemeKey]
        if ($null -eq $scheme) { $scheme = $schemes["business"] }
        $count = 0
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $textRange = $shape.TextFrame.TextRange
                        if ($textRange.Font.Size -ge 24) { $textRange.Font.Color.RGB = $scheme.title } else { $textRange.Font.Color.RGB = $scheme.body }
                        $count++
                    }
                } catch {}
            }
        }
        Output-Json @{ success = $true; data = @{ style = $schemeKey; count = $count } }
    }

    "createProgressBar" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $left = if ($p.left) { $p.left } else { 100 }
        $top = if ($p.top) { $p.top } else { 300 }
        $width = if ($p.width) { $p.width } else { 400 }
        $height = if ($p.height) { $p.height } else { 30 }
        $progress = if ($null -ne $p.progress) { [double]$p.progress } else { 0.5 }
        if ($progress -lt 0) { $progress = 0 }
        if ($progress -gt 1) { $progress = 1 }
        $label = if ($p.label) { $p.label } else { "" }

        $bgBar = $slide.Shapes.AddShape(5, $left, $top, $width, $height)
        $bgColor = Convert-HexColorToRgbInt([string]$(if ($p.bgColor) { $p.bgColor } else { "#e0e0e0" }))
        if ($null -ne $bgColor) { $bgBar.Fill.Solid(); $bgBar.Fill.ForeColor.RGB = $bgColor }
        $bgBar.Line.Visible = $false

        $progressWidth = $width * $progress
        $progressBar = $slide.Shapes.AddShape(5, $left, $top, $progressWidth, $height)
        $colorValue = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#28a745" }))
        if ($null -ne $colorValue) { $progressBar.Fill.Solid(); $progressBar.Fill.ForeColor.RGB = $colorValue }
        $progressBar.Line.Visible = $false

        $percentText = $slide.Shapes.AddTextbox(1, $left + $width + 10, $top, 60, $height)
        $percentText.TextFrame.TextRange.Text = "{0}%" -f ([Math]::Round($progress * 100))
        $percentText.TextFrame.TextRange.Font.Size = 14
        $percentText.TextFrame.TextRange.Font.Bold = $true

        if ($label) {
            $labelBox = $slide.Shapes.AddTextbox(1, $left, $top - 25, $width, 20)
            $labelBox.TextFrame.TextRange.Text = $label
            $labelBox.TextFrame.TextRange.Font.Size = 12
        }

        Output-Json @{ success = $true; data = @{ bgBar = $bgBar.Name; progressBar = $progressBar.Name; progress = $progress } }
    }

    "createGauge" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $centerX = if ($p.centerX) { $p.centerX } else { 360 }
        $centerY = if ($p.centerY) { $p.centerY } else { 300 }
        $radius = if ($p.radius) { $p.radius } else { 100 }
        $value = if ($null -ne $p.value) { [double]$p.value } else { 0.5 }
        if ($value -lt 0) { $value = 0 }
        if ($value -gt 1) { $value = 1 }
        $title = if ($p.title) { $p.title } else { "" }

        $outerCircle = $slide.Shapes.AddShape(9, $centerX - $radius, $centerY - $radius, $radius * 2, $radius * 2)
        $outerColor = Convert-HexColorToRgbInt([string]"#e0e0e0")
        if ($null -ne $outerColor) { $outerCircle.Fill.Solid(); $outerCircle.Fill.ForeColor.RGB = $outerColor }
        $outerCircle.Line.Visible = $false

        $innerRadius = $radius * 0.7
        $innerCircle = $slide.Shapes.AddShape(9, $centerX - $innerRadius, $centerY - $innerRadius, $innerRadius * 2, $innerRadius * 2)
        $innerColor = Convert-HexColorToRgbInt([string]"#ffffff")
        if ($null -ne $innerColor) { $innerCircle.Fill.Solid(); $innerCircle.Fill.ForeColor.RGB = $innerColor }
        $innerCircle.Line.Visible = $false

        $valueText = $slide.Shapes.AddTextbox(1, $centerX - 40, $centerY - 20, 80, 40)
        $valueText.TextFrame.TextRange.Text = "{0}%" -f ([Math]::Round($value * 100))
        $valueText.TextFrame.TextRange.Font.Size = 24
        $valueText.TextFrame.TextRange.Font.Bold = $true
        $valueText.TextFrame.TextRange.ParagraphFormat.Alignment = 2

        if ($title) {
            $titleBox = $slide.Shapes.AddTextbox(1, $centerX - 60, $centerY + $radius + 10, 120, 25)
            $titleBox.TextFrame.TextRange.Text = $title
            $titleBox.TextFrame.TextRange.Font.Size = 14
            $titleBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2
        }

        Output-Json @{ success = $true; data = @{ gauge = $outerCircle.Name; value = $value } }
    }

    "createMiniCharts" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $items = if ($p.items) { $p.items } else { @() }
        $startX = if ($p.startX) { $p.startX } else { 50 }
        $startY = if ($p.startY) { $p.startY } else { 400 }
        $itemWidth = if ($p.itemWidth) { $p.itemWidth } else { 100 }
        $gap = if ($p.gap) { $p.gap } else { 30 }
        $colors = @("#28a745", "#17a2b8", "#ffc107", "#dc3545", "#6f42c1")
        $created = @()

        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            $x = $startX + ($i * ($itemWidth + $gap))
            $color = if ($item.color) { $item.color } else { $colors[$i % $colors.Count] }
            $colorValue = Convert-HexColorToRgbInt([string]$color)

            $valueBox = $slide.Shapes.AddTextbox(1, $x, $startY, $itemWidth, 30)
            $valueBox.TextFrame.TextRange.Text = if ($item.value) { $item.value } else { "0" }
            $valueBox.TextFrame.TextRange.Font.Size = 20
            $valueBox.TextFrame.TextRange.Font.Bold = $true
            if ($null -ne $colorValue) { $valueBox.TextFrame.TextRange.Font.Color.RGB = $colorValue }

            $labelBox = $slide.Shapes.AddTextbox(1, $x, $startY + 30, $itemWidth, 20)
            $labelBox.TextFrame.TextRange.Text = if ($item.label) { $item.label } else { "" }
            $labelBox.TextFrame.TextRange.Font.Size = 11
            $labelBox.TextFrame.TextRange.Font.Color.RGB = 6710886

            if ($item.trend) {
                $trendBox = $slide.Shapes.AddTextbox(1, $x + $itemWidth - 30, $startY, 30, 20)
                $trendBox.TextFrame.TextRange.Text = if ($item.trend -eq "up") { "↑" } else { "↓" }
                $trendBox.TextFrame.TextRange.Font.Size = 14
                $trendColor = if ($item.trend -eq "up") { "#28a745" } else { "#dc3545" }
                $trendColorValue = Convert-HexColorToRgbInt([string]$trendColor)
                if ($null -ne $trendColorValue) { $trendBox.TextFrame.TextRange.Font.Color.RGB = $trendColorValue }
            }

            $created += @{ label = $item.label; value = $item.value }
        }

        Output-Json @{ success = $true; data = @{ count = $created.Count; items = $created } }
    }

    "createDonutChart" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $centerX = if ($p.centerX) { $p.centerX } else { 360 }
        $centerY = if ($p.centerY) { $p.centerY } else { 280 }
        $radius = if ($p.radius) { $p.radius } else { 80 }
        $value = if ($null -ne $p.value) { [double]$p.value } else { 0.75 }
        if ($value -lt 0) { $value = 0 }
        if ($value -gt 1) { $value = 1 }
        $title = if ($p.title) { $p.title } else { "" }
        $centerText = if ($p.centerText) { $p.centerText } else { "{0}%" -f ([Math]::Round($value * 100)) }

        $outerCircle = $slide.Shapes.AddShape(9, $centerX - $radius, $centerY - $radius, $radius * 2, $radius * 2)
        $outerColor = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#0d47a1" }))
        if ($null -ne $outerColor) { $outerCircle.Fill.Solid(); $outerCircle.Fill.ForeColor.RGB = $outerColor }
        $outerCircle.Line.Visible = $false

        $innerRadius = $radius * 0.6
        $innerCircle = $slide.Shapes.AddShape(9, $centerX - $innerRadius, $centerY - $innerRadius, $innerRadius * 2, $innerRadius * 2)
        $innerColor = Convert-HexColorToRgbInt([string]"#ffffff")
        if ($null -ne $innerColor) { $innerCircle.Fill.Solid(); $innerCircle.Fill.ForeColor.RGB = $innerColor }
        $innerCircle.Line.Visible = $false

        $textBox = $slide.Shapes.AddTextbox(1, $centerX - 40, $centerY - 15, 80, 30)
        $textBox.TextFrame.TextRange.Text = $centerText
        $textBox.TextFrame.TextRange.Font.Size = 18
        $textBox.TextFrame.TextRange.Font.Bold = $true
        $textBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2

        if ($title) {
            $titleBox = $slide.Shapes.AddTextbox(1, $centerX - 60, $centerY + $radius + 15, 120, 25)
            $titleBox.TextFrame.TextRange.Text = $title
            $titleBox.TextFrame.TextRange.Font.Size = 12
            $titleBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2
        }

        Output-Json @{ success = $true; data = @{ donut = $outerCircle.Name; value = $value } }
    }

    "autoLayout" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $layout = if ($p.layout) { $p.layout } else { "grid" }
        $margin = if ($p.margin) { $p.margin } else { 50 }
        $gap = if ($p.gap) { $p.gap } else { 20 }
        $slideWidth = 720
        $slideHeight = 540

        $shapes = @()
        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $s = $slide.Shapes.Item($i)
            if ($s.Type -eq 1 -or $s.Type -eq 6 -or $s.Type -eq 17) { $shapes += $s }
        }

        if ($shapes.Count -eq 0) {
            Output-Json @{ success = $true; data = @{ message = "没有可排列的形状"; count = 0 } }
            break
        }

        if ($layout -eq "horizontal") {
            $totalWidth = 0
            foreach ($shape in $shapes) { $totalWidth += $shape.Width }
            $availWidth = $slideWidth - 2 * $margin
            $spacing = ($availWidth - $totalWidth) / ($shapes.Count + 1)
            $currentX = $margin + $spacing
            foreach ($shape in $shapes) {
                $shape.Left = $currentX
                $shape.Top = ($slideHeight - $shape.Height) / 2
                $currentX += $shape.Width + $spacing
            }
        } elseif ($layout -eq "vertical") {
            $currentY = $margin
            foreach ($shape in $shapes) {
                $shape.Left = ($slideWidth - $shape.Width) / 2
                $shape.Top = $currentY
                $currentY += $shape.Height + $gap
            }
        } else {
            $cols = if ($p.cols) { $p.cols } else { [Math]::Ceiling([Math]::Sqrt($shapes.Count)) }
            $rows = [Math]::Ceiling($shapes.Count / $cols)
            $cellWidth = ($slideWidth - 2 * $margin) / $cols
            $cellHeight = ($slideHeight - 2 * $margin) / $rows
            for ($idx = 0; $idx -lt $shapes.Count; $idx++) {
                $col = $idx % $cols
                $row = [Math]::Floor($idx / $cols)
                $shape = $shapes[$idx]
                $shape.Left = $margin + $col * $cellWidth + ($cellWidth - $shape.Width) / 2
                $shape.Top = $margin + $row * $cellHeight + ($cellHeight - $shape.Height) / 2
            }
        }

        Output-Json @{ success = $true; data = @{ layout = $layout; count = $shapes.Count } }
    }

    "smartDistribute" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $direction = if ($p.direction) { $p.direction } else { "horizontal" }
        $shapeNames = if ($p.shapes) { $p.shapes } else { @() }
        $shapes = @()

        if ($shapeNames.Count -gt 0) {
            foreach ($name in $shapeNames) {
                try { $shapes += $slide.Shapes.Item($name) } catch {}
            }
        } else {
            for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
                $s = $slide.Shapes.Item($i)
                if ($s.Type -eq 1 -or $s.Type -eq 6 -or $s.Type -eq 17) { $shapes += $s }
            }
        }

        if ($shapes.Count -lt 2) {
            Output-Json @{ success = $true; data = @{ message = "需要至少2个形状"; count = $shapes.Count } }
            break
        }

        $shapes = if ($direction -eq "horizontal") { $shapes | Sort-Object Left } else { $shapes | Sort-Object Top }

        if ($direction -eq "horizontal") {
            $minX = $shapes[0].Left
            $maxX = $shapes[$shapes.Count - 1].Left + $shapes[$shapes.Count - 1].Width
            $totalWidth = 0
            foreach ($shape in $shapes) { $totalWidth += $shape.Width }
            $spacing = ($maxX - $minX - $totalWidth) / ($shapes.Count - 1)
            $currentX = $minX
            foreach ($shape in $shapes) {
                $shape.Left = $currentX
                $currentX += $shape.Width + $spacing
            }
        } else {
            $minY = $shapes[0].Top
            $maxY = $shapes[$shapes.Count - 1].Top + $shapes[$shapes.Count - 1].Height
            $totalHeight = 0
            foreach ($shape in $shapes) { $totalHeight += $shape.Height }
            $spacing = ($maxY - $minY - $totalHeight) / ($shapes.Count - 1)
            $currentY = $minY
            foreach ($shape in $shapes) {
                $shape.Top = $currentY
                $currentY += $shape.Height + $spacing
            }
        }

        Output-Json @{ success = $true; data = @{ direction = $direction; count = $shapes.Count } }
    }

    "createGrid" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $rows = if ($p.rows) { $p.rows } else { 2 }
        $cols = if ($p.cols) { $p.cols } else { 3 }
        $margin = if ($p.margin) { $p.margin } else { 50 }
        $gap = if ($p.gap) { $p.gap } else { 15 }
        $slideWidth = 720
        $slideHeight = 540

        $cellWidth = ($slideWidth - 2 * $margin - ($cols - 1) * $gap) / $cols
        $cellHeight = ($slideHeight - 2 * $margin - ($rows - 1) * $gap) / $rows
        $cells = @()

        for ($r = 0; $r -lt $rows; $r++) {
            for ($c = 0; $c -lt $cols; $c++) {
                $left = $margin + $c * ($cellWidth + $gap)
                $top = $margin + $r * ($cellHeight + $gap)
                $cell = $slide.Shapes.AddShape(5, $left, $top, $cellWidth, $cellHeight)
                $cellColor = Convert-HexColorToRgbInt([string]$(if ($p.cellColor) { $p.cellColor } else { "#f8f9fa" }))
                $borderColor = Convert-HexColorToRgbInt([string]$(if ($p.borderColor) { $p.borderColor } else { "#dee2e6" }))
                if ($null -ne $cellColor) { $cell.Fill.Solid(); $cell.Fill.ForeColor.RGB = $cellColor }
                if ($null -ne $borderColor) { $cell.Line.ForeColor.RGB = $borderColor }
                $cell.Line.Weight = 1
                $cells += $cell.Name
            }
        }

        Output-Json @{ success = $true; data = @{ rows = $rows; cols = $cols; cells = $cells } }
    }

    "addAnimationPreset" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $preset = if ($p.preset) { $p.preset } else { "fadeIn" }
        $timeline = $slide.TimeLine
        $delay = 0
        $delayIncrement = if ($p.delayIncrement) { $p.delayIncrement } else { 0.3 }
        $presets = @{ fadeIn = @{ effect = 10; duration = 0.5 }; flyIn = @{ effect = 2; duration = 0.5 }; zoomIn = @{ effect = 53; duration = 0.4 }; wipeIn = @{ effect = 22; duration = 0.5 }; appear = @{ effect = 1; duration = 0 } }
        $config = $presets[$preset]
        if ($null -eq $config) { $config = $presets["fadeIn"] }
        $animatedCount = 0

        for ($i = 1; $i -le $slide.Shapes.Count; $i++) {
            $shape = $slide.Shapes.Item($i)
            try {
                $effect = $timeline.MainSequence.AddEffect($shape, $config.effect, 0, 1)
                $effect.Timing.Duration = $config.duration
                $effect.Timing.TriggerDelayTime = $delay
                $delay += $delayIncrement
                $animatedCount++
            } catch {}
        }

        Output-Json @{ success = $true; data = @{ preset = $preset; animatedShapes = $animatedCount } }
    }

    "addEmphasisAnimation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))

        $effectType = if ($p.effect) { $p.effect } else { "pulse" }
        $effectMap = @{ pulse = 63; spin = 15; grow = 53; teeter = 28 }
        $effectId = if ($effectMap[$effectType]) { $effectMap[$effectType] } else { 63 }

        $timeline = $slide.TimeLine
        $effect = $timeline.MainSequence.AddEffect($shape, $effectId, 0, 2)
        $effect.Timing.Duration = if ($p.duration) { $p.duration } else { 0.5 }

        Output-Json @{ success = $true; data = @{ shape = $shape.Name; effect = $effectType } }
    }

    "createFlowChart" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $steps = if ($p.steps) { $p.steps } else { @("开始", "步骤1", "步骤2", "结束") }
        $direction = if ($p.direction) { $p.direction } else { "horizontal" }
        $startX = if ($p.startX) { $p.startX } else { 80 }
        $startY = if ($p.startY) { $p.startY } else { 250 }
        $boxWidth = if ($p.boxWidth) { $p.boxWidth } else { 100 }
        $boxHeight = if ($p.boxHeight) { $p.boxHeight } else { 50 }
        $gap = if ($p.gap) { $p.gap } else { 60 }
        $colors = @{ start = "#28a745"; process = "#0d47a1"; end = "#dc3545" }
        $shapes = @()

        for ($i = 0; $i -lt $steps.Count; $i++) {
            if ($direction -eq "horizontal") {
                $x = $startX + $i * ($boxWidth + $gap)
                $y = $startY
            } else {
                $x = $startX
                $y = $startY + $i * ($boxHeight + $gap)
            }

            $shapeType = 5
            $colorKey = "process"
            if ($i -eq 0) { $shapeType = 9; $colorKey = "start" }
            elseif ($i -eq $steps.Count - 1) { $shapeType = 9; $colorKey = "end" }

            $shape = $slide.Shapes.AddShape($shapeType, $x, $y, $boxWidth, $boxHeight)
            $colorValue = Convert-HexColorToRgbInt([string]$colors[$colorKey])
            if ($null -ne $colorValue) { $shape.Fill.Solid(); $shape.Fill.ForeColor.RGB = $colorValue }
            $shape.Line.Visible = $false
            $shape.TextFrame.TextRange.Text = $steps[$i]
            $shape.TextFrame.TextRange.Font.Color.RGB = 16777215
            $shape.TextFrame.TextRange.Font.Size = 12
            $shape.TextFrame.TextRange.Font.Bold = $true
            $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 2
            $shapes += $shape.Name

            if ($i -lt $steps.Count - 1) {
                if ($direction -eq "horizontal") {
                    $arrowX1 = $x + $boxWidth
                    $arrowY1 = $y + $boxHeight / 2
                    $arrowX2 = $x + $boxWidth + $gap
                    $arrowY2 = $arrowY1
                } else {
                    $arrowX1 = $x + $boxWidth / 2
                    $arrowY1 = $y + $boxHeight
                    $arrowX2 = $arrowX1
                    $arrowY2 = $y + $boxHeight + $gap
                }
                $arrow = $slide.Shapes.AddLine($arrowX1, $arrowY1, $arrowX2, $arrowY2)
                $arrow.Line.EndArrowheadStyle = 2
                $arrow.Line.Weight = 2
                $arrowColor = Convert-HexColorToRgbInt([string]"#666666")
                if ($null -ne $arrowColor) { $arrow.Line.ForeColor.RGB = $arrowColor }
            }
        }

        Output-Json @{ success = $true; data = @{ steps = $steps.Count; shapes = $shapes } }
    }

    "createOrgChart" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $nodes = if ($p.nodes) { $p.nodes } else { @(@{ name = "CEO"; level = 0 }, @{ name = "技术总监"; level = 1 }, @{ name = "市场总监"; level = 1 }, @{ name = "财务总监"; level = 1 }) }
        $centerX = 360
        $startY = if ($p.startY) { $p.startY } else { 80 }
        $boxWidth = if ($p.boxWidth) { $p.boxWidth } else { 100 }
        $boxHeight = if ($p.boxHeight) { $p.boxHeight } else { 40 }
        $levelGap = if ($p.levelGap) { $p.levelGap } else { 80 }
        $levelColors = @("#1a365d", "#2d5a87", "#4a7ab0", "#6b9bd1")

        $levels = @{}
        foreach ($node in $nodes) {
            $level = if ($node.level -ne $null) { $node.level } else { 0 }
            if (-not $levels.ContainsKey($level)) { $levels[$level] = @() }
            $levels[$level] += $node
        }

        $levelKeys = $levels.Keys | Sort-Object
        $shapes = @()
        $levelIndex = 0
        foreach ($levelKey in $levelKeys) {
            $levelNodes = $levels[$levelKey]
            $levelY = $startY + $levelIndex * $levelGap
            $totalWidth = $levelNodes.Count * $boxWidth + ($levelNodes.Count - 1) * 30
            $startX = $centerX - $totalWidth / 2

            for ($i = 0; $i -lt $levelNodes.Count; $i++) {
                $x = $startX + $i * ($boxWidth + 30)
                $shape = $slide.Shapes.AddShape(5, $x, $levelY, $boxWidth, $boxHeight)
                $colorValue = Convert-HexColorToRgbInt([string]$levelColors[$levelIndex % $levelColors.Count])
                if ($null -ne $colorValue) { $shape.Fill.Solid(); $shape.Fill.ForeColor.RGB = $colorValue }
                $shape.Line.Visible = $false
                $shape.TextFrame.TextRange.Text = $levelNodes[$i].name
                $shape.TextFrame.TextRange.Font.Color.RGB = 16777215
                $shape.TextFrame.TextRange.Font.Size = 11
                $shape.TextFrame.TextRange.Font.Bold = $true
                $shape.TextFrame.TextRange.ParagraphFormat.Alignment = 2
                $shape.Shadow.Visible = $true
                $shape.Shadow.Blur = 5
                $shape.Shadow.OffsetX = 2
                $shape.Shadow.OffsetY = 2
                $shape.Shadow.Transparency = 0.7
                $shapes += $shape.Name
            }

            $levelIndex++
        }

        Output-Json @{ success = $true; data = @{ levels = $levelKeys.Count; totalNodes = $nodes.Count; shapes = $shapes } }
    }

    "createTimeline" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $events = if ($p.events) { $p.events } else { @(@{ date = "2020"; title = "成立" }, @{ date = "2021"; title = "融资" }, @{ date = "2022"; title = "扩张" }, @{ date = "2023"; title = "上市" }) }
        $startX = if ($p.startX) { $p.startX } else { 80 }
        $startY = if ($p.startY) { $p.startY } else { 280 }
        $lineLength = if ($p.lineLength) { $p.lineLength } else { 560 }

        $mainLine = $slide.Shapes.AddLine($startX, $startY, $startX + $lineLength, $startY)
        $lineColor = Convert-HexColorToRgbInt([string]$(if ($p.lineColor) { $p.lineColor } else { "#1a365d" }))
        if ($null -ne $lineColor) { $mainLine.Line.ForeColor.RGB = $lineColor }
        $mainLine.Line.Weight = 3

        $gap = if ($events.Count -gt 1) { $lineLength / ($events.Count - 1) } else { 0 }
        $shapes = @()

        for ($i = 0; $i -lt $events.Count; $i++) {
            $x = $startX + ($i * $gap)
            $above = ($i % 2 -eq 0)

            $dot = $slide.Shapes.AddShape(9, $x - 8, $startY - 8, 16, 16)
            $dotColor = Convert-HexColorToRgbInt([string]$(if ($p.dotColor) { $p.dotColor } else { "#0d47a1" }))
            if ($null -ne $dotColor) { $dot.Fill.Solid(); $dot.Fill.ForeColor.RGB = $dotColor }
            $dot.Line.Visible = $false

            $lineY = if ($above) { $startY - 50 } else { $startY + 50 }
            $connector = $slide.Shapes.AddLine($x, $startY, $x, $lineY)
            $connector.Line.Weight = 2
            $connectorColor = Convert-HexColorToRgbInt([string]"#cccccc")
            if ($null -ne $connectorColor) { $connector.Line.ForeColor.RGB = $connectorColor }

            $dateBox = $slide.Shapes.AddTextbox(1, $x - 30, $(if ($above) { $lineY - 45 } else { $lineY + 5 }), 60, 20)
            $dateBox.TextFrame.TextRange.Text = $events[$i].date
            $dateBox.TextFrame.TextRange.Font.Size = 12
            $dateBox.TextFrame.TextRange.Font.Bold = $true
            $dateBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2

            $titleBox = $slide.Shapes.AddTextbox(1, $x - 40, $(if ($above) { $lineY - 25 } else { $lineY + 25 }), 80, 20)
            $titleBox.TextFrame.TextRange.Text = $events[$i].title
            $titleBox.TextFrame.TextRange.Font.Size = 10
            $titleColor = Convert-HexColorToRgbInt([string]"#666666")
            if ($null -ne $titleColor) { $titleBox.TextFrame.TextRange.Font.Color.RGB = $titleColor }
            $titleBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2

            $shapes += $dot.Name
        }

        Output-Json @{ success = $true; data = @{ events = $events.Count; shapes = $shapes } }
    }

    "getSlideMaster" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $master = $pres.SlideMaster
        $masters = @()
        for ($i = 1; $i -le $master.Shapes.Count; $i++) {
            $shape = $master.Shapes.Item($i)
            $masters += @{ name = $shape.Name; type = $shape.Type; left = $shape.Left; top = $shape.Top; width = $shape.Width; height = $shape.Height }
        }
        Output-Json @{ success = $true; data = @{ shapeCount = $masters.Count; shapes = $masters } }
    }

    "setMasterBackground" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $master = $pres.SlideMaster
        if ($p.gradient) {
            $master.Background.Fill.TwoColorGradient(1, 1)
            $color1 = Convert-HexColorToRgbInt([string]$(if ($p.color1) { $p.color1 } else { "#1a365d" }))
            $color2 = Convert-HexColorToRgbInt([string]$(if ($p.color2) { $p.color2 } else { "#2d5a87" }))
            if ($null -ne $color1) { $master.Background.Fill.GradientStops.Item(1).Color.RGB = $color1 }
            if ($null -ne $color2) { $master.Background.Fill.GradientStops.Item(2).Color.RGB = $color2 }
        } else {
            $master.Background.Fill.Solid()
            $colorValue = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#ffffff" }))
            if ($null -ne $colorValue) { $master.Background.Fill.ForeColor.RGB = $colorValue }
        }
        Output-Json @{ success = $true; data = @{ message = "母版背景已更新" } }
    }

    "addMasterElement" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $master = $pres.SlideMaster

        $type = if ($p.type) { $p.type } else { "textbox" }
        $left = if ($p.left) { $p.left } else { 600 }
        $top = if ($p.top) { $p.top } else { 20 }
        $width = if ($p.width) { $p.width } else { 100 }
        $height = if ($p.height) { $p.height } else { 40 }

        if ($type -eq "textbox") {
            $shape = $master.Shapes.AddTextbox(1, $left, $top, $width, $height)
            $shape.TextFrame.TextRange.Text = if ($p.text) { $p.text } else { "Logo" }
            $shape.TextFrame.TextRange.Font.Size = if ($p.fontSize) { $p.fontSize } else { 14 }
            $shape.TextFrame.TextRange.Font.Bold = $true
        } elseif ($type -eq "shape") {
            $shape = $master.Shapes.AddShape($(if ($p.shapeType) { $p.shapeType } else { 5 }), $left, $top, $width, $height)
            $colorValue = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#1a365d" }))
            if ($null -ne $colorValue) { $shape.Fill.Solid(); $shape.Fill.ForeColor.RGB = $colorValue }
            $shape.Line.Visible = $false
        } else {
            Output-Json @{ success = $false; error = "Unsupported master element type" }
            break
        }

        Output-Json @{ success = $true; data = @{ name = $shape.Name; type = $type } }
    }

    "set3DRotation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))

        $shape.ThreeD.RotationX = if ($p.rotationX -ne $null) { $p.rotationX } else { 0 }
        $shape.ThreeD.RotationY = if ($p.rotationY -ne $null) { $p.rotationY } else { 0 }
        $shape.ThreeD.RotationZ = if ($p.rotationZ -ne $null) { $p.rotationZ } else { 0 }

        if ($p.preset) {
            $presets = @{ isometric = @{ x = 45; y = 45; z = 0 }; perspective = @{ x = 30; y = 30; z = 0 }; oblique = @{ x = 20; y = 60; z = 0 }; tiltLeft = @{ x = 0; y = -30; z = 0 }; tiltRight = @{ x = 0; y = 30; z = 0 } }
            $preset = $presets[$p.preset]
            if ($preset) {
                $shape.ThreeD.RotationX = $preset.x
                $shape.ThreeD.RotationY = $preset.y
                $shape.ThreeD.RotationZ = $preset.z
            }
        }

        Output-Json @{ success = $true; data = @{ shape = $shape.Name; rotationX = $shape.ThreeD.RotationX; rotationY = $shape.ThreeD.RotationY } }
    }

    "set3DDepth" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))

        $depth = if ($p.depth) { $p.depth } else { 20 }
        $shape.ThreeD.Depth = $depth
        if ($p.depthColor) {
            $colorValue = Convert-HexColorToRgbInt([string]$p.depthColor)
            if ($null -ne $colorValue) { $shape.ThreeD.ExtrusionColor.RGB = $colorValue }
        }
        if ($p.lighting) {
            $lightingMap = @{ bright = 1; normal = 2; dim = 3; flat = 4 }
            $lightingValue = if ($lightingMap[$p.lighting]) { $lightingMap[$p.lighting] } else { 2 }
            $shape.ThreeD.PresetLighting = $lightingValue
        }

        Output-Json @{ success = $true; data = @{ shape = $shape.Name; depth = $depth } }
    }

    "set3DMaterial" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))

        $material = if ($p.material) { $p.material } else { "plastic" }
        $materialMap = @{ matte = 1; plastic = 2; metal = 3; wireFrame = 4; glass = 5 }
        $materialValue = if ($materialMap[$material]) { $materialMap[$material] } else { 2 }
        $shape.ThreeD.PresetMaterial = $materialValue

        Output-Json @{ success = $true; data = @{ shape = $shape.Name; material = $material } }
    }

    "create3DText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)

        $text = if ($p.text) { $p.text } else { "3D文字" }
        $left = if ($p.left) { $p.left } else { 200 }
        $top = if ($p.top) { $p.top } else { 200 }
        $width = if ($p.width) { $p.width } else { 300 }
        $height = if ($p.height) { $p.height } else { 100 }
        $textBox = $slide.Shapes.AddTextbox(1, $left, $top, $width, $height)
        $textBox.TextFrame.TextRange.Text = $text
        $textBox.TextFrame.TextRange.Font.Size = if ($p.fontSize) { $p.fontSize } else { 48 }
        $textBox.TextFrame.TextRange.Font.Bold = $true
        $colorValue = Convert-HexColorToRgbInt([string]$(if ($p.color) { $p.color } else { "#1a365d" }))
        if ($null -ne $colorValue) { $textBox.TextFrame.TextRange.Font.Color.RGB = $colorValue }
        $textBox.TextFrame.TextRange.ParagraphFormat.Alignment = 2

        $textBox.ThreeD.RotationX = if ($p.rotationX -ne $null) { $p.rotationX } else { 15 }
        $textBox.ThreeD.RotationY = if ($p.rotationY -ne $null) { $p.rotationY } else { 30 }
        $textBox.ThreeD.Depth = if ($p.depth) { $p.depth } else { 10 }

        $textBox.Shadow.Visible = $true
        $textBox.Shadow.Blur = 8
        $textBox.Shadow.OffsetX = 5
        $textBox.Shadow.OffsetY = 5
        $textBox.Shadow.Transparency = 0.5

        Output-Json @{ success = $true; data = @{ name = $textBox.Name; text = $text } }
    }

    "setPptChartData" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.chartName) { $p.chartName } else { $p.chartIndex }))
        $chart = $shape.Chart
        $chart.ChartData.Activate()
        $dataSheet = $chart.ChartData.Workbook.Worksheets.Item(1)
        if ($p.data) {
            for ($r = 0; $r -lt $p.data.Count; $r++) {
                $rowData = $p.data[$r]
                for ($c = 0; $c -lt $rowData.Count; $c++) {
                    $dataSheet.Cells.Item($r + 1, $c + 1).Value2 = $rowData[$c]
                }
            }
        }
        Output-Json @{ success = $true; data = @{ chartName = $shape.Name } }
    }

    "setPptChartStyle" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.chartName) { $p.chartName } else { $p.chartIndex }))
        $chart = $shape.Chart
        if ($p.title) {
            $chart.HasTitle = $true
            $chart.ChartTitle.Text = $p.title
        }
        if ($null -ne $p.hasLegend) {
            $chart.HasLegend = $p.hasLegend
        }
        Output-Json @{ success = $true; data = @{ chartName = $shape.Name } }
    }

    "removeAnimation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $seq = $slide.TimeLine.MainSequence
        if ($p.index) {
            $seq.Item($p.index).Delete()
        } else {
            while ($seq.Count -gt 0) { $seq.Item(1).Delete() }
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex } }
    }

    "getAnimations" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $seq = $slide.TimeLine.MainSequence
        $animations = @()
        for ($i = 1; $i -le $seq.Count; $i++) {
            $effect = $seq.Item($i)
            $animations += @{ index = $i; shapeName = $effect.Shape.Name; effectType = $effect.EffectType; duration = $effect.Timing.Duration }
        }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; animations = $animations; count = $animations.Count } }
    }

    "setAnimationOrder" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $seq = $slide.TimeLine.MainSequence
        $effect = $seq.Item($p.from)
        $effect.MoveTo($p.to)
        Output-Json @{ success = $true; data = @{ from = $p.from; to = $p.to } }
    }

    "removeSlideTransition" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $slide.SlideShowTransition.EntryEffect = 0
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex } }
    }

    "applyTransitionToAll" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $transitionMap = @{ none = 0; fade = 1; push = 2; wipe = 3; split = 4; reveal = 5; random = 6 }
        $transition = if ($transitionMap[$p.transition]) { $transitionMap[$p.transition] } else { if ($p.transition) { $p.transition } else { 1 } }
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            $slide.SlideShowTransition.EntryEffect = $transition
            if ($p.duration) { $slide.SlideShowTransition.Duration = $p.duration }
        }
        Output-Json @{ success = $true; data = @{ transition = $p.transition; appliedTo = $pres.Slides.Count } }
    }

    "setBackgroundColor" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $colorValue = Convert-HexColorToRgbInt([string]$p.color)
        if ($p.applyToAll) {
            for ($i = 1; $i -le $pres.Slides.Count; $i++) {
                $slide = $pres.Slides.Item($i)
                $slide.FollowMasterBackground = $false
                $slide.Background.Fill.Solid()
                if ($null -ne $colorValue) { $slide.Background.Fill.ForeColor.RGB = $colorValue }
            }
            Output-Json @{ success = $true; data = @{ color = $p.color; appliedTo = $pres.Slides.Count } }
        } else {
            $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
            $slide = $pres.Slides.Item($slideIndex)
            $slide.FollowMasterBackground = $false
            $slide.Background.Fill.Solid()
            if ($null -ne $colorValue) { $slide.Background.Fill.ForeColor.RGB = $colorValue }
            Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; color = $p.color } }
        }
    }

    "setBackgroundImage" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $slide.FollowMasterBackground = $false
        $slide.Background.Fill.UserPicture($p.path)
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndex; path = $p.path } }
    }

    "addPptHyperlink" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))
        $actionSettings = $shape.ActionSettings.Item(1)
        $actionSettings.Hyperlink.Address = if ($p.address) { $p.address } else { "" }
        if ($p.subAddress) { $actionSettings.Hyperlink.SubAddress = $p.subAddress }
        Output-Json @{ success = $true; data = @{ shapeName = $shape.Name; address = $p.address } }
    }

    "removePptHyperlink" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } else { $p.shapeIndex }))
        $shape.ActionSettings.Item(1).Hyperlink.Address = ""
        Output-Json @{ success = $true; data = @{ shapeName = $shape.Name } }
    }

    "setSlideNumber" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        if ($null -ne $p.visible) { $pres.SlideMaster.HeadersFooters.SlideNumber.Visible = $p.visible }
        Output-Json @{ success = $true; data = @{ visible = $p.visible } }
    }

    "setPptFooter" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $pres.SlideMaster.HeadersFooters.Footer.Visible = $true
        $pres.SlideMaster.HeadersFooters.Footer.Text = if ($p.text) { $p.text } else { "" }
        Output-Json @{ success = $true; data = @{ text = $p.text } }
    }

    "setPptDateTime" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $pres.SlideMaster.HeadersFooters.DateAndTime.Visible = if ($p.visible -ne $null) { $p.visible } else { $true }
        if ($p.useFixed) {
            $pres.SlideMaster.HeadersFooters.DateAndTime.UseFormat = $false
            $pres.SlideMaster.HeadersFooters.DateAndTime.Text = if ($p.text) { $p.text } else { "" }
        }
        Output-Json @{ success = $true; data = @{ visible = if ($p.visible -ne $null) { $p.visible } else { $true } } }
    }

    "findPptText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $results = @()
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $text = $shape.TextFrame.TextRange.Text
                        if ($text -and $text.Contains($p.text)) {
                            $results += @{ slideIndex = $i; shapeName = $shape.Name; text = $text }
                        }
                    }
                } catch {}
            }
        }
        Output-Json @{ success = $true; data = @{ searchText = $p.text; results = $results; count = $results.Count } }
    }

    "replacePptText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $count = 0
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $text = $shape.TextFrame.TextRange.Text
                        if ($text -and $text.Contains($p.findText)) {
                            $shape.TextFrame.TextRange.Text = $text.Replace($p.findText, $(if ($p.replaceText) { $p.replaceText } else { "" }))
                            $count++
                        }
                    }
                } catch {}
            }
        }
        Output-Json @{ success = $true; data = @{ findText = $p.findText; replaceText = $p.replaceText; count = $count } }
    }

    "startSlideShow" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $pres.SlideShowSettings.Run()
        Output-Json @{ success = $true }
    }

    "endSlideShow" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        if ($ppt.SlideShowWindows.Count -gt 0) { $ppt.SlideShowWindows.Item(1).View.Exit() }
        Output-Json @{ success = $true }
    }

    "unifyFont" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $fontName = if ($p.fontName) { $p.fontName } else { "微软雅黑" }
        $count = 0
        for ($i = 1; $i -le $pres.Slides.Count; $i++) {
            $slide = $pres.Slides.Item($i)
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $shape.TextFrame.TextRange.Font.Name = $fontName
                        $count++
                    }
                } catch {}
            }
        }
        Output-Json @{ success = $true; data = @{ fontName = $fontName; count = $count } }
    }

    "slide.beautify" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $schemes = @{
            business = @{ title = 0x2F5496; body = 0x333333 }
            tech = @{ title = 0x00B0F0; body = 0x404040 }
            creative = @{ title = 0xFF6B6B; body = 0x4A4A4A }
            minimal = @{ title = 0x000000; body = 0x666666 }
        }
        $schemeKey = if ($p.style -and $p.style.colorScheme) { $p.style.colorScheme } elseif ($p.style) { $p.style } else { "business" }
        $scheme = $schemes[$schemeKey]
        if ($null -eq $scheme) { $scheme = $schemes["business"] }
        $fontName = if ($p.style -and $p.style.font) { $p.style.font } else { $null }
        $slideIndex = $p.slideIndex
        $slides = @()
        if ($slideIndex -eq "all") {
            for ($i = 1; $i -le $pres.Slides.Count; $i++) { $slides += $pres.Slides.Item($i) }
        } else {
            $target = if ($slideIndex) { [int]$slideIndex } else { $pres.Windows.Item(1).Selection.SlideRange.SlideIndex }
            $slides += $pres.Slides.Item($target)
        }
        $ops = @(
            @{ operation = "unify_font"; count = 0 },
            @{ operation = "apply_color_scheme"; count = 0 },
            @{ operation = "align"; count = 0 },
            @{ operation = "optimize_spacing"; count = 0 }
        )
        foreach ($slide in $slides) {
            for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
                $shape = $slide.Shapes.Item($j)
                try {
                    if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                        $textRange = $shape.TextFrame.TextRange
                        if ($textRange.Font.Size -ge 24) { $textRange.Font.Color.RGB = $scheme.title }
                        else { $textRange.Font.Color.RGB = $scheme.body }
                        $ops[1].count++
                        if ($fontName) { $textRange.Font.Name = $fontName; $ops[0].count++ }
                    }
                } catch {}
            }
        }
        $slideIndexOut = if ($slideIndex -eq "all") { "all" } else { ($slides | Select-Object -First 1).SlideIndex }
        Output-Json @{ success = $true; data = @{ slideIndex = $slideIndexOut; operations = $ops } }
    }

    "set3DRotation" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { [int]$p.shapeIndex } else { 1 }))
        $rotX = if ($null -ne $p.rotationX) { [double]$p.rotationX } else { 0 }
        $rotY = if ($null -ne $p.rotationY) { [double]$p.rotationY } else { 0 }
        $rotZ = if ($null -ne $p.rotationZ) { [double]$p.rotationZ } else { 0 }
        if ($p.preset) {
            $presets = @{
                isometric   = @{ x = 45; y = 45; z = 0 }
                perspective = @{ x = 30; y = 30; z = 0 }
                oblique     = @{ x = 20; y = 60; z = 0 }
                tiltLeft    = @{ x = 0;  y = -30; z = 0 }
                tiltRight   = @{ x = 0;  y = 30; z = 0 }
            }
            $pr = $presets[$p.preset]
            if ($null -ne $pr) { $rotX = $pr.x; $rotY = $pr.y; $rotZ = $pr.z }
        }
        $shape.ThreeD.RotationX = $rotX
        $shape.ThreeD.RotationY = $rotY
        $shape.ThreeD.RotationZ = $rotZ
        Output-Json @{ success = $true; data = @{ shape = $shape.Name; rotationX = $rotX; rotationY = $rotY; rotationZ = $rotZ } }
    }

    "set3DDepth" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { [int]$p.shapeIndex } else { 1 }))
        $depth = if ($null -ne $p.depth) { [double]$p.depth } else { 20 }
        $shape.ThreeD.Depth = $depth
        if ($p.depthColor) {
            $dc = Convert-HexColorToRgbInt([string]$p.depthColor)
            if ($null -ne $dc) { $shape.ThreeD.ExtrusionColor.RGB = $dc }
        }
        if ($p.lighting) {
            $lightingMap = @{ bright = 1; normal = 2; dim = 3; flat = 4 }
            $lv = $lightingMap[$p.lighting]
            if ($null -ne $lv) { $shape.ThreeD.PresetLighting = $lv }
        }
        Output-Json @{ success = $true; data = @{ shape = $shape.Name; depth = $depth } }
    }

    "set3DMaterial" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $shape = $slide.Shapes.Item($(if ($p.shapeName) { $p.shapeName } elseif ($p.shapeIndex) { [int]$p.shapeIndex } else { 1 }))
        $material = if ($p.material) { $p.material } else { "plastic" }
        $materialMap = @{ matte = 1; plastic = 2; metal = 3; wireFrame = 4; glass = 5 }
        $mv = $materialMap[$material]
        if ($null -eq $mv) { $mv = 2 }
        $shape.ThreeD.PresetMaterial = $mv
        Output-Json @{ success = $true; data = @{ shape = $shape.Name; material = $material } }
    }

    "create3DText" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { [int]$p.slideIndex } else { 1 }
        $slide = $pres.Slides.Item($slideIndex)
        $text = if ($p.text) { $p.text } else { "3D文字" }
        $left = if ($null -ne $p.left) { $p.left } else { 200 }
        $top = if ($null -ne $p.top) { $p.top } else { 200 }
        $width = if ($null -ne $p.width) { $p.width } else { 300 }
        $height = if ($null -ne $p.height) { $p.height } else { 100 }
        $tb = $slide.Shapes.AddTextbox(1, $left, $top, $width, $height)
        $tb.TextFrame.TextRange.Text = $text
        $tb.TextFrame.TextRange.Font.Size = if ($p.fontSize) { $p.fontSize } else { 36 }
        $tb.TextFrame.TextRange.Font.Bold = $true
        if ($p.fontColor) {
            $fc = Convert-HexColorToRgbInt([string]$p.fontColor)
            if ($null -ne $fc) { $tb.TextFrame.TextRange.Font.Color.RGB = $fc }
        }
        $tb.ThreeD.Depth = if ($null -ne $p.depth) { $p.depth } else { 20 }
        $tb.ThreeD.RotationX = if ($null -ne $p.rotationX) { $p.rotationX } else { 30 }
        $tb.ThreeD.RotationY = if ($null -ne $p.rotationY) { $p.rotationY } else { 30 }
        $tb.ThreeD.PresetMaterial = 2
        Output-Json @{ success = $true; data = @{ shape = $tb.Name; text = $text } }
    }

    "beautifySlide" {
        $ppt = Get-WpsPpt
        if ($null -eq $ppt) { Output-Json @{ success = $false; error = "WPS PPT not running" }; exit }
        $pres = Get-WpsPptPresentation $ppt
        $slideIndex = if ($p.slideIndex) { $p.slideIndex } else { $pres.Windows.Item(1).Selection.SlideRange.SlideIndex }
        $slide = $pres.Slides.Item($slideIndex)
        $schemes = @{
            business = @{ title = 0x2F5496; body = 0x333333 }
            tech = @{ title = 0x00B0F0; body = 0x404040 }
            creative = @{ title = 0xFF6B6B; body = 0x4A4A4A }
            minimal = @{ title = 0x000000; body = 0x666666 }
        }
        $scheme = $schemes[$p.style]
        if ($null -eq $scheme) { $scheme = $schemes["business"] }
        $count = 0
        for ($j = 1; $j -le $slide.Shapes.Count; $j++) {
            $shape = $slide.Shapes.Item($j)
            try {
                if ($shape.HasTextFrame -and $shape.TextFrame.HasText) {
                    $textRange = $shape.TextFrame.TextRange
                    if ($textRange.Font.Size -ge 24) { $textRange.Font.Color.RGB = $scheme.title }
                    else { $textRange.Font.Color.RGB = $scheme.body }
                    $count++
                }
            } catch {}
        }
        Output-Json @{ success = $true; data = @{ style = $p.style; count = $count } }
    }

    default {
        Output-Json @{ success = $false; error = "Unknown action: $Action" }
    }
}
