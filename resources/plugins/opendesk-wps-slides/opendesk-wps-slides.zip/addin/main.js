/*
 * Input: WPS JS action values and caught runtime errors
 * Output: Existing WpsApiResponse-compatible result objects
 * Pos: Shared Phase 3 Addin response and serialized-state boundary
 */

var WpsJsBridgeResult = (function () {
    function sameState(left, right) {
        if (left === right) return true;
        if (!left || !right || typeof left !== 'object' || typeof right !== 'object') return false;
        if (Array.isArray(left) || Array.isArray(right)) {
            return Array.isArray(left) && Array.isArray(right) && left.length === right.length &&
                left.every(function (item, index) { return sameState(item, right[index]); });
        }
        var keys = Object.keys(left);
        return keys.length === Object.keys(right).length && keys.every(function (key) {
            return Object.prototype.hasOwnProperty.call(right, key) && sameState(left[key], right[key]);
        });
    }
    function errorText(error) {
        if (!error) return 'unknown_error';
        return String(error.message || error.description || error);
    }

    function success(data) {
        return { success: true, data: data };
    }

    function failure(code, message, data) {
        return {
            success: false,
            error: message || code,
            data: Object.assign({ reasonCode: code }, data || {})
        };
    }

    return { errorText: errorText, success: success, failure: failure, sameState: sameState };
})();


/*
 * Input: Active WPP application, Presentation, Slide and Shape objects
 * Output: Stable native identities and fail-closed presentation protection state
 * Pos: Identity and write-authorization helper for the Phase 3 Addin
 */

var WpsJsBridgeIdentity = (function () {
    var instanceId = null;
    var documents = [];
    var nextDocumentId = 0;
    var eventsRegistered = false;

    function nativeKey(presentation) {
        var name = safeRead(function () { return presentation.Name; }, null);
        if (!name) return null;
        return normalizedPath(fullPath(presentation) || String(name));
    }

    function bindInstance(id) {
        if (!eventsRegistered) {
            var events = safeRead(function () { return Application.ApiEvent; }, null);
            if (!events || typeof events.AddApiEventListener !== 'function' ||
                events.AddApiEventListener('PresentationClose', forgetPresentation) === false) {
                throw new Error('wps_js_presentation_lifecycle_events_unavailable');
            }
            eventsRegistered = true;
        }
        if (instanceId !== id) { documents = []; nextDocumentId = 0; }
        instanceId = id;
    }

    function documentEntry(presentation) {
        var key = nativeKey(presentation);
        if (!key) throw new Error('wps_js_presentation_identity_unavailable');
        // WPS returns a fresh JS wrapper on every access. The close event ends
        // the open identity; paths only match wrappers during that lifetime.
        var existing = documents.filter(function (entry) { return nativeKey(entry.presentation) === key; });
        if (existing.length) return existing[0];
        var entry = { presentation: presentation, id: 'document-' + (++nextDocumentId) };
        documents.push(entry);
        return entry;
    }

    function forgetPresentation(presentation, reference) {
        if (typeof reference === 'string' && reference.indexOf('wps-js:') === 0) {
            var parts = JSON.parse(decodeURIComponent(reference.slice(7)));
            documents = documents.filter(function (entry) { return entry.id !== parts[1]; });
            return;
        }
        var key = nativeKey(presentation);
        // Some WPS builds invalidate the closing object before notifying us.
        // Recapture is preferable to attaching an old ref to a reopened file.
        documents = key ? documents.filter(function (entry) {
            return entry.presentation !== presentation && nativeKey(entry.presentation) !== key;
        }) : [];
    }

    function scopedPresentation(reference) {
        if (typeof reference !== 'string' || reference.indexOf('wps-js:') !== 0) return null;
        var parts;
        try { parts = JSON.parse(decodeURIComponent(reference.slice(7))); } catch (_error) { return null; }
        if (!Array.isArray(parts) || parts.length !== 2 || parts[0] !== instanceId) return null;
        var matches = documents.filter(function (entry) { return entry.id === parts[1]; });
        if (matches.length !== 1) return null;
        var presentation = matches[0].presentation;
        var key = nativeKey(presentation);
        var current = [];
        for (var index = 1; index <= Application.Presentations.Count; index++) {
            var candidate = Application.Presentations.Item(index);
            if (key && nativeKey(candidate) === key) current.push(candidate);
        }
        if (current.length === 1) return current[0];
        forgetPresentation(presentation);
        return null;
    }
    function safeRead(read, fallback) {
        try {
            var value = read();
            return value === undefined ? fallback : value;
        } catch (_error) {
            return fallback;
        }
    }

    function nativeBoolean(value) {
        return value === null || value === undefined ? null : Number(value) !== 0;
    }

    function normalizedPath(value) {
        return String(value || '').replace(/\//g, '\\').replace(/[\\]+$/, '').toLowerCase();
    }

    function fullPath(presentation) {
        var name = String(safeRead(function () { return presentation.Name; }, '') || '');
        var value = String(safeRead(function () { return presentation.FullName; }, '') || '');
        return value && value !== name ? value : '';
    }

    function applicationIdentity() {
        return {
            name: safeRead(function () { return Application.Name; }, null),
            version: safeRead(function () { return Application.Version; }, null),
            build: safeRead(function () { return Application.Build; }, null),
            caption: safeRead(function () { return Application.Caption; }, null)
        };
    }

    function windowIdentity(presentation) {
        var window = safeRead(function () { return presentation.Windows.Item(1); }, null);
        if (!window) return null;
        return {
            caption: safeRead(function () { return window.Caption; },
                safeRead(function () { return Application.Caption; }, null)),
            hwnd: safeRead(function () { return window.HWND; }, null),
            presentationPath: fullPath(presentation),
            presentationName: safeRead(function () { return presentation.Name; }, null)
        };
    }

    function hostWindowIdentity(presentation) {
        return {
            appInstanceId: instanceId,
            pid: safeRead(function () { return Number(Application.Env.GetPID()); }, null),
            mainWindowCount: safeRead(function () { return Number(Application.MainWindows.Count); }, null),
            documentCount: Number(Application.Presentations.Count),
            hwnd: presentation ? safeRead(function () { return presentation.Windows.Item(1).HWND; }, null)
                : safeRead(function () { return Application.HWND; }, null),
            presentation: presentation ? presentationIdentity(presentation) : null
        };
    }

    function runtimeLocator(presentation) {
        if (instanceId) {
            return 'wps-js:' + encodeURIComponent(JSON.stringify([instanceId, documentEntry(presentation).id]));
        }
        var path = fullPath(presentation);
        if (path) return 'wps-path:' + path;
        var name = String(safeRead(function () { return presentation.Name; }, '') || '');
        var hwnd = safeRead(function () { return presentation.Windows.Item(1).HWND; }, null);
        return hwnd === null ? 'wps-name:' + name : 'wps-runtime::' + hwnd + ':' + name;
    }

    function isActivePresentation(presentation) {
        var active = safeRead(function () { return Application.ActivePresentation; }, null);
        if (!active || !presentation) return false;
        var activePath = fullPath(active);
        var candidatePath = fullPath(presentation);
        if (activePath || candidatePath) return normalizedPath(activePath) === normalizedPath(candidatePath);
        return String(safeRead(function () { return active.Name; }, '')) ===
            String(safeRead(function () { return presentation.Name; }, ''));
    }

    function classifyProtection(evidence) {
        var reasons = [];
        var protectedState = false;
        var unknown = false;
        if (evidence.readOnly === true) reasons.push('read_only');
        else if (evidence.readOnly === null) reasons.push('read_only_state_unavailable');
        if (evidence.final === true) {
            protectedState = true;
            reasons.push('final');
        } else if (evidence.final === null) {
            unknown = true;
            reasons.push('final_state_unavailable');
        }
        if (evidence.sandboxApplicable) {
            if (evidence.isSandboxed === true) {
                protectedState = true;
                reasons.push('protected_view');
            } else if (evidence.isSandboxed === null) {
                unknown = true;
                reasons.push('sandbox_state_unavailable');
            }
        }
        if (evidence.permissionEnabled === true) {
            protectedState = true;
            reasons.push('permission_enabled_unqualified');
        } else if (evidence.permissionEnabled === null) {
            unknown = true;
            reasons.push('permission_state_unavailable');
        }
        var protectMode = protectedState ? true : (unknown ? null : false);
        var blocked = reasons.some(function (reason) {
            return reason === 'read_only' || reason === 'final' ||
                reason === 'protected_view' || reason === 'permission_enabled_unqualified';
        });
        return {
            status: blocked ? 'blocked' :
                (evidence.readOnly === null || protectMode === null ? 'unknown' : 'writable'),
            readOnly: evidence.readOnly,
            protectMode: protectMode,
            reasons: reasons,
            evidence: evidence
        };
    }

    function protectionState(presentation) {
        var active = isActivePresentation(presentation);
        var permission = safeRead(function () { return presentation.Permission; }, null);
        return classifyProtection({
            readOnly: nativeBoolean(safeRead(function () { return presentation.ReadOnly; }, null)),
            final: nativeBoolean(safeRead(function () { return presentation.Final; }, null)),
            isSandboxed: active ?
                nativeBoolean(safeRead(function () { return Application.IsSandboxed; }, null)) : null,
            permissionEnabled: permission ?
                nativeBoolean(safeRead(function () { return permission.Enabled; }, null)) : null,
            sandboxApplicable: active
        });
    }

    function assertWritable(presentation) {
        var state = protectionState(presentation);
        if (state.status !== 'writable') {
            var error = new Error('presentation_write_blocked:' + state.status + ':' + state.reasons.join(','));
            error.code = 'presentation_write_blocked';
            error.protection = state;
            throw error;
        }
        return state;
    }

    function shapeId(shape) {
        return safeRead(function () { return shape.Id; },
            safeRead(function () { return shape.ID; }, null));
    }

    function slideId(slide) {
        return safeRead(function () { return slide.SlideID; },
            safeRead(function () { return slide.Id; }, null));
    }

    function presentationIdentity(presentation) {
        if (!presentation) return null;
        var protection = protectionState(presentation);
        var path = fullPath(presentation);
        return {
            name: safeRead(function () { return presentation.Name; }, null),
            path: path,
            fullPath: path,
            runtimeLocator: runtimeLocator(presentation),
            saved: nativeBoolean(safeRead(function () { return presentation.Saved; }, null)),
            readOnly: protection.readOnly,
            protectMode: protection.protectMode,
            active: isActivePresentation(presentation),
            slideCount: safeRead(function () { return presentation.Slides.Count; }, null),
            pageSize: {
                width: safeRead(function () { return presentation.PageSetup.SlideWidth; }, null),
                height: safeRead(function () { return presentation.PageSetup.SlideHeight; }, null)
            },
            application: {
                name: safeRead(function () { return Application.Name; }, null),
                version: safeRead(function () { return Application.Version; }, null),
                build: safeRead(function () { return Application.Build; }, null)
            },
            window: windowIdentity(presentation)
        };
    }

    function slideIdentity(slide) {
        return {
            slideIndex: safeRead(function () { return slide.SlideIndex; }, null),
            nativeSlideId: slideId(slide),
            layout: safeRead(function () { return slide.Layout; }, null)
        };
    }

    function matchesPresentationRef(presentation, reference) {
        if (!reference) return true;
        if (String(reference).indexOf('wps-js:') === 0) {
            var bound = scopedPresentation(reference);
            return Boolean(bound && nativeKey(bound) === nativeKey(presentation));
        }
        var identity = presentationIdentity(presentation);
        var candidates = [identity.runtimeLocator, identity.fullPath, identity.path, identity.name];
        return candidates.some(function (candidate) {
            if (!candidate) return false;
            if (/^(?:wps-path:)?[a-z]:[\\/]/i.test(String(reference))) {
                return normalizedPath(String(candidate).replace(/^wps-path:/i, '')) ===
                    normalizedPath(String(reference).replace(/^wps-path:/i, ''));
            }
            return String(candidate) === String(reference);
        });
    }

    function requireActivePresentation(reference) {
        var presentation = safeRead(function () { return Application.ActivePresentation; }, null);
        if (!presentation) throw new Error('wps_js_no_active_presentation');
        if (!matchesPresentationRef(presentation, reference)) {
            throw new Error('wps_js_presentation_binding_mismatch');
        }
        return presentation;
    }

    function findPresentation(reference) {
        if (!reference) return safeRead(function () { return Application.ActivePresentation; }, null);
        if (String(reference).indexOf('wps-js:') === 0) return scopedPresentation(reference);
        var matches = [];
        var count = safeRead(function () { return Application.Presentations.Count; }, 0);
        for (var index = 1; index <= count; index++) {
            var candidate = safeRead(function () {
                return Application.Presentations.Item(index);
            }, null);
            if (candidate && matchesPresentationRef(candidate, reference)) matches.push(candidate);
        }
        return matches.length === 1 ? matches[0] : null;
    }

    function requirePresentation(reference) {
        var presentation = findPresentation(reference);
        if (!presentation) throw new Error(reference ?
            'wps_js_presentation_binding_mismatch' : 'wps_js_no_active_presentation');
        return presentation;
    }

    function findPresentationByPath(filePath) {
        var target = normalizedPath(filePath);
        var count = safeRead(function () { return Application.Presentations.Count; }, 0);
        var found = null;
        for (var index = 1; index <= count; index++) {
            var candidate = Application.Presentations.Item(index);
            if (normalizedPath(fullPath(candidate)) === target) {
                if (found) throw new Error('wps_js_presentation_target_ambiguous');
                found = candidate;
            }
        }
        return found;
    }

    function requireSlide(presentation, index, nativeSlideId) {
        var slideIndex = Number(index || 0);
        var slide = null;
        if (nativeSlideId !== undefined && nativeSlideId !== null) {
            for (var candidateIndex = 1; candidateIndex <= presentation.Slides.Count; candidateIndex++) {
                var candidate = presentation.Slides.Item(candidateIndex);
                if (String(slideId(candidate)) === String(nativeSlideId)) {
                    slide = candidate;
                    slideIndex = candidateIndex;
                    break;
                }
            }
            if (!slide) throw new Error('wps_js_slide_not_found');
        }
        if (!slide) {
            slideIndex = Number(index || 1);
            if (!isFinite(slideIndex) || slideIndex < 1 || slideIndex > presentation.Slides.Count) {
                throw new Error('wps_js_slide_index_out_of_range');
            }
            slide = presentation.Slides.Item(slideIndex);
        }
        if (nativeSlideId !== undefined && nativeSlideId !== null &&
            String(slideId(slide)) !== String(nativeSlideId)) {
            throw new Error('wps_js_slide_identity_mismatch');
        }
        return slide;
    }

    function requireShape(slide, target) {
        target = target || {};
        var expectedId = target.nativeShapeId;
        var expectedIndex = target.shapeIndex;
        var expectedName = target.shapeName || target.expectedShapeName || target.name;
        if ((expectedId === undefined || expectedId === null) ||
            ((expectedIndex === undefined || expectedIndex === null) && !expectedName)) {
            throw new Error('wps_js_shape_identity_incomplete');
        }
        var match = null;
        var matchIndex = null;
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var candidate = slide.Shapes.Item(index);
            if (String(shapeId(candidate)) === String(expectedId)) {
                match = candidate;
                matchIndex = index;
                break;
            }
        }
        if (!match) throw new Error('wps_js_shape_not_found');
        if (expectedIndex !== undefined && expectedIndex !== null && Number(expectedIndex) !== matchIndex) {
            throw new Error('wps_js_shape_index_mismatch');
        }
        if (expectedName && String(match.Name) !== String(expectedName)) {
            throw new Error('wps_js_shape_name_mismatch');
        }
        return { shape: match, shapeIndex: matchIndex, nativeShapeId: shapeId(match) };
    }


    function findShapeInCollection(collection, nativeShapeId, parentPath) {
        var count = Number(safeRead(function () { return collection.Count; }, 0));
        for (var index = 1; index <= count; index++) {
            var candidate = collection.Item(index);
            var path = parentPath.concat([index]);
            if (String(shapeId(candidate)) === String(nativeShapeId)) {
                return { shape: candidate, shapeIndex: path[0],
                    nativeShapeId: shapeId(candidate),
                    groupPath: path.length > 1 ? path : [] };
            }
            var members = safeRead(function () { return candidate.GroupItems; }, null);
            if (members) {
                var nested = findShapeInCollection(members, nativeShapeId,
                    path);
                if (nested) return nested;
            }
        }
        return null;
    }

    function findShapeById(slide, nativeShapeId) {
        return findShapeInCollection(slide.Shapes, nativeShapeId, []);
    }

    function shapeAtGroupPath(slide, groupPath) {
        if (!Array.isArray(groupPath) || groupPath.length < 2) return null;
        var normalized = groupPath.map(Number);
        if (normalized.some(function (index) { return !isFinite(index) || index < 1; })) return null;
        var shape = safeRead(function () { return slide.Shapes.Item(normalized[0]); }, null);
        if (!shape) return null;
        for (var depth = 1; depth < groupPath.length; depth++) {
            var members = safeRead(function () { return shape.GroupItems; }, null);
            if (!members || normalized[depth] > Number(safeRead(function () {
                return members.Count;
            }, 0))) return null;
            shape = safeRead(function () { return members.Item(normalized[depth]); }, null);
            if (!shape) return null;
        }
        return { shape: shape, shapeIndex: normalized[0], groupPath: normalized };
    }

    function findTopLevelShapeById(slide, nativeShapeId) {
        var count = Number(safeRead(function () { return slide.Shapes.Count; }, 0));
        for (var index = 1; index <= count; index++) {
            var candidate = slide.Shapes.Item(index);
            if (String(shapeId(candidate)) === String(nativeShapeId)) {
                return { shape: candidate, shapeIndex: index,
                    nativeShapeId: shapeId(candidate), groupPath: [] };
            }
        }
        return null;
    }

    function requireFrozenShape(slide, target) {
        target = target || {};
        var normalized = target.target || target;
        var groupPath = Array.isArray(normalized.groupPath) ? normalized.groupPath : [];
        if (groupPath.length > 0) {
            var byPath = shapeAtGroupPath(slide, groupPath);
            if (!byPath) throw new Error('wps_js_group_member_binding_stale');
            var groupExpectedId = normalized.nativeShapeId;
            if (groupExpectedId !== undefined && groupExpectedId !== null &&
                String(shapeId(byPath.shape)) !== String(groupExpectedId)) {
                throw new Error('wps_js_group_member_binding_stale');
            }
            var groupExpectedName = normalized.expectedShapeName || normalized.shapeName || normalized.name;
            if (groupExpectedName && String(byPath.shape.Name) !== String(groupExpectedName)) {
                throw new Error('wps_js_group_member_binding_stale');
            }
            return { shape: byPath.shape, shapeIndex: byPath.shapeIndex,
                nativeShapeId: shapeId(byPath.shape), groupPath: byPath.groupPath };
        }
        var frozenName = normalized.expectedShapeName || normalized.shapeName || normalized.name;
        if ((normalized.nativeShapeId === undefined || normalized.nativeShapeId === null) ||
            ((normalized.shapeIndex === undefined || normalized.shapeIndex === null) && !frozenName)) {
            throw new Error('wps_js_shape_identity_incomplete');
        }
        if (normalized.nativeShapeId !== undefined && normalized.nativeShapeId !== null) {
            var resolvedById = findTopLevelShapeById(slide, normalized.nativeShapeId);
            if (!resolvedById ||
                String(shapeId(resolvedById.shape)) !== String(normalized.nativeShapeId)) {
                throw new Error('wps_js_shape_not_found');
            }
            var expectedName = frozenName;
            if (expectedName && String(resolvedById.shape.Name) !== String(expectedName)) {
                throw new Error('wps_js_shape_name_mismatch');
            }
            return { shape: resolvedById.shape, shapeIndex: resolvedById.shapeIndex,
                nativeShapeId: shapeId(resolvedById.shape),
                groupPath: resolvedById.groupPath || [] };
        }
        var fallback = normalized.shapeIndexFallback || normalized.shapeIndex ||
            normalized.textboxIndex || normalized.textBoxIndex || normalized.index;
        var name = normalized.expectedShapeName || normalized.shapeName || normalized.name;
        if (fallback === undefined && !name) throw new Error('wps_js_shape_identity_incomplete');
        var shape = null;
        var shapeIndex = null;
        if (name) {
            for (var index = 1; index <= slide.Shapes.Count; index++) {
                var candidate = slide.Shapes.Item(index);
                if (String(candidate.Name) === String(name)) {
                    if (shape) throw new Error('wps_js_shape_name_ambiguous');
                    shape = candidate;
                    shapeIndex = index;
                }
            }
        }
        if (!shape && fallback !== undefined) {
            shapeIndex = Number(fallback);
            if (!isFinite(shapeIndex) || shapeIndex < 1 || shapeIndex > slide.Shapes.Count) {
                throw new Error('wps_js_shape_index_out_of_range');
            }
            shape = slide.Shapes.Item(shapeIndex);
        }
        if (!shape) throw new Error('wps_js_shape_not_found');
        if (name && String(shape.Name) !== String(name)) throw new Error('wps_js_shape_name_mismatch');
        return { shape: shape, shapeIndex: shapeIndex, nativeShapeId: shapeId(shape), groupPath: [] };
    }

    return {
        bindInstance: bindInstance,
        forgetPresentation: forgetPresentation,
        safeRead: safeRead,
        nativeBoolean: nativeBoolean,
        normalizedPath: normalizedPath,
        fullPath: fullPath,
        runtimeLocator: runtimeLocator,
        applicationIdentity: applicationIdentity,
        windowIdentity: windowIdentity,
        hostWindowIdentity: hostWindowIdentity,
        shapeId: shapeId,
        slideId: slideId,
        protectionState: protectionState,
        assertWritable: assertWritable,
        presentationIdentity: presentationIdentity,
        slideIdentity: slideIdentity,
        matchesPresentationRef: matchesPresentationRef,
        findPresentation: findPresentation,
        findPresentationByPath: findPresentationByPath,
        requirePresentation: requirePresentation,
        requireActivePresentation: requireActivePresentation,
        requireSlide: requireSlide,
        requireShape: requireShape,
        findShapeById: findShapeById,
        shapeAtGroupPath: shapeAtGroupPath,
        requireFrozenShape: requireFrozenShape
    };
})();


/*
 * Input: Canonical managePptPresentation lifecycle requests
 * Output: Existing presentation identity and lifecycle result contract
 * Pos: WPS JS implementation of the native presentation lifecycle boundary
 */

var WpsJsBridgeLifecycle = (function () {
    var Identity = WpsJsBridgeIdentity;
    var Result = WpsJsBridgeResult;
    var ACTIONS = [
        'list', 'create', 'open', 'save', 'save_as', 'close', 'switch',
        'active_presentation_identity', 'find_open_presentation_by_path',
        'window_identity', 'activate_window'
    ];

    function failure(code, message, details) {
        return Result.failure(code, message, Object.assign({ wroteToWps: false }, details || {}));
    }

    function activate(presentation) {
        try { presentation.Windows.Item(1).Activate(); } catch (error) {
            var failure = new Error('wps_js_presentation_activate_failed:' + Result.errorText(error));
            failure.code = 'wps_js_presentation_activate_failed';
            throw failure;
        }
    }

    function createdIdentity(presentation) {
        var activation = { status: 'activated' };
        try { activate(presentation); } catch (error) {
            activation = { status: 'failed', reasonCode: error.code, error: Result.errorText(error) };
        }
        var identity = Identity.presentationIdentity(presentation);
        if (!identity || !identity.runtimeLocator) throw new Error('presentation_identity_incomplete');
        Identity.requirePresentation(identity.runtimeLocator);
        identity.activation = activation;
        return Result.success(identity);
    }

    function list() {
        var presentations = [];
        for (var index = 1; index <= Application.Presentations.Count; index++) {
            presentations.push(Identity.presentationIdentity(Application.Presentations.Item(index)));
        }
        return Result.success({ presentations: presentations, count: presentations.length });
    }

    function uncertain(error) {
        return failure('native_write_uncertain', Result.errorText(error), {
            wroteToWps: true, state: 'indeterminate', recoveryRequired: true,
            retryable: false, retryableInCurrentTurn: false,
            guidance: 'The presentation or file may have changed. Do not retry writes in this turn. Report the uncertain state and require explicit recovery.'
        });
    }

    function verifyClosed(presentation, closed) {
        var rawCount = Application.Presentations.Count;
        var count = Number(rawCount);
        if (rawCount === null || rawCount === undefined || !isFinite(count) || count < 0 || Math.floor(count) !== count) {
            throw new Error('PPT_PRESENTATION_CLOSE_READBACK_UNAVAILABLE');
        }
        for (var index = 1; index <= count; index++) {
            var current = Identity.presentationIdentity(Application.Presentations.Item(index));
            if (!current || !current.name) throw new Error('PPT_PRESENTATION_CLOSE_READBACK_UNAVAILABLE');
            // Close events can retire the locator before the native collection changes.
            if (current.runtimeLocator === closed.runtimeLocator ||
                (current.name === closed.name && Identity.normalizedPath(current.fullPath) ===
                    Identity.normalizedPath(closed.fullPath))) {
                throw new Error('PPT_PRESENTATION_CLOSE_NOT_APPLIED');
            }
        }
        Identity.forgetPresentation(presentation, closed.runtimeLocator);
        return Result.success({ closed: true, name: closed.name, fullPath: closed.fullPath,
            remainingPresentationCount: count });
    }

    function finishClose(presentation, closed) {
        try { return verifyClosed(presentation, closed); } catch (_pending) {
            // Yield only on conflicting readback. Never repeat the native Close call.
            return new Promise(function (resolve) {
                var attempts = 0;
                function check() {
                    try { resolve(verifyClosed(presentation, closed)); } catch (error) {
                        if (++attempts >= 5) { resolve(uncertain(error)); return; }
                        setTimeout(check, 100);
                    }
                }
                setTimeout(check, 100);
            });
        }
    }

    function execute(params, expectedPresentationRef) {
        params = params || {};
        var action = String(params.lifecycleAction || '');
        var mutationAttempted = false;
        if (ACTIONS.indexOf(action) < 0) {
            return failure('PPT_INVALID_LIFECYCLE_ACTION', 'Unsupported PPT lifecycle action.', {
                lifecycleAction: action
            });
        }
        try {
            if (action === 'list') return list();
            if (action === 'window_identity' || action === 'activate_window') {
                var windowRef = expectedPresentationRef || params.presentationId;
                var target = windowRef ? Identity.requirePresentation(windowRef) :
                    Identity.safeRead(function () { return Application.ActivePresentation; }, null);
                if (action === 'activate_window') {
                    if (target) activate(target);
                    else Application.Activate();
                }
                return Result.success(Identity.hostWindowIdentity(target));
            }
            if (action === 'active_presentation_identity') {
                var active = Identity.safeRead(function () { return Application.ActivePresentation; }, null);
                return Result.success({ presentation: Identity.presentationIdentity(active) });
            }
            if (action === 'find_open_presentation_by_path') {
                if (!params.filePath || !/^(?:[a-z]:[\\/]|\\\\|\/)/i.test(String(params.filePath))) {
                    return failure('PPT_FILE_PATH_REQUIRED',
                        'find_open_presentation_by_path requires an absolute filePath.');
                }
                return Result.success({
                    presentation: Identity.presentationIdentity(
                        Identity.findPresentationByPath(params.filePath)
                    )
                });
            }
            if (action === 'create') {
                mutationAttempted = true;
                var created = Application.Presentations.Add();
                if (!created) throw new Error('PPT_PRESENTATION_CREATE_FAILED');
                return createdIdentity(created);
            }
            if (action === 'open') {
                if (!String(params.filePath || '').trim()) {
                    return failure('PPT_FILE_PATH_REQUIRED', 'open requires filePath.');
                }
                var opened;
                try {
                    opened = Identity.findPresentationByPath(params.filePath);
                    if (!opened) {
                        mutationAttempted = true;
                        opened = Application.Presentations.Open(
                            String(params.filePath), Boolean(params.readOnly), false, true
                        );
                    }
                } catch (openError) {
                    throw openError;
                }
                return createdIdentity(opened);
            }

            var reference = expectedPresentationRef || params.presentationId ||
                params.presentationRef || params.runtimeLocator;
            var presentation = Identity.requirePresentation(reference);
            if (action === 'switch') {
                activate(presentation);
                return Result.success(Identity.presentationIdentity(presentation));
            }
            if (action === 'save') {
                Identity.assertWritable(presentation);
                if (!Identity.fullPath(presentation)) {
                    return failure('PPT_SAVE_AS_REQUIRED',
                        'This presentation has no file path. Use save_as with an explicit filePath.', {
                            retryable: true
                        });
                }
                Identity.assertWritable(presentation);
                mutationAttempted = true;
                presentation.Save();
                return Result.success(Identity.presentationIdentity(presentation));
            }
            if (action === 'save_as') {
                if (!String(params.filePath || '').trim()) {
                    return failure('PPT_FILE_PATH_REQUIRED', 'save_as requires filePath.');
                }
                Identity.assertWritable(presentation);
                mutationAttempted = true;
                presentation.SaveAs(String(params.filePath));
                if (Identity.normalizedPath(Identity.fullPath(presentation)) !==
                    Identity.normalizedPath(params.filePath)) {
                    throw new Error('wps_js_save_as_readback_mismatch');
                }
                return Result.success(Identity.presentationIdentity(presentation));
            }
            if (action === 'close') {
                var saved = Identity.nativeBoolean(Identity.safeRead(function () {
                    return presentation.Saved;
                }, null));
                if (saved !== true && params.discardChanges !== true) {
                    return failure('PPT_UNSAVED_CLOSE_REQUIRES_DECISION',
                        'close requires discardChanges=true when the presentation has unsaved changes.', {
                            retryable: true
                        });
                }
                if (params.discardChanges === true) {
                    mutationAttempted = true;
                    try { presentation.Saved = true; } catch (_savedError) {}
                }
                var closed = Identity.presentationIdentity(presentation);
                mutationAttempted = true;
                presentation.Close();
                return finishClose(presentation, closed);
            }
        } catch (error) {
            if (mutationAttempted) {
                return uncertain(error);
            }
            return failure(error.code || 'wps_js_presentation_lifecycle_failed',
                Result.errorText(error), { protection: error.protection || null });
        }
        return failure('PPT_INVALID_LIFECYCLE_ACTION');
    }

    return { execute: execute };
})();


/* Native drawing enums and requested-style readback, shared by capture and execution. */
var WpsJsBridgeDrawing = (function () {
    var dashValues = { solid: 1, square_dot: 2, round_dot: 3, dash: 4,
        dash_dot: 5, dash_dot_dot: 6, long_dash: 7, long_dash_dot: 8 };
    var shapeValues = { rectangle: 1, roundedRectangle: 5, oval: 9, triangle: 7,
        diamond: 4, pentagon: 12, hexagon: 10, arrow: 33, rightArrow: 33,
        leftArrow: 34, upArrow: 35, downArrow: 36, star: 92, heart: 21, cloud: 179,
        cylinder: 13, trapezoid: 3, parallelogram: 2, leftBracket: 29, rightBracket: 30,
        leftBrace: 31, rightBrace: 32, bracketPair: 26, bracePair: 27,
        cube: 14, bevel: 15, donut: 18, octagon: 6, chevron: 52, plus: 11, flowchartProcess: 61, flowchartDecision: 63 };
    var dashNames = {};
    var shapeNames = {};
    var lineEnums = {
        compoundStyle: { single: 1, thin_thin: 2, thin_thick: 3, thick_thin: 4, thick_between_thin: 5 },
        pattern: { percent_5: 1, percent_10: 2, percent_20: 3, percent_25: 4, percent_30: 5,
            percent_40: 6, percent_50: 7, percent_60: 8, percent_70: 9, percent_75: 10, percent_80: 11, percent_90: 12 },
        beginArrowWidth: { narrow: 1, medium: 2, wide: 3 }, endArrowWidth: { narrow: 1, medium: 2, wide: 3 },
        beginArrowLength: { short: 1, medium: 2, long: 3 }, endArrowLength: { short: 1, medium: 2, long: 3 }
    };
    var lineProperties = { compoundStyle: 'Style', pattern: 'Pattern', beginArrowWidth: 'BeginArrowheadWidth',
        endArrowWidth: 'EndArrowheadWidth', beginArrowLength: 'BeginArrowheadLength', endArrowLength: 'EndArrowheadLength' };
    Object.keys(dashValues).forEach(function (name) { dashNames[dashValues[name]] = name; });
    Object.keys(shapeValues).forEach(function (name) { shapeNames[shapeValues[name]] = name; });

    function setDash(shape, name) {
        if (!Object.prototype.hasOwnProperty.call(dashValues, name)) throw new Error('wps_js_invalid_line_dash');
        shape.Line.DashStyle = dashValues[name];
    }

    function reversibleGeometry(shape) {
        return Number(shape.Type) === 1 && [1, 9, 4, 21, 179, 61, 63].indexOf(Number(shape.AutoShapeType)) >= 0;
    }

    function assertGeometryChange(slide, shape, preset) {
        if (!reversibleGeometry(shape) || !Object.prototype.hasOwnProperty.call(shapeValues, preset)) {
            throw new Error('capability_unavailable:shape_geometry_snapshot_not_reversible');
        }
        function visit(collection) {
            for (var i = 1; i <= collection.Count; i++) {
                var other = collection.Item(i);
                if (Number(other.Type) === 6) visit(other.GroupItems);
                if (WpsJsBridgeIdentity.nativeBoolean(WpsJsBridgeIdentity.safeRead(function () { return other.Connector; }, false))) {
                    var format = other.ConnectorFormat;
                    if ((format.BeginConnected && Number(format.BeginConnectedShape.Id) === Number(shape.Id)) ||
                        (format.EndConnected && Number(format.EndConnectedShape.Id) === Number(shape.Id))) {
                        throw new Error('capability_unavailable:connected_shape_geometry');
                    }
                }
            }
        }
        visit(slide.Shapes);
    }

    function setGeometry(shape, preset) {
        var value = shapeValues[preset], name = String(shape.Name);
        if (value === undefined) throw new Error('wps_js_invalid_shape_geometry');
        if (Number(shape.AutoShapeType) !== value) shape.AutoShapeType = value;
        if (String(shape.Name) !== name) shape.Name = name;
        if (Number(shape.AutoShapeType) !== value) throw new Error('wps_js_shape_geometry_write_mismatch');
        return ['autoShapeType'];
    }

    function advancedLine(shape) {
        var result = {};
        Object.keys(lineEnums).forEach(function (field) {
            var native = WpsJsBridgeIdentity.safeRead(function () { return shape.Line[lineProperties[field]]; }, null);
            var names = Object.keys(lineEnums[field]);
            result[field] = names.filter(function (name) { return native === lineEnums[field][name]; })[0] || null;
        });
        return result;
    }

    function setAdvancedLine(shape, style) {
        var applied = [];
        Object.keys(lineEnums).forEach(function (field) {
            if (style[field] === undefined) return;
            if (!Object.prototype.hasOwnProperty.call(lineEnums[field], style[field])) throw new Error('wps_js_invalid_line_' + field);
            shape.Line[lineProperties[field]] = lineEnums[field][style[field]];
            applied.push(field);
        });
        return applied;
    }

    function restoreAdvancedLine(shape, state) {
        if (!state) return;
        var actual = advancedLine(shape), changes = {};
        Object.keys(lineEnums).forEach(function (field) {
            if (state[field] === undefined || actual[field] === state[field]) return;
            if (state[field] === null) throw new Error('wps_js_line_restore_unavailable:' + field);
            changes[field] = state[field];
        });
        setAdvancedLine(shape, changes);
    }

    function hex(value) {
        value = Number(value);
        return '#' + [value & 255, (value >> 8) & 255, (value >> 16) & 255].map(function (part) {
            return ('0' + part.toString(16)).slice(-2);
        }).join('').toUpperCase();
    }

    function creationEvidence(shape, action) {
        if (action.requiredDrawingContractVersion !== 1) return null;
        var facets = action.facets || {};
        var isConnector = action.kind === 'connector';
        var expected = isConnector ? facets.connector : (facets.shape || {}).style;
        var result = { version: 1, style: {} };
        if (action.kind === 'auto_shape') {
            result.autoShapeType = Number(shape.AutoShapeType);
            if (result.autoShapeType !== shapeValues[(facets.shape || {}).geometry]) {
                throw new Error('wps_js_creation_geometry_mismatch');
            }
        }
        var getters = {
            fillColor: function () { if (Number(shape.Fill.Visible) === 0) throw new Error('wps_js_creation_fill_not_visible'); return hex(shape.Fill.ForeColor.RGB); },
            lineColor: function () { return hex(shape.Line.ForeColor.RGB); },
            lineWidth: function () { return Number(shape.Line.Weight); },
            lineTransparency: function () { return Number(shape.Line.Transparency); },
            transparency: function () { return Number(isConnector ? shape.Line.Transparency : shape.Fill.Transparency); },
            lineDashStyle: function () { return dashNames[Number(shape.Line.DashStyle)]; },
            beginArrow: function () { return Number(shape.Line.BeginArrowheadStyle); },
            endArrow: function () { return Number(shape.Line.EndArrowheadStyle); }
        };
        var arrows = { none: 1, triangle: 2, open: 3, stealth: 4, diamond: 5, oval: 6 };
        Object.keys(lineEnums).forEach(function (field) {
            getters[field] = function () { return advancedLine(shape)[field]; };
        });
        ['fill', 'effects'].forEach(function (field) {
            getters[field] = function () { return WpsJsBridgeEffects.creationEvidence(shape, expected)[field]; };
        });
        function matches(actual, wanted) {
            if (wanted && typeof wanted === 'object') return actual && Object.keys(actual).length === Object.keys(wanted).length &&
                Object.keys(wanted).every(function (key) { return matches(actual[key], wanted[key]); });
            if (typeof wanted === 'number') return typeof actual === 'number' && isFinite(actual) && Math.abs(actual - wanted) <= 0.01;
            return actual === (typeof wanted === 'string' && /^#[a-f0-9]{6}$/i.test(wanted) ? wanted.toUpperCase() : wanted);
        }
        Object.keys(expected || {}).forEach(function (field) {
            if (!getters[field]) return;
            var actual = getters[field]();
            var wanted = expected[field];
            if (field === 'beginArrow' || field === 'endArrow') wanted = arrows[wanted];
            else if (field === 'fillColor' || field === 'lineColor') wanted = String(wanted).toUpperCase();
            else if (field === 'fill' && (wanted.kind === 'picture' || wanted.kind === 'texture')) wanted = {
                kind: wanted.kind, textureName: String(wanted.localPath || '').replace(/\\/g, '/').split('/').pop().replace(/\.[^.]+$/, '')
            };
            if (!matches(actual, wanted)) {
                throw new Error('wps_js_creation_style_mismatch:' + field);
            }
            result.style[field] = actual;
        });
        return result;
    }

    return { dashValues: dashValues, dashNames: dashNames, shapeValues: shapeValues,
        reversibleGeometry: reversibleGeometry, assertGeometryChange: assertGeometryChange, setGeometry: setGeometry,
        patternName: function (value) { return Object.keys(lineEnums.pattern).filter(function (key) { return lineEnums.pattern[key] === value; })[0] || null; },
        patternValue: function (name) { if (!Object.prototype.hasOwnProperty.call(lineEnums.pattern, name)) throw new Error('wps_js_invalid_fill_pattern'); return lineEnums.pattern[name]; },
        shapeNames: shapeNames, setDash: setDash, creationEvidence: creationEvidence,
        advancedLine: advancedLine, setAdvancedLine: setAdvancedLine, restoreAdvancedLine: restoreAdvancedLine };
})();


/* Qualified TextRange2/ParagraphFormat2 properties, shared by cells and ordinary text. */
var WpsJsBridgeText = (function () {
    var Identity = WpsJsBridgeIdentity;
    var cases = { normal: 0, small_caps: 1, all_caps: 2 };
    var directions = { left_to_right: 1, right_to_left: 2 };
    var orientations = { horizontal: 1, upward: 2, downward: 3, vertical_east_asian: 4,
        vertical: 5, horizontal_rotated_east_asian: 6 };
    var tabs = { left: 1, center: 2, right: 3, decimal: 4 };
    function read(fn) { return Identity.safeRead(fn, null); }
    function name(value, mapping) {
        return Object.keys(mapping).filter(function (key) { return mapping[key] === value; })[0] || null;
    }
    function runExtras(run, run2, includeScriptFonts) {
        var extras = { languageId: read(function () { return run.LanguageID; }),
            case: name(read(function () { return run2.Font.Caps; }), cases),
            fontNameEastAsia: read(function () { return run.Font.NameFarEast; }) };
        if (includeScriptFonts) {
            extras.fontNameLatin = read(function () { return run.Font.NameAscii; });
            extras.fontNameComplexScript = read(function () { return run.Font.NameComplexScript; });
        }
        return extras;
    }
    function tabStops(format2) {
        return read(function () {
            var collection = format2.TabStops, result = [], count = collection.Count;
            if (count === null || count === undefined) return null;
            for (var i = 1; i <= count; i++) {
                var stop = collection.Item(i), type = name(stop.Type, tabs), position = stop.Position;
                if (!type || typeof position !== 'number') return null;
                result.push({ type: type, position: position });
            }
            return result;
        });
    }
    function paragraphExtras(format2) {
        return { leftIndent: read(function () { return format2.LeftIndent; }),
            rightIndent: read(function () { return format2.RightIndent; }),
            firstLineIndent: read(function () { return format2.FirstLineIndent; }),
            textDirection: name(read(function () { return format2.TextDirection; }), directions),
            tabStops: tabStops(format2) };
    }
    function orientation(frame) { return name(read(function () { return frame.Orientation; }), orientations); }
    function setRun(run, run2, style) {
        var applied = [];
        if (style.languageId !== undefined) { run.LanguageID = style.languageId; applied.push('languageId'); }
        if (style.fontNameEastAsia !== undefined) { run.Font.NameFarEast = style.fontNameEastAsia; applied.push('fontNameEastAsia'); }
        if (style.fontNameLatin !== undefined) { run.Font.NameAscii = style.fontNameLatin; applied.push('fontNameLatin'); }
        if (style.fontNameComplexScript !== undefined) { run.Font.NameComplexScript = style.fontNameComplexScript; applied.push('fontNameComplexScript'); }
        if (style.case !== undefined) {
            if (!Object.prototype.hasOwnProperty.call(cases, style.case)) throw new Error('wps_js_invalid_text_case');
            run2.Font.Caps = cases[style.case]; applied.push('case');
        }
        return applied;
    }
    function setParagraph(format2, style) {
        var applied = [];
        ['leftIndent', 'rightIndent', 'firstLineIndent'].forEach(function (field) {
            if (style[field] === undefined) return;
            format2[field.charAt(0).toUpperCase() + field.slice(1)] = style[field]; applied.push(field);
        });
        if (style.textDirection !== undefined) {
            if (!Object.prototype.hasOwnProperty.call(directions, style.textDirection)) throw new Error('wps_js_invalid_text_direction');
            format2.TextDirection = directions[style.textDirection]; applied.push('textDirection');
        }
        if (style.tabStops !== undefined) {
            var collection = format2.TabStops;
            for (var i = collection.Count; i >= 1; i--) collection.Item(i).Clear();
            style.tabStops.forEach(function (stop) {
                if (!Object.prototype.hasOwnProperty.call(tabs, stop.type)) throw new Error('wps_js_invalid_tab_type');
                collection.Add(tabs[stop.type], stop.position);
            });
            applied.push('tabStops');
        }
        return applied;
    }
    function setOrientation(frame, value) {
        if (!Object.prototype.hasOwnProperty.call(orientations, value)) throw new Error('wps_js_invalid_text_orientation');
        frame.Orientation = orientations[value];
    }
    function differences(expected, actual) {
        var changes = {};
        Object.keys(expected || {}).forEach(function (field) {
            if (WpsJsBridgeResult.sameState(expected[field], actual[field])) return;
            if (expected[field] === null) throw new Error('wps_js_text_restore_unavailable:' + field);
            changes[field] = expected[field];
        });
        return changes;
    }
    function coalesceRuns(runs) {
        var result = [];
        (runs || []).forEach(function (run) {
            var current = Object.assign({}, run), previous = result[result.length - 1];
            var style = function (value) {
                var fields = Object.assign({}, value); delete fields.start; delete fields.length; return fields;
            };
            if (previous && previous.length > 0 && current.length > 0 && previous.start + previous.length === current.start &&
                WpsJsBridgeResult.sameState(style(previous), style(current))) previous.length += current.length;
            else result.push(current);
        });
        return result;
    }
    function replacementState(state, start, length, inserted) {
        var original = String(state.text).replace(/\r$/, ''), end = start + length;
        if (start < 1 || length < 1 || end - 1 > original.length) throw new Error('wps_js_text_range_out_of_bounds');
        var result = JSON.parse(JSON.stringify(state)), delta = inserted.length - length, runs = [];
        function add(run, from, to, destination) {
            if (to > from) runs.push(Object.assign({}, run, { start: destination, length: to - from }));
        }
        state.runs.forEach(function (run) {
            var a = run.start, b = a + run.length;
            add(run, a, Math.min(b, start), a);
            if (a <= start && b > start && inserted.length) runs.push(Object.assign({}, run, { start: start, length: inserted.length }));
            add(run, Math.max(a, end), b, Math.max(a, end) + delta);
        });
        result.runs = runs.sort(function (a, b) { return a.start - b.start; });
        var beforeCount = original.slice(0, start - 1).split(/\r\n|\r|\n/).length - 1;
        var removedCount = original.slice(start - 1, end - 1).split(/\r\n|\r|\n/).length - 1;
        var addedCount = inserted.split(/\r\n|\r|\n/).length - 1;
        var paragraphs = state.paragraphs.slice(0, beforeCount);
        for (var i = 0; i <= addedCount; i++) paragraphs.push(state.paragraphs[beforeCount]);
        result.paragraphs = paragraphs.concat(state.paragraphs.slice(beforeCount + removedCount + 1))
            .map(function (p, index) { return Object.assign({}, p, { index: index + 1 }); });
        result.text = original.slice(0, start - 1) + inserted + original.slice(end - 1);
        return result;
    }
    return { runExtras: runExtras, paragraphExtras: paragraphExtras, orientation: orientation,
        setRun: setRun, setParagraph: setParagraph, setOrientation: setOrientation, differences: differences,
        replacementState: replacementState, coalesceRuns: coalesceRuns };
})();


/* Native fill ownership and effect state; mutations use the qualified subset only. */
var WpsJsBridgeEffects = (function () {
    function read(fn) { return WpsJsBridgeIdentity.safeRead(fn, null); }
    function hex(value) { return WpsJsBridgeCapture.rgbHex(value); }
    function color(format) {
        return { rgb: read(function () { return format.RGB; }), type: read(function () { return format.Type; }),
            theme: read(function () { return format.ObjectThemeColor; }), tint: read(function () { return format.TintAndShade; }) };
    }
    function restoreColor(format, state) {
        if (WpsJsBridgeResult.sameState(color(format), state)) return;
        if (state.type === 2 && state.theme > 0) format.ObjectThemeColor = state.theme;
        else if (state.type === 1 && state.rgb !== null) format.RGB = state.rgb;
        else throw new Error('wps_js_fill_color_source_not_reversible');
        if (state.tint !== null && format.TintAndShade !== state.tint) format.TintAndShade = state.tint;
    }
    function fill(shape) {
        return { type: read(function () { return shape.Fill.Type; }),
            pattern: read(function () { return shape.Fill.Pattern; }),
            foreground: color(read(function () { return shape.Fill.ForeColor; })),
            background: color(read(function () { return shape.Fill.BackColor; })),
            transparency: read(function () { return shape.Fill.Transparency; }),
            textureName: read(function () { return shape.Fill.Type === 6 || shape.Fill.Type === 4 ? shape.Fill.TextureName : null; }),
            visible: read(function () { return shape.Fill.Visible; }) };
    }
    function fillProjection(shape) {
        var state = fill(shape);
        return { kind: state.type === 1 ? 'solid' : state.type === 2 ? 'pattern' : state.type === 3 ? 'gradient' :
            state.type === 4 ? 'texture' : state.type === 6 ? 'picture' : 'unknown',
            pattern: WpsJsBridgeDrawing.patternName(state.pattern),
            textureName: state.textureName,
            foregroundSource: state.foreground, backgroundSource: state.background,
            backgroundColorHex: read(function () { return hex(state.background.rgb); }) };
    }
    function restoreFill(shape, state) {
        if (WpsJsBridgeResult.sameState(fill(shape), state)) return;
        if (state.type === 1) {
            if (!WpsJsBridgeResult.sameState(color(shape.Fill.BackColor), state.background)) {
                if (shape.Fill.Type !== 2) shape.Fill.Patterned(1);
                restoreColor(shape.Fill.BackColor, state.background);
            }
            shape.Fill.Solid();
        }
        else if (state.type === 2 && state.pattern > 0) shape.Fill.Patterned(state.pattern);
        else throw new Error('wps_js_fill_snapshot_not_reversible');
        restoreColor(shape.Fill.ForeColor, state.foreground);
        restoreColor(shape.Fill.BackColor, state.background);
        if (state.transparency !== null) shape.Fill.Transparency = state.transparency;
        if (state.visible !== null) shape.Fill.Visible = state.visible;
    }
    function creationEvidence(shape, style) {
        var result = {};
        if (style.fill) {
            var fillState = fillProjection(shape);
            result.fill = { kind: fillState.kind, color: hex(shape.Fill.ForeColor.RGB) };
            if (style.fill.kind === 'picture' || style.fill.kind === 'texture') result.fill = { kind: fillState.kind, textureName: fillState.textureName };
            if (style.fill.pattern !== undefined) result.fill.pattern = fillState.pattern;
            if (style.fill.backgroundColor !== undefined) result.fill.backgroundColor = hex(shape.Fill.BackColor.RGB);
            if (style.fill.transparency !== undefined) result.fill.transparency = shape.Fill.Transparency;
        }
        if (style.effects) {
            var current = effects(shape); result.effects = {};
            Object.keys(style.effects).forEach(function (kind) {
                result.effects[kind] = {};
                Object.keys(style.effects[kind]).forEach(function (field) {
                    result.effects[kind][field] = field === 'color' ? hex(current[kind].color.rgb) :
                        field === 'preset' ? current[kind].type === 0 ? 'none' : 'preset_' + current[kind].type :
                        field === 'material' || field === 'lighting' ? 'preset_' + current[kind][field] : current[kind][field];
                });
            });
        }
        return result;
    }
    function effects(shape) {
        return { shadow: { visible: read(function () { return shape.Shadow.Visible; }), type: read(function () { return shape.Shadow.Type; }),
                style: read(function () { return shape.Shadow.Style; }), blur: read(function () { return shape.Shadow.Blur; }),
                offsetX: read(function () { return shape.Shadow.OffsetX; }), offsetY: read(function () { return shape.Shadow.OffsetY; }),
                transparency: read(function () { return shape.Shadow.Transparency; }), rotateWithShape: read(function () { return shape.Shadow.RotateWithShape; }),
                size: read(function () { return shape.Shadow.Size; }), color: color(read(function () { return shape.Shadow.ForeColor; })) },
            softEdge: { radius: read(function () { return shape.SoftEdge.Radius; }), type: read(function () { return shape.SoftEdge.Type; }) },
            glow: { radius: read(function () { return shape.Glow.Radius; }), transparency: read(function () { return shape.Glow.Transparency; }),
                color: color(read(function () { return shape.Glow.Color; })) },
            reflection: { type: read(function () { return shape.Reflection.Type; }), blur: read(function () { return shape.Reflection.Blur; }),
                size: read(function () { return shape.Reflection.Size; }), offset: read(function () { return shape.Reflection.Offset; }),
                transparency: read(function () { return shape.Reflection.Transparency; }) },
            threeD: { visible: read(function () { return shape.ThreeD.Visible; }), depth: read(function () { return shape.ThreeD.Depth; }),
                rotationX: read(function () { return shape.ThreeD.RotationX; }), rotationY: read(function () { return shape.ThreeD.RotationY; }),
                rotationZ: read(function () { return shape.ThreeD.RotationZ; }), material: read(function () { return shape.ThreeD.PresetMaterial; }),
                lighting: read(function () { return shape.ThreeD.PresetLighting; }), lightingDirection: read(function () { return shape.ThreeD.PresetLightingDirection; }),
                bevelTopType: read(function () { return shape.ThreeD.BevelTopType; }), bevelTopDepth: read(function () { return shape.ThreeD.BevelTopDepth; }),
                bevelTopInset: read(function () { return shape.ThreeD.BevelTopInset; }), bevelBottomType: read(function () { return shape.ThreeD.BevelBottomType; }),
                bevelBottomDepth: read(function () { return shape.ThreeD.BevelBottomDepth; }), bevelBottomInset: read(function () { return shape.ThreeD.BevelBottomInset; }),
                contourWidth: read(function () { return shape.ThreeD.ContourWidth; }), contourColor: color(read(function () { return shape.ThreeD.ContourColor; })),
                extrusionColor: color(read(function () { return shape.ThreeD.ExtrusionColor; })) } };
    }
    function set(shape, style, parseRgb) {
        var applied = [];
        if (style.fill) {
            if (style.fill.kind === 'solid') shape.Fill.Solid();
            else if (style.fill.kind === 'pattern') shape.Fill.Patterned(WpsJsBridgeDrawing.patternValue(style.fill.pattern));
            else if (style.fill.kind === 'picture' && typeof style.fill.localPath === 'string' && style.fill.localPath) shape.Fill.UserPicture(style.fill.localPath);
            else if (style.fill.kind === 'texture' && typeof style.fill.localPath === 'string' && style.fill.localPath) shape.Fill.UserTextured(style.fill.localPath);
            else throw new Error('wps_js_fill_kind_not_qualified');
            shape.Fill.Visible = -1;
            if (style.fill.color !== undefined) shape.Fill.ForeColor.RGB = parseRgb(style.fill.color);
            if (style.fill.backgroundColor !== undefined) shape.Fill.BackColor.RGB = parseRgb(style.fill.backgroundColor);
            if (style.fill.transparency !== undefined) shape.Fill.Transparency = style.fill.transparency;
            applied.push('fill');
        }
        if (style.effects) {
            if (style.effects.shadow) {
                var shadow = style.effects.shadow;
                if (shadow.preset !== undefined) { shape.Shadow.Type = Number(shadow.preset.slice(7)); shape.Shadow.Visible = -1; }
                if (shadow.color !== undefined) shape.Shadow.ForeColor.RGB = parseRgb(shadow.color);
                applied.push('effects.shadow');
            }
            if (style.effects.softEdge) { shape.SoftEdge.Radius = style.effects.softEdge.radius; applied.push('effects.softEdge'); }
            if (style.effects.glow) {
                var g = style.effects.glow;
                if (g.radius !== undefined) shape.Glow.Radius = g.radius;
                if (g.transparency !== undefined) shape.Glow.Transparency = g.transparency;
                if (g.color !== undefined) shape.Glow.Color.RGB = parseRgb(g.color);
                applied.push('effects.glow');
            }
            if (style.effects.reflection) { shape.Reflection.Type = style.effects.reflection.preset === 'none' ? 0 : Number(style.effects.reflection.preset.slice(7)); applied.push('effects.reflection'); }
            if (style.effects.threeD) {
                var d = style.effects.threeD;
                ['depth', 'rotationX', 'rotationY', 'rotationZ'].forEach(function (field) {
                    if (d[field] !== undefined) shape.ThreeD[field.charAt(0).toUpperCase() + field.slice(1)] = d[field];
                });
                if (d.material !== undefined) shape.ThreeD.PresetMaterial = Number(d.material.slice(7));
                if (d.lighting !== undefined) shape.ThreeD.PresetLighting = Number(d.lighting.slice(7));
                applied.push('effects.threeD');
            }
        }
        return applied;
    }
    function restoreEffects(shape, state) {
        var current = effects(shape);
        if (state.shadow && !WpsJsBridgeResult.sameState(current.shadow, state.shadow)) {
            if (state.shadow.type < 1 || state.shadow.type > 20) throw new Error('wps_js_shadow_snapshot_not_reversible');
            shape.Shadow.Type = state.shadow.type;
            restoreColor(shape.Shadow.ForeColor, state.shadow.color);
            shape.Shadow.Visible = state.shadow.visible;
        }
        if (state.softEdge && !WpsJsBridgeResult.sameState(current.softEdge, state.softEdge)) shape.SoftEdge.Radius = state.softEdge.radius;
        if (state.glow && !WpsJsBridgeResult.sameState(current.glow, state.glow)) {
            restoreColor(shape.Glow.Color, state.glow.color);
            shape.Glow.Transparency = state.glow.transparency;
            shape.Glow.Radius = state.glow.radius;
        }
        if (state.reflection && !WpsJsBridgeResult.sameState(current.reflection, state.reflection)) {
            if (state.reflection.type >= 0) shape.Reflection.Type = state.reflection.type;
            else {
                ['blur', 'size', 'offset', 'transparency'].forEach(function (field) {
                    shape.Reflection[field.charAt(0).toUpperCase() + field.slice(1)] = state.reflection[field];
                });
            }
        }
        if (state.threeD && !WpsJsBridgeResult.sameState(current.threeD, state.threeD)) {
            ['depth', 'rotationX', 'rotationY', 'rotationZ'].forEach(function (field) {
                if (state.threeD[field] !== null) shape.ThreeD[field.charAt(0).toUpperCase() + field.slice(1)] = state.threeD[field];
            });
            if (state.threeD.material > 0) shape.ThreeD.PresetMaterial = state.threeD.material;
            if (state.threeD.lighting > 0) shape.ThreeD.PresetLighting = state.threeD.lighting;
            shape.ThreeD.Visible = state.threeD.visible;
        }
    }
    return { fill: fill, fillProjection: fillProjection, restoreFill: restoreFill, color: color, restoreColor: restoreColor,
        effects: effects, set: set, restoreEffects: restoreEffects, creationEvidence: creationEvidence };
})();


/* Logical grid identity is relative to the captured table version, never Cell.Shape.Id. */
var WpsJsBridgeTable = (function () {
    function close(a, b) { return typeof a === 'number' && typeof b === 'number' && Math.abs(a - b) <= 0.25; }
    function dimensions(table) {
        var rows = [], columns = [], i;
        for (i = 1; i <= table.Rows.Count; i++) rows.push(Number(table.Rows.Item(i).Height));
        for (i = 1; i <= table.Columns.Count; i++) columns.push(Number(table.Columns.Item(i).Width));
        return { rowHeights: rows, columnWidths: columns };
    }
    function span(sizes, start, size) {
        var total = 0;
        for (var end = start; end < sizes.length; end++) {
            if (!(sizes[end] > 0)) break;
            total += sizes[end];
            if (close(total, size)) return end - start + 1;
            if (total > size + 0.25) break;
        }
        throw new Error('wps_js_table_cell_extent_not_on_grid');
    }
    function readTopology(table) {
        var size = dimensions(table), seen = {}, cells = [], rows = size.rowHeights.length, columns = size.columnWidths.length;
        if (!rows || !columns || rows > 100 || columns > 100) throw new Error('wps_js_table_grid_out_of_range');
        for (var row = 1; row <= rows; row++) for (var col = 1; col <= columns; col++) {
            if (seen[row + ':' + col]) continue;
            var shape = table.Cell(row, col).Shape, width = Number(shape.Width), height = Number(shape.Height);
            var rowSpan, columnSpan;
            try {
                rowSpan = span(size.rowHeights, row - 1, height);
                columnSpan = span(size.columnWidths, col - 1, width);
            } catch (error) {
                error.tableCellExtent = { row: row, col: col, width: width, height: height,
                    rowHeights: size.rowHeights, columnWidths: size.columnWidths };
                throw error;
            }
            var text = String(shape.TextFrame.TextRange.Text);
            for (var r = row; r < row + rowSpan; r++) for (var c = col; c < col + columnSpan; c++) {
                var alias = table.Cell(r, c).Shape;
                if (seen[r + ':' + c] || !close(Number(alias.Width), width) || !close(Number(alias.Height), height) || String(alias.TextFrame.TextRange.Text) !== text) {
                    throw new Error('wps_js_table_merge_alias_inconsistent');
                }
                seen[r + ':' + c] = true;
            }
            cells.push({ row: row, col: col, rowSpan: rowSpan, columnSpan: columnSpan });
        }
        return { version: 1, rows: rows, columns: columns, cells: cells };
    }
    function topology(table) {
        try { return readTopology(table); }
        catch (error) {
            var prior = error.tableCellExtent;
            if (!prior) throw error;
            // WPP refreshes resized cell extents when its owning shape geometry is read.
            WpsJsBridgeIdentity.safeRead(function () { return Number(table.Parent.Width); }, null);
            // Re-read once with the same strict grid checks; never retry the mutation.
            return readTopology(table);
        }
    }
    function restoreDimensions(table, size) {
        size.columnWidths.forEach(function (width, index) { if (!close(Number(table.Columns.Item(index + 1).Width), width)) table.Columns.Item(index + 1).Width = width; });
        size.rowHeights.forEach(function (height, index) { if (!close(Number(table.Rows.Item(index + 1).Height), height)) table.Rows.Item(index + 1).Height = height; });
    }
    function splitRegion(table, region) {
        if (region.rowSpan === 1 && region.columnSpan === 1) return;
        var size = dimensions(table), shape = table.Cell(region.row, region.col).Shape;
        var width = Number(shape.Width), height = Number(shape.Height);
        // WPS Split uses equal subdivisions; align the temporary grid so it does not add columns/rows.
        for (var c = region.col; c < region.col + region.columnSpan; c++) table.Columns.Item(c).Width = width / region.columnSpan;
        for (var r = region.row; r < region.row + region.rowSpan; r++) table.Rows.Item(r).Height = height / region.rowSpan;
        table.Cell(region.row, region.col).Split(region.rowSpan, region.columnSpan);
        if (Number(table.Rows.Count) !== size.rowHeights.length || Number(table.Columns.Count) !== size.columnWidths.length) {
            throw new Error('wps_js_table_split_changed_grid');
        }
        restoreDimensions(table, size);
    }
    function flatten(table) {
        topology(table).cells.forEach(function (region) { splitRegion(table, region); });
        if (topology(table).cells.some(function (cell) { return cell.rowSpan !== 1 || cell.columnSpan !== 1; })) throw new Error('wps_js_table_split_not_verified');
    }
    function applyRegions(table, grid) {
        grid.cells.forEach(function (cell) {
            if (cell.rowSpan > 1 || cell.columnSpan > 1) table.Cell(cell.row, cell.col).Merge(table.Cell(cell.row + cell.rowSpan - 1, cell.col + cell.columnSpan - 1));
        });
        if (!WpsJsBridgeResult.sameState(topology(table), grid)) throw new Error('wps_js_table_merge_not_verified');
    }
    function restoreTopology(table, state) {
        if (!state.topology) return;
        var current = topology(table);
        if (WpsJsBridgeResult.sameState(current, state.topology)) return;
        var retained = current.cells.filter(function (cell) { return cell.row <= state.rows && cell.col <= state.columns; });
        // Appending rows must not split or re-merge any original cell during recovery.
        var prefixUnchanged = current.rows >= state.rows && current.columns >= state.columns &&
            WpsJsBridgeResult.sameState(retained, state.topology.cells);
        if (!prefixUnchanged) {
            current.cells.forEach(function (cell) { table.Cell(cell.row, cell.col).Shape.TextFrame.TextRange.Text = ''; });
            flatten(table);
        }
        resize(table, 'Rows', state.rows);
        resize(table, 'Columns', state.columns);
        restoreDimensions(table, state);
        if (!prefixUnchanged) applyRegions(table, state.topology);
        if (!WpsJsBridgeResult.sameState(topology(table), state.topology)) throw new Error('wps_js_table_topology_restore_not_verified');
    }
    function resize(table, axis, expected) {
        var count = Number(table[axis].Count), steps = Math.abs(expected - count);
        if (steps > 100) throw new Error('wps_js_table_resize_out_of_range');
        for (var i = 0; i < steps; i++) {
            var before = Number(table[axis].Count);
            if (before > expected) table[axis].Item(before).Delete();
            else table[axis].Add(before);
            if (Number(table[axis].Count) !== before + (before > expected ? -1 : 1)) throw new Error('wps_js_table_resize_no_progress');
        }
        if (Number(table[axis].Count) !== expected) throw new Error('wps_js_table_resize_not_verified');
    }
    function style(table) {
        function read(fn) { return WpsJsBridgeIdentity.safeRead(fn, null); }
        return { styleId: read(function () { return table.Style.Id; }),
            firstRow: read(function () { return table.FirstRow; }), lastRow: read(function () { return table.LastRow; }),
            firstColumn: read(function () { return table.FirstCol; }), lastColumn: read(function () { return table.LastCol; }),
            rowBanding: read(function () { return table.HorizBanding; }), columnBanding: read(function () { return table.VertBanding; }) };
    }
    function transitionState(state, transition) {
        var result = JSON.parse(JSON.stringify(state));
        function find(row, col) {
            var cell = state.cells.filter(function (item) { return item.row === row && item.col === col; })[0];
            if (!cell) throw new Error('wps_js_table_transition_source_missing');
            return cell;
        }
        result.rows = transition.topology.rows; result.columns = transition.topology.columns;
        result.topology = transition.topology; result.rowHeights = transition.rowHeights; result.columnWidths = transition.columnWidths;
        result.cells = transition.cells.map(function (mapping) {
            var cell = JSON.parse(JSON.stringify(find(mapping.sourceRow, mapping.sourceCol)));
            cell.row = mapping.row; cell.col = mapping.col;
            if (mapping.textSources || cell.text !== mapping.text) {
                var text = String(mapping.text).replace(/\r$/, ''), runs = [], paragraphs = [];
                if (mapping.textSources) {
                    var offset = 0;
                    mapping.textSources.forEach(function (part, index) {
                        var original = find(part.row, part.col).textState, body = String(original.text).replace(/\r$/, '');
                        var priorRuns = original.runs, paragraphOffset = paragraphs.length;
                        priorRuns.forEach(function (run) {
                            if (run.start <= body.length) runs.push(Object.assign({}, run, { start: run.start + offset,
                                length: Math.min(run.length, body.length - run.start + 1) }));
                        });
                        if (index + 1 < mapping.textSources.length) runs.push(Object.assign({}, priorRuns[priorRuns.length - 1], { start: offset + body.length + 1, length: 1 }));
                        original.paragraphs.forEach(function (paragraph) { paragraphs.push(Object.assign({}, paragraph,
                            { index: paragraphOffset + paragraph.index })); });
                        offset += body.length + (index + 1 < mapping.textSources.length ? 1 : 0);
                    });
                } else {
                    runs = [Object.assign({}, cell.textState.runs[0], { start: 1, length: text.length || 1 })];
                    var start = 1;
                    paragraphs = text ? text.split('\r').map(function (body, index, all) {
                        var length = body.length + (index < all.length - 1 ? 1 : 0);
                        var paragraph = Object.assign({}, cell.textState.paragraphs[0], { index: index + 1 });
                        start += length; return paragraph;
                    }) : [];
                }
                cell.textState = Object.assign({}, cell.textState, { text: mapping.text, runs: runs, paragraphs: paragraphs });
                cell.text = mapping.text;
            }
            return cell;
        });
        return result;
    }
    function setStyle(table, requested) {
        var fields = { firstRow: 'FirstRow', firstColumn: 'FirstCol' };
        Object.keys(requested).forEach(function (key) {
            if (!fields[key] || typeof requested[key] !== 'boolean' || typeof table[fields[key]] !== 'boolean') {
                throw new Error('wps_js_table_style_flag_not_qualified');
            }
            if (table[fields[key]] !== requested[key]) table[fields[key]] = requested[key];
        });
    }
    function restoreStyle(table, state) {
        if (!state || WpsJsBridgeResult.sameState(style(table), state)) return;
        if (style(table).styleId !== state.styleId) throw new Error('wps_js_table_theme_restore_unavailable');
        setStyle(table, { firstRow: state.firstRow, firstColumn: state.firstColumn });
        if (!WpsJsBridgeResult.sameState(style(table), state)) throw new Error('wps_js_table_theme_restore_unverified');
    }
    function reversibleBorders(borders) {
        return !!borders && ['top', 'left', 'bottom', 'right'].every(function (edge, index) {
            var border = Array.isArray(borders) ? borders[index] : borders[edge];
            return border && typeof border.width === 'number' && isFinite(border.width) && border.width >= 0 &&
                border.color !== null && border.color !== undefined && border.dashStyle !== null && border.dashStyle !== undefined;
        });
    }
    return { reversibleBorders: reversibleBorders, dimensions: dimensions, topology: topology, splitRegion: splitRegion, flatten: flatten,
        restoreDimensions: restoreDimensions, applyRegions: applyRegions, restoreTopology: restoreTopology, resize: resize, style: style,
        transitionState: transitionState, setStyle: setStyle, restoreStyle: restoreStyle };
})();


/*
 * Input: Bound WPP presentations, slides, shapes and exact readback targets
 * Output: Existing Scene capture, context, fingerprint and rollback snapshot contracts
 * Pos: Full Phase 3 read boundary; chart semantic data remains explicitly unavailable
 */

var WpsJsBridgeCapture = (function () {
    var Identity = WpsJsBridgeIdentity;
    var Result = WpsJsBridgeResult;
    var TYPE_NAMES = {
        1: 'autoShape', 2: 'callout', 3: 'chart', 5: 'freeform', 6: 'group',
        7: 'embeddedOleObject', 9: 'line', 10: 'linkedOleObject', 11: 'linkedPicture',
        13: 'picture', 14: 'placeholder', 15: 'textEffect', 16: 'media',
        17: 'textBox', 19: 'table', 21: 'diagram', 24: 'smartArt',
        28: 'graphic', 29: 'linkedGraphic'
    };
    var PLACEHOLDER_NAMES = {
        1: 'title', 2: 'body', 3: 'centerTitle', 4: 'subtitle', 5: 'verticalTitle',
        6: 'verticalBody', 7: 'object', 8: 'chart', 9: 'bitmap', 10: 'mediaClip',
        11: 'orgChart', 12: 'table', 13: 'slideNumber', 14: 'header',
        15: 'footer', 16: 'date'
    };
    var CHART_NAMES = { 1: 'area', 4: 'line', 5: 'pie', 51: 'column_clustered',
        52: 'column_stacked', 57: 'bar_clustered', 65: 'line_markers',
        '-4120': 'doughnut', '-4169': 'scatter', '-4151': 'radar' };

    function value(read, fallback) {
        return Identity.safeRead(read, fallback === undefined ? null : fallback);
    }

    function bool(read) {
        return Identity.nativeBoolean(value(read, null));
    }

    function nativeEnum(read, names) {
        var native = value(read);
        return Object.prototype.hasOwnProperty.call(names, native) ? names[native] : native;
    }

    function rgbHex(rgb) {
        if (rgb === null || rgb === undefined) return null;
        var number = Number(rgb) >>> 0;
        function byte(offset) {
            var text = ((number >> offset) & 255).toString(16).toUpperCase();
            return text.length === 1 ? '0' + text : text;
        }
        return '#' + byte(0) + byte(8) + byte(16);
    }

    function compactHash(input) {
        var text = String(input || '');
        var seeds = [2166136261, 2654435761, 2246822519, 3266489917];
        var output = '';
        for (var seedIndex = 0; seedIndex < seeds.length; seedIndex++) {
            var hash = seeds[seedIndex] >>> 0;
            for (var index = 0; index < text.length; index++) {
                hash ^= text.charCodeAt(index);
                hash = Math.imul(hash, 16777619) >>> 0;
            }
            var part = hash.toString(16);
            output += ('00000000' + part).slice(-8);
        }
        return output;
    }

    function typeName(shape) {
        var code = Number(value(function () { return shape.Type; }, -1));
        return TYPE_NAMES[code] || 'shapeType:' + code;
    }

    function componentDescriptor(name) {
        var match = String(name || '').match(/^(R[0-9]+_(.+?)_([0-9]+))(__CB_([a-zA-Z0-9-]+))?_(.+)$/);
        if (!match) return null;
        var part = match[6];
        var item = part.match(/^(.+)__ITEM_([a-zA-Z0-9-]+)$/);
        if (item) part = item[1];
        return {
            componentId: match[1] + (match[4] || ''),
            layoutComponentId: match[1],
            contentBlockId: match[5] || '',
            componentType: match[2],
            componentIndex: Number(match[3]),
            part: part,
            itemId: item ? item[2] : ''
        };
    }

    function textRuns(shape, includeScriptFonts) {
        var output = [];
        var range = shape.TextFrame.TextRange;
        var contentLength = String(value(function () { return range.Text; }, '') || '')
            .replace(/\r$/, '').length;
        var count = value(function () { return range.Runs().Count; }, 0);
        for (var index = 1; index <= count; index++) {
            var run = range.Runs(index, 1);
            var start = Number(value(function () { return run.Start; }, 0));
            var length = Number(value(function () { return run.Length; }, 0));
            if (contentLength > 0) {
                length = Math.min(length, Math.max(0, contentLength - start + 1));
                if (length === 0) continue;
            }
            var run2 = value(function () {
                return shape.TextFrame2.TextRange.Characters(start, length);
            }, null);
            output.push(Object.assign(WpsJsBridgeText.runExtras(run, run2, includeScriptFonts), {
                start: start,
                length: length,
                text: String(value(function () { return run.Text; }, '') || '').slice(0, length),
                fontName: value(function () { return run.Font.Name; }),
                fontSize: value(function () { return run.Font.Size; }),
                bold: bool(function () { return run.Font.Bold; }),
                italic: bool(function () { return run.Font.Italic; }),
                fontColorHex: rgbHex(value(function () { return run.Font.Color.RGB; })),
                underline: bool(function () { return run.Font.Underline; }),
                strikethrough: run2 ? bool(function () { return run2.Font.Strike; }) : null,
                characterSpacing: run2 ? value(function () { return run2.Font.Spacing; }) : null,
                baseline: bool(function () { return run.Font.Superscript; }) === true ? 'superscript' :
                    (bool(function () { return run.Font.Subscript; }) === true ? 'subscript' : 'normal'),
            }));
        }
        return output;
    }

    function textParagraphs(shape) {
        var output = [];
        var range = shape.TextFrame.TextRange;
        var count = value(function () { return range.Paragraphs().Count; }, 0);
        for (var index = 1; index <= count; index++) {
            var paragraph = range.Paragraphs(index, 1);
            var format = paragraph.ParagraphFormat;
            var format2 = value(function () {
                return shape.TextFrame2.TextRange.Paragraphs(index, 1).ParagraphFormat;
            });
            output.push(Object.assign(WpsJsBridgeText.paragraphExtras(format2), {
                index: index,
                start: value(function () { return paragraph.Start; }),
                length: value(function () { return paragraph.Length; }),
                text: value(function () { return paragraph.Text; }, ''),
                alignment: value(function () { return format.Alignment; }),
                leftIndent: value(function () { return format2.LeftIndent; }),
                rightIndent: value(function () { return format2.RightIndent; }),
                firstLineIndent: value(function () { return format2.FirstLineIndent; }),
                spaceBefore: value(function () { return format.SpaceBefore; }),
                spaceAfter: value(function () { return format.SpaceAfter; }),
                lineSpacing: value(function () { return format.SpaceWithin; }),
                bullet: {
                    kind: bool(function () { return format.Bullet.Visible; }) === false ||
                        value(function () { return format.Bullet.Type; }) === 0 ? 'none' :
                        nativeEnum(function () { return format.Bullet.Type; }, { 1: 'bullet', 2: 'number' }),
                    character: value(function () { return String.fromCharCode(format.Bullet.Character); }),
                    startAt: value(function () { return format.Bullet.StartValue; })
                }
            }));
        }
        return output;
    }

    function textFormatting(shape) {
        var properties = { fontName: 'Name', fontSize: 'Size', fontBold: 'Bold',
            fontItalic: 'Italic', fontUnderline: 'Underline', fontSubscript: 'Subscript',
            fontSuperscript: 'Superscript' };
        var rows = [];
        var range = shape.TextFrame.TextRange;
        var count = value(function () { return range.Runs().Count; }, 0);
        for (var index = 1; index <= count; index++) {
            var run = range.Runs(index, 1);
            var run2 = value(function () {
                return shape.TextFrame2.TextRange.Characters(run.Start, run.Length);
            });
            var row = {};
            Object.keys(properties).forEach(function (key) {
                row[key] = value(function () { return run.Font[properties[key]]; });
            });
            row.fontColor = value(function () { return run.Font.Color.RGB; });
            row.fontStrike = value(function () { return run2.Font.Strike; });
            row.characterSpacing = value(function () { return run2.Font.Spacing; });
            row.allCaps = value(function () { return run2.Font.Allcaps; });
            row.smallCaps = value(function () { return run2.Font.Smallcaps; });
            row.alignment = value(function () { return run.ParagraphFormat.Alignment; });
            rows.push(row);
        }
        var states = {};
        Object.keys(properties).concat(['fontColor', 'fontStrike', 'characterSpacing',
            'allCaps', 'smallCaps', 'alignment']).forEach(function (key) {
            states[key] = !rows.length || rows.some(function (row) { return row[key] === null; })
                ? 'unknown' : rows.some(function (row) { return row[key] !== rows[0][key]; })
                    ? 'mixed' : 'uniform';
        });
        return { propertyStates: states, formatState: Object.keys(states).some(function (key) {
            return states[key] === 'mixed';
        }) ? 'mixed' : rows.length ? 'uniform' : 'unknown' };
    }

    function textFit(shape, text) {
        var height = Number(value(function () { return shape.Height; }, 0));
        var width = Number(value(function () { return shape.Width; }, 0));
        var bound = value(function () { return shape.TextFrame2.TextRange.BoundHeight; });
        var layoutHeight = Number(value(function () { return shape.Height; }, 0));
        var layoutWidth = Number(value(function () { return shape.Width; }, 0));
        // WPP's first BoundHeight read initializes cold cell geometry but returns the old measurement.
        if (height !== layoutHeight || width !== layoutWidth) {
            height = layoutHeight;
            width = layoutWidth;
            bound = value(function () { return shape.TextFrame2.TextRange.BoundHeight; });
        }
        if (!text.length) return { overflow: false, boundHeight: 0, availableHeight: height };
        if (bound === null || Number(bound) <= 0) {
            var font = Math.max(1, Number(value(function () { return shape.TextFrame.TextRange.Font.Size; }, 12)));
            var availableWidth = Math.max(24, width - 4);
            var perLine = Math.max(6, Math.floor(availableWidth / Math.max(1, font * 0.72)));
            var units = 0;
            for (var index = 0; index < text.length; index++) {
                if (text[index] === '\r') continue;
                units += text[index] === '\n' ? 8 : text.charCodeAt(index) > 255 ? 1 : 0.55;
            }
            bound = text.trim() ? Math.ceil(Math.max(text.split(/\r?\n/).length,
                Math.ceil(units / perLine)) * font * 1.35 + 4) : 0;
        }
        // Match the existing COM content_fits contract, including its 1pt allowance.
        var available = Math.max(1, height - 2);
        return { overflow: Number(bound) > available + 1,
            boundHeight: Math.round(Number(bound) * 100) / 100,
            availableHeight: Math.round(available * 100) / 100 };
    }

    function textInfo(shape, includeContent, includeScriptFonts) {
        var capable = bool(function () { return shape.HasTextFrame; }) === true;
        if (!capable) return {
            textCapable: false, hasText: false, text: includeContent ? '' : undefined,
            textPreview: '', textLength: 0, textRuns: [], textParagraphs: [], textFrame: null,
            textOverflow: null, textFit: null, style: null
        };
        var range = shape.TextFrame.TextRange;
        var text = String(value(function () { return range.Text; }, '') || '');
        var fit = textFit(shape, text);
        var formatting = value(function () { return textFormatting(shape); },
            { formatState: 'unknown', propertyStates: {} });
        function uniform(property, read) {
            return formatting.propertyStates[property] === 'mixed' ? null : value(read);
        }
        function fontBoolean(property, read) {
            var native = uniform(property, read);
            return native === -2 ? null : Identity.nativeBoolean(native);
        }
        return {
            textCapable: true,
            hasText: text.length > 0,
            text: includeContent ? text : undefined,
            textPreview: text.length > 160 ? text.slice(0, 160) : text,
            textLength: text.length,
            textPreviewTruncated: text.length > 160,
            textTruncated: !includeContent && text.length > 0,
            textRuns: includeContent ? value(function () { return textRuns(shape, includeScriptFonts); }, []) : [],
            textParagraphs: includeContent ? value(function () { return textParagraphs(shape); }, []) : [],
            textFrame: {
                orientation: WpsJsBridgeText.orientation(shape.TextFrame),
                marginLeft: value(function () { return shape.TextFrame.MarginLeft; }),
                marginRight: value(function () { return shape.TextFrame.MarginRight; }),
                marginTop: value(function () { return shape.TextFrame.MarginTop; }),
                marginBottom: value(function () { return shape.TextFrame.MarginBottom; }),
                verticalAnchor: value(function () { return shape.TextFrame.VerticalAnchor; }),
                wordWrap: value(function () { return shape.TextFrame.WordWrap; }),
                autoSize: value(function () { return shape.TextFrame.AutoSize; })
            },
            textOverflow: fit.overflow,
            textFit: fit,
            style: {
                formatState: formatting.formatState, propertyStates: formatting.propertyStates,
                fontName: uniform('fontName', function () { return range.Font.Name; }),
                fontSize: uniform('fontSize', function () { return range.Font.Size; }),
                bold: fontBoolean('fontBold', function () { return range.Font.Bold; }),
                italic: fontBoolean('fontItalic', function () { return range.Font.Italic; }),
                fontColor: uniform('fontColor', function () { return range.Font.Color.RGB; }),
                fontColorHex: rgbHex(uniform('fontColor', function () { return range.Font.Color.RGB; })),
                alignment: uniform('alignment', function () { return range.ParagraphFormat.Alignment; }),
                verticalAnchor: value(function () { return shape.TextFrame.VerticalAnchor; }),
                marginLeft: value(function () { return shape.TextFrame.MarginLeft; }),
                marginRight: value(function () { return shape.TextFrame.MarginRight; }),
                marginTop: value(function () { return shape.TextFrame.MarginTop; }),
                marginBottom: value(function () { return shape.TextFrame.MarginBottom; })
            }
        };
    }

    function tableInfo(shape, includeContent) {
        var table = shape.Table;
        var rows = Number(value(function () { return table.Rows.Count; }, 0));
        var columns = Number(value(function () { return table.Columns.Count; }, 0));
        var cells = [];
        var rowHeights = [];
        var columnWidths = [];
        for (var row = 1; row <= rows; row++) rowHeights.push(table.Rows.Item(row).Height);
        for (var column = 1; column <= columns; column++) columnWidths.push(table.Columns.Item(column).Width);
        if (includeContent) {
            for (row = 1; row <= rows; row++) {
                for (column = 1; column <= columns; column++) {
                    var cell = table.Cell(row, column);
                    var cellShape = cell.Shape;
                    var borders = {};
                    ['top', 'left', 'bottom', 'right'].forEach(function (edge, index) {
                        var border = value(function () { return cell.Borders.Item(index + 1); });
                        if (border) borders[edge] = {
                            color: rgbHex(value(function () { return border.ForeColor.RGB; })),
                            width: value(function () { return border.Weight; }),
                            dashStyle: WpsJsBridgeDrawing.dashNames[value(function () { return border.DashStyle; })] || null,
                            transparency: value(function () { return border.Transparency; })
                        };
                    });
                    var format = cellShape.TextFrame.TextRange.ParagraphFormat;
                    cells.push({
                        row: row, col: column,
                        fillState: WpsJsBridgeEffects.fill(cellShape),
                        text: String(value(function () { return cellShape.TextFrame.TextRange.Text; }, '') || ''),
                        runs: value(function () { return textRuns(cellShape, true); }, null),
                        paragraphs: value(function () { return textParagraphs(cellShape); }, null),
                        left: value(function () { return cellShape.Left; }),
                        top: value(function () { return cellShape.Top; }),
                        width: value(function () { return cellShape.Width; }),
                        height: value(function () { return cellShape.Height; }),
                        style: {
                            fillColor: rgbHex(value(function () { return cellShape.Fill.ForeColor.RGB; })),
                            fontColor: rgbHex(value(function () { return cellShape.TextFrame.TextRange.Font.Color.RGB; })),
                            fontName: value(function () { return cellShape.TextFrame.TextRange.Font.Name; }),
                            fontSize: value(function () { return cellShape.TextFrame.TextRange.Font.Size; }),
                            bold: bool(function () { return cellShape.TextFrame.TextRange.Font.Bold; }),
                            alignment: nativeEnum(function () { return format.Alignment; },
                                { 1: 'left', 2: 'center', 3: 'right' }),
                            paragraph: {
                                alignment: nativeEnum(function () { return format.Alignment; },
                                    { 1: 'left', 2: 'center', 3: 'right', 4: 'justify' }),
                                spaceBefore: value(function () { return format.SpaceBefore; }),
                                spaceAfter: value(function () { return format.SpaceAfter; }),
                                lineSpacing: value(function () { return format.SpaceWithin; })
                            },
                            borders: borders
                        }
                    });
                }
            }
        }
        return { rows: rows, columns: columns, cells: cells,
            topologyEditable: includeContent && cells.length === rows * columns && cells.every(function (cell) {
                return cell.fillState.type === 1 && cell.fillState.foreground.type === 1 && WpsJsBridgeTable.reversibleBorders(cell.style.borders);
            }),
            topology: value(function () { return WpsJsBridgeTable.topology(table); }, null),
            tableStyle: value(function () { return WpsJsBridgeTable.style(table); }, null),
            rowHeights: rowHeights, columnWidths: columnWidths };
    }

    function chartInfo(shape) {
        var chart = shape.Chart;
        var axes = [];
        ['category', 'value'].forEach(function (kind, index) {
            var axis = value(function () { return chart.Axes(index + 1, 1); }, null);
            if (!axis) return;
            var hasTitle = bool(function () { return axis.HasTitle; }) === true;
            axes.push({
                kind: kind, hasTitle: hasTitle,
                title: hasTitle ? value(function () { return axis.AxisTitle.Text; }, '') : '',
                hasMajorGridlines: bool(function () { return axis.HasMajorGridlines; }),
                minimumScale: value(function () { return axis.MinimumScale; }),
                maximumScale: value(function () { return axis.MaximumScale; }),
                minimumScaleIsAuto: bool(function () { return axis.MinimumScaleIsAuto; }),
                maximumScaleIsAuto: bool(function () { return axis.MaximumScaleIsAuto; })
            });
        });
        var series = [];
        var collection = value(function () { return chart.SeriesCollection(); }, null);
        var count = collection ? Number(value(function () { return collection.Count; }, 0)) : 0;
        for (var index = 1; index <= count; index++) {
            var item = collection.Item(index);
            series.push({ index: index, name: value(function () { return item.Name; }, ''),
                fillColor: rgbHex(value(function () { return item.Format.Fill.ForeColor.RGB; })),
                hasDataLabels: bool(function () { return item.HasDataLabels; }) });
        }
        var hasTitle = bool(function () { return chart.HasTitle; }) === true;
        var hasLegend = bool(function () { return chart.HasLegend; }) === true;
        var chartType = value(function () { return chart.ChartType; });
        return {
            hasChart: true, chartType: chartType,
            chartTypeName: chartType === null ? null : CHART_NAMES[chartType] || 'chartType:' + chartType,
            hasTitle: hasTitle,
            title: hasTitle ? value(function () { return chart.ChartTitle.Text; }, '') : '',
            hasLegend: hasLegend,
            legendPosition: hasLegend ? nativeEnum(function () { return chart.Legend.Position; },
                { '-4160': 'top', '-4152': 'right', '-4107': 'bottom', '-4131': 'left' }) : null,
            seriesCount: count, axes: axes, series: series,
            semanticData: null,
            semanticDataCapability: 'excluded_chart_semantic_data'
        };
    }

    function connectorInfo(shape) {
        var format = shape.ConnectorFormat;
        var beginConnected = bool(function () { return format.BeginConnected; }) === true;
        var endConnected = bool(function () { return format.EndConnected; }) === true;
        var connectorType = value(function () { return format.Type; });
        return {
            connectorType: connectorType,
            horizontalFlip: bool(function () { return shape.HorizontalFlip; }),
            verticalFlip: bool(function () { return shape.VerticalFlip; }),
            routeType: Number(connectorType) === 1 ? 'straight' :
                (Number(connectorType) === 2 ? 'elbow' : connectorType),
            beginConnected: beginConnected,
            endConnected: endConnected,
            beginConnectedShapeId: beginConnected ? value(function () {
                return format.BeginConnectedShape.Id;
            }) : null,
            endConnectedShapeId: endConnected ? value(function () {
                return format.EndConnectedShape.Id;
            }) : null,
            beginConnectionSite: value(function () { return format.BeginConnectionSite; }),
            endConnectionSite: value(function () { return format.EndConnectionSite; }),
            beginArrow: value(function () { return shape.Line.BeginArrowheadStyle; }),
            endArrow: value(function () { return shape.Line.EndArrowheadStyle; })
        };
    }

    function captureShape(shape, presentation, slideIndex, shapeIndex, includeContent, groupPath) {
        var protection = Identity.protectionState(presentation);
        var type = typeName(shape);
        var typeCode = value(function () { return shape.Type; });
        var placeholderType = value(function () { return shape.PlaceholderFormat.Type; });
        var placeholderName = PLACEHOLDER_NAMES[Number(placeholderType)] || null;
        var hasTable = bool(function () { return shape.HasTable; }) === true;
        // Name the source explicitly: WPP exposes the first cell through a table TextFrame.
        var text = textInfo(hasTable ? shape.Table.Cell(1, 1).Shape : shape, includeContent, hasTable);
        var kind = type;
        var role = type;
        if (bool(function () { return shape.HasTable; }) === true) { kind = role = 'table'; }
        else if (type === 'placeholder') {
            if (['title', 'centerTitle', 'verticalTitle'].indexOf(placeholderName) >= 0) kind = role = 'title';
            else if (placeholderName === 'subtitle') kind = role = 'subtitle';
            else { kind = 'placeholder'; role = placeholderName || 'placeholder'; }
        } else if (type === 'textBox' || text.hasText) { kind = 'textbox'; role = 'text'; }
        else if (type === 'picture' || type === 'linkedPicture') { kind = role = 'picture'; }
        else if (type === 'chart') { kind = role = 'chart'; }
        else if (type === 'graphic' || type === 'linkedGraphic') { kind = role = 'graphic'; }
        else if (type === 'group') { kind = role = 'group'; }
        else if (type === 'line' || bool(function () { return shape.Connector; }) === true) { kind = role = 'connector'; }
        var nativeLocked = bool(function () { return shape.Locked; });
        var object = {
            editingContractVersion: 1,
            unavailableEditingFields: ['languageId'],
            objectId: 'slide:' + slideIndex + ':shape:' + shapeIndex,
            shapeId: 'slide:' + slideIndex + ':shape:' + shapeIndex,
            nativeShapeId: Identity.shapeId(shape), shapeIndex: shapeIndex,
            shapeName: String(value(function () { return shape.Name; }, '') || ''),
            name: String(value(function () { return shape.Name; }, '') || ''),
            kind: kind, role: role, type: type, nativeType: type,
            typeCode: typeCode,
            autoShapeType: value(function () { return shape.AutoShapeType; }),
            connectionSiteCount: value(function () { return shape.ConnectionSiteCount; }),
            autoShapeTypeName: WpsJsBridgeDrawing.shapeNames[Number(value(function () { return shape.AutoShapeType; }))] || null,
            placeholderType: placeholderType, placeholderTypeName: placeholderName,
            bounds: {
                left: value(function () { return shape.Left; }), top: value(function () { return shape.Top; }),
                width: value(function () { return shape.Width; }), height: value(function () { return shape.Height; }),
                rotation: value(function () { return shape.Rotation; }, 0),
                horizontalFlip: bool(function () { return shape.HorizontalFlip; }),
                verticalFlip: bool(function () { return shape.VerticalFlip; })
            },
            zOrder: value(function () { return shape.ZOrderPosition; }),
            visible: bool(function () { return shape.Visible; }),
            readOnly: protection.readOnly, protectMode: protection.protectMode,
            nativeLocked: nativeLocked,
            locked: protection.protectMode === null || nativeLocked === null ? null :
                Boolean(protection.protectMode && nativeLocked),
            effectiveLocked: protection.protectMode === null || nativeLocked === null ? null :
                Boolean(protection.protectMode && nativeLocked),
            groupPath: groupPath || [],
            fillColorHex: rgbHex(value(function () { return shape.Fill.ForeColor.RGB; })),
            style: {
                fill: Object.assign(WpsJsBridgeEffects.fillProjection(shape), { visible: bool(function () { return shape.Fill.Visible; }),
                    color: value(function () { return shape.Fill.ForeColor.RGB; }),
                    colorHex: rgbHex(value(function () { return shape.Fill.ForeColor.RGB; })),
                    transparency: value(function () { return shape.Fill.Transparency; }) }),
                effects: WpsJsBridgeEffects.effects(shape),
                line: Object.assign(WpsJsBridgeDrawing.advancedLine(shape), { visible: bool(function () { return shape.Line.Visible; }),
                    color: value(function () { return shape.Line.ForeColor.RGB; }),
                    colorHex: rgbHex(value(function () { return shape.Line.ForeColor.RGB; })),
                    transparency: value(function () { return shape.Line.Transparency; }),
                    width: value(function () { return shape.Line.Weight; }),
                    dashStyle: nativeEnum(function () { return shape.Line.DashStyle; },
                        WpsJsBridgeDrawing.dashNames) }),
                text: text.style
            },
            textCapable: text.textCapable, hasText: text.hasText,
            textPreview: text.textPreview, textLength: text.textLength,
            textPreviewTruncated: text.textPreviewTruncated,
            textTruncated: text.textTruncated, textOverflow: text.textOverflow,
            textFit: text.textFit, textRuns: text.textRuns,
            textParagraphs: text.textParagraphs, textFrame: text.textFrame
        };
        if (hasTable) object.textProjectionCell = { row: 1, col: 1 };
        if (includeContent) object.text = text.text;
        if (kind === 'table') object.table = tableInfo(shape, includeContent);
        if (kind === 'chart') object.chart = chartInfo(shape);
        if (kind === 'picture') object.image = {
            sourcePath: value(function () { return shape.LinkFormat.SourceFullName; }),
            linked: type === 'linkedPicture',
            colorMode: nativeEnum(function () { return shape.PictureFormat.ColorType; },
                { 1: 'automatic', 2: 'grayscale' }),
            brightness: value(function () { return shape.PictureFormat.Brightness; }),
            contrast: value(function () { return shape.PictureFormat.Contrast; }),
            transparentBackground: value(function () { var state = shape.PictureFormat.TransparentBackground;
                return state === -1 || state === true ? true : state === 0 || state === false ? false : null; }),
            transparencyColor: rgbHex(value(function () { return shape.PictureFormat.TransparencyColor; })),
            crop: { left: value(function () { return shape.PictureFormat.CropLeft; }),
                top: value(function () { return shape.PictureFormat.CropTop; }),
                right: value(function () { return shape.PictureFormat.CropRight; }),
                bottom: value(function () { return shape.PictureFormat.CropBottom; }) }
        };
        if (kind === 'graphic') object.graphic = {
            embedded: type === 'graphic', linked: type === 'linkedGraphic',
            sourcePath: value(function () { return shape.LinkFormat.SourceFullName; })
        };
        if (kind === 'connector') object.connector = connectorInfo(shape);
        if (kind === 'group') {
            var members = [];
            var count = Number(value(function () { return shape.GroupItems.Count; }, 0));
            var path = groupPath && groupPath.length ? groupPath.slice() : [shapeIndex];
            for (var memberIndex = 1; memberIndex <= count; memberIndex++) {
                members.push(captureShape(shape.GroupItems.Item(memberIndex), presentation,
                    slideIndex, memberIndex, includeContent, path.concat([memberIndex])));
            }
            object.group = { memberCount: members.length, members: members };
        }
        var component = componentDescriptor(object.shapeName);
        if (component) object.component = component;
        return object;
    }

    function slideSummary(slide, index) {
        var parts = [Identity.slideId(slide), index];
        var title = '';
        var excerpts = [];
        var counts = {};
        for (var shapeIndex = 1; shapeIndex <= slide.Shapes.Count; shapeIndex++) {
            var shape = slide.Shapes.Item(shapeIndex);
            var text = String(value(function () { return shape.TextFrame.TextRange.Text; }, '') || '')
                .replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
            var code = Number(value(function () { return shape.Type; }, -1));
            counts['type-' + code] = (counts['type-' + code] || 0) + 1;
            if (text && excerpts.length < 4) excerpts.push(text.slice(0, 160));
            if (!title && [1, 3].indexOf(Number(value(function () {
                return shape.PlaceholderFormat.Type;
            }, -1))) >= 0) title = text;
            parts.push(Identity.shapeId(shape), value(function () { return shape.Name; }, ''), code,
                text, value(function () { return shape.Left; }), value(function () { return shape.Top; }),
                value(function () { return shape.Width; }), value(function () { return shape.Height; }),
                value(function () { return shape.Rotation; }));
        }
        if (!title && excerpts.length) title = excerpts[0];
        return {
            nativeSlideId: Identity.slideId(slide), index: index, title: title,
            textExcerpts: excerpts, objectCount: Number(slide.Shapes.Count), objectCounts: counts,
            hidden: bool(function () { return slide.SlideShowTransition.Hidden; }),
            nativeLayoutName: value(function () { return slide.CustomLayout.Name; }, ''),
            directBackground: {
                followMasterBackground: bool(function () { return slide.FollowMasterBackground; }),
                fillType: value(function () { return slide.Background.Fill.Type; }),
                fillForeColor: value(function () { return slide.Background.Fill.ForeColor.RGB; })
            },
            fingerprint: compactHash(parts.join('|'))
        };
    }

    function captureSlide(presentation, slide, mode) {
        var slideIndex = Number(value(function () { return slide.SlideIndex; }, 1));
        var includeContent = mode === 'content' || mode === 'both';
        var objects = [];
        var counts = { title: 0, subtitle: 0, textbox: 0, placeholder: 0,
            table: 0, picture: 0, chart: 0, graphic: 0, connector: 0, group: 0, shape: 0 };
        var textLengthTotal = 0;
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var object = captureShape(slide.Shapes.Item(index), presentation, slideIndex, index, includeContent, []);
            objects.push(object);
            var key = Object.prototype.hasOwnProperty.call(counts, object.kind) ? object.kind : 'shape';
            counts[key]++;
            textLengthTotal += Number(object.textLength || 0);
        }
        var diagnostics = resolveComponentInstances(objects);
        return {
            mode: mode, presentation: Identity.presentationIdentity(presentation),
            slide: { slideIndex: slideIndex, nativeSlideId: Identity.slideId(slide),
                layout: value(function () { return slide.Layout; }),
                width: value(function () { return presentation.PageSetup.SlideWidth; }),
                height: value(function () { return presentation.PageSetup.SlideHeight; }),
                objectCount: objects.length, counts: counts, textLengthTotal: textLengthTotal,
                fingerprint: slideSummary(slide, slideIndex).fingerprint },
            objects: objects, componentIdentityDiagnostics: diagnostics
        };
    }

    function presentationScene(presentation) {
        var identity = Identity.presentationIdentity(presentation);
        var slides = [];
        var parts = [identity.pageSize.width, identity.pageSize.height];
        for (var index = 1; index <= presentation.Slides.Count; index++) {
            var summary = slideSummary(presentation.Slides.Item(index), index);
            slides.push(summary);
            parts.push(summary.nativeSlideId, index, summary.fingerprint);
        }
        return { presentation: identity, slides: slides, fingerprint: compactHash(parts.join('|')) };
    }

    function validateMode(params) {
        var mode = String(params.mode || (params.includeContent ? 'content' : 'structure'));
        if (['structure', 'content', 'both'].indexOf(mode) < 0) {
            throw new Error('PPT_INVALID_STRUCTURE_MODE');
        }
        return mode;
    }

    function selectedObjects(captured) {
        var selection = value(function () { return Application.ActiveWindow.Selection; }, null);
        var selected = [];
        var count = selection ? Number(value(function () { return selection.ShapeRange.Count; }, 0)) : 0;
        for (var index = 1; index <= count; index++) {
            var id = Identity.shapeId(selection.ShapeRange.Item(index));
            for (var objectIndex = 0; objectIndex < captured.objects.length; objectIndex++) {
                if (String(captured.objects[objectIndex].nativeShapeId) === String(id)) {
                    selected.push(captured.objects[objectIndex]);
                }
            }
        }
        return { selection: selection, objects: selected };
    }

    function resolveComponentInstances(objects) {
        var groups = Object.create(null);
        var diagnostics = [];
        objects.forEach(function (object) {
            if (!object.component) return;
            var id = object.component.componentId;
            if (!groups[id]) groups[id] = [];
            groups[id].push(object);
        });
        Object.keys(groups).forEach(function (rawId) {
            var members = groups[rawId];
            var anchors = members.filter(function (object) {
                return /(^|_)(bg|band|background)($|_)/i.test(object.component.part);
            }).sort(function (a, b) { return a.shapeIndex - b.shapeIndex; });
            function instanceId(anchor) {
                return rawId + '@' + (anchor.nativeShapeId !== null && anchor.nativeShapeId !== undefined
                    ? 'native-' + anchor.nativeShapeId : 'shape-' + anchor.shapeIndex);
            }
            members.forEach(function (member) {
                var component = member.component;
                component.rawComponentId = rawId;
                component.componentInstanceId = rawId;
                component.identitySource = 'shape_name';
                if (anchors.length <= 1) return;
                var anchor = anchors.filter(function (item) { return item.objectId === member.objectId; })[0];
                if (!anchor) {
                    var bounds = member.bounds;
                    var x = Number(bounds.left) + Number(bounds.width) / 2;
                    var y = Number(bounds.top) + Number(bounds.height) / 2;
                    var ranked = anchors.map(function (item) {
                        var b = item.bounds;
                        var inside = x >= b.left - 2 && x <= b.left + b.width + 2 &&
                            y >= b.top - 2 && y <= b.top + b.height + 2;
                        return { anchor: item, score: Math.pow(x - b.left - b.width / 2, 2) +
                            Math.pow(y - b.top - b.height / 2, 2) + (inside ? 0 : 1000000000) };
                    }).sort(function (a, b) { return a.score - b.score || a.anchor.shapeIndex - b.anchor.shapeIndex; });
                    anchor = ranked[0].anchor;
                    if (Math.abs(ranked[0].score - ranked[1].score) < 0.01) {
                        component.identityAmbiguous = true;
                        diagnostics.push({ code: 'PPT_COMPONENT_INSTANCE_AMBIGUOUS',
                            rawComponentId: rawId, objectId: member.objectId, shapeIndex: member.shapeIndex,
                            candidateInstanceIds: ranked.filter(function (item) {
                                return Math.abs(item.score - ranked[0].score) < 0.01;
                            }).map(function (item) { return instanceId(item.anchor); }) });
                    }
                }
                component.componentId = component.componentInstanceId = instanceId(anchor);
                component.identitySource = 'background_native_shape';
            });
        });
        return diagnostics;
    }

    function componentGroups(objects) {
        var byId = {};
        objects.forEach(function (object) {
            if (!object.component) return;
            var id = object.component.componentId;
            if (!byId[id]) byId[id] = { componentId: id,
                componentType: object.component.componentType,
                componentIndex: object.component.componentIndex,
                objectIds: [], shapeIndexes: [], shapeNames: [], parts: [], texts: [] };
            var group = byId[id];
            group.objectIds.push(object.objectId); group.shapeIndexes.push(object.shapeIndex);
            group.shapeNames.push(object.shapeName); group.parts.push(object.component.part);
            if (object.textPreview) group.texts.push(object.textPreview);
        });
        return Object.keys(byId).map(function (key) { return byId[key]; });
    }

    function getCurrentPptContext(params, expectedPresentationRef) {
        try {
            var presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            var slideIndex = value(function () { return Application.ActiveWindow.View.Slide.SlideIndex; }, 1);
            var slide = Identity.requireSlide(presentation, slideIndex, params.nativeSlideId);
            var captured = captureSlide(presentation, slide, validateMode(params));
            var selected = selectedObjects(captured);
            var title = '';
            captured.objects.some(function (object) {
                if (object.role === 'title' && object.textPreview) { title = object.textPreview; return true; }
                return false;
            });
            return Result.success({
                presentation: captured.presentation,
                currentSlide: { slideIndex: captured.slide.slideIndex,
                    nativeSlideId: captured.slide.nativeSlideId, title: title,
                    layout: captured.slide.layout, width: captured.slide.width,
                    height: captured.slide.height, objectCount: captured.slide.objectCount,
                    fingerprint: captured.slide.fingerprint },
                view: { currentSlideSource: 'activeWindowView',
                    viewType: value(function () { return Application.ActiveWindow.ViewType; }),
                    selectionType: selected.selection ? value(function () { return selected.selection.Type; }) : null },
                selection: { selectedShapeIndexes: selected.objects.map(function (object) {
                    return object.shapeIndex;
                }), selectedObjects: selected.objects, selectedObjectCount: selected.objects.length },
                componentGroups: componentGroups(captured.objects),
                componentIdentityDiagnostics: captured.componentIdentityDiagnostics, targetCandidates: [],
                objects: params.includeSlideObjects === false ? [] : captured.objects,
                rollbackSnapshot: params.includeRollbackSnapshot ?
                    WpsJsBridgeOperations.snapshotPresentation(presentation,
                        params.rollbackSlideIndexes || [captured.slide.slideIndex],
                        params.rollbackTargetsBySlide || []) : null
            });
        } catch (error) {
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error));
        }
    }

    function exportSlide(slide, params) {
        var format = String(params.format || 'PNG').toUpperCase();
        if (format === 'JPEG') format = 'JPG';
        if (['PNG', 'JPG', 'GIF', 'BMP'].indexOf(format) < 0) {
            throw new Error('PPT_INVALID_IMAGE_FORMAT');
        }
        var outputPath = String(params.outputPath || params.path || '');
        if (!outputPath) throw new Error('PPT_SCREENSHOT_OUTPUT_PATH_REQUIRED');
        var width = Number(params.width || 1280);
        var height = Number(params.height || 720);
        slide.Export(outputPath, format, width, height);
        return { slideIndex: Number(slide.SlideIndex), outputPath: outputPath, format: format,
            mimeType: format === 'JPG' ? 'image/jpeg' : 'image/' + format.toLowerCase(),
            width: width, height: height, captureStatus: 'exported',
            renderCloneCleanupVerified: true,
            visualQaPending: { requiresMultimodal: true, status: 'not_implemented' } };
    }

    function readSlides(params, expectedPresentationRef) {
        try {
            var presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            var mode = validateMode(params);
            var indexes = [];
            if (params.nativeSlideId !== undefined && params.nativeSlideId !== null) {
                var bound = Identity.requireSlide(presentation, params.slideIndex, params.nativeSlideId);
                indexes.push(Number(bound.SlideIndex));
            } else if (Array.isArray(params.slideIndexes)) indexes = params.slideIndexes.map(Number);
            else {
                var start = Number(params.startSlide || params.start || 1);
                var end = Number(params.endSlide || params.end || presentation.Slides.Count);
                if (start > end) throw new Error('PPT_INVALID_SLIDE_RANGE');
                for (var index = start; index <= end; index++) indexes.push(index);
            }
            var maxSlides = Number(params.maxSlides || 50);
            if (indexes.length > maxSlides) indexes = indexes.slice(0, maxSlides);
            var slides = [];
            indexes.forEach(function (index) {
                var slide = Identity.requireSlide(presentation, index, null);
                var captured = captureSlide(presentation, slide, mode);
                if (params.includeScreenshot) captured.screenshot = exportSlide(slide, params);
                slides.push(captured);
            });
            return Result.success({ mode: mode, includeScreenshot: Boolean(params.includeScreenshot),
                presentation: Identity.presentationIdentity(presentation),
                requestedSlideIndexes: indexes, slides: slides, count: slides.length });
        } catch (error) {
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error));
        }
    }

    function readPresentationScene(params, expectedPresentationRef) {
        try {
            return Result.success(presentationScene(
                Identity.requirePresentation(expectedPresentationRef || params.presentationId)
            ));
        } catch (error) { return Result.failure(Result.errorText(error)); }
    }

    function readTargets(params, expectedPresentationRef) {
        try {
            var presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            var slide = Identity.requireSlide(presentation, params.slideIndex, params.nativeSlideId);
            var targets = Array.isArray(params.targets) ? params.targets : [];
            var objectKeys = {};
            var objects = [];
            var resolvedTargets = targets.map(function (target) {
                var resolved = Identity.requireFrozenShape(slide, target);
                var groupPath = resolved.groupPath || [];
                var objectShape = resolved.shape;
                var objectShapeIndex = resolved.shapeIndex;
                if (groupPath.length > 1) {
                    objectShapeIndex = groupPath[0];
                    objectShape = slide.Shapes.Item(objectShapeIndex);
                }
                var objectKey = 'shapeIndex:' + objectShapeIndex;
                if (!objectKeys[objectKey]) {
                    objects.push(captureShape(objectShape, presentation, Number(slide.SlideIndex),
                        objectShapeIndex, true, []));
                    objectKeys[objectKey] = true;
                }
                return { nativeShapeId: resolved.nativeShapeId,
                    expectedShapeName: String(resolved.shape.Name),
                    shapeIndex: resolved.shapeIndex, groupPath: groupPath.slice() };
            });
            var durableShapeRefs = [];
            var identityObjects = [];
            for (var shapeIndex = 1; shapeIndex <= slide.Shapes.Count; shapeIndex++) {
                var durableShape = slide.Shapes.Item(shapeIndex);
                durableShapeRefs.push({ nativeShapeId: Identity.shapeId(durableShape),
                    expectedShapeName: String(durableShape.Name) });
                var existing = objects.filter(function (object) { return object.shapeIndex === shapeIndex; })[0];
                var component = componentDescriptor(String(durableShape.Name));
                if (component) identityObjects.push(existing || {
                    objectId: 'slide:' + Number(slide.SlideIndex) + ':shape:' + shapeIndex,
                    shapeIndex: shapeIndex, nativeShapeId: Identity.shapeId(durableShape), component: component,
                    bounds: { left: Number(durableShape.Left), top: Number(durableShape.Top),
                        width: Number(durableShape.Width), height: Number(durableShape.Height) }
                });
            }
            var diagnostics = resolveComponentInstances(identityObjects);
            var slideIndex = Number(slide.SlideIndex);
            return Result.success({
                presentation: { name: String(presentation.Name),
                    path: Identity.fullPath(presentation) },
                slide: { slideIndex: slideIndex, nativeSlideId: Identity.slideId(slide),
                    width: Number(presentation.PageSetup.SlideWidth),
                    height: Number(presentation.PageSetup.SlideHeight),
                    objectCount: Number(slide.Shapes.Count),
                    fingerprint: slideSummary(slide, slideIndex).fingerprint },
                slideIndex: slideIndex, nativeSlideId: Identity.slideId(slide),
                objects: objects, resolvedTargets: resolvedTargets,
                componentIdentityDiagnostics: diagnostics,
                durableShapeRefs: durableShapeRefs,
                rollbackSnapshot: params.includeRollbackSnapshot ?
                    WpsJsBridgeOperations.snapshotPresentation(presentation,
                        [slideIndex], [{ slideIndex: slideIndex,
                            nativeShapeIds: resolvedTargets.filter(function (target) {
                                return target.groupPath.length === 0;
                            }).map(function (target) { return target.nativeShapeId; }),
                            groupPaths: resolvedTargets.filter(function (target) {
                                return target.groupPath.length > 1;
                            }).map(function (target) { return target.groupPath; }) }]) : null });
        } catch (error) { return Result.failure(Result.errorText(error)); }
    }

    return {
        rgbHex: rgbHex, compactHash: compactHash, captureShape: captureShape,
        captureSlide: captureSlide, slideSummary: slideSummary,
        presentationScene: presentationScene, getCurrentPptContext: getCurrentPptContext,
        readSlides: readSlides, readPresentationScene: readPresentationScene,
        readTargets: readTargets, exportSlide: exportSlide
    };
})();


/*
 * Input: Canonical Scene adapter operations and frozen native identities
 * Output: Transactional writes, exact readback and verified rollback evidence
 * Pos: Shared Phase 3 mutation primitive layer for edit, duplicate, plans and recovery
 */

var WpsJsBridgeOperations = (function () {
    var Identity = WpsJsBridgeIdentity;
    var Capture = WpsJsBridgeCapture;
    var Result = WpsJsBridgeResult;
    var SHAPE_TYPES = { rectangle: 1, roundedRectangle: 5, oval: 9, triangle: 7,
        diamond: 4, pentagon: 12, hexagon: 10, arrow: 33, rightArrow: 33,
        leftArrow: 34, upArrow: 35, downArrow: 36, star: 92, heart: 21, cloud: 179 };
    var LEGEND_POSITIONS = { top: -4160, right: -4152, bottom: -4107, left: -4131 };
    var BATCH_OPERATION_TYPES = [
        'setShapeText', 'set_shape_text', 'setTextboxText', 'setTextBoxText',
        'set_textbox_text', 'setShapePosition', 'set_shape_position',
        'setTextBoxStyle', 'setTextboxStyle', 'set_textbox_style',
        'setTextRangeStyle', 'set_text_range_style', 'setParagraphStyle',
        'set_paragraph_style', 'setTextFrame', 'set_text_frame',
        'setShapeStyle', 'set_shape_style', 'setPictureStyle',
        'set_picture_style', 'setConnectorStyle', 'set_connector_style',
        'setConnectorRoute', 'set_connector_route', 'setTableCells',
        'set_table_cells', 'setTableCellStyles', 'set_table_cell_styles',
        'appendTableRows', 'append_table_rows', 'setTableDimensions',
        'editTableTopology',
        'setTableStyle', 'setShapeGeometry',
        'set_table_dimensions', 'setChartProperties', 'set_chart_properties',
        'setChartAxisProperties', 'set_chart_axis_properties',
        'setChartSeriesProperties', 'set_chart_series_properties'
    ];

    function value(read, fallback) {
        return Identity.safeRead(read, fallback === undefined ? null : fallback);
    }

    function rgb(valueText) {
        var match = String(valueText || '').match(/^#?([0-9a-f]{6})$/i);
        if (!match) throw new Error('wps_js_invalid_color');
        var hex = match[1];
        return parseInt(hex.slice(0, 2), 16) |
            (parseInt(hex.slice(2, 4), 16) << 8) |
            (parseInt(hex.slice(4, 6), 16) << 16);
    }

    function nearly(left, right, tolerance) {
        return Math.abs(Number(left) - Number(right)) <= (tolerance || 0.01);
    }

    function unique(values) {
        return values.filter(function (value, index) { return values.indexOf(value) === index; });
    }

    function snapshotText(shape, includeScriptFonts) {
        if (Identity.nativeBoolean(value(function () { return shape.HasTextFrame; })) !== true) return null;
        var range = shape.TextFrame.TextRange;
        var text = String(value(function () { return range.Text; }, '') || '');
        var contentLength = text.replace(/\r$/, '').length;
        var runs = [];
        var runCount = Number(value(function () { return range.Runs().Count; }, 0));
        // Empty text still has an insertion font that a cell-style operation can change.
        for (var index = 1; index <= (contentLength === 0 ? Math.max(1, runCount) : runCount); index++) {
            var run = runCount === 0 ? range : range.Runs(index, 1);
            var runStart = Number(value(function () { return run.Start; }, 0));
            var runLength = Number(value(function () { return run.Length; }, 0));
            if (contentLength > 0) {
                runLength = Math.min(runLength, Math.max(0, contentLength - runStart + 1));
                if (runLength === 0) continue;
            }
            var run2 = value(function () {
                return shape.TextFrame2.TextRange.Characters(runStart, runLength);
            }, null);
            runs.push({ start: runStart,
                advanced: WpsJsBridgeText.runExtras(run, run2, includeScriptFonts),
                length: runLength,
                fontName: value(function () { return run.Font.Name; }),
                fontSize: value(function () { return run.Font.Size; }),
                bold: value(function () { return run.Font.Bold; }),
                italic: value(function () { return run.Font.Italic; }),
                underline: value(function () { return run.Font.Underline; }),
                color: value(function () { return run.Font.Color.RGB; }),
                subscript: value(function () { return run.Font.Subscript; }),
                superscript: value(function () { return run.Font.Superscript; }),
                strike: run2 ? value(function () { return run2.Font.Strike; }) : null,
                spacing: run2 ? value(function () { return run2.Font.Spacing; }) : null });
        }
        var paragraphs = [];
        var paragraphCount = Number(value(function () { return range.Paragraphs().Count; }, 0));
        for (index = 1; index <= paragraphCount; index++) {
            var paragraph = range.Paragraphs(index, 1).ParagraphFormat;
            var paragraph2 = value(function () {
                return shape.TextFrame2.TextRange.Paragraphs(index, 1).ParagraphFormat;
            }, null);
            var bulletVisible = value(function () { return paragraph.Bullet.Visible; });
            var bulletType = Identity.nativeBoolean(bulletVisible) === true
                ? value(function () { return paragraph.Bullet.Type; }) : null;
            paragraphs.push({ index: index, alignment: value(function () { return paragraph.Alignment; }),
                advanced: WpsJsBridgeText.paragraphExtras(paragraph2),
                leftIndent: paragraph2 ? value(function () { return paragraph2.LeftIndent; }) : null,
                rightIndent: paragraph2 ? value(function () { return paragraph2.RightIndent; }) : null,
                firstLineIndent: paragraph2 ? value(function () { return paragraph2.FirstLineIndent; }) : null,
                spaceBefore: value(function () { return paragraph.SpaceBefore; }),
                spaceAfter: value(function () { return paragraph.SpaceAfter; }),
                lineSpacing: value(function () { return paragraph.SpaceWithin; }),
                bulletVisible: bulletVisible,
                bulletType: bulletType,
                bulletCharacter: bulletType === 1 ? value(function () { return paragraph.Bullet.Character; }) : null,
                bulletStart: bulletType === 2 ? value(function () { return paragraph.Bullet.StartValue; }) : null });
        }
        return { text: text, runs: runs,
            paragraphs: paragraphs, frame: { marginLeft: value(function () { return shape.TextFrame.MarginLeft; }),
                orientation: WpsJsBridgeText.orientation(shape.TextFrame),
                marginRight: value(function () { return shape.TextFrame.MarginRight; }),
                marginTop: value(function () { return shape.TextFrame.MarginTop; }),
                marginBottom: value(function () { return shape.TextFrame.MarginBottom; }),
                verticalAnchor: value(function () { return shape.TextFrame.VerticalAnchor; }),
                wordWrap: value(function () { return shape.TextFrame.WordWrap; }),
                autoSize: value(function () { return shape.TextFrame.AutoSize; }) } };
    }

    function snapshotTable(shape) {
        if (Identity.nativeBoolean(value(function () { return shape.HasTable; })) !== true) return null;
        var table = shape.Table;
        var snapshot = { rows: Number(table.Rows.Count), columns: Number(table.Columns.Count),
            rowHeights: [], columnWidths: [], cells: [],
            topology: value(function () { return WpsJsBridgeTable.topology(table); }, null),
            tableStyle: WpsJsBridgeTable.style(table) };
        var row;
        var column;
        for (row = 1; row <= snapshot.rows; row++) snapshot.rowHeights.push(table.Rows.Item(row).Height);
        for (column = 1; column <= snapshot.columns; column++) snapshot.columnWidths.push(table.Columns.Item(column).Width);
        for (row = 1; row <= snapshot.rows; row++) {
            for (column = 1; column <= snapshot.columns; column++) {
                var cell = table.Cell(row, column);
                var cellShape = cell.Shape;
                var borders = [1, 2, 3, 4].map(function (index) {
                    return { index: index,
                        color: value(function () { return cell.Borders.Item(index).ForeColor.RGB; }),
                        width: value(function () { return cell.Borders.Item(index).Weight; }),
                        dashStyle: value(function () { return cell.Borders.Item(index).DashStyle; }),
                        transparency: value(function () { return cell.Borders.Item(index).Transparency; }) };
                });
                snapshot.cells.push({ row: row, col: column,
                    textState: snapshotText(cellShape, true),
                    fillState: WpsJsBridgeEffects.fill(cellShape),
                    borders: borders,
                    text: value(function () { return cellShape.TextFrame.TextRange.Text; }, ''),
                    fillColor: value(function () { return cellShape.Fill.ForeColor.RGB; }),
                    fontColor: value(function () { return cellShape.TextFrame.TextRange.Font.Color.RGB; }),
                    fontName: value(function () { return cellShape.TextFrame.TextRange.Font.Name; }),
                    fontSize: value(function () { return cellShape.TextFrame.TextRange.Font.Size; }),
                    bold: value(function () { return cellShape.TextFrame.TextRange.Font.Bold; }),
                    alignment: value(function () { return cellShape.TextFrame.TextRange.ParagraphFormat.Alignment; }) });
            }
        }
        return snapshot;
    }

    var LABEL_PROPERTIES = ['Position', 'NumberFormat', 'NumberFormatLinked',
        'ShowValue', 'ShowCategoryName', 'ShowSeriesName', 'ShowLegendKey', 'ShowPercentage',
        'Separator', 'Left', 'Top'];
    var LABEL_FONT_PROPERTIES = ['Name', 'Size', 'Bold', 'Italic', 'Underline', 'Color'];

    function snapshotSeriesLabels(series) {
        var points = value(function () { return series.Points(); }, null);
        if (!points) return null;
        var states = [];
        for (var index = 1; index <= points.Count; index++) {
            var point = points.Item(index);
            var active = Identity.nativeBoolean(point.HasDataLabel) === true;
            var state = { index: index, active: active, properties: {}, font: {} };
            if (active) {
                LABEL_PROPERTIES.forEach(function (key) {
                    state.properties[key] = value(function () { return point.DataLabel[key]; });
                });
                LABEL_FONT_PROPERTIES.forEach(function (key) {
                    state.font[key] = value(function () { return point.DataLabel.Font[key]; });
                });
            }
            states.push(state);
        }
        return states;
    }

    function restoreSeriesLabels(series, states) {
        var points = series.Points();
        states.forEach(function (state) {
            var point = points.Item(state.index);
            if ((Identity.nativeBoolean(point.HasDataLabel) === true) !== state.active) {
                point.HasDataLabel = state.active;
            }
        });
        // Visibility and fonts can trigger chart layout. Restore positions last.
        states.forEach(function (state) {
            var point = points.Item(state.index);
            if (!state.active) return;
            [ [point.DataLabel.Font, state.font], [point.DataLabel, state.properties] ].forEach(function (pair) {
                Object.keys(pair[1]).forEach(function (key) {
                    var expected = pair[1][key];
                    if (expected !== null && String(pair[0][key]) !== String(expected)) pair[0][key] = expected;
                });
            });
        });
    }

    function snapshotChart(shape) {
        if (Number(value(function () { return shape.Type; }, -1)) !== 3) return null;
        var chart = shape.Chart;
        var hasTitle = Identity.nativeBoolean(value(function () { return chart.HasTitle; })) === true;
        var hasLegend = Identity.nativeBoolean(value(function () { return chart.HasLegend; })) === true;
        var axes = [];
        ['category', 'value'].forEach(function (kind, index) {
            var axis = value(function () { return chart.Axes(index + 1, 1); }, null);
            if (!axis) return;
            var axisHasTitle = Identity.nativeBoolean(value(function () { return axis.HasTitle; })) === true;
            axes.push({ kind: kind, hasTitle: axisHasTitle,
                title: axisHasTitle ? value(function () { return axis.AxisTitle.Text; }, '') : '',
                hasMajorGridlines: value(function () { return axis.HasMajorGridlines; }),
                minimumScale: value(function () { return axis.MinimumScale; }),
                maximumScale: value(function () { return axis.MaximumScale; }),
                minimumScaleIsAuto: value(function () { return axis.MinimumScaleIsAuto; }),
                maximumScaleIsAuto: value(function () { return axis.MaximumScaleIsAuto; }) });
        });
        var series = [];
        var collection = value(function () { return chart.SeriesCollection(); }, null);
        var count = collection ? Number(value(function () { return collection.Count; }, 0)) : 0;
        for (var index = 1; index <= count; index++) {
            var item = collection.Item(index);
            series.push({ index: index, hasDataLabels: value(function () { return item.HasDataLabels; }),
                labels: snapshotSeriesLabels(item) });
        }
        return { chartType: value(function () { return chart.ChartType; }), hasTitle: hasTitle,
            title: hasTitle ? value(function () { return chart.ChartTitle.Text; }, '') : '',
            hasLegend: hasLegend,
            legendPosition: hasLegend ? value(function () { return chart.Legend.Position; }) : null,
            axes: axes, series: series };
    }

    function snapshotConnector(shape) {
        if (Number(value(function () { return shape.Type; }, -1)) !== 9 &&
            Identity.nativeBoolean(value(function () { return shape.Connector; })) !== true) return null;
        var format = shape.ConnectorFormat;
        var beginConnected = Identity.nativeBoolean(value(function () { return format.BeginConnected; })) === true;
        var endConnected = Identity.nativeBoolean(value(function () { return format.EndConnected; })) === true;
        var adjustments = value(function () {
            var values = [];
            for (var index = 1; index <= shape.Adjustments.Count; index++) {
                values.push(Number(shape.Adjustments.Item(index)));
            }
            return values;
        }, null);
        return { type: value(function () { return format.Type; }), beginConnected: beginConnected,
            horizontalFlip: value(function () { return shape.HorizontalFlip; }),
            verticalFlip: value(function () { return shape.VerticalFlip; }), adjustments: adjustments,
            endConnected: endConnected,
            beginShapeId: beginConnected ? value(function () { return format.BeginConnectedShape.Id; }) : null,
            endShapeId: endConnected ? value(function () { return format.EndConnectedShape.Id; }) : null,
            beginSite: value(function () { return format.BeginConnectionSite; }),
            endSite: value(function () { return format.EndConnectionSite; }),
            beginArrow: value(function () { return shape.Line.BeginArrowheadStyle; }),
            endArrow: value(function () { return shape.Line.EndArrowheadStyle; }) };
    }

    function snapshotShape(shape, groupPath, memberParentPath) {
        var state = { nativeShapeId: Identity.shapeId(shape), name: String(shape.Name),
            groupPath: Array.isArray(groupPath) ? groupPath.slice() : [],
            nativeType: value(function () { return shape.Type; }),
            autoShapeType: value(function () { return shape.AutoShapeType; }),
            placeholderType: value(function () { return shape.PlaceholderFormat.Type; }),
            left: value(function () { return shape.Left; }), top: value(function () { return shape.Top; }),
            width: value(function () { return shape.Width; }), height: value(function () { return shape.Height; }),
            lockAspectRatio: value(function () { return shape.LockAspectRatio; }),
            rotation: value(function () { return shape.Rotation; }), zOrderPosition: value(function () { return shape.ZOrderPosition; }),
            horizontalFlip: value(function () { return shape.HorizontalFlip; }),
            verticalFlip: value(function () { return shape.VerticalFlip; }),
            fillVisible: value(function () { return shape.Fill.Visible; }),
            fillState: value(function () { var fill = WpsJsBridgeEffects.fill(shape); return fill.type === null ? null : fill; }, null),
            effectsState: WpsJsBridgeEffects.effects(shape),
            fillColor: value(function () { return shape.Fill.ForeColor.RGB; }),
            fillTransparency: value(function () { return shape.Fill.Transparency; }),
            lineVisible: value(function () { return shape.Line.Visible; }),
            lineColor: value(function () { return shape.Line.ForeColor.RGB; }),
            lineWeight: value(function () { return shape.Line.Weight; }),
            lineTransparency: value(function () { return shape.Line.Transparency; }),
            lineDashStyle: value(function () { return shape.Line.DashStyle; }),
            advancedLine: WpsJsBridgeDrawing.advancedLine(shape),
            textState: value(function () { return snapshotText(
                Identity.nativeBoolean(shape.HasTable) === true ? shape.Table.Cell(1, 1).Shape : shape,
                Identity.nativeBoolean(shape.HasTable) === true); }, null),
            table: value(function () { return snapshotTable(shape); }, null),
            chart: value(function () { return snapshotChart(shape); }, null),
            picture: { colorType: value(function () { return shape.PictureFormat.ColorType; }),
                brightness: value(function () { return shape.PictureFormat.Brightness; }),
                contrast: value(function () { return shape.PictureFormat.Contrast; }),
                transparentBackground: value(function () { return shape.PictureFormat.TransparentBackground; }),
                transparencyColor: value(function () { return shape.PictureFormat.TransparencyColor; }),
                sourcePath: value(function () { return shape.LinkFormat.SourceFullName; }),
                cropLeft: value(function () { return shape.PictureFormat.CropLeft; }),
                cropTop: value(function () { return shape.PictureFormat.CropTop; }),
                cropRight: value(function () { return shape.PictureFormat.CropRight; }),
                cropBottom: value(function () { return shape.PictureFormat.CropBottom; }) },
            connector: value(function () { return snapshotConnector(shape); }, null),
            members: [] };
        var members = value(function () { return shape.GroupItems; }, null);
        var memberCount = members ? Number(value(function () { return members.Count; }, 0)) : 0;
        var parentPath = Array.isArray(memberParentPath) ? memberParentPath : state.groupPath;
        for (var memberIndex = 1; memberIndex <= memberCount; memberIndex++) {
            state.members.push(snapshotShape(members.Item(memberIndex),
                parentPath.concat([memberIndex])));
        }
        return state;
    }

    function compareSnapshotValue(expected, actual, path, issues, exact) {
        if (expected === null || expected === undefined ||
            actual === null || actual === undefined) {
            if (expected !== actual) issues.push({ code: 'rollback_snapshot_mismatch', field: path,
                expected: expected, actual: actual });
            return;
        }
        if (typeof expected === 'number' && typeof actual === 'number') {
            // Crop points refer to the original image, which can be much smaller than its frame.
            var tolerance = /\.picture\.crop(Left|Top|Right|Bottom)$/.test(path) ? 0.0001 : 0.15;
            if (exact ? expected !== actual : !nearly(expected, actual, tolerance)) issues.push({ code: 'rollback_snapshot_mismatch',
                field: path, expected: expected, actual: actual });
            return;
        }
        if (Array.isArray(expected)) {
            if (/\.textState\.runs$/.test(path) && Array.isArray(actual)) {
                expected = WpsJsBridgeText.coalesceRuns(expected);
                actual = WpsJsBridgeText.coalesceRuns(actual);
            }
            if (!Array.isArray(actual) || expected.length !== actual.length) {
                issues.push({ code: 'rollback_snapshot_mismatch', field: path + '.length',
                    expected: expected.length, actual: actual && actual.length });
                return;
            }
            expected.forEach(function (item, index) {
                compareSnapshotValue(item, actual[index], path + '[' + index + ']', issues, exact);
            });
            return;
        }
        if (typeof expected === 'object') {
            if (typeof actual !== 'object') {
                issues.push({ code: 'rollback_snapshot_mismatch', field: path,
                    expected: expected, actual: actual });
                return;
            }
            Object.keys(expected).forEach(function (key) {
                compareSnapshotValue(expected[key], actual[key], path ? path + '.' + key : key, issues, exact);
            });
            return;
        }
        if (String(expected) !== String(actual)) {
            issues.push({ code: 'rollback_snapshot_mismatch', field: path,
                expected: expected, actual: actual });
        }
    }

    function snapshotShapeIssues(slide, state) {
        var resolved = state.groupPath && state.groupPath.length > 1 ?
            Identity.shapeAtGroupPath(slide, state.groupPath) :
            Identity.findShapeById(slide, state.nativeShapeId);
        if (!resolved || String(resolved.shape.Name) !== String(state.name)) {
            return [{ code: 'rollback_shape_binding_missing', nativeShapeId: state.nativeShapeId,
                groupPath: state.groupPath || [] }];
        }
        var current = snapshotShape(resolved.shape, state.groupPath || [],
            state.groupPath && state.groupPath.length > 1 ? undefined : [resolved.shapeIndex]);
        var issues = [];
        compareSnapshotValue(state, current, 'shape:' + state.nativeShapeId, issues);
        return issues;
    }

    function currentZOrder(slide) {
        var entries = [];
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var shape = slide.Shapes.Item(index);
            entries.push({ id: Identity.shapeId(shape),
                position: Number(value(function () { return shape.ZOrderPosition; }, index)) });
        }
        return entries.sort(function (left, right) { return left.position - right.position; })
            .map(function (entry) { return Number(entry.id); });
    }

    function restoreZOrder(slide, baseline) {
        (baseline || []).forEach(function (nativeShapeId) {
            var resolved = Identity.findShapeById(slide, nativeShapeId);
            if (!resolved) throw new Error('wps_js_rollback_z_order_shape_missing:' + nativeShapeId);
            resolved.shape.ZOrder(0);
        });
    }

    function verifySnapshot(presentation, snapshot) {
        var issues = [];
        if (snapshot.pageSize && (!nearly(presentation.PageSetup.SlideWidth,
            snapshot.pageSize.width, 0.15) || !nearly(presentation.PageSetup.SlideHeight,
            snapshot.pageSize.height, 0.15))) {
            issues.push({ code: 'rollback_page_size_mismatch' });
        }
        (snapshot.slides || []).forEach(function (slideState) {
            try {
                var slide = Identity.requireSlide(presentation, slideState.slideIndex,
                    slideState.nativeSlideId);
                if (JSON.stringify(currentZOrder(slide)) !==
                    JSON.stringify((slideState.baselineZOrderNativeShapeIds || []).map(Number))) {
                    issues.push({ code: 'rollback_z_order_mismatch', slideIndex: slideState.slideIndex });
                }
                (slideState.shapes || []).forEach(function (shapeState) {
                    issues = issues.concat(snapshotShapeIssues(slide, shapeState));
                });
            } catch (error) {
                issues.push({ code: 'rollback_slide_verification_failed',
                    slideIndex: slideState.slideIndex, message: Result.errorText(error) });
            }
        });
        if (snapshot.presentationFingerprint) {
            var actualFingerprint = Capture.presentationScene(presentation).fingerprint;
            if (String(actualFingerprint) !== String(snapshot.presentationFingerprint)) {
                issues.push({ code: 'rollback_presentation_fingerprint_mismatch',
                    expected: snapshot.presentationFingerprint, actual: actualFingerprint });
            }
        }
        return issues;
    }

    function verifySnapshotShapes(presentation, snapshot) {
        var issues = [];
        (snapshot.slides || []).forEach(function (slideState) {
            try {
                var slide = Identity.requireSlide(presentation, slideState.slideIndex,
                    slideState.nativeSlideId);
                (slideState.shapes || []).forEach(function (shapeState) {
                    issues = issues.concat(snapshotShapeIssues(slide, shapeState));
                });
            } catch (error) {
                issues.push({ code: 'source_snapshot_verification_failed',
                    message: Result.errorText(error) });
            }
        });
        return issues;
    }

    function setBaseline(font, subscript, superscript) {
        // WPP can clear the opposite baseline even when assigning false.
        if (Identity.nativeBoolean(subscript) === true) {
            if (superscript !== null) font.Superscript = superscript;
            font.Subscript = subscript;
        } else {
            if (subscript !== null) font.Subscript = subscript;
            if (superscript !== null) font.Superscript = superscript;
        }
    }

    function restoreText(shape, state) {
        if (!state) return;
        var range = shape.TextFrame.TextRange;
        var desiredText = String(state.text || '').replace(/\r$/, '');
        var currentText = String(value(function () { return range.Text; }, '') || '');
        var currentLength = currentText.replace(/\r$/, '').length;
        if (currentText.replace(/\r$/, '') !== desiredText) {
            if (currentLength > 0) range.Characters(1, currentLength).Text = desiredText;
            else range.Text = desiredText;
        }
        state.runs.forEach(function (runState) {
            var run = runState.length === 0 ? range : range.Characters(runState.start, runState.length);
            if (runState.fontName !== null) run.Font.Name = runState.fontName;
            if (runState.fontSize !== null) run.Font.Size = runState.fontSize;
            if (runState.bold !== null) run.Font.Bold = runState.bold;
            if (runState.italic !== null) run.Font.Italic = runState.italic;
            if (runState.underline !== null) run.Font.Underline = runState.underline;
            if (runState.color !== null) run.Font.Color.RGB = runState.color;
            setBaseline(run.Font, runState.subscript, runState.superscript);
            var run2 = value(function () {
                return shape.TextFrame2.TextRange.Characters(runState.start, runState.length);
            }, null);
            if (run2 && runState.strike !== null) run2.Font.Strike = runState.strike;
            if (run2 && runState.spacing !== null) run2.Font.Spacing = runState.spacing;
            if (runState.advanced) WpsJsBridgeText.setRun(run, run2,
                WpsJsBridgeText.differences(runState.advanced, WpsJsBridgeText.runExtras(run, run2,
                    Object.prototype.hasOwnProperty.call(runState.advanced || {}, 'fontNameLatin'))));
        });
        state.frame && Object.keys(state.frame).forEach(function (field) {
            if (field === 'orientation') {
                if (state.frame.orientation !== null && state.frame.orientation !== WpsJsBridgeText.orientation(shape.TextFrame)) {
                    WpsJsBridgeText.setOrientation(shape.TextFrame, state.frame.orientation);
                }
                return;
            }
            var mapping = { marginLeft: 'MarginLeft', marginRight: 'MarginRight',
                marginTop: 'MarginTop', marginBottom: 'MarginBottom', verticalAnchor: 'VerticalAnchor',
                wordWrap: 'WordWrap', autoSize: 'AutoSize' };
            if (state.frame[field] !== null) shape.TextFrame[mapping[field]] = state.frame[field];
        });
        state.paragraphs.forEach(function (paragraphState) {
            var format = range.Paragraphs(paragraphState.index, 1).ParagraphFormat;
            if (paragraphState.alignment !== null) format.Alignment = paragraphState.alignment;
            if (paragraphState.spaceBefore !== null) format.SpaceBefore = paragraphState.spaceBefore;
            if (paragraphState.spaceAfter !== null) format.SpaceAfter = paragraphState.spaceAfter;
            if (paragraphState.lineSpacing !== null) format.SpaceWithin = paragraphState.lineSpacing;
            var bullet = format.Bullet;
            if (paragraphState.bulletVisible !== null && bullet.Visible !== paragraphState.bulletVisible) {
                bullet.Visible = paragraphState.bulletVisible;
            }
            if (Identity.nativeBoolean(paragraphState.bulletVisible) === true) {
                if (paragraphState.bulletType !== null && bullet.Type !== paragraphState.bulletType) {
                    bullet.Type = paragraphState.bulletType;
                }
                if (paragraphState.bulletType === 1 && paragraphState.bulletCharacter !== null &&
                    bullet.Character !== paragraphState.bulletCharacter) bullet.Character = paragraphState.bulletCharacter;
                if (paragraphState.bulletType === 2 && paragraphState.bulletStart !== null &&
                    bullet.StartValue !== paragraphState.bulletStart) bullet.StartValue = paragraphState.bulletStart;
            }
            // WPP Bullet setters can reset indentation, including when disabling bullets.
            ['leftIndent', 'rightIndent', 'firstLineIndent'].forEach(function (key) {
                if (paragraphState[key] === null || paragraphState[key] === undefined) return;
                var format2 = shape.TextFrame2.TextRange.Paragraphs(paragraphState.index, 1).ParagraphFormat;
                var nativeKey = key.charAt(0).toUpperCase() + key.slice(1);
                if (format2[nativeKey] !== paragraphState[key]) format2[nativeKey] = paragraphState[key];
            });
            if (paragraphState.advanced) {
                var paragraph2 = value(function () { return shape.TextFrame2.TextRange.Paragraphs(paragraphState.index, 1).ParagraphFormat; });
                WpsJsBridgeText.setParagraph(paragraph2, WpsJsBridgeText.differences(paragraphState.advanced,
                    WpsJsBridgeText.paragraphExtras(paragraph2)));
            }
        });
    }

    function restoreStep(issues, context, action) {
        function failed(error) {
            if (!issues) throw error;
            issues.push({ code: 'rollback_shape_failed', nativeSlideId: context.nativeSlideId,
                nativeShapeId: context.nativeShapeId, field: context.field,
                message: Result.errorText(error) });
        }
        try {
            var result = action();
            return result && typeof result.then === 'function' ? result.catch(failed) : result;
        } catch (error) { return failed(error); }
    }

    function restoreTable(shape, state, issues, nativeSlideId) {
        if (!state) return;
        WpsJsBridgeTable.restoreTopology(shape.Table, state);
        WpsJsBridgeTable.restoreStyle(shape.Table, state.tableStyle);
        WpsJsBridgeTable.resize(shape.Table, 'Rows', state.rows);
        state.columnWidths.forEach(function (width, index) {
            restoreStep(issues, { nativeSlideId: nativeSlideId, nativeShapeId: Identity.shapeId(shape),
                field: 'table.columns.' + (index + 1) }, function () {
            if (!nearly(shape.Table.Columns.Item(index + 1).Width, width, 0.01)) shape.Table.Columns.Item(index + 1).Width = width;
            });
        });
        state.cells.forEach(function (cellState) {
            restoreStep(issues, { nativeSlideId: nativeSlideId, nativeShapeId: Identity.shapeId(shape),
                field: 'table.cells.' + cellState.row + ':' + cellState.col }, function () {
            var cell = shape.Table.Cell(cellState.row, cellState.col).Shape;
            if (cellState.textState && !Result.sameState(snapshotText(cell, true), cellState.textState)) {
                restoreText(cell, cellState.textState);
            } else if (!cellState.textState && String(cell.TextFrame.TextRange.Text) !== String(cellState.text)) {
                cell.TextFrame.TextRange.Text = cellState.text;
            }
            if (!cellState.textState) {
                if (cellState.fontColor !== null) cell.TextFrame.TextRange.Font.Color.RGB = cellState.fontColor;
                if (cellState.fontName !== null) cell.TextFrame.TextRange.Font.Name = cellState.fontName;
                if (cellState.fontSize !== null) cell.TextFrame.TextRange.Font.Size = cellState.fontSize;
                if (cellState.bold !== null) cell.TextFrame.TextRange.Font.Bold = cellState.bold;
                if (cellState.alignment !== null) cell.TextFrame.TextRange.ParagraphFormat.Alignment = cellState.alignment;
            }
            if (cellState.fillState) WpsJsBridgeEffects.restoreFill(cell, cellState.fillState);
            else if (cellState.fillColor !== null && cell.Fill.ForeColor.RGB !== cellState.fillColor) {
                cell.Fill.Solid(); cell.Fill.ForeColor.RGB = cellState.fillColor;
            }
            (cellState.borders || []).forEach(function (borderState) {
                if (borderState.color === null && borderState.width === null) return;
                var border = shape.Table.Cell(cellState.row, cellState.col).Borders.Item(borderState.index);
                if (borderState.color !== null && border.ForeColor.RGB !== borderState.color) border.ForeColor.RGB = borderState.color;
                if (borderState.width !== null && !nearly(border.Weight, borderState.width, 0.01)) border.Weight = borderState.width;
                if (borderState.dashStyle !== undefined && borderState.dashStyle !== null && border.DashStyle !== borderState.dashStyle) border.DashStyle = borderState.dashStyle;
                if (borderState.transparency !== undefined && borderState.transparency !== null && !nearly(border.Transparency, borderState.transparency, 0.01)) border.Transparency = borderState.transparency;
            });
            });
        });
        state.rowHeights.forEach(function (height, index) {
            restoreStep(issues, { nativeSlideId: nativeSlideId, nativeShapeId: Identity.shapeId(shape),
                field: 'table.rows.' + (index + 1) }, function () {
            if (!nearly(shape.Table.Rows.Item(index + 1).Height, height, 0.01)) shape.Table.Rows.Item(index + 1).Height = height;
            });
        });
    }

    async function waitForChartState(check, reason) {
        var deadline = Date.now() + 1000;
        while (!check()) {
            if (Date.now() >= deadline) throw new Error(reason);
            await new Promise(function (resolve) { setTimeout(resolve, 25); });
        }
    }

    async function restoreChart(shape, state) {
        if (!state) return;
        var chart = shape.Chart;
        if (chart.ChartType !== state.chartType) chart.ChartType = state.chartType;
        // WPP rebuilds axes on its event loop after a type change, on both desktop hosts.
        await waitForChartState(function () {
            chart = shape.Chart;
            return ['category', 'value'].every(function (kind, index) {
                var expected = state.axes.some(function (axis) { return axis.kind === kind; });
                return Boolean(value(function () { return chart.Axes(index + 1, 1); }, null)) === expected;
            });
        }, 'wps_js_chart_axis_restore_unverified');
        if ((Identity.nativeBoolean(chart.HasTitle) === true) !== state.hasTitle) chart.HasTitle = state.hasTitle;
        if (state.hasTitle && chart.ChartTitle.Text !== state.title) chart.ChartTitle.Text = state.title;
        if ((Identity.nativeBoolean(chart.HasLegend) === true) !== state.hasLegend) chart.HasLegend = state.hasLegend;
        if (state.hasLegend && state.legendPosition !== null && chart.Legend.Position !== state.legendPosition) chart.Legend.Position = state.legendPosition;
        state.axes.forEach(function (axisState) {
            var axis = chart.Axes(axisState.kind === 'category' ? 1 : 2, 1);
            axis.HasTitle = axisState.hasTitle;
            if (axisState.hasTitle) axis.AxisTitle.Text = axisState.title;
            if (axisState.hasMajorGridlines !== null) axis.HasMajorGridlines = axisState.hasMajorGridlines;
            if (axisState.minimumScaleIsAuto) axis.MinimumScaleIsAuto = axisState.minimumScaleIsAuto;
            else if (axisState.minimumScale !== null) axis.MinimumScale = axisState.minimumScale;
            if (axisState.maximumScaleIsAuto) axis.MaximumScaleIsAuto = axisState.maximumScaleIsAuto;
            else if (axisState.maximumScale !== null) axis.MaximumScale = axisState.maximumScale;
        });
        var collection = chart.SeriesCollection();
        state.series.forEach(function (seriesState) {
            var series = collection.Item(seriesState.index);
            if (seriesState.labels) restoreSeriesLabels(series, seriesState.labels);
            else if (Identity.nativeBoolean(seriesState.hasDataLabels) === true) enableSeriesLabels(series);
            else value(function () { series.DataLabels().Delete(); return true; }, false);
        });
        await waitForChartState(function () { return Result.sameState(snapshotChart(shape), state); },
            'wps_js_chart_state_restore_unverified');
    }

    function restoreConnector(slide, shape, state) {
        if (!state) return;
        var format = shape.ConnectorFormat;
        value(function () { format.BeginDisconnect(); return true; }, false);
        value(function () { format.EndDisconnect(); return true; }, false);
        if (state.beginConnected) {
            var begin = Identity.findShapeById(slide, state.beginShapeId);
            if (!begin) throw new Error('wps_js_connector_rollback_begin_missing');
            format.BeginConnect(begin.shape, state.beginSite);
        }
        if (state.endConnected) {
            var end = Identity.findShapeById(slide, state.endShapeId);
            if (!end) throw new Error('wps_js_connector_rollback_end_missing');
            format.EndConnect(end.shape, state.endSite);
        }
        if (state.type !== null) setConnectorType(shape, state.type);
        if (state.beginArrow !== null) shape.Line.BeginArrowheadStyle = state.beginArrow;
        if (state.endArrow !== null) shape.Line.EndArrowheadStyle = state.endArrow;
    }

    async function restoreShape(slide, state, issues) {
        var resolved = state.groupPath && state.groupPath.length > 1 ?
            Identity.shapeAtGroupPath(slide, state.groupPath) :
            Identity.findShapeById(slide, state.nativeShapeId);
        if (!resolved || String(Identity.shapeId(resolved.shape)) !== String(state.nativeShapeId) ||
            String(resolved.shape.Type) !== String(state.nativeType) ||
            (String(resolved.shape.Name) !== String(state.name) &&
                !(state.connector && snapshotConnector(resolved.shape)))) {
            throw new Error('wps_js_rollback_shape_binding_missing');
        }
        var shape = resolved.shape;
        function stage(field, action) {
            return restoreStep(issues, { nativeSlideId: Identity.slideId(slide),
                nativeShapeId: state.nativeShapeId, field: field }, action);
        }
        function restoreGeometry() {
            var changed = {};
            ['left', 'top', 'width', 'height'].forEach(function (field) {
                if (state.table && (field === 'width' || field === 'height')) return;
                var property = field.charAt(0).toUpperCase() + field.slice(1);
                if (state[field] !== null && state[field] !== undefined &&
                    Number(shape[property]) !== Number(state[field])) changed[field] = state[field];
            });
            if (Object.keys(changed).length) setPosition(shape, changed);
            if (state.rotation !== null && Number(shape.Rotation) !== Number(state.rotation)) shape.Rotation = state.rotation;
        }
        stage('autoShapeType', function () {
            if (state.nativeType === 1 && state.autoShapeType > 0 && Number(shape.AutoShapeType) !== state.autoShapeType) {
                if ([1, 9, 4, 21, 179, 61, 63].indexOf(state.autoShapeType) < 0) throw new Error('wps_js_shape_geometry_restore_not_qualified');
                shape.AutoShapeType = state.autoShapeType;
                shape.Name = state.name;
            }
        });
        stage('connector', function () {
            restoreConnector(slide, shape, state.connector);
            if (state.connector && String(shape.Name) !== String(state.name)) shape.Name = state.name;
        });
        stage('geometry', function () {
            restoreGeometry();
        });
        stage('fillAndLine', function () {
        WpsJsBridgeDrawing.restoreAdvancedLine(shape, state.advancedLine);
        if (state.fillColor !== null && String(value(function () {
            return shape.Fill.ForeColor.RGB;
        })) !== String(state.fillColor)) shape.Fill.ForeColor.RGB = state.fillColor;
        if (state.fillTransparency !== null && !nearly(value(function () {
            return shape.Fill.Transparency;
        }), state.fillTransparency, 0.01)) shape.Fill.Transparency = state.fillTransparency;
        if (state.lineColor !== null && String(value(function () {
            return shape.Line.ForeColor.RGB;
        })) !== String(state.lineColor)) shape.Line.ForeColor.RGB = state.lineColor;
        if (state.lineWeight !== null && !nearly(value(function () {
            return shape.Line.Weight;
        }), state.lineWeight, 0.01)) {
            if (state.nativeType === 13) setPictureBorderWidth(shape, state.lineWeight);
            else shape.Line.Weight = state.lineWeight;
        }
        if (state.lineDashStyle !== null && String(value(function () {
            return shape.Line.DashStyle;
        })) !== String(state.lineDashStyle)) shape.Line.DashStyle = state.lineDashStyle;
        });
        stage('advancedFillAndEffects', function () {
            if (state.fillState && !state.table && state.nativeType !== 6) WpsJsBridgeEffects.restoreFill(shape, state.fillState);
            if (state.effectsState) WpsJsBridgeEffects.restoreEffects(shape, state.effectsState);
        });
        stage('textState', function () {
            // Table cells own their text state; restoring the table alias again can format other cells.
            if (!state.table && !Result.sameState(snapshotText(shape), state.textState)) restoreText(shape, state.textState);
        });
        stage('table', function () { restoreTable(shape, state.table, issues, Identity.slideId(slide)); });
        await stage('chart', function () {
            if (!Result.sameState(snapshotChart(shape), state.chart)) return restoreChart(shape, state.chart);
        });
        stage('picture.colorType', function () {
            if (state.picture.colorType !== null) shape.PictureFormat.ColorType = state.picture.colorType;
            ['brightness', 'contrast', 'transparencyColor', 'transparentBackground'].forEach(function (field) {
                if (state.picture[field] === undefined) return;
                var property = field.charAt(0).toUpperCase() + field.slice(1);
                var actual = value(function () { return shape.PictureFormat[property]; });
                if (actual === state.picture[field]) return;
                if (state.picture[field] === null) throw new Error('wps_js_picture_restore_unavailable:' + field);
                shape.PictureFormat[property] = state.picture[field];
            });
        });
        stage('visibility', function () {
        if (state.fillVisible !== null && String(value(function () {
            return shape.Fill.Visible;
        })) !== String(state.fillVisible)) shape.Fill.Visible = state.fillVisible;
        if (state.lineVisible !== null && String(value(function () {
            return shape.Line.Visible;
        })) !== String(state.lineVisible)) shape.Line.Visible = state.lineVisible;
        if (state.lineTransparency !== null && !nearly(value(function () {
            return shape.Line.Transparency;
        }), state.lineTransparency, 0.01)) shape.Line.Transparency = state.lineTransparency;
        });
        for (var memberState of state.members || []) {
            await restoreStep(issues, { nativeSlideId: Identity.slideId(slide), nativeShapeId: memberState.nativeShapeId,
                field: 'groupMember' }, function () { return restoreShape(slide, memberState, issues); });
        }
        stage('geometryAfterMembers', function () {
        ['horizontalFlip', 'verticalFlip'].forEach(function (field, index) {
            if (state[field] !== null && state[field] !== undefined &&
                Identity.nativeBoolean(shape[field === 'horizontalFlip' ? 'HorizontalFlip' : 'VerticalFlip']) !==
                    Identity.nativeBoolean(state[field])) shape.Flip(index);
        });
        if (state.connector) {
            ['horizontalFlip', 'verticalFlip'].forEach(function (field, index) {
                var expected = state.connector[field];
                if (expected !== null && expected !== undefined &&
                    Identity.nativeBoolean(shape[field === 'horizontalFlip' ? 'HorizontalFlip' : 'VerticalFlip']) !==
                        Identity.nativeBoolean(expected)) shape.Flip(index);
            });
        }
        restoreGeometry();
        if (state.connector && Array.isArray(state.connector.adjustments)) {
            state.connector.adjustments.forEach(function (adjustment, index) {
                shape.Adjustments.Item(index + 1, adjustment);
            });
        }
        });
        stage('picture.crop', function () {
        var cropStyle = {};
        ['cropLeft', 'cropTop', 'cropRight', 'cropBottom'].forEach(function (field) {
            var property = field.charAt(0).toUpperCase() + field.slice(1);
            if (state.picture[field] !== null && state.picture[field] !== undefined &&
                Number(shape.PictureFormat[property]) !== Number(state.picture[field])) cropStyle[field] = state.picture[field];
        });
        if (Object.keys(cropStyle).length) setPictureStyle(shape, cropStyle);
        });
        stage('lockAspectRatio', function () {
            if (state.lockAspectRatio !== null && state.lockAspectRatio !== undefined &&
                String(value(function () { return shape.LockAspectRatio; })) !== String(state.lockAspectRatio)) {
                shape.LockAspectRatio = state.lockAspectRatio;
            }
        });
    }

    function snapshotPresentation(presentation, slideIndexes, targetsBySlide) {
        var targetMap = {};
        (targetsBySlide || []).forEach(function (target) {
            targetMap[String(target.slideIndex)] = target;
        });
        var slides = [];
        unique((slideIndexes || []).map(Number)).forEach(function (slideIndex) {
            var slide = Identity.requireSlide(presentation, slideIndex, null);
            var target = targetMap[String(slideIndex)] || {};
            var hasExplicitTargets = Object.prototype.hasOwnProperty.call(targetMap, String(slideIndex));
            var ids = Array.isArray(target.nativeShapeIds) ? target.nativeShapeIds.map(String) : [];
            var groupPaths = Array.isArray(target.groupPaths) ? target.groupPaths : [];
            var shapes = [];
            function containsTarget(shape) {
                if (ids.indexOf(String(Identity.shapeId(shape))) >= 0) return true;
                var members = value(function () { return shape.GroupItems; }, null);
                for (var child = 1; members && child <= members.Count; child++) {
                    if (containsTarget(members.Item(child))) return true;
                }
                return false;
            }
            for (var index = 1; index <= slide.Shapes.Count; index++) {
                var shape = slide.Shapes.Item(index);
                if ((!hasExplicitTargets && ids.length === 0) ||
                    containsTarget(shape)) {
                    shapes.push(snapshotShape(shape, [], [index]));
                }
            }
            groupPaths.forEach(function (groupPath) {
                var resolved = Identity.shapeAtGroupPath(slide, groupPath);
                if (!resolved) throw new Error('wps_js_group_member_binding_stale');
                shapes.push(snapshotShape(resolved.shape, resolved.groupPath));
            });
            var baselineZOrderNativeShapeIds = [];
            for (index = 1; index <= slide.Shapes.Count; index++) {
                baselineZOrderNativeShapeIds.push(Identity.shapeId(slide.Shapes.Item(index)));
            }
            slides.push({ slideIndex: slideIndex, nativeSlideId: Identity.slideId(slide),
                shapes: shapes, baselineZOrderNativeShapeIds: baselineZOrderNativeShapeIds });
        });
        return { schemaVersion: 1, presentationRef: Identity.runtimeLocator(presentation),
            presentationFingerprint: Capture.presentationScene(presentation).fingerprint,
            pageSize: { width: presentation.PageSetup.SlideWidth, height: presentation.PageSetup.SlideHeight },
            slides: slides };
    }

    async function restoreSnapshot(presentation, snapshot, creationReceipts) {
        var issues = [];
        (creationReceipts || []).slice().reverse().forEach(function (receipt) {
            try {
                var created = receipt.created || receipt;
                var slide = Identity.requireSlide(presentation, created.slideIndex || receipt.slideIndex,
                    created.nativeSlideId || receipt.nativeSlideId);
                var ids = created.nativeShapeIds || (created.nativeShapeId ? [created.nativeShapeId] : []);
                ids.slice().reverse().forEach(function (id) {
                    var resolved = Identity.findShapeById(slide, id);
                    if (resolved) resolved.shape.Delete();
                });
                if ((receipt.entityClass === 'slide' || created.entityClass === 'slide') && ids.length === 0) slide.Delete();
            } catch (error) { issues.push({ code: 'rollback_created_entity_failed', message: Result.errorText(error) }); }
        });
        try {
            if (snapshot.pageSize) {
                presentation.PageSetup.SlideWidth = snapshot.pageSize.width;
                presentation.PageSetup.SlideHeight = snapshot.pageSize.height;
            }
        } catch (error) { issues.push({ code: 'rollback_page_size_failed', message: Result.errorText(error) }); }
        for (var slideState of snapshot.slides || []) {
            try {
                var slide = Identity.requireSlide(presentation, slideState.slideIndex, slideState.nativeSlideId);
                for (var shapeState of slideState.shapes || []) {
                    try {
                        if (snapshotShapeIssues(slide, shapeState).length) await restoreShape(slide, shapeState, issues);
                    } catch (error) {
                        issues.push({ code: 'rollback_shape_failed', nativeSlideId: slideState.nativeSlideId,
                            nativeShapeId: shapeState.nativeShapeId, message: Result.errorText(error) });
                    }
                }
            } catch (error) { issues.push({ code: 'rollback_shape_failed', message: Result.errorText(error) }); }
        }
        (snapshot.slides || []).forEach(function (slideState) {
            try {
                var slide = Identity.requireSlide(presentation, slideState.slideIndex, slideState.nativeSlideId);
                restoreZOrder(slide, slideState.baselineZOrderNativeShapeIds || []);
            } catch (error) { issues.push({ code: 'rollback_z_order_failed',
                message: Result.errorText(error) }); }
        });
        issues = issues.concat(verifySnapshot(presentation, snapshot));
        var verified = issues.length === 0;
        var checkpoint = !verified ? value(function () {
            return snapshotPresentation(presentation, (snapshot.slides || []).map(function (slide) {
                return slide.slideIndex;
            }));
        }, null) : null;
        return { rolledBack: true, rollbackVerified: verified, rollbackIssues: issues,
            recoveryCheckpoint: checkpoint,
            presentationFingerprintAfter: Capture.presentationScene(presentation).fingerprint };
    }

    function setPosition(shape, source) {
        var applied = [];
        var flips = source.horizontalFlip !== undefined || source.verticalFlip !== undefined;
        var rotation = source.rotation !== undefined && source.rotation !== null ? Number(source.rotation) :
            flips ? value(function () { return shape.Rotation; }) : null;
        if (flips && rotation === null) throw new Error('wps_js_flip_rotation_unavailable');
        var resizes = source.width !== undefined && source.width !== null ||
            source.height !== undefined && source.height !== null;
        var locked = resizes ? value(function () { return shape.LockAspectRatio; }) : null;
        var unlock = Identity.nativeBoolean(locked) === true;
        var originalPosition = resizes ? { left: Number(shape.Left), top: Number(shape.Top) } : null;
        // Scene bounds are independent coordinates, including an unchanged omitted dimension.
        try {
            if (unlock) shape.LockAspectRatio = 0;
            ['width', 'height'].forEach(function (field) {
                if (source[field] === undefined || source[field] === null) return;
                shape[field.charAt(0).toUpperCase() + field.slice(1)] = Number(source[field]);
                applied.push(field);
            });
            // Resizing a rotated shape can move its origin; resolve absolute position last.
            ['left', 'top'].forEach(function (field) {
                var explicit = source[field] !== undefined && source[field] !== null;
                if (!explicit && !originalPosition) return;
                var expected = explicit ? Number(source[field]) : originalPosition[field];
                var property = field.charAt(0).toUpperCase() + field.slice(1);
                if (Number(shape[property]) !== expected) shape[property] = expected;
                if (explicit) applied.push(field);
            });
        } finally {
            if (unlock) shape.LockAspectRatio = locked;
        }
        ['horizontalFlip', 'verticalFlip'].forEach(function (field, index) {
            if (source[field] === undefined) return;
            var actual = Identity.nativeBoolean(shape[field === 'horizontalFlip' ? 'HorizontalFlip' : 'VerticalFlip']);
            if (actual === null || typeof source[field] !== 'boolean') throw new Error('wps_js_flip_state_unavailable:' + field);
            if (actual !== source[field]) shape.Flip(index);
            applied.push(field);
        });
        // Native Flip mirrors Rotation; Scene fields specify independent absolute states.
        if (rotation !== null) shape.Rotation = rotation;
        if (source.rotation !== undefined && source.rotation !== null) applied.push('rotation');
        return applied;
    }

    function setTextStyle(shape, style) {
        style = style || {};
        var applied = [];
        var range = shape.TextFrame.TextRange;
        if (style.fontSize !== undefined) { range.Font.Size = Number(style.fontSize); applied.push('fontSize'); }
        if (style.fontName !== undefined) { range.Font.Name = String(style.fontName); applied.push('fontName'); }
        if (style.bold !== undefined) { range.Font.Bold = style.bold ? -1 : 0; applied.push('bold'); }
        if (style.italic !== undefined) { range.Font.Italic = style.italic ? -1 : 0; applied.push('italic'); }
        if (style.fontColor !== undefined || style.color !== undefined) {
            range.Font.Color.RGB = rgb(style.fontColor || style.color); applied.push('fontColor');
        }
        var alignment = style.alignment || style.align || style.horizontalAlignment;
        if (alignment !== undefined) {
            var alignmentMap = { left: 1, center: 2, right: 3, justify: 4 };
            if (alignmentMap[alignment] === undefined) throw new Error('wps_js_invalid_alignment');
            range.ParagraphFormat.Alignment = alignmentMap[alignment]; applied.push('alignment');
        }
        var vertical = style.verticalAlignment || style.verticalAlign;
        if (vertical !== undefined) {
            var verticalMap = { top: 1, middle: 3, center: 3, bottom: 4 };
            if (verticalMap[vertical] === undefined) throw new Error('wps_js_invalid_vertical_alignment');
            shape.TextFrame.VerticalAnchor = verticalMap[vertical]; applied.push('verticalAlignment');
        }
        ['marginLeft', 'marginRight', 'marginTop', 'marginBottom'].forEach(function (field) {
            if (style[field] === undefined) return;
            shape.TextFrame[field.charAt(0).toUpperCase() + field.slice(1)] = Number(style[field]);
            applied.push(field);
        });
        return applied;
    }

    function setShapeStyle(shape, style) {
        style = style || {};
        var effectFields = WpsJsBridgeEffects.set(shape, style, rgb);
        var applied = WpsJsBridgeDrawing.setAdvancedLine(shape, style || {});
        var fill = style.fillColor || style.backgroundColor;
        if (fill !== undefined) { shape.Fill.Visible = -1; shape.Fill.Solid(); shape.Fill.ForeColor.RGB = rgb(fill); applied.push('fillColor'); }
        var line = style.lineColor || style.borderColor;
        if (line !== undefined) { shape.Line.Visible = -1; shape.Line.ForeColor.RGB = rgb(line); applied.push('lineColor'); }
        var width = style.lineWidth === undefined ? style.borderWidth : style.lineWidth;
        if (width !== undefined) { shape.Line.Weight = Number(width); applied.push('lineWidth'); }
        var transparency = style.transparency === undefined ? style.fillTransparency : style.transparency;
        if (transparency !== undefined) { shape.Fill.Transparency = Number(transparency); applied.push('transparency'); }
        if (style.lineTransparency !== undefined) { shape.Line.Transparency = Number(style.lineTransparency); applied.push('lineTransparency'); }
        if (style.lineDashStyle !== undefined) {
            WpsJsBridgeDrawing.setDash(shape, style.lineDashStyle); applied.push('lineDashStyle');
        }
        if (style.text !== undefined) { shape.TextFrame.TextRange.Text = String(style.text); applied.push('text'); }
        return unique(applied.concat(effectFields, setPosition(shape, { left: style.left, top: style.top, width: style.width, height: style.height }),
            setTextStyle(shape, style.textStyle || style)));
    }

    function setTextRanges(shape, ranges) {
        var applied = [];
        var total = Number(shape.TextFrame.TextRange.Length);
        (ranges || []).forEach(function (update) {
            var start = Number(update.start);
            var length = Number(update.length);
            if (start < 1 || length < 1 || start + length - 1 > total) {
                throw new Error('wps_js_text_range_out_of_bounds');
            }
            var range = shape.TextFrame.TextRange.Characters(start, length);
            var range2 = value(function () {
                return shape.TextFrame2.TextRange.Characters(start, length);
            }, null);
            var style = update.style || {};
            var prefix = 'ranges[' + start + ',' + length + ']';
            applied = applied.concat(WpsJsBridgeText.setRun(range, range2, style).map(function (field) { return prefix + '.' + field; }));
            if (style.fontName !== undefined) { range.Font.Name = style.fontName; applied.push(prefix + '.fontName'); }
            if (style.fontSize !== undefined) { range.Font.Size = Number(style.fontSize); applied.push(prefix + '.fontSize'); }
            if (style.fontColor !== undefined) { range.Font.Color.RGB = rgb(style.fontColor); applied.push(prefix + '.fontColor'); }
            ['bold', 'italic', 'underline'].forEach(function (field) {
                if (style[field] === undefined) return;
                range.Font[field.charAt(0).toUpperCase() + field.slice(1)] = style[field] ? -1 : 0;
                applied.push(prefix + '.' + field);
            });
            if (style.strikethrough !== undefined) {
                if (!range2) throw new Error('wps_js_textframe2_unavailable');
                range2.Font.Strike = style.strikethrough ? 1 : 0;
                applied.push(prefix + '.strikethrough');
            }
            if (style.baseline !== undefined) {
                setBaseline(range.Font, style.baseline === 'subscript' ? -1 : 0,
                    style.baseline === 'superscript' ? -1 : 0);
                applied.push(prefix + '.baseline');
            }
            if (style.characterSpacing !== undefined) {
                if (!range2) throw new Error('wps_js_textframe2_unavailable');
                range2.Font.Spacing = Number(style.characterSpacing);
                applied.push(prefix + '.characterSpacing');
            }
        });
        return applied;
    }

    function setParagraphs(shape, paragraphs) {
        var applied = [];
        var count = Number(shape.TextFrame.TextRange.Paragraphs().Count);
        (paragraphs || []).forEach(function (update) {
            var index = Number(update.index);
            if (index < 1 || index > count) throw new Error('wps_js_paragraph_out_of_bounds');
            var format = shape.TextFrame.TextRange.Paragraphs(index, 1).ParagraphFormat;
            var style = update.style || {};
            var format2 = value(function () { return shape.TextFrame2.TextRange.Paragraphs(index, 1).ParagraphFormat; });
            var originalIndents = {};
            if (style.bullet) ['LeftIndent', 'RightIndent', 'FirstLineIndent'].forEach(function (field) {
                originalIndents[field] = value(function () { return format2[field]; });
            });
            var prefix = 'paragraphs[' + index + ']';
            if (style.alignment !== undefined) {
                var map = { left: 1, center: 2, right: 3, justify: 4 };
                if (map[style.alignment] === undefined) throw new Error('wps_js_invalid_paragraph_alignment');
                format.Alignment = map[style.alignment]; applied.push(prefix + '.alignment');
            }
            [['spaceBefore', 'SpaceBefore'], ['spaceAfter', 'SpaceAfter'], ['lineSpacing', 'SpaceWithin']]
                .forEach(function (mapping) {
                    if (style[mapping[0]] === undefined) return;
                    format[mapping[1]] = Number(style[mapping[0]]); applied.push(prefix + '.' + mapping[0]);
                });
            if (style.bullet) {
                var bullet = style.bullet;
                if (bullet.kind === 'none') format.Bullet.Visible = 0;
                else if (bullet.kind === 'bullet') {
                    format.Bullet.Visible = -1; format.Bullet.Type = 1;
                    if (bullet.character) format.Bullet.Character = String(bullet.character).charCodeAt(0);
                } else if (bullet.kind === 'number') {
                    format.Bullet.Visible = -1; format.Bullet.Type = 2;
                    if (bullet.startAt !== undefined) format.Bullet.StartValue = Number(bullet.startAt);
                } else throw new Error('wps_js_invalid_bullet_kind');
                applied.push(prefix + '.bullet');
                // Preserve unrequested geometry before applying any explicit indent updates.
                Object.keys(originalIndents).forEach(function (field) {
                    if (originalIndents[field] !== null && originalIndents[field] !== undefined &&
                        format2[field] !== originalIndents[field]) format2[field] = originalIndents[field];
                });
            }
            applied = applied.concat(WpsJsBridgeText.setParagraph(format2, style).map(function (field) { return prefix + '.' + field; }));
        });
        return applied;
    }

    function setTextFrame(shape, frame) {
        var applied = [];
        frame = frame || {};
        if (frame.orientation !== undefined) { WpsJsBridgeText.setOrientation(shape.TextFrame, frame.orientation); applied.push('orientation'); }
        ['marginLeft', 'marginRight', 'marginTop', 'marginBottom'].forEach(function (field) {
            if (frame[field] === undefined) return;
            shape.TextFrame[field.charAt(0).toUpperCase() + field.slice(1)] = Number(frame[field]);
            applied.push(field);
        });
        if (frame.verticalAlignment !== undefined) {
            var vertical = { top: 1, middle: 3, bottom: 4 };
            if (vertical[frame.verticalAlignment] === undefined) throw new Error('wps_js_invalid_vertical_alignment');
            shape.TextFrame.VerticalAnchor = vertical[frame.verticalAlignment]; applied.push('verticalAlignment');
        }
        if (frame.autoFit !== undefined) {
            var fit = { none: 0, fit_shape_to_text: 1, shrink_text_on_overflow: 2 };
            if (fit[frame.autoFit] === undefined) throw new Error('wps_js_invalid_autofit');
            shape.TextFrame.AutoSize = fit[frame.autoFit]; applied.push('autoFit');
        }
        if (frame.wordWrap !== undefined) { shape.TextFrame.WordWrap = frame.wordWrap ? -1 : 0; applied.push('wordWrap'); }
        return applied;
    }

    function setPictureBorderWidth(shape, width) {
        var line = shape.Line;
        line.Weight = Number(width);
        if (Number(line.Visible) !== 0 || nearly(Number(line.Weight), Number(width), 0.001)) return;
        // Some WPS hosts ignore Weight on noFill picture lines. Keep their
        // original visibility while materializing the requested hidden width.
        try {
            line.Visible = -1;
            line.Weight = Number(width);
        } finally {
            line.Visible = 0;
        }
    }

    function setPictureStyle(shape, style) {
        style = style || {};
        var applied = [];
        ['brightness', 'contrast', 'transparentBackground', 'transparencyColor'].forEach(function (field) {
            if (style[field] === undefined) return;
            var wanted = field === 'transparencyColor' ? rgb(style[field]) :
                (field === 'transparentBackground' ? (style[field] ? -1 : 0) : Number(style[field]));
            shape.PictureFormat[field.charAt(0).toUpperCase() + field.slice(1)] = wanted;
            applied.push(field);
        });
        var cropFields = ['cropLeft', 'cropTop', 'cropRight', 'cropBottom'];
        var crops = cropFields.some(function (field) { return style[field] !== undefined; });
        var frame = crops ? { Left: shape.Left, Top: shape.Top, Width: shape.Width, Height: shape.Height } : null;
        if (style.borderColor !== undefined) {
            shape.Line.Visible = -1; shape.Line.ForeColor.RGB = rgb(style.borderColor); applied.push('borderColor');
        }
        if (style.borderWidth !== undefined) { setPictureBorderWidth(shape, style.borderWidth); applied.push('borderWidth'); }
        cropFields.forEach(function (field) {
            if (style[field] === undefined) return;
            shape.PictureFormat[field.charAt(0).toUpperCase() + field.slice(1)] = Number(style[field]);
            applied.push(field);
        });
        if (frame && ['Left', 'Top', 'Width', 'Height'].some(function (field) {
            return Math.abs(Number(shape[field]) - Number(frame[field])) > 0.001;
        })) {
            var locked = value(function () { return shape.LockAspectRatio; });
            try {
                if (locked !== null) shape.LockAspectRatio = 0;
                var crop = shape.PictureFormat.Crop;
                var scaleX = frame.Width / Number(crop.ShapeWidth);
                var scaleY = frame.Height / Number(crop.ShapeHeight);
                var pictureWidth = Number(crop.PictureWidth) * scaleX;
                var pictureHeight = Number(crop.PictureHeight) * scaleY;
                var offsetX = Number(crop.PictureOffsetX) * scaleX;
                var offsetY = Number(crop.PictureOffsetY) * scaleY;
                if (![scaleX, scaleY, pictureWidth, pictureHeight].every(function (number) {
                    return isFinite(number) && number > 0;
                })) throw new Error('wps_js_picture_crop_extent_invalid');
                crop.ShapeWidth = frame.Width; crop.ShapeHeight = frame.Height;
                crop.PictureWidth = pictureWidth; crop.PictureHeight = pictureHeight;
                crop.PictureOffsetX = offsetX; crop.PictureOffsetY = offsetY;
                shape.Left = frame.Left; shape.Top = frame.Top;
            } finally { if (locked !== null) shape.LockAspectRatio = locked; }
        }
        if (style.rotation !== undefined) { shape.Rotation = Number(style.rotation); applied.push('rotation'); }
        if (style.colorMode !== undefined) {
            var modes = { automatic: 1, grayscale: 2 };
            if (modes[style.colorMode] === undefined) throw new Error('wps_js_invalid_picture_color_mode');
            shape.PictureFormat.ColorType = modes[style.colorMode]; applied.push('colorMode');
        }
        return applied;
    }

    function setConnectorStyle(shape, style) {
        style = style || {};
        var applied = WpsJsBridgeDrawing.setAdvancedLine(shape, style);
        if (style.lineDashStyle !== undefined) {
            WpsJsBridgeDrawing.setDash(shape, style.lineDashStyle); applied.push('lineDashStyle');
        }
        if (style.lineColor !== undefined) { shape.Line.ForeColor.RGB = rgb(style.lineColor); applied.push('lineColor'); }
        if (style.lineWidth !== undefined) { shape.Line.Weight = Number(style.lineWidth); applied.push('lineWidth'); }
        if (style.transparency !== undefined) { shape.Line.Transparency = Number(style.transparency); applied.push('transparency'); }
        var arrows = { none: 1, triangle: 2, open: 3, stealth: 4, diamond: 5, oval: 6 };
        if (style.beginArrow !== undefined) {
            if (arrows[style.beginArrow] === undefined) throw new Error('wps_js_invalid_connector_arrow');
            shape.Line.BeginArrowheadStyle = arrows[style.beginArrow]; applied.push('beginArrow');
        }
        if (style.endArrow !== undefined) {
            if (arrows[style.endArrow] === undefined) throw new Error('wps_js_invalid_connector_arrow');
            shape.Line.EndArrowheadStyle = arrows[style.endArrow]; applied.push('endArrow');
        }
        return applied;
    }

    function setConnectorType(shape, type) {
        var name = String(shape.Name);
        try {
            shape.ConnectorFormat.Type = type;
        } finally {
            // WPS renames default connectors when changing their native route type.
            if (String(shape.Name) !== name) shape.Name = name;
        }
    }

    function setConnectorRoute(slide, shape, operation) {
        var applied = [];
        ['begin', 'end'].forEach(function (name) {
            var endpoint = operation[name];
            if (!endpoint) return;
            var resolved = Identity.requireFrozenShape(slide, endpoint.target);
            var site = Number(endpoint.site);
            if (!Number.isInteger(site) || site < 1) throw new Error('wps_js_invalid_connector_site');
            if (name === 'begin') {
                value(function () { shape.ConnectorFormat.BeginDisconnect(); return true; }, false);
                shape.ConnectorFormat.BeginConnect(resolved.shape, site);
            } else {
                value(function () { shape.ConnectorFormat.EndDisconnect(); return true; }, false);
                shape.ConnectorFormat.EndConnect(resolved.shape, site);
            }
            applied.push(name);
        });
        if (operation.routeType !== undefined) {
            var routes = { straight: 1, elbow: 2 };
            if (routes[operation.routeType] === undefined) throw new Error('wps_js_invalid_connector_route');
            setConnectorType(shape, routes[operation.routeType]); applied.push('routeType');
        }
        if (applied.length > 0) value(function () { shape.RerouteConnections(); return true; }, false);
        return applied;
    }

    function requireTable(shape) {
        if (Identity.nativeBoolean(value(function () { return shape.HasTable; })) !== true) {
            throw new Error('wps_js_target_not_table');
        }
        return shape.Table;
    }

    function tableCell(table, row, column) {
        row = Number(row); column = Number(column);
        if (row < 1 || row > table.Rows.Count || column < 1 || column > table.Columns.Count) {
            throw new Error('wps_js_table_cell_out_of_range');
        }
        return table.Cell(row, column).Shape;
    }

    function setTableCells(shape, cells) {
        var table = requireTable(shape);
        var applied = [];
        var heights = [];
        for (var row = 1; row <= table.Rows.Count; row++) heights.push(Number(table.Rows.Item(row).Height));
        (cells || []).forEach(function (update) {
            tableCell(table, update.row, update.col).TextFrame.TextRange.Text = String(update.text || '');
            applied.push('cells[' + update.row + ',' + update.col + '].text');
        });
        heights.forEach(function (height, index) {
            if (Math.abs(Number(table.Rows.Item(index + 1).Height) - height) > 0.001) {
                table.Rows.Item(index + 1).Height = height;
            }
        });
        return applied;
    }

    function setTableCellStyles(shape, cells) {
        var table = requireTable(shape);
        var applied = [];
        (cells || []).forEach(function (update) {
            if (update.expectedText !== undefined && String(tableCell(table, update.row, update.col).TextFrame.TextRange.Text) !== update.expectedText) {
                throw new Error('stale_table_cell_text');
            }
        });
        (cells || []).forEach(function (update) {
            var cell = tableCell(table, update.row, update.col);
            var style = update.style || {};
            var prefix = 'cells[' + update.row + ',' + update.col + ']';
            if (style.fillColor !== undefined) { cell.Fill.Solid(); cell.Fill.ForeColor.RGB = rgb(style.fillColor); applied.push(prefix + '.fillColor'); }
            if (style.fontColor !== undefined) { cell.TextFrame.TextRange.Font.Color.RGB = rgb(style.fontColor); applied.push(prefix + '.fontColor'); }
            if (style.fontName !== undefined) { cell.TextFrame.TextRange.Font.Name = style.fontName; applied.push(prefix + '.fontName'); }
            if (style.fontSize !== undefined) { cell.TextFrame.TextRange.Font.Size = Number(style.fontSize); applied.push(prefix + '.fontSize'); }
            if (style.bold !== undefined) { cell.TextFrame.TextRange.Font.Bold = style.bold ? -1 : 0; applied.push(prefix + '.bold'); }
            if (style.italic !== undefined) { cell.TextFrame.TextRange.Font.Italic = style.italic ? -1 : 0; applied.push(prefix + '.italic'); }
            if (style.alignment !== undefined) {
                var align = { left: 1, center: 2, right: 3, justify: 4 };
                if (align[style.alignment] === undefined) throw new Error('wps_js_invalid_table_alignment');
                cell.TextFrame.TextRange.ParagraphFormat.Alignment = align[style.alignment];
                applied.push(prefix + '.alignment');
            }
            if (style.verticalAlignment !== undefined) {
                var vertical = { top: 1, middle: 3, bottom: 4 };
                if (vertical[style.verticalAlignment] === undefined) {
                    throw new Error('wps_js_invalid_table_vertical_alignment');
                }
                cell.TextFrame.VerticalAnchor = vertical[style.verticalAlignment];
                applied.push(prefix + '.verticalAlignment');
            }
            if (style.paragraph) {
                var paragraph = cell.TextFrame.TextRange.ParagraphFormat;
                var paragraphStyle = style.paragraph;
                if (paragraphStyle.alignment !== undefined) {
                    var paragraphAlign = { left: 1, center: 2, right: 3, justify: 4 };
                    if (paragraphAlign[paragraphStyle.alignment] === undefined) {
                        throw new Error('wps_js_invalid_table_paragraph_alignment');
                    }
                    paragraph.Alignment = paragraphAlign[paragraphStyle.alignment];
                }
                [['spaceBefore', 'SpaceBefore'], ['spaceAfter', 'SpaceAfter'],
                    ['lineSpacing', 'SpaceWithin']].forEach(function (mapping) {
                    if (paragraphStyle[mapping[0]] !== undefined) {
                        paragraph[mapping[1]] = Number(paragraphStyle[mapping[0]]);
                    }
                });
                applied.push(prefix + '.paragraph');
            }
            if (style.borders) {
                var borderIndexes = { top: 1, left: 2, bottom: 3, right: 4 };
                Object.keys(style.borders).forEach(function (edge) {
                    if (borderIndexes[edge] === undefined) throw new Error('wps_js_invalid_table_border');
                    var borderStyle = style.borders[edge] || {};
                    var border = shape.Table.Cell(Number(update.row), Number(update.col))
                        .Borders.Item(borderIndexes[edge]);
                    if (borderStyle.color !== undefined) border.ForeColor.RGB = rgb(borderStyle.color);
                    if (borderStyle.width !== undefined) border.Weight = Number(borderStyle.width);
                    if (borderStyle.dashStyle !== undefined) {
                        if (!Object.prototype.hasOwnProperty.call(WpsJsBridgeDrawing.dashValues, borderStyle.dashStyle)) throw new Error('wps_js_invalid_line_dash');
                        border.DashStyle = WpsJsBridgeDrawing.dashValues[borderStyle.dashStyle];
                    }
                    if (borderStyle.transparency !== undefined) border.Transparency = Number(borderStyle.transparency);
                });
                applied.push(prefix + '.borders');
            }
            if (style.ranges) { setTextRanges(cell, style.ranges); applied.push(prefix + '.ranges'); }
            if (style.paragraphs) { setParagraphs(cell, style.paragraphs); applied.push(prefix + '.paragraphs'); }
        });
        return applied;
    }

    function setTableDimensions(shape, operation) {
        var table = requireTable(shape);
        var applied = [];
        (operation.rows || []).forEach(function (update) {
            if (Number(update.index) < 1 || Number(update.index) > table.Rows.Count) throw new Error('wps_js_table_row_out_of_range');
            table.Rows.Item(Number(update.index)).Height = Number(update.height); applied.push('rows[' + update.index + '].height');
        });
        (operation.columns || []).forEach(function (update) {
            if (Number(update.index) < 1 || Number(update.index) > table.Columns.Count) throw new Error('wps_js_table_column_out_of_range');
            table.Columns.Item(Number(update.index)).Width = Number(update.width); applied.push('columns[' + update.index + '].width');
        });
        return applied;
    }

    function appendTableRows(shape, rows) {
        var table = requireTable(shape);
        var applied = [];
        (rows || []).forEach(function (definition) {
            var values = definition && Array.isArray(definition.cells) ? definition.cells : definition;
            if (!Array.isArray(values) || values.length !== table.Columns.Count) {
                throw new Error('wps_js_appended_table_row_width_mismatch');
            }
            var widths = [];
            for (var colIndex = 1; colIndex <= table.Columns.Count; colIndex++) {
                widths.push(Number(table.Columns.Item(colIndex).Width));
            }
            var rowHeights = [];
            for (var oldRow = 1; oldRow <= table.Rows.Count; oldRow++) rowHeights.push(Number(table.Rows.Item(oldRow).Height));
            var row = table.Rows.Add();
            var newRowIndex = Number(table.Rows.Count);
            // Rows.Add inherits a merged last row. Split only the new row before writing.
            for (var column = 1; column <= table.Columns.Count; column++) {
                var cell = table.Cell(newRowIndex, column);
                var width = Number(cell.Shape.Width);
                var spanWidth = Number(table.Columns.Item(column).Width);
                var span = 1;
                while (spanWidth < width - 0.25 && column + span <= table.Columns.Count) {
                    spanWidth += Number(table.Columns.Item(column + span).Width);
                    span++;
                }
                if (span > 1) {
                    if (!nearly(spanWidth, width, 0.25)) throw new Error('wps_js_new_table_row_merge_unqualified');
                    // Split creates equal subdivisions. Align its temporary grid to avoid extra columns.
                    for (var offset = 0; offset < span; offset++) {
                        if (!nearly(table.Columns.Item(column + offset).Width, width / span, 0.01)) {
                            table.Columns.Item(column + offset).Width = width / span;
                        }
                    }
                    cell.Split(1, span);
                    column += span - 1;
                }
            }
            if (table.Columns.Count !== widths.length) throw new Error('wps_js_new_table_row_columns_changed');
            widths.forEach(function (columnWidth, index) {
                if (!nearly(table.Columns.Item(index + 1).Width, columnWidth, 0.01)) {
                    table.Columns.Item(index + 1).Width = columnWidth;
                }
                if (!nearly(table.Cell(newRowIndex, index + 1).Shape.Width, columnWidth, 0.25)) {
                    throw new Error('wps_js_new_table_row_split_unverified');
                }
            });
            rowHeights.forEach(function (height, index) {
                if (!nearly(table.Rows.Item(index + 1).Height, height, 0.01)) table.Rows.Item(index + 1).Height = height;
            });
            var rowIndex = Number(table.Rows.Count);
            values.forEach(function (text, columnIndex) {
                table.Cell(rowIndex, columnIndex + 1).Shape.TextFrame.TextRange.Text =
                    text === null || text === undefined ? '' : String(text);
            });
            applied.push('rows[' + rowIndex + ']');
            if (!row) throw new Error('wps_js_table_row_add_failed');
        });
        return applied;
    }

    function requireChart(shape) {
        if (Number(value(function () { return shape.Type; }, -1)) !== 3) throw new Error('wps_js_target_not_chart');
        return shape.Chart;
    }

    function rejectChartSemanticData(operation) {
        var fields = ['data', 'categories', 'values', 'xValues', 'seriesName', 'semanticData'];
        var found = fields.some(function (field) { return operation[field] !== undefined; });
        if (!found && Array.isArray(operation.series)) {
            found = operation.series.some(function (series) {
                return fields.some(function (field) { return series[field] !== undefined; });
            });
        }
        if (found) {
            var error = new Error('wps_js_chart_semantic_data_not_supported');
            error.code = 'wps_js_chart_semantic_data_not_supported';
            throw error;
        }
    }

    function setChartProperties(shape, operation) {
        rejectChartSemanticData(operation);
        var chart = requireChart(shape);
        var applied = [];
        if (operation.title !== undefined) {
            chart.HasTitle = String(operation.title).length > 0;
            if (String(operation.title).length > 0) chart.ChartTitle.Text = String(operation.title);
            applied.push('title');
        }
        if (operation.hasLegend !== undefined) { chart.HasLegend = Boolean(operation.hasLegend); applied.push('hasLegend'); }
        if (operation.legendPosition !== undefined) {
            if (LEGEND_POSITIONS[operation.legendPosition] === undefined) throw new Error('wps_js_invalid_legend_position');
            chart.HasLegend = true; chart.Legend.Position = LEGEND_POSITIONS[operation.legendPosition]; applied.push('legendPosition');
        }
        if (operation.chartType !== undefined) { chart.ChartType = Number(operation.chartType); applied.push('chartType'); }
        return applied;
    }

    function setChartAxes(shape, updates) {
        var chart = requireChart(shape);
        var applied = [];
        (updates || []).forEach(function (update) {
            var axisType = update.kind === 'category' ? 1 : update.kind === 'value' ? 2 : 0;
            if (!axisType) throw new Error('wps_js_invalid_chart_axis_kind');
            var axis = chart.Axes(axisType, 1);
            var prefix = 'axes[' + update.kind + ']';
            if (update.title !== undefined) { axis.HasTitle = String(update.title).length > 0;
                if (String(update.title).length) axis.AxisTitle.Text = String(update.title); applied.push(prefix + '.title'); }
            if (update.hasMajorGridlines !== undefined) { axis.HasMajorGridlines = Boolean(update.hasMajorGridlines); applied.push(prefix + '.hasMajorGridlines'); }
            if (update.minimumScale !== undefined) { if (update.kind !== 'value') throw new Error('wps_js_chart_scale_value_axis_only'); axis.MinimumScale = Number(update.minimumScale); applied.push(prefix + '.minimumScale'); }
            if (update.maximumScale !== undefined) { if (update.kind !== 'value') throw new Error('wps_js_chart_scale_value_axis_only'); axis.MaximumScale = Number(update.maximumScale); applied.push(prefix + '.maximumScale'); }
        });
        return applied;
    }

    function setChartSeries(shape, updates) {
        var chart = requireChart(shape);
        var collection = chart.SeriesCollection();
        var applied = [];
        (updates || []).forEach(function (update) {
            rejectChartSemanticData(update);
            var index = Number(update.index);
            if (index < 1 || index > collection.Count) throw new Error('wps_js_chart_series_out_of_range');
            var series = collection.Item(index);
            if (update.hasDataLabels !== undefined) {
                if (update.hasDataLabels) enableSeriesLabels(series);
                else value(function () { series.DataLabels().Delete(); return true; }, false);
                applied.push('series[' + index + '].hasDataLabels');
            }
            if (update.fillColor !== undefined) {
                series.Format.Fill.ForeColor.RGB = rgb(update.fillColor);
                applied.push('series[' + index + '].fillColor');
            }
        });
        return applied;
    }

    function enableSeriesLabels(series) {
        var points = value(function () { return series.Points(); }, null);
        if (points && points.Count > 0) {
            for (var index = 1; index <= points.Count; index++) {
                var point = points.Item(index);
                if (Identity.nativeBoolean(point.HasDataLabel) !== true) point.HasDataLabel = true;
            }
        } else if (Identity.nativeBoolean(series.HasDataLabels) !== true) series.ApplyDataLabels();
        if (Identity.nativeBoolean(series.HasDataLabels) !== true) {
            throw new Error('wps_js_chart_labels_enable_unverified');
        }
    }

    function operationType(operation) {
        return String(operation.type || operation.action || operation.method || '');
    }

    function assertOperationSupported(operation) {
        var type = operationType(operation);
        if (BATCH_OPERATION_TYPES.indexOf(type) < 0) {
            throw new Error('wps_js_batch_operation_not_supported:' + type);
        }
        if (/^set_?chart/i.test(type)) rejectChartSemanticData(operation);
        return type;
    }

    function geometry(shape) {
        return { left: Number(shape.Left), top: Number(shape.Top),
            width: Number(shape.Width), height: Number(shape.Height) };
    }

    function restoreGeometry(shape, state) {
        setPosition(shape, state);
    }

    function resultKind(type) {
        if (/Text|Paragraph/.test(type)) return 'text';
        if (/Table/.test(type)) return 'table';
        if (/Chart/.test(type)) return 'chart';
        if (/Picture/.test(type)) return 'picture';
        if (/Connector/.test(type)) return 'connector';
        return 'shape';
    }

    function preflightOperation(slide, operation) {
        var type = assertOperationSupported(operation);
        var resolved = Identity.requireFrozenShape(slide, operation);
        if (/Text|Paragraph/.test(type) &&
            Identity.nativeBoolean(value(function () { return resolved.shape.HasTextFrame; })) !== true) {
            throw new Error('wps_js_target_not_text_capable');
        }
        if (/Table/.test(type)) requireTable(resolved.shape);
        if (type === 'setShapeGeometry') WpsJsBridgeDrawing.assertGeometryChange(slide, resolved.shape, operation.preset);
        if (type === 'setTableStyle') {
            var nativeStyle = WpsJsBridgeTable.style(resolved.shape.Table);
            if (!nativeStyle.styleId || typeof nativeStyle.firstRow !== 'boolean' || typeof nativeStyle.firstColumn !== 'boolean') {
                throw new Error('capability_unavailable:table_theme_flags_not_reversible');
            }
        }
        if (type === 'editTableTopology') {
            var tableState = snapshotTable(resolved.shape);
            if (!tableState.topology || tableState.cells.some(function (cell) {
                return !cell.fillState || cell.fillState.type !== 1 || cell.fillState.foreground.type !== 1 || !WpsJsBridgeTable.reversibleBorders(cell.borders);
            })) throw new Error('capability_unavailable:table_style_not_reversible');
        }
        if (/Chart/.test(type)) requireChart(resolved.shape);
        return { type: type, resolved: resolved };
    }

    function applyOperation(slide, operation, preflight) {
        var type = preflight.type;
        var resolved = preflight.resolved;
        var shape = resolved.shape;
        var applied = [];
        var beforeGeometry = null;
        if (operation.preserveGeometry) beforeGeometry = geometry(shape);
        if (['setShapeText', 'set_shape_text', 'setTextboxText', 'setTextBoxText',
            'set_textbox_text'].indexOf(type) >= 0) {
            var newText = operation.text === undefined || operation.text === null ? '' : String(operation.text);
            if (operation.range) {
                var replacement = WpsJsBridgeText.replacementState(snapshotText(shape),
                    operation.range.start, operation.range.length, newText);
                shape.TextFrame.TextRange.Characters(operation.range.start, operation.range.length).Text = newText;
                if (String(shape.TextFrame.TextRange.Text).replace(/\r$/, '') !== replacement.text) throw new Error('wps_js_text_range_write_mismatch');
                restoreText(shape, replacement);
            } else shape.TextFrame.TextRange.Text = newText;
            applied = ['text'];
        } else if (['setShapePosition', 'set_shape_position'].indexOf(type) >= 0) {
            applied = setPosition(shape, operation);
        } else if (['setTextBoxStyle', 'setTextboxStyle', 'set_textbox_style'].indexOf(type) >= 0) {
            applied = setTextStyle(shape, operation.style || operation);
        } else if (['setTextRangeStyle', 'set_text_range_style'].indexOf(type) >= 0) {
            applied = setTextRanges(shape, operation.ranges);
        } else if (['setParagraphStyle', 'set_paragraph_style'].indexOf(type) >= 0) {
            applied = setParagraphs(shape, operation.paragraphs);
        } else if (['setTextFrame', 'set_text_frame'].indexOf(type) >= 0) {
            applied = setTextFrame(shape, operation.frame);
        } else if (['setShapeStyle', 'set_shape_style'].indexOf(type) >= 0) {
            applied = setShapeStyle(shape, operation.style || operation);
        } else if (type === 'setShapeGeometry') {
            applied = WpsJsBridgeDrawing.setGeometry(shape, operation.preset);
        } else if (['setPictureStyle', 'set_picture_style'].indexOf(type) >= 0) {
            applied = setPictureStyle(shape, operation.style || operation);
        } else if (['setConnectorStyle', 'set_connector_style'].indexOf(type) >= 0) {
            applied = setConnectorStyle(shape, operation.style || operation);
        } else if (['setConnectorRoute', 'set_connector_route'].indexOf(type) >= 0) {
            applied = setConnectorRoute(slide, shape, operation);
        } else if (['setTableCells', 'set_table_cells'].indexOf(type) >= 0) {
            applied = setTableCells(shape, operation.cells);
        } else if (type === 'setTableStyle') {
            WpsJsBridgeTable.setStyle(requireTable(shape), operation.style || {});
            applied = ['table.tableStyle', 'table.cells'];
        } else if (type === 'editTableTopology') {
            var desired = WpsJsBridgeTable.transitionState(snapshotTable(shape), operation.transition), tableIssues = [];
            restoreTable(shape, desired, tableIssues, Identity.slideId(slide));
            if (tableIssues.length) throw new Error('wps_js_table_transition_failed:' + JSON.stringify(tableIssues));
            applied = ['table.topology', 'table.cells', 'table.dimensions'];
        } else if (['setTableCellStyles', 'set_table_cell_styles'].indexOf(type) >= 0) {
            applied = setTableCellStyles(shape, operation.cells);
        } else if (['appendTableRows', 'append_table_rows'].indexOf(type) >= 0) {
            applied = appendTableRows(shape, operation.rows);
        } else if (['setTableDimensions', 'set_table_dimensions'].indexOf(type) >= 0) {
            applied = setTableDimensions(shape, operation);
        } else if (['setChartProperties', 'set_chart_properties'].indexOf(type) >= 0) {
            applied = setChartProperties(shape, operation);
        } else if (['setChartAxisProperties', 'set_chart_axis_properties'].indexOf(type) >= 0) {
            applied = setChartAxes(shape, operation.axes);
        } else if (['setChartSeriesProperties', 'set_chart_series_properties'].indexOf(type) >= 0) {
            applied = setChartSeries(shape, operation.series);
        }
        if (beforeGeometry) restoreGeometry(shape, beforeGeometry);
        if (applied.length === 0) throw new Error('wps_js_batch_operation_applied_nothing:' + type);
        return { operationIndex: operation.operationIndex, operationId: operation.operationId,
            kind: resultKind(type), name: String(shape.Name),
            nativeShapeId: resolved.nativeShapeId, shapeIndex: resolved.shapeIndex,
            target: operation, applied: applied };
    }

    function editFailureData(presentation, slide, operations, failed, transactional, details) {
        return Object.assign({ partialMutation: !transactional, transactional: transactional,
            rolledBack: false, rollbackVerified: false, rollbackAttempted: false,
            wroteToWps: false, presentationId: presentation ? String(presentation.Name) : null,
            slideIndex: slide ? Number(slide.SlideIndex) : null,
            total: operations.length, created: [], changed: [], failed: failed,
            succeeded: 0, failedCount: failed.length }, details || {});
    }

    async function editSlideBatch(params, expectedPresentationRef) {
        params = params || {};
        var operations = Array.isArray(params.operations) ? params.operations : [];
        var presentation = null;
        var slide = null;
        var before = null;
        var prepared = [];
        var compiledTransaction = Boolean(String(params.compiledPlanFingerprint || '').trim());
        var stopOnError = compiledTransaction || params.stopOnError === true;
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            slide = Identity.requireSlide(presentation, params.slideIndex || 1, params.nativeSlideId);
            if (operations.length < 1) throw new Error('wps_js_batch_operations_required');
            operations.forEach(function (operation) {
                if (/^set_?chart/i.test(operationType(operation))) rejectChartSemanticData(operation);
            });
            if (compiledTransaction) {
                operations.forEach(function (operation) {
                    prepared.push(preflightOperation(slide, operation));
                });
            }
            Identity.assertWritable(presentation);
            if (compiledTransaction) {
                var providedSnapshots = Array.isArray(params.transactionSnapshots) ?
                    params.transactionSnapshots : [];
                if (providedSnapshots.length) {
                    var baseline = [];
                    for (var shapeIndex = 1; shapeIndex <= slide.Shapes.Count; shapeIndex++) {
                        baseline.push(Identity.shapeId(slide.Shapes.Item(shapeIndex)));
                    }
                    before = { schemaVersion: 1,
                        presentationRef: Identity.runtimeLocator(presentation),
                        presentationFingerprint: Capture.presentationScene(presentation).fingerprint,
                        pageSize: { width: presentation.PageSetup.SlideWidth,
                            height: presentation.PageSetup.SlideHeight },
                        slides: [{ slideIndex: Number(slide.SlideIndex),
                            nativeSlideId: Identity.slideId(slide), shapes: providedSnapshots,
                            baselineZOrderNativeShapeIds: baseline }] };
                } else {
                    before = snapshotPresentation(presentation, [Number(slide.SlideIndex)], []);
                }
            }
        } catch (error) {
            var rejected = editFailureData(presentation, slide, operations, [{ operationIndex: 0,
                type: operations[0] ? operationType(operations[0]) : '', error: Result.errorText(error) }],
            compiledTransaction, {
                protection: error.protection || null
            });
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error), rejected);
        }
        var changed = [];
        var failed = [];
        var mutationAttempted = false;
        for (var index = 0; index < operations.length; index++) {
            var operation = operations[index];
            try {
                var operationPreflight = compiledTransaction ? prepared[index] :
                    preflightOperation(slide, operation);
                Identity.assertWritable(presentation);
                mutationAttempted = true;
                changed.push(applyOperation(slide, operation, operationPreflight));
            } catch (error) {
                failed.push({ operationIndex: index, type: operationType(operation),
                    error: Result.errorText(error), reasonCode: error.code || Result.errorText(error),
                    protection: error.protection || null });
                if (stopOnError) break;
            }
        }
        var rollback = compiledTransaction && failed.length && mutationAttempted ?
            await restoreSnapshot(presentation, before, []) :
            { rolledBack: false, rollbackVerified: false, rollbackIssues: [] };
        if (rollback.rolledBack) changed = [];
        var data = { partialMutation: !compiledTransaction, transactional: compiledTransaction,
            rolledBack: rollback.rolledBack, rollbackVerified: rollback.rollbackVerified,
            rollbackAttempted: rollback.rolledBack, rollbackIssues: rollback.rollbackIssues || [],
            recoveryCheckpoint: rollback.recoveryCheckpoint || null,
            wroteToWps: rollback.rollbackVerified ? false :
                (changed.length > 0 || mutationAttempted && failed.length > 0),
            protection: failed.length ? failed[0].protection : null,
            presentationId: String(presentation.Name), slideIndex: Number(slide.SlideIndex),
            total: operations.length, created: [], changed: changed, failed: failed,
            succeeded: changed.length, failedCount: failed.length };
        if (!failed.length && Array.isArray(params.postWriteReadbackTargets) &&
            params.postWriteReadbackTargets.length) {
            data.postWriteReadback = Capture.readTargets({
                presentationId: Identity.runtimeLocator(presentation),
                slideIndex: Number(slide.SlideIndex), nativeSlideId: Identity.slideId(slide),
                targets: params.postWriteReadbackTargets, includeRollbackSnapshot: false
            }, Identity.runtimeLocator(presentation));
        }
        return failed.length ? Result.failure(failed[0].reasonCode || 'wps_js_batch_operation_failed',
            'editSlideBatch completed with ' + failed.length + ' failed operations', data) :
            Result.success(data);
    }

    function shapeRecords(slide, bindings) {
        return (bindings || []).map(function (binding) {
            var resolved = Identity.requireFrozenShape(slide, binding);
            return { shape: resolved.shape, shapeIndex: resolved.shapeIndex,
                nativeShapeId: resolved.nativeShapeId, binding: binding,
                part: String(binding.part || ''), canonicalPart: String(binding.canonicalPart || ''),
                itemId: String(binding.itemId || ''), contentBlockId: String(binding.contentBlockId || '') };
        }).sort(function (left, right) { return left.shapeIndex - right.shapeIndex; });
    }

    function envelope(records) {
        if (!records.length) return null;
        var left = Infinity; var top = Infinity; var right = -Infinity; var bottom = -Infinity;
        records.forEach(function (record) {
            var current = geometry(record.shape);
            left = Math.min(left, current.left); top = Math.min(top, current.top);
            right = Math.max(right, current.left + current.width);
            bottom = Math.max(bottom, current.top + current.height);
        });
        return { left: left, top: top, width: right - left, height: bottom - top };
    }

    function overlap(left, top, width, height, other) {
        return Math.max(0, Math.min(left + width, other.left + other.width) - Math.max(left, other.left)) *
            Math.max(0, Math.min(top + height, other.top + other.height) - Math.max(top, other.top));
    }

    function placementClear(slide, ignoredIds, bounds, pageSize) {
        if (bounds.left < 8 || bounds.top < 8 || bounds.left + bounds.width > pageSize.width - 8 ||
            bounds.top + bounds.height > pageSize.height - 8) return false;
        var slideArea = Math.max(1, pageSize.width * pageSize.height);
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var shape = slide.Shapes.Item(index);
            if (ignoredIds[String(Identity.shapeId(shape))]) continue;
            var other = geometry(shape);
            if (other.width * other.height / slideArea >= 0.8) continue;
            if (overlap(bounds.left, bounds.top, bounds.width, bounds.height, other) > 0.5) return false;
        }
        return true;
    }

    function placementCandidate(reference, copy, direction, alignment, gap) {
        var result = { left: copy.left, top: copy.top, width: copy.width, height: copy.height };
        if (direction === 'below' || direction === 'above') {
            result.top = direction === 'below' ? reference.top + reference.height + gap :
                reference.top - gap - copy.height;
            result.left = alignment === 'center' ? reference.left + (reference.width - copy.width) / 2 :
                alignment === 'end' ? reference.left + reference.width - copy.width : reference.left;
        } else if (direction === 'left' || direction === 'right') {
            result.left = direction === 'right' ? reference.left + reference.width + gap :
                reference.left - gap - copy.width;
            result.top = alignment === 'center' ? reference.top + (reference.height - copy.height) / 2 :
                alignment === 'end' ? reference.top + reference.height - copy.height : reference.top;
        } else throw new Error('wps_js_duplicate_direction_invalid');
        return result;
    }

    function resolvePlacement(slide, ignoredIds, reference, copy, policy, spacing, pageSize) {
        policy = policy || {};
        var direction = String(policy.direction || 'auto');
        var alignment = String(policy.alignment || 'start');
        var intent = String(policy.gapIntent || 'preferred');
        var minimum = Math.max(8, Number(spacing && spacing.minimumGap || 8));
        var preferred = Math.max(minimum, Number(spacing && spacing.preferredGap || 12));
        var gaps = intent === 'exact' ? [Number(policy.gap)] : intent === 'minimum' ? [minimum] :
            unique([preferred, minimum]);
        if (gaps.some(function (gap) { return !isFinite(gap) || gap < 0; })) {
            throw new Error('wps_js_duplicate_gap_invalid');
        }
        var directions = direction === 'auto' ? ['right', 'below', 'left', 'above'] : [direction];
        for (var gapIndex = 0; gapIndex < gaps.length; gapIndex++) {
            for (var directionIndex = 0; directionIndex < directions.length; directionIndex++) {
                var candidate = placementCandidate(reference, copy, directions[directionIndex], alignment, gaps[gapIndex]);
                if (placementClear(slide, ignoredIds, candidate, pageSize)) {
                    return { bounds: candidate, relation: { direction: direction,
                        resolvedDirection: directions[directionIndex], alignment: alignment,
                        gapIntent: intent, actualGap: gaps[gapIndex] } };
                }
            }
        }
        return null;
    }

    async function copyShape(presentation, slide, source) {
        var existing = {};
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            existing[String(Identity.shapeId(slide.Shapes.Item(index)))] = true;
        }
        function createdShapes() {
            var created = [];
            for (var index = 1; index <= slide.Shapes.Count; index++) {
                var candidate = slide.Shapes.Item(index);
                if (!existing[String(Identity.shapeId(candidate))]) created.push(candidate);
            }
            return created;
        }
        try {
            var location = Identity.findShapeById(slide, Identity.shapeId(source));
            var path = location.groupPath || [];
            var root = path.length > 1 ? slide.Shapes.Item(path[0]) : source;
            var created = [];
            var attempts = 0;
            // WPP can return an empty paste while its clipboard is still preparing.
            // Retry only a verified zero-creation result, never a partial native write.
            while (attempts < 3 && created.length === 0) {
                attempts++;
                root.Copy();
                await new Promise(function (resolve) { setTimeout(resolve, 50); });
                Identity.assertWritable(presentation);
                slide.Shapes.Paste();
                created = createdShapes();
            }
            if (created.length !== 1) throw new Error('wps_js_duplicate_identity_ambiguous: source=' +
                String(root.Name) + ', expected=1, actual=' + created.length);
            var clone = created[0];
            // Extract from the copied group; the source and unrelated members stay untouched.
            for (var depth = 1; depth < path.length; depth++) {
                var selectedId = Identity.shapeId(clone.GroupItems.Item(path[depth]));
                clone.Ungroup();
                var selected = Identity.findShapeById(slide, selectedId);
                var extractedRoots = {};
                while (selected && selected.groupPath && selected.groupPath.length > 1) {
                    var container = slide.Shapes.Item(selected.groupPath[0]);
                    var containerId = String(Identity.shapeId(container));
                    if (existing[containerId] || extractedRoots[containerId]) throw new Error('wps_js_duplicate_member_identity_ambiguous');
                    extractedRoots[containerId] = true;
                    // WPS may expose flattened members until Ungroup restores an inner group.
                    container.Ungroup();
                    selected = Identity.findShapeById(slide, selectedId);
                }
                if (!selected) throw new Error('wps_js_duplicate_member_identity_lost');
                createdShapes().forEach(function (candidate) {
                    if (String(Identity.shapeId(candidate)) !== String(selectedId)) candidate.Delete();
                });
                clone = selected.shape;
            }
            return { shape: clone, pasteAttempts: attempts };
        } catch (error) {
            createdShapes().forEach(function (candidate) {
                try { candidate.Delete(); } catch (_cleanupError) {}
            });
            var failure = new Error(Result.errorText(error));
            failure.nativeCreatedIds = createdShapes().map(Identity.shapeId);
            throw failure;
        }
    }

    function duplicateSignature(shape, originLeft, originTop) {
        var type = Number(value(function () { return shape.Type; }, -1));
        var range = value(function () { return shape.TextFrame.TextRange; }, null);
        var sourcePath = type === 11 || type === 13 ?
            value(function () { return shape.LinkFormat.SourceFullName; }) : null;
        var members = value(function () { return shape.GroupItems; }, null);
        var groupMembers = [];
        var memberCount = members ? Number(value(function () { return members.Count; }, 0)) : 0;
        for (var index = 1; index <= memberCount; index++) {
            groupMembers.push(duplicateSignature(members.Item(index), originLeft, originTop));
        }
        return { type: type,
            autoShapeType: value(function () { return shape.AutoShapeType; }),
            placeholderType: value(function () { return shape.PlaceholderFormat.Type; }),
            left: Number(shape.Left) - Number(originLeft), top: Number(shape.Top) - Number(originTop),
            width: Number(shape.Width), height: Number(shape.Height),
            text: range ? String(value(function () { return range.Text; }, '') || '') : null,
            fontName: range ? value(function () { return range.Font.Name; }) : null,
            fontSize: range ? value(function () { return range.Font.Size; }) : null,
            fontBold: range ? value(function () { return range.Font.Bold; }) : null,
            fontColor: range ? value(function () { return range.Font.Color.RGB; }) : null,
            fillVisible: value(function () { return shape.Fill.Visible; }),
            fillColor: value(function () { return shape.Fill.ForeColor.RGB; }),
            fillTransparency: value(function () { return shape.Fill.Transparency; }),
            lineVisible: value(function () { return shape.Line.Visible; }),
            lineColor: value(function () { return shape.Line.ForeColor.RGB; }),
            lineTransparency: value(function () { return shape.Line.Transparency; }),
            lineDashStyle: value(function () { return shape.Line.DashStyle; }),
            lineWeight: value(function () { return shape.Line.Weight; }),
            rotation: value(function () { return shape.Rotation; }, 0),
            pictureLinked: type === 11 || Boolean(sourcePath), pictureSourcePath: sourcePath,
            pictureColorType: type === 11 || type === 13 ?
                value(function () { return shape.PictureFormat.ColorType; }) : null,
            cropLeft: type === 11 || type === 13 ?
                value(function () { return shape.PictureFormat.CropLeft; }) : null,
            cropTop: type === 11 || type === 13 ?
                value(function () { return shape.PictureFormat.CropTop; }) : null,
            cropRight: type === 11 || type === 13 ?
                value(function () { return shape.PictureFormat.CropRight; }) : null,
            cropBottom: type === 11 || type === 13 ?
                value(function () { return shape.PictureFormat.CropBottom; }) : null,
            groupMembers: groupMembers };
    }

    function duplicateSignatureMismatches(expected, actual, prefix) {
        var issues = [];
        var exactFields = ['type', 'autoShapeType', 'placeholderType', 'text', 'fontName',
            'fontBold', 'fontColor', 'fillVisible', 'fillColor', 'lineVisible', 'lineColor',
            'lineDashStyle', 'pictureLinked', 'pictureSourcePath', 'pictureColorType'];
        var numericFields = ['left', 'top', 'width', 'height', 'rotation', 'fontSize',
            'fillTransparency', 'lineTransparency', 'lineWeight', 'cropLeft', 'cropTop',
            'cropRight', 'cropBottom'];
        exactFields.forEach(function (field) {
            if (String(expected[field]) !== String(actual[field])) issues.push((prefix || '') + field);
        });
        numericFields.forEach(function (field) {
            if (expected[field] === null && actual[field] === null) return;
            if (expected[field] === null || actual[field] === null ||
                !nearly(expected[field], actual[field], 0.15)) issues.push((prefix || '') + field);
        });
        if (expected.groupMembers.length !== actual.groupMembers.length) {
            issues.push((prefix || '') + 'groupMembers.count');
        } else expected.groupMembers.forEach(function (member, index) {
            issues = issues.concat(duplicateSignatureMismatches(member,
                actual.groupMembers[index], (prefix || '') + 'groupMembers[' + index + '].'));
        });
        return issues;
    }

    function textFit(shape) {
        if (Identity.nativeBoolean(value(function () { return shape.HasTextFrame; })) !== true) return null;
        var text = String(value(function () { return shape.TextFrame.TextRange.Text; }, '') || '');
        if (!text) return null;
        var marginTop = Number(value(function () { return shape.TextFrame.MarginTop; }, 0));
        var marginBottom = Number(value(function () { return shape.TextFrame.MarginBottom; }, 0));
        var boundHeight = value(function () { return shape.TextFrame2.TextRange.BoundHeight; }, null);
        if (boundHeight === null) {
            boundHeight = value(function () { return shape.TextFrame.TextRange.BoundHeight; }, null);
        }
        if (boundHeight === null || !isFinite(Number(boundHeight))) {
            throw new Error('wps_js_text_bound_height_unavailable');
        }
        var availableHeight = Math.max(0, Number(shape.Height) - marginTop - marginBottom);
        return { boundHeight: Number(boundHeight), availableHeight: availableHeight,
            requiredHeight: Number(boundHeight) + marginTop + marginBottom,
            overflow: Number(boundHeight) > availableHeight + 0.25 };
    }

    function componentBackground(records) {
        var matches = records.filter(function (record) {
            var part = String(record.canonicalPart || record.part || '').toLowerCase();
            return part === 'background' || /(^|_)(bg|band|background|table)($|_)/.test(part);
        }).sort(function (left, right) {
            return Number(right.shape.Width) * Number(right.shape.Height) -
                Number(left.shape.Width) * Number(left.shape.Height);
        });
        if (matches.length !== 1) {
            throw new Error('PPT_DUPLICATE_COMPONENT_BACKGROUND_REQUIRED:found=' + matches.length);
        }
        var background = geometry(matches[0].shape);
        records.forEach(function (record) {
            var bounds = geometry(record.shape);
            if (bounds.left < background.left - 2 || bounds.top < background.top - 2 ||
                bounds.left + bounds.width > background.left + background.width + 2) {
                throw new Error('PPT_DUPLICATE_COMPONENT_INTERNAL_LAYOUT_INCONSISTENT:part=' +
                    (record.canonicalPart || record.part));
            }
        });
        return matches[0];
    }

    function fitComponentContent(presentation, records) {
        var background = componentBackground(records);
        var plans = [];
        var backgroundBottom = Number(background.shape.Top) + Number(background.shape.Height);
        var contentBottomBefore = Number(background.shape.Top);
        records.forEach(function (record) {
            if (record !== background) {
                contentBottomBefore = Math.max(contentBottomBefore,
                    Number(record.shape.Top) + Number(record.shape.Height));
            }
        });
        var bottomPadding = Math.max(4, Math.min(12, backgroundBottom - contentBottomBefore));
        var requiredBottom = Number(background.shape.Top) + 42;
        records.forEach(function (record) {
            if (record === background) return;
            var fit = textFit(record.shape);
            var targetHeight = fit ? Math.max(2, fit.requiredHeight) : Number(record.shape.Height);
            if (fit) plans.push({ record: record, before: fit, targetHeight: targetHeight });
            requiredBottom = Math.max(requiredBottom, Number(record.shape.Top) + targetHeight);
        });
        var backgroundHeight = Math.max(Number(background.shape.Height),
            requiredBottom - Number(background.shape.Top) + bottomPadding);
        if (requiredBottom + bottomPadding < backgroundBottom - 0.25) {
            backgroundHeight = Math.max(42,
                requiredBottom - Number(background.shape.Top) + bottomPadding);
        }
        var pageHeight = Number(presentation.PageSetup.SlideHeight);
        if (Number(background.shape.Top) < 0 || Number(background.shape.Top) + backgroundHeight > pageHeight) {
            throw new Error('PPT_DUPLICATE_COMPONENT_TEXT_OVERFLOW:page_bounds');
        }
        var changedIds = [];
        plans.forEach(function (plan) {
            if (!nearly(plan.record.shape.Height, plan.targetHeight, 0.01)) {
                plan.record.shape.Height = plan.targetHeight;
                changedIds.push(Number(plan.record.nativeShapeId));
            }
        });
        if (!nearly(background.shape.Height, backgroundHeight, 0.01)) {
            background.shape.Height = backgroundHeight;
            changedIds.push(Number(background.nativeShapeId));
        }
        var items = [];
        plans.forEach(function (plan) {
            var after = textFit(plan.record.shape);
            items.push({ part: plan.record.canonicalPart || plan.record.part,
                nativeShapeId: Number(plan.record.nativeShapeId), overflow: after.overflow,
                boundHeight: after.boundHeight, availableHeight: after.availableHeight });
            if (after.overflow) throw new Error('PPT_DUPLICATE_COMPONENT_TEXT_OVERFLOW:part=' +
                (plan.record.canonicalPart || plan.record.part));
        });
        var backgroundBounds = geometry(background.shape);
        records.forEach(function (record) {
            var bounds = geometry(record.shape);
            if (bounds.left < backgroundBounds.left - 2 || bounds.top < backgroundBounds.top - 2 ||
                bounds.left + bounds.width > backgroundBounds.left + backgroundBounds.width + 2 ||
                bounds.top + bounds.height > backgroundBounds.top + backgroundBounds.height + 2) {
                throw new Error('PPT_DUPLICATE_COMPONENT_INTERNAL_LAYOUT_INCONSISTENT:part=' +
                    (record.canonicalPart || record.part));
            }
        });
        return { passed: true, items: items, changedObjectIds: unique(changedIds),
            bounds: envelope(records) };
    }

    function moveRecords(records, deltaLeft, deltaTop) {
        records.forEach(function (record) {
            record.shape.Left = Number(record.shape.Left) + Number(deltaLeft);
            record.shape.Top = Number(record.shape.Top) + Number(deltaTop);
        });
    }

    function deleteCreated(slide, ids) {
        ids.slice().reverse().forEach(function (id) {
            var found = Identity.findShapeById(slide, id);
            if (found) found.shape.Delete();
        });
    }

    function nextComponentIndex(slide) {
        var maximum = 0;
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var match = String(slide.Shapes.Item(index).Name || '')
                .match(/^R[0-9]+_.+?_([0-9]+)(?:__CB_[a-zA-Z0-9-]+)?_/);
            if (match) maximum = Math.max(maximum, Number(match[1]));
        }
        return maximum + 1;
    }

    function createdBinding(presentation, slide, records, componentId, objectId) {
        return { presentationRef: Identity.runtimeLocator(presentation),
            nativeSlideId: Identity.slideId(slide), slideIndex: Number(slide.SlideIndex),
            nativeShapeIds: records.map(function (record) { return record.nativeShapeId; }),
            shapeNames: records.map(function (record) { return String(record.shape.Name); }),
            shapeIndexes: records.map(function (record) {
                return Identity.findShapeById(slide, record.nativeShapeId).shapeIndex;
            }), componentInstanceId: componentId || '', objectId: objectId || '' };
    }

    async function duplicate(params, expectedPresentationRef, componentMode) {
        params = params || {};
        var presentation = null; var slide = null; var sourceRecords = [];
        var sourceSnapshot = null; var createdIds = []; var creationReceipts = [];
        var created = []; var placements = []; var verificationItems = [];
        var overrideItems = []; var contentFitItems = []; var copyDiagnostics = [];
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            slide = Identity.requireSlide(presentation, params.slideIndex, params.nativeSlideId);
            sourceRecords = componentMode ? shapeRecords(slide, params.componentBindings) :
                shapeRecords(slide, [params.sourceBinding]);
            if (!sourceRecords.length) throw new Error(componentMode ?
                'PPT_DUPLICATE_COMPONENT_BINDINGS_REQUIRED' : 'PPT_DUPLICATE_OBJECT_BINDING_REQUIRED');
            Identity.assertWritable(presentation);
            sourceSnapshot = snapshotPresentation(presentation, [Number(slide.SlideIndex)], [{
                slideIndex: Number(slide.SlideIndex),
                nativeShapeIds: sourceRecords.map(function (record) { return record.nativeShapeId; })
            }]);
            var sourceBounds = envelope(sourceRecords);
            var pageSize = { width: Number(presentation.PageSetup.SlideWidth),
                height: Number(presentation.PageSetup.SlideHeight) };
            var sourceIds = {};
            sourceRecords.forEach(function (record) { sourceIds[String(record.nativeShapeId)] = true; });
            var referenceRecords = params.reference && params.reference.kind !== 'source' ?
                shapeRecords(slide, params.reference.bindings || []) : sourceRecords;
            var nextReference = referenceRecords;
            var copyCount = Math.max(1, Math.min(20, Number(params.copyCount || 1)));
            for (var copyIndex = 0; copyIndex < copyCount; copyIndex++) {
                var placement = resolvePlacement(slide, sourceIds, envelope(nextReference), sourceBounds,
                    params.relativePlacement, params.spacingPolicy, pageSize);
                if (!placement) throw new Error('PPT_DUPLICATE_RELATIVE_PLACEMENT_NO_SPACE');
                Identity.assertWritable(presentation);
                var deltaLeft = placement.bounds.left - sourceBounds.left;
                var deltaTop = placement.bounds.top - sourceBounds.top;
                var cloneRecords = [];
                var componentType = componentMode ?
                    String(params.componentBindings[0].componentType || 'component')
                        .replace(/[^a-zA-Z0-9_]/g, '_') : '';
                var componentId = componentMode ?
                    'R4_' + componentType + '_' + nextComponentIndex(slide) : '';
                for (var sourceIndex = 0; sourceIndex < sourceRecords.length; sourceIndex++) {
                    var record = sourceRecords[sourceIndex];
                    var copied = await copyShape(presentation, slide, record.shape);
                    var clone = copied.shape;
                    if (copied.pasteAttempts > 1) copyDiagnostics.push({
                        sourceNativeShapeId: record.nativeShapeId, pasteAttempts: copied.pasteAttempts
                    });
                    var id = Identity.shapeId(clone);
                    createdIds.push(id);
                    clone.Left = Number(record.shape.Left) + deltaLeft;
                    clone.Top = Number(record.shape.Top) + deltaTop;
                    if (componentMode) {
                        var part = record.part || 'part_' + (sourceIndex + 1);
                        clone.Name = componentId + '_' + part + (record.itemId ? '__ITEM_' + record.itemId : '');
                    } else clone.Name = String(record.shape.Name) + '_copy_' + id;
                    cloneRecords.push({ shape: clone, nativeShapeId: id, shapeIndex: slide.Shapes.Count,
                        binding: record.binding, part: record.part, canonicalPart: record.canonicalPart,
                        itemId: record.itemId, contentBlockId: record.contentBlockId,
                        sourceNativeShapeId: record.nativeShapeId });
                }
                cloneRecords.forEach(function (record, sourceIndex) {
                    var sourceSignature = duplicateSignature(sourceRecords[sourceIndex].shape,
                        sourceBounds.left, sourceBounds.top);
                    var cloneSignature = duplicateSignature(record.shape,
                        placement.bounds.left, placement.bounds.top);
                    var mismatches = duplicateSignatureMismatches(sourceSignature, cloneSignature, '');
                    verificationItems.push({ part: record.part,
                        sourceNativeShapeId: Number(sourceRecords[sourceIndex].nativeShapeId),
                        cloneNativeShapeId: Number(record.nativeShapeId),
                        equivalent: mismatches.length === 0, mismatches: mismatches });
                    if (mismatches.length) throw new Error((componentMode ?
                        'PPT_DUPLICATE_COMPONENT_EQUIVALENCE_FAILED:' :
                        'PPT_DUPLICATE_OBJECT_EQUIVALENCE_FAILED:') + mismatches.join(','));
                });
                if (componentMode && params.partOverrides) {
                    cloneRecords.forEach(function (record) {
                        var part = record.canonicalPart || record.part;
                        if (params.partOverrides[part] === undefined) return;
                        if (Identity.nativeBoolean(value(function () { return record.shape.HasTextFrame; })) !== true) {
                            throw new Error('PPT_DUPLICATE_COMPONENT_OVERRIDE_NOT_TEXT:' + part);
                        }
                        var expectedText = String(params.partOverrides[part]);
                        record.shape.TextFrame.TextRange.Text = expectedText;
                        var actualText = String(record.shape.TextFrame.TextRange.Text || '');
                        overrideItems.push({ componentId: componentId, part: part,
                            cloneNativeShapeId: Number(record.nativeShapeId), expectedText: expectedText,
                            actualText: actualText, passed: actualText === expectedText });
                        if (actualText !== expectedText) {
                            throw new Error('PPT_DUPLICATE_COMPONENT_OVERRIDE_FAILED:' + part);
                        }
                    });
                }
                var hasPartOverrides = componentMode && params.partOverrides &&
                    Object.keys(params.partOverrides).length > 0;
                if (hasPartOverrides) {
                    var fit = fitComponentContent(presentation, cloneRecords);
                    contentFitItems = contentFitItems.concat(fit.items);
                    var finalBounds = envelope(cloneRecords);
                    var ignoredCloneIds = {};
                    cloneRecords.forEach(function (record) {
                        ignoredCloneIds[String(record.nativeShapeId)] = true;
                    });
                    if (!placementClear(slide, ignoredCloneIds, finalBounds, pageSize)) {
                        var finalPlacement = resolvePlacement(slide, ignoredCloneIds,
                            envelope(nextReference), finalBounds, params.relativePlacement,
                            params.spacingPolicy, pageSize);
                        if (!finalPlacement) throw new Error(
                            'PPT_DUPLICATE_COMPONENT_NO_SPACE_AFTER_CONTENT_FIT');
                        moveRecords(cloneRecords, finalPlacement.bounds.left - finalBounds.left,
                            finalPlacement.bounds.top - finalBounds.top);
                        placement = finalPlacement;
                    }
                }
                var summaries = cloneRecords.map(function (record) {
                    var resolved = Identity.findShapeById(slide, record.nativeShapeId);
                    return { componentId: componentId, part: record.part,
                        canonicalPart: record.canonicalPart, nativeShapeId: record.nativeShapeId,
                        shapeIndex: resolved.shapeIndex, shapeName: String(record.shape.Name),
                        bounds: geometry(record.shape) };
                });
                created = created.concat(summaries);
                var committedBounds = envelope(cloneRecords);
                placements.push({ componentId: componentId, bounds: committedBounds,
                    deltaLeft: committedBounds.left - sourceBounds.left,
                    deltaTop: committedBounds.top - sourceBounds.top, relation: placement.relation });
                var objectId = componentMode ? '' :
                    'slide:' + slide.SlideIndex + ':shape:' + summaries[0].shapeIndex;
                var binding = createdBinding(presentation, slide, cloneRecords, componentId, objectId);
                if (componentMode) binding.partBindings = cloneRecords.map(function (record) {
                    return { itemId: record.itemId, contentBlockId: record.contentBlockId,
                        part: record.canonicalPart || record.part,
                        sourceNativeShapeId: Number(record.sourceNativeShapeId),
                        createdNativeShapeId: Number(record.nativeShapeId) };
                });
                var contentLineage = componentMode ? cloneRecords.filter(function (record) {
                    return Boolean(record.contentBlockId);
                }).map(function (record) {
                    var part = record.canonicalPart || record.part;
                    return { sourceContentBlockId: record.contentBlockId,
                        createdOccurrenceId: String(params.operationId || '') + ':' + copyIndex + ':' +
                            record.contentBlockId + ':' + part,
                        authorizedDuplicate: true,
                        overridden: Boolean(params.partOverrides &&
                            params.partOverrides[part] !== undefined) };
                }) : [];
                creationReceipts.push({ operationId: String(params.operationId || ''),
                    resultIndex: copyIndex, entityKind: componentMode ? 'component' : 'object',
                    source: createdBinding(presentation, slide, sourceRecords,
                        componentMode ? String(params.sourceComponentId || '') : '',
                        componentMode ? '' : String(params.sourceBinding.objectId || '')),
                    reference: createdBinding(presentation, slide, nextReference, '', ''),
                    created: binding, placement: placement.relation,
                    contentLineage: contentLineage, status: 'committed' });
                nextReference = cloneRecords;
            }
            var sourceIssues = verifySnapshotShapes(presentation, sourceSnapshot);
            if (sourceIssues.length) throw new Error((componentMode ?
                'PPT_DUPLICATE_COMPONENT_SOURCE_CHANGED:' :
                'PPT_DUPLICATE_OBJECT_SOURCE_CHANGED:') + sourceIssues[0].field);
            return Result.success({ transactional: true, rolledBack: false, rollbackVerified: false,
                wroteToWps: true, slideIndex: Number(slide.SlideIndex), created: created,
                createdObjectCount: createdIds.length, creationReceipts: creationReceipts,
                placement: placements, verification: { passed: true,
                    checkedObjectCount: verificationItems.length, items: verificationItems,
                    overrideItems: overrideItems, contentFitItems: contentFitItems,
                    copyDiagnostics: copyDiagnostics },
                cloneComponentIds: componentMode ? placements.map(function (item) {
                    return item.componentId;
                }) : undefined });
        } catch (error) {
            createdIds = unique(createdIds.concat(error.nativeCreatedIds || []));
            var hadWrites = createdIds.length > 0;
            var rollback = { rolledBack: false, rollbackVerified: false, rollbackIssues: [] };
            if (hadWrites && slide) {
                try { deleteCreated(slide, createdIds); } catch (_deleteError) {}
                rollback = await restoreSnapshot(presentation, sourceSnapshot, []);
            }
            var pageUnchanged = !hadWrites || rollback.rollbackVerified;
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error), {
                transactional: true, blocked: !hadWrites &&
                    /^PPT_DUPLICATE_RELATIVE_PLACEMENT_NO_SPACE/.test(Result.errorText(error)),
                rolledBack: hadWrites, rollbackVerified: hadWrites && rollback.rollbackVerified,
                rollbackAttempted: hadWrites, wroteToWps: hadWrites && !rollback.rollbackVerified,
                pageUnchangedVerified: pageUnchanged,
                slideIndex: slide ? Number(slide.SlideIndex) : null, created: created,
                creationReceipts: creationReceipts, rollbackIssues: rollback.rollbackIssues || [],
                verification: { passed: false, items: verificationItems,
                    overrideItems: overrideItems, contentFitItems: contentFitItems }
            });
        }
    }

    function duplicateObject(params, expectedPresentationRef) {
        return duplicate(params, expectedPresentationRef, false);
    }

    function duplicateComponent(params, expectedPresentationRef) {
        return duplicate(params, expectedPresentationRef, true);
    }

    async function normalizeComponentGrid(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var slide = null; var before = null; var wrote = false;
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            slide = Identity.requireSlide(presentation, params.slideIndex, params.nativeSlideId);
            var sizeAxes = Array.isArray(params.sizeAxes) ? params.sizeAxes.map(String) : [];
            if (params.contentFitOnly !== true || String(params.layoutAspect || '') !== 'size' ||
                String(params.componentSizeIntent || '') !== 'fit' || sizeAxes.length !== 1 ||
                sizeAxes[0] !== 'height') {
                throw new Error('wps_js_content_fit_contract_required');
            }
            var bindings = Array.isArray(params.componentBindings) ? params.componentBindings : [];
            if (!bindings.length) throw new Error('wps_js_component_bindings_required');
            var records = shapeRecords(slide, bindings);
            var byComponent = {};
            records.forEach(function (record) {
                var id = String(record.binding.componentId || record.binding.aggregateId || '');
                if (!id) throw new Error('wps_js_component_id_required');
                if (!byComponent[id]) byComponent[id] = [];
                byComponent[id].push(record);
            });
            var rows = params.slideLayoutPlan && Array.isArray(params.slideLayoutPlan.rows) ?
                params.slideLayoutPlan.rows : [];
            if (!rows.length) throw new Error('wps_js_slide_layout_rows_required');
            var targets = [];
            rows.forEach(function (row) {
                (row.componentRects || []).forEach(function (rect) {
                    if (!byComponent[String(rect.componentId)]) {
                        throw new Error('wps_js_layout_component_binding_missing:' + rect.componentId);
                    }
                    targets.push(rect);
                });
            });
            if (targets.length !== 1 || Object.keys(byComponent).length !== 1) {
                throw new Error('wps_js_content_fit_single_component_required');
            }
            componentBackground(records);
            Identity.assertWritable(presentation);
            before = snapshotPresentation(presentation, [Number(slide.SlideIndex)], [{
                slideIndex: Number(slide.SlideIndex),
                nativeShapeIds: records.map(function (record) { return record.nativeShapeId; })
            }]);
            Identity.assertWritable(presentation);
            wrote = true;
            var fit = fitComponentContent(presentation,
                byComponent[String(targets[0].componentId)]);
            var changedIds = fit.changedObjectIds;
            wrote = changedIds.length > 0;
            if (wrote && params.testControl && params.testControl.failAfterWrite) {
                throw new Error('wps_js_content_fit_injected_failure_after_write');
            }
            var readback = Array.isArray(params.postWriteReadbackTargets) ? Capture.readTargets({
                presentationId: Identity.runtimeLocator(presentation), slideIndex: Number(slide.SlideIndex),
                nativeSlideId: Identity.slideId(slide), targets: params.postWriteReadbackTargets
            }, Identity.runtimeLocator(presentation)) : null;
            return Result.success({ partialMutation: false, transactional: true, rolledBack: false,
                rollbackVerified: false, wroteToWps: changedIds.length > 0,
                slideIndex: Number(slide.SlideIndex), changedObjectIds: unique(changedIds),
                changed: unique(changedIds).map(function (id) { return { nativeShapeId: id }; }),
                postWriteReadback: readback, dryRun: { ok: true, targetCount: targets.length,
                    layoutAspect: 'size', componentSizeIntent: 'fit', sizeAxes: ['height'] },
                feasibility: { feasible: true, source: 'live_bound_height' },
                verification: { compact: true, scope: 'mutation_targets', ok: true,
                    issueCount: 0, errorCount: 0, warningCount: 0, issues: [],
                    contentFitItems: fit.items } });
        } catch (error) {
            var rollback = wrote ? await restoreSnapshot(presentation, before, []) :
                { rolledBack: false, rollbackVerified: false, rollbackIssues: [] };
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error), {
                partialMutation: wrote && !rollback.rollbackVerified, transactional: true,
                wroteToWps: wrote && !rollback.rollbackVerified,
                rolledBack: wrote, rollbackVerified: wrote && rollback.rollbackVerified,
                rollbackAttempted: wrote, rollbackIssues: rollback.rollbackIssues || []
            });
        }
    }

    async function restoreMutationSnapshot(params, expectedPresentationRef) {
        params = params || {};
        var mutationAttempted = false;
        try {
            var presentation = Identity.requirePresentation(expectedPresentationRef ||
                params.presentationId || (params.snapshot && params.snapshot.presentationRef));
            if (params.recoveryMode === 'verify_or_restore') {
                var snapshot = params.snapshot;
                if (!snapshot || snapshot.schemaVersion !== 1 || !snapshot.slides || !snapshot.slides.length ||
                    snapshot.presentationRef !== Identity.runtimeLocator(presentation)) {
                    throw new Error('wps_js_recovery_snapshot_identity_mismatch');
                }
                if (verifySnapshot(presentation, snapshot).length === 0) {
                    return Result.success({ rolledBack: true, rollbackVerified: true,
                        rollbackAttempted: false, wroteToWps: false, rollbackIssues: [],
                        recoveryStatus: 'already_restored' });
                }
                var checkpoint = params.expectedCurrentSnapshot;
                if (!checkpoint || checkpoint.presentationRef !== snapshot.presentationRef ||
                    params.verifyOnly === true) throw new Error('wps_js_recovery_verification_required');
                var checkpointIssues = [];
                compareSnapshotValue(checkpoint, snapshotPresentation(presentation,
                    (checkpoint.slides || []).map(function (slide) { return slide.slideIndex; })),
                    'recoveryCheckpoint', checkpointIssues, true);
                if (checkpointIssues.length > 0) {
                    throw new Error('wps_js_recovery_current_state_changed');
                }
            }
            Identity.assertWritable(presentation);
            mutationAttempted = true;
            var restored = await restoreSnapshot(presentation, params.snapshot || {}, params.creationReceipts || []);
            restored.rollbackAttempted = true;
            restored.wroteToWps = true;
            if (params.recoveryMode === 'verify_or_restore') restored.recoveryStatus =
                restored.rollbackVerified ? 'restored' : 'unverified';
            return restored.rollbackVerified ? Result.success(restored) :
                Result.failure('wps_js_rollback_unverified', null, restored);
        } catch (error) {
            return Result.failure(error.code || Result.errorText(error), Result.errorText(error), {
                rolledBack: false, rollbackVerified: false, wroteToWps: mutationAttempted,
                rollbackAttempted: mutationAttempted, partialMutation: mutationAttempted,
                rollbackIssues: [{ code: mutationAttempted ? 'rollback_execution_failed' :
                    'rollback_precondition_failed', message: Result.errorText(error) }]
            });
        }
    }

    return {
        snapshotShape: snapshotShape,
        snapshotPresentation: snapshotPresentation,
        restoreSnapshot: restoreSnapshot,
        rejectChartSemanticData: rejectChartSemanticData,
        assertOperationSupported: assertOperationSupported,
        preflightOperation: preflightOperation,
        applyOperation: applyOperation,
        editSlideBatch: editSlideBatch,
        duplicateObject: duplicateObject,
        duplicateComponent: duplicateComponent,
        normalizeComponentGrid: normalizeComponentGrid,
        restoreMutationSnapshot: restoreMutationSnapshot,
        setShapeStyle: setShapeStyle,
        setTextStyle: setTextStyle,
        setPosition: setPosition,
        setConnectorStyle: setConnectorStyle,
        setTableCellStyles: setTableCellStyles,
        geometry: geometry
    };
})();


/*
 * Input: Canonical Scene creation, structural and mixed plans
 * Output: Identity-bound receipts or verified whole-plan rollback evidence
 * Pos: Phase 3 native plan transaction boundary; chart semantic data is excluded
 */

var WpsJsBridgePlans = (function () {
    var Identity = WpsJsBridgeIdentity;
    var Capture = WpsJsBridgeCapture;
    var Operations = WpsJsBridgeOperations;
    var Result = WpsJsBridgeResult;
    var SHAPE_TYPES = WpsJsBridgeDrawing.shapeValues;
    var LEGEND_POSITIONS = { top: -4160, right: -4152, bottom: -4107, left: -4131 };
    var PAGE_DISPLAY_YIELD_MS = 800;

    function value(read, fallback) {
        return Identity.safeRead(read, fallback === undefined ? null : fallback);
    }

    function errorCode(error) {
        return error && error.code ? error.code : Result.errorText(error);
    }

    function requireBounds(bounds) {
        bounds = bounds || {};
        var normalized = { left: Number(bounds.left), top: Number(bounds.top),
            width: Number(bounds.width), height: Number(bounds.height) };
        if (!isFinite(normalized.left) || !isFinite(normalized.top) ||
            !isFinite(normalized.width) || !isFinite(normalized.height) ||
            normalized.width <= 0 || normalized.height <= 0) {
            throw new Error('wps_js_creation_bounds_invalid');
        }
        return normalized;
    }

    function chartSemanticError() {
        var error = new Error('wps_js_chart_semantic_data_not_supported');
        error.code = 'wps_js_chart_semantic_data_not_supported';
        return error;
    }

    function assertNoChartSemanticData(actions) {
        (actions || []).forEach(function (action) {
            var chart = action.facets && action.facets.chart;
            if (action.adapterAction === 'create_chart' && chart &&
                (chart.data !== undefined || chart.semanticData !== undefined ||
                    chart.categories !== undefined || chart.series !== undefined)) {
                throw chartSemanticError();
            }
        });
    }

    function preflightCreation(presentation, actions, plannedSlideCount) {
        if (!Array.isArray(actions) || actions.length < 1) {
            throw new Error('PPT_SCENE_CREATION_PLAN_EMPTY');
        }
        assertNoChartSemanticData(actions);
        var createdSlides = {};
        var clientRefs = {};
        var simulatedSlideCount = plannedSlideCount === undefined
            ? Number(presentation.Slides.Count) : plannedSlideCount;
        actions.forEach(function (action) {
            var clientRef = String(action.clientRef || '');
            if (!clientRef || clientRefs[clientRef]) throw new Error('wps_js_creation_client_ref_invalid');
            clientRefs[clientRef] = true;
            if (action.entityClass === 'slide') {
                if (['add_slide', 'duplicate_slide'].indexOf(action.adapterAction) < 0) {
                    throw new Error('wps_js_creation_slide_action_invalid');
                }
                var insertAt = Number(action.insertAt);
                if (!Number.isInteger(insertAt) || insertAt < 1 || insertAt > simulatedSlideCount + 1) {
                    throw new Error('wps_js_creation_insert_at_invalid');
                }
                if (action.adapterAction === 'duplicate_slide') {
                    var source = action.sourceSlide || {};
                    Identity.requireSlide(presentation, source.slideIndex, source.nativeSlideId);
                }
                if (action.layoutRef !== undefined) throw new Error('creation_layout_ref_adapter_unavailable');
                createdSlides[clientRef] = true;
                simulatedSlideCount++;
                return;
            }
            if (action.entityClass !== 'element') throw new Error('wps_js_creation_entity_class_invalid');
            var allowed = ['add_text_box', 'add_shape', 'insert_picture', 'insert_graphic',
                'create_table', 'create_chart', 'add_connector'];
            if (allowed.indexOf(String(action.adapterAction || '')) < 0) {
                throw new Error('wps_js_creation_adapter_action_invalid');
            }
            var parent = action.parent || {};
            if (parent.kind === 'created_slide') {
                if (!createdSlides[String(parent.clientRef || '')]) {
                    throw new Error('wps_js_creation_parent_unavailable');
                }
            } else if (parent.kind === 'existing_slide') {
                Identity.requireSlide(presentation, parent.slideIndex, parent.nativeSlideId);
            } else throw new Error('wps_js_creation_parent_invalid');
            if (action.adapterAction !== 'add_connector') requireBounds(action.bounds);
            if (['insert_picture', 'insert_graphic'].indexOf(action.adapterAction) >= 0 &&
                !String(action.asset && action.asset.localPath || '').trim()) {
                throw new Error('wps_js_creation_asset_path_required');
            }
            if (action.adapterAction === 'add_shape' &&
                !SHAPE_TYPES[String(action.facets && action.facets.shape &&
                    action.facets.shape.geometry || '')]) {
                throw new Error('wps_js_creation_shape_geometry_invalid');
            }
        });
        Identity.assertWritable(presentation);
        return simulatedSlideCount;
    }

    function resolveParent(presentation, parent, createdSlides) {
        if (parent.kind === 'created_slide') {
            return Identity.requireSlide(presentation, null, createdSlides[String(parent.clientRef)]);
        }
        return Identity.requireSlide(presentation, parent.slideIndex, parent.nativeSlideId);
    }

    function setTableStyle(shape, style) {
        if (!style) return;
        var cells = [];
        for (var row = 1; row <= shape.Table.Rows.Count; row++) {
            for (var column = 1; column <= shape.Table.Columns.Count; column++) {
                cells.push({ row: row, col: column, style: {
                    fillColor: style.backgroundColor,
                    fontColor: style.fontColor,
                    fontName: style.fontName,
                    fontSize: style.fontSize,
                    bold: style.bold,
                    italic: style.italic,
                    alignment: style.alignment,
                    verticalAlignment: style.verticalAlignment
                } });
            }
        }
        Operations.setTableCellStyles(shape, cells);
    }

    function createShape(presentation, slide, action, tracker) {
        var bounds = action.adapterAction === 'add_connector' ? null : requireBounds(action.bounds);
        var facets = action.facets || {};
        var shape = null;
        if (action.adapterAction === 'add_text_box') {
            shape = slide.Shapes.AddTextbox(1, bounds.left, bounds.top, bounds.width, bounds.height);
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
            var text = facets.text || {};
            shape.TextFrame.TextRange.Text = String(text.content || '');
            if (text.style) Operations.setTextStyle(shape, text.style);
        } else if (action.adapterAction === 'add_shape') {
            var shapeFacet = facets.shape || {};
            shape = slide.Shapes.AddShape(SHAPE_TYPES[String(shapeFacet.geometry)],
                bounds.left, bounds.top, bounds.width, bounds.height);
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
            if (shapeFacet.style) Operations.setShapeStyle(shape, shapeFacet.style);
            if (facets.text) {
                shape.TextFrame.TextRange.Text = String(facets.text.content || '');
                if (facets.text.style) Operations.setTextStyle(shape, facets.text.style);
            }
        } else if (action.adapterAction === 'insert_picture' ||
            action.adapterAction === 'insert_graphic') {
            shape = slide.Shapes.AddPicture(String(action.asset.localPath), false, true,
                bounds.left, bounds.top, bounds.width, bounds.height);
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
        } else if (action.adapterAction === 'create_table') {
            var table = facets.table || {};
            shape = slide.Shapes.AddTable(Number(table.rows), Number(table.columns),
                bounds.left, bounds.top, bounds.width, bounds.height);
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
            (table.data || []).forEach(function (rowValues, rowIndex) {
                rowValues.forEach(function (cell, columnIndex) {
                    shape.Table.Cell(rowIndex + 1, columnIndex + 1).Shape.TextFrame.TextRange.Text =
                        cell === null || cell === undefined ? '' : String(cell);
                });
            });
            setTableStyle(shape, table.style);
        } else if (action.adapterAction === 'create_chart') {
            var chart = facets.chart || {};
            if (chart.data !== undefined) throw chartSemanticError();
            shape = slide.Shapes.AddChart(Number(action.nativeChartType),
                bounds.left, bounds.top, bounds.width, bounds.height);
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
            if (chart.title !== undefined) {
                shape.Chart.HasTitle = String(chart.title).length > 0;
                if (String(chart.title).length) shape.Chart.ChartTitle.Text = String(chart.title);
            }
            if (chart.hasLegend !== undefined) shape.Chart.HasLegend = Boolean(chart.hasLegend);
            if (chart.legendPosition !== undefined) {
                if (LEGEND_POSITIONS[chart.legendPosition] === undefined) {
                    throw new Error('wps_js_creation_legend_position_invalid');
                }
                shape.Chart.HasLegend = true;
                shape.Chart.Legend.Position = LEGEND_POSITIONS[chart.legendPosition];
            }
        } else if (action.adapterAction === 'add_connector') {
            var connector = facets.connector || {};
            shape = slide.Shapes.AddConnector(1, Number(connector.beginX), Number(connector.beginY),
                Number(connector.endX), Number(connector.endY));
            tracker.push({ presentation: presentation, slide: slide, shape: shape,
                nativeSlideId: Identity.slideId(slide),
                nativeShapeId: Identity.shapeId(shape) });
            Operations.setConnectorStyle(shape, connector);
        }
        if (!shape) throw new Error('wps_js_creation_shape_missing');
        if (action.rotation !== undefined && action.adapterAction !== 'add_connector') {
            shape.Rotation = Number(action.rotation);
        }
        return shape;
    }

    function expectedType(kind) {
        return { text_box: 17, auto_shape: 1, picture: 13, graphic: 28,
            table: 19, chart: 3 }[kind];
    }

    function verifyCreatedKind(shape, kind) {
        if (kind === 'connector') {
            if (Identity.nativeBoolean(value(function () { return shape.Connector; }, null)) !== true) {
                throw new Error('wps_js_creation_kind_mismatch');
            }
            return;
        }
        if (Number(shape.Type) !== expectedType(kind)) throw new Error('wps_js_creation_kind_mismatch');
        if (kind === 'table' && Identity.nativeBoolean(value(function () {
            return shape.HasTable;
        }, null)) !== true) throw new Error('wps_js_creation_table_readback_failed');
    }

    function creationReceipt(slide, shape, action) {
        var found = Identity.findShapeById(slide, Identity.shapeId(shape));
        if (!found) throw new Error('wps_js_created_shape_readback_missing');
        verifyCreatedKind(found.shape, String(action.kind));
        var receipt = { operationId: String(action.operationId), resultIndex: Number(action.resultIndex),
            clientRef: String(action.clientRef), entityClass: 'element', kind: String(action.kind),
            nativeSlideId: Number(Identity.slideId(slide)), slideIndex: Number(slide.SlideIndex),
            nativeShapeId: Number(Identity.shapeId(found.shape)), name: String(found.shape.Name),
            nativeTypeCode: Number(found.shape.Type), actualBounds: Operations.geometry(found.shape),
            sourceRefs: Array.isArray(action.sourceRefs) ? action.sourceRefs : [],
            evidenceRefs: Array.isArray(action.evidenceRefs) ? action.evidenceRefs : [] };
        if (action.asset) receipt.asset = { assetRef: String(action.asset.assetRef),
            contentHash: String(action.asset.contentHash), mimeType: String(action.asset.mimeType) };
        var drawing = WpsJsBridgeDrawing.creationEvidence(found.shape, action);
        if (drawing) receipt.drawing = drawing;
        return receipt;
    }

    function removeTracked(trackedShapes, trackedSlides) {
        var issues = [];
        trackedShapes.slice().reverse().forEach(function (tracked) {
            try {
                var slide = Identity.requireSlide(tracked.presentation,
                    value(function () { return tracked.slide.SlideIndex; }), tracked.nativeSlideId);
                var found = Identity.findShapeById(slide, tracked.nativeShapeId);
                if (found) found.shape.Delete();
            } catch (error) { issues.push({ code: 'rollback_created_shape_delete_failed',
                nativeSlideId: tracked.nativeSlideId, nativeShapeId: tracked.nativeShapeId,
                message: Result.errorText(error) }); }
        });
        trackedSlides.slice().reverse().forEach(function (tracked) {
            try {
                var resolved = Identity.requireSlide(tracked.presentation, null, tracked.nativeSlideId);
                resolved.Delete();
            } catch (error) { issues.push({ code: 'rollback_created_slide_delete_failed',
                nativeSlideId: tracked.nativeSlideId, message: Result.errorText(error) }); }
        });
        return issues;
    }

    function executeCreationPlanSync(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var beforeFingerprint = ''; var wrote = false;
        var createdSlides = {}; var trackedSlides = []; var trackedShapes = []; var receipts = [];
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            beforeFingerprint = Capture.presentationScene(presentation).fingerprint;
            preflightCreation(presentation, params.actions);
            var authoritativeSlideCount = Number(presentation.Slides.Count);
            for (var actionIndex = 0; actionIndex < params.actions.length; actionIndex++) {
                var action = params.actions[actionIndex];
                var control = params.testControl || {};
                if (String(control.failBeforeOperationId || '') === String(action.operationId) ||
                    Number(control.failBeforeResultIndex) === Number(action.resultIndex)) {
                    throw new Error('scene_creation_injected_failure_before:' + action.resultIndex);
                }
                Identity.assertWritable(presentation);
                if (action.entityClass === 'slide') {
                    var insertAt = Number(action.insertAt);
                    var slide;
                    if (action.adapterAction === 'add_slide') slide = presentation.Slides.Add(insertAt, 12);
                    else {
                        var source = action.sourceSlide || {};
                        slide = Identity.requireSlide(presentation, source.slideIndex,
                            source.nativeSlideId).Duplicate().Item(1);
                    }
                    wrote = true;
                    var nativeSlideId = Number(Identity.slideId(slide));
                    trackedSlides.push({ presentation: presentation, slide: slide, nativeSlideId: nativeSlideId });
                    createdSlides[String(action.clientRef)] = nativeSlideId;
                    authoritativeSlideCount++;
                    if (action.adapterAction === 'duplicate_slide') moveSlideTo(presentation, slide, insertAt);
                    receipts.push({ operationId: String(action.operationId),
                        resultIndex: Number(action.resultIndex), clientRef: String(action.clientRef),
                        entityClass: 'slide', kind: 'slide', nativeSlideId: nativeSlideId,
                        slideIndex: Number(slide.SlideIndex),
                        sourceRefs: Array.isArray(action.sourceRefs) ? action.sourceRefs : [],
                        evidenceRefs: Array.isArray(action.evidenceRefs) ? action.evidenceRefs : [] });
                } else {
                    var parent = resolveParent(presentation, action.parent || {}, createdSlides);
                    wrote = true;
                    var shape = createShape(presentation, parent, action, trackedShapes);
                    if (Number(control.corruptReadbackResultIndex) === Number(action.resultIndex)) {
                        shape.Name = 'SceneV2_Injected_Readback_Mismatch';
                        throw new Error('scene_creation_injected_readback_mismatch:' + action.resultIndex);
                    }
                    receipts.push(creationReceipt(parent, shape, action));
                }
                if (Number(control.failAfterResultIndex) === Number(action.resultIndex)) {
                    throw new Error('scene_creation_injected_failure_after:' + action.resultIndex);
                }
            }
            return Result.success({ transactional: true, wroteToWps: true, rolledBack: false,
                rollbackVerified: false, presentationFingerprintBefore: beforeFingerprint,
                presentationFingerprintAfter: Capture.presentationScene(presentation).fingerprint,
                receipts: receipts });
        } catch (error) {
            var issues = wrote ? removeTracked(trackedShapes, trackedSlides) : [];
            var afterFingerprint = presentation ? Capture.presentationScene(presentation).fingerprint : '';
            if (wrote && beforeFingerprint && afterFingerprint !== beforeFingerprint) {
                issues.push({ code: 'rollback_presentation_fingerprint_mismatch',
                    expected: beforeFingerprint, actual: afterFingerprint });
            }
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: wrote && issues.length > 0, rolledBack: wrote,
                rollbackVerified: wrote && issues.length === 0,
                presentationFingerprintBefore: beforeFingerprint,
                presentationFingerprintAfter: afterFingerprint,
                reason: Result.errorText(error), rollbackIssues: issues, receipts: receipts
            });
        }
    }

    function pageDisplayGroups(actions) {
        var groups = [];
        var current = null;
        (actions || []).forEach(function (action) {
            if (action.entityClass === 'slide') {
                current = { slideClientRef: String(action.clientRef), actions: [action] };
                groups.push(current);
                return;
            }
            if (!current || !action.parent || action.parent.kind !== 'created_slide' ||
                String(action.parent.clientRef) !== current.slideClientRef) {
                throw new Error('page_by_page_requires_contiguous_new_slide_actions');
            }
            current.actions.push(action);
        });
        if (!groups.length) throw new Error('page_by_page_requires_new_slides');
        return groups;
    }

    function activeSlideIndex(presentation) {
        return Number(value(function () {
            return presentation.Windows.Item(1).View.Slide.SlideIndex;
        }, NaN));
    }

    function pageDisplayDelay() {
        return new Promise(function (resolve) {
            setTimeout(resolve, PAGE_DISPLAY_YIELD_MS);
        });
    }

    async function executeCreationPlanPageByPage(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var beforeFingerprint = ''; var wrote = false;
        var receipts = []; var childRollbackIssues = []; var pageDisplayEvidence = [];
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            beforeFingerprint = Capture.presentationScene(presentation).fingerprint;
            if (params.requiredPageDisplayContractVersion !== 1) {
                throw new Error('wps_js_page_display_contract_invalid');
            }
            preflightCreation(presentation, params.actions);
            var groups = pageDisplayGroups(params.actions);
            for (var pageIndex = 0; pageIndex < groups.length; pageIndex++) {
                var created = executeCreationPlanSync({
                    actions: groups[pageIndex].actions,
                    testControl: params.testControl
                }, Identity.runtimeLocator(presentation));
                if (!created.success) {
                    var childData = created.data || {};
                    wrote = wrote || childData.wroteToWps === true || childData.rolledBack === true;
                    childRollbackIssues = (childData.rollbackIssues || []).slice();
                    throw new Error(created.error || 'wps_js_page_creation_failed');
                }
                wrote = true;
                var pageReceipts = created.data.receipts || [];
                receipts = receipts.concat(pageReceipts);
                var slideReceipt = pageReceipts.filter(function (receipt) {
                    return receipt.entityClass === 'slide';
                })[0];
                if (!slideReceipt) throw new Error('wps_js_page_display_slide_receipt_missing');
                var targetSlideIndex = Number(slideReceipt.slideIndex);
                var view = presentation.Windows.Item(1).View;
                var activeBeforeGoto = activeSlideIndex(presentation);
                var gotoAtMs = Date.now();
                view.GotoSlide(targetSlideIndex);
                var activeAfterGoto = activeSlideIndex(presentation);
                if (activeAfterGoto !== targetSlideIndex) {
                    throw new Error('wps_js_page_display_active_slide_mismatch');
                }
                var yielded = false;
                var yieldAtMs = null;
                var activeAfterYield = activeAfterGoto;
                if (pageIndex < groups.length - 1) {
                    await pageDisplayDelay();
                    yieldAtMs = Date.now();
                    yielded = true;
                    activeAfterYield = activeSlideIndex(presentation);
                    if (activeAfterYield !== targetSlideIndex) {
                        throw new Error('wps_js_page_display_active_slide_changed');
                    }
                }
                pageDisplayEvidence.push({
                    pageIndex: pageIndex,
                    slideIndex: targetSlideIndex,
                    nativeSlideId: Number(slideReceipt.nativeSlideId),
                    activeBeforeGoto: activeBeforeGoto,
                    activeAfterGoto: activeAfterGoto,
                    activeAfterYield: activeAfterYield,
                    gotoAtMs: gotoAtMs,
                    yieldAtMs: yieldAtMs,
                    yielded: yielded
                });
            }
            return Result.success({ transactional: true, wroteToWps: true, rolledBack: false,
                rollbackVerified: false, presentationFingerprintBefore: beforeFingerprint,
                presentationFingerprintAfter: Capture.presentationScene(presentation).fingerprint,
                receipts: receipts, pageDisplayEvidence: pageDisplayEvidence });
        } catch (error) {
            var issues = childRollbackIssues.slice();
            if (receipts.length && presentation && beforeFingerprint) {
                var rollback = rollbackCreationCommit({
                    presentationFingerprintBefore: beforeFingerprint,
                    receipts: receipts
                }, Identity.runtimeLocator(presentation));
                if (!rollback.success || !rollback.data || rollback.data.rollbackVerified !== true) {
                    issues = issues.concat(rollback.data && rollback.data.rollbackIssues || [{
                        code: 'page_display_rollback_unverified',
                        message: rollback.error || 'page display rollback was not verified'
                    }]);
                }
            }
            var afterFingerprint = presentation ? Capture.presentationScene(presentation).fingerprint : '';
            if (wrote && beforeFingerprint && afterFingerprint !== beforeFingerprint &&
                !issues.some(function (issue) {
                    return issue.code === 'creation_commit_rollback_fingerprint_mismatch';
                })) {
                issues.push({ code: 'rollback_presentation_fingerprint_mismatch',
                    expected: beforeFingerprint, actual: afterFingerprint });
            }
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: wrote, rolledBack: wrote,
                rollbackVerified: wrote && issues.length === 0 &&
                    afterFingerprint === beforeFingerprint,
                presentationFingerprintBefore: beforeFingerprint,
                presentationFingerprintAfter: afterFingerprint,
                reason: Result.errorText(error), rollbackIssues: issues, receipts: receipts,
                pageDisplayEvidence: pageDisplayEvidence
            });
        }
    }

    function executeCreationPlan(params, expectedPresentationRef) {
        if (params && params.displayMode === 'page_by_page') {
            return executeCreationPlanPageByPage(params, expectedPresentationRef);
        }
        return executeCreationPlanSync(params, expectedPresentationRef);
    }

    function rollbackCreationCommit(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null;
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            if (!String(params.presentationFingerprintBefore || '') ||
                !Array.isArray(params.receipts) || !params.receipts.length) {
                throw new Error('PPT_SCENE_CREATION_ROLLBACK_INPUT_INVALID');
            }
            Identity.assertWritable(presentation);
            var issues = [];
            params.receipts.slice().reverse().forEach(function (receipt) {
                try {
                    var slide = Identity.requireSlide(presentation, receipt.slideIndex, receipt.nativeSlideId);
                    if (receipt.entityClass === 'element') {
                        var found = Identity.findShapeById(slide, receipt.nativeShapeId);
                        if (!found || String(found.shape.Name) !== String(receipt.name) ||
                            Number(found.shape.Type) !== Number(receipt.nativeTypeCode)) {
                            throw new Error('wps_js_creation_rollback_binding_mismatch');
                        }
                        found.shape.Delete();
                    } else slide.Delete();
                } catch (error) { issues.push({ code: receipt.entityClass === 'element' ?
                    'creation_commit_rollback_shape_delete_failed' :
                    'creation_commit_rollback_slide_delete_failed', message: Result.errorText(error) }); }
            });
            var after = Capture.presentationScene(presentation).fingerprint;
            if (after !== String(params.presentationFingerprintBefore)) {
                issues.push({ code: 'creation_commit_rollback_fingerprint_mismatch',
                    expected: String(params.presentationFingerprintBefore), actual: after });
            }
            var data = { transactional: true, wroteToWps: true, rolledBack: true,
                rollbackVerified: issues.length === 0,
                presentationFingerprintBefore: String(params.presentationFingerprintBefore),
                presentationFingerprintAfter: after, rollbackIssues: issues };
            return issues.length ? Result.failure('wps_js_creation_commit_rollback_unverified', null, data) :
                Result.success(data);
        } catch (error) {
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: false, rolledBack: false,
                rollbackVerified: false, rollbackIssues: []
            });
        }
    }

    function nativeSlideOrder(presentation) {
        var result = [];
        for (var index = 1; index <= presentation.Slides.Count; index++) {
            result.push(Number(Identity.slideId(presentation.Slides.Item(index))));
        }
        return result;
    }

    function nativeShapeOrder(slide) {
        var result = [];
        for (var index = 1; index <= slide.Shapes.Count; index++) {
            var shape = slide.Shapes.Item(index);
            result.push({ id: Number(Identity.shapeId(shape)),
                z: Number(value(function () { return shape.ZOrderPosition; }, index)) });
        }
        return result.sort(function (left, right) { return left.z - right.z; })
            .map(function (item) { return item.id; });
    }

    function equalOrder(left, right) {
        return JSON.stringify((left || []).map(Number)) === JSON.stringify((right || []).map(Number));
    }

    function moveSlideTo(presentation, slide, targetIndex) {
        var count = Number(presentation.Slides.Count);
        if (targetIndex < 1 || targetIndex > count) throw new Error('wps_js_slide_target_index_invalid');
        var current = Number(slide.SlideIndex);
        if (current !== targetIndex) slide.MoveTo(current < targetIndex ? targetIndex + 1 : targetIndex);
        if (Number(slide.SlideIndex) !== targetIndex) throw new Error('wps_js_slide_reorder_readback_mismatch');
    }

    function setShapeOrder(slide, ids) {
        ids.forEach(function (id) {
            var found = Identity.findShapeById(slide, id);
            if (!found) throw new Error('wps_js_shape_order_binding_missing');
            found.shape.ZOrder(0);
        });
    }

    function structuralShapes(presentation, target) {
        var slide = Identity.requireSlide(presentation, target.slideIndex, target.nativeSlideId);
        var ids = Array.isArray(target.nativeShapeIds) ? target.nativeShapeIds : [];
        if (!ids.length) throw new Error('wps_js_structural_shape_ids_required');
        var names = Array.isArray(target.expectedShapeNames) ? target.expectedShapeNames : [];
        var shapes = ids.map(function (id, index) {
            var found = Identity.findShapeById(slide, id);
            if (!found) throw new Error('wps_js_structural_shape_stale');
            if (names[index] && String(found.shape.Name) !== String(names[index])) {
                throw new Error('wps_js_structural_shape_name_changed');
            }
            return found.shape;
        });
        return { slide: slide, shapes: shapes, nativeShapeIds: ids.map(Number) };
    }

    function preflightStructural(presentation, action) {
        if (!action || ['delete_entities', 'reorder_slide', 'reorder_shapes',
            'set_presentation_properties', 'set_slide_properties'].indexOf(action.action) < 0) {
            throw new Error('PPT_SCENE_STRUCTURAL_ACTION_UNSUPPORTED');
        }
        if (action.action === 'delete_entities') {
            if (!Array.isArray(action.targets) || !action.targets.length) {
                throw new Error('wps_js_structural_targets_required');
            }
            action.targets.forEach(function (target) {
                if (target.targetKind === 'slide') {
                    Identity.requireSlide(presentation, target.slideIndex, target.nativeSlideId);
                } else structuralShapes(presentation, target);
            });
        } else if (action.action === 'reorder_slide') {
            Identity.requireSlide(presentation, action.target.slideIndex, action.target.nativeSlideId);
            if (!equalOrder(action.baselineNativeSlideIds, nativeSlideOrder(presentation))) {
                throw new Error('stale_scene: slide order changed after capture');
            }
        } else if (action.action === 'reorder_shapes') {
            var bound = structuralShapes(presentation, action.target);
            if (!equalOrder(action.baselineNativeShapeIds, nativeShapeOrder(bound.slide))) {
                throw new Error('stale_scene: z-order changed after capture');
            }
        } else if (action.action === 'set_slide_properties') {
            Identity.requireSlide(presentation, action.target.slideIndex, action.target.nativeSlideId);
        } else {
            requireBounds({ left: 0, top: 0, width: action.pageSize && action.pageSize.width,
                height: action.pageSize && action.pageSize.height });
        }
        Identity.assertWritable(presentation);
    }

    function structuralState(presentation) {
        var slides = [];
        for (var index = 1; index <= presentation.Slides.Count; index++) {
            var slide = presentation.Slides.Item(index);
            slides.push({ nativeSlideId: Number(Identity.slideId(slide)),
                hidden: Identity.nativeBoolean(value(function () {
                    return slide.SlideShowTransition.Hidden;
                }, 0)) === true,
                followMasterBackground: Identity.nativeBoolean(value(function () {
                    return slide.FollowMasterBackground;
                }, -1)) === true,
                fillType: value(function () { return slide.Background.Fill.Type; }, null),
                fillColor: value(function () { return slide.Background.Fill.ForeColor.RGB; }, null),
                nativeShapeIds: nativeShapeOrder(slide) });
        }
        return { nativeSlideIds: nativeSlideOrder(presentation),
            pageSize: { width: Number(presentation.PageSetup.SlideWidth),
                height: Number(presentation.PageSetup.SlideHeight) }, slides: slides };
    }

    function restoreStructuralState(presentation, state) {
        var issues = [];
        try {
            presentation.PageSetup.SlideWidth = state.pageSize.width;
            presentation.PageSetup.SlideHeight = state.pageSize.height;
        } catch (error) { issues.push({ code: 'rollback_page_size_failed', message: Result.errorText(error) }); }
        (state.slides || []).forEach(function (item) {
            try {
                var slide = Identity.requireSlide(presentation, null, item.nativeSlideId);
                slide.SlideShowTransition.Hidden = item.hidden;
                if (item.followMasterBackground) slide.FollowMasterBackground = true;
                else {
                    slide.FollowMasterBackground = false;
                    if (Number(item.fillType) === 1) slide.Background.Fill.Solid();
                    if (item.fillColor !== null) slide.Background.Fill.ForeColor.RGB = item.fillColor;
                }
                setShapeOrder(slide, item.nativeShapeIds);
            } catch (error) { issues.push({ code: 'rollback_slide_state_failed',
                nativeSlideId: item.nativeSlideId, message: Result.errorText(error) }); }
        });
        try {
            (state.nativeSlideIds || []).forEach(function (id, index) {
                moveSlideTo(presentation, Identity.requireSlide(presentation, null, id), index + 1);
            });
        } catch (error) { issues.push({ code: 'rollback_slide_order_failed', message: Result.errorText(error) }); }
        return issues;
    }

    function applyStructural(presentation, action) {
        var readback = {}; var undoCount = 0;
        if (action.action === 'delete_entities') {
            action.targets.forEach(function (target) {
                if (target.targetKind === 'slide') {
                    Identity.requireSlide(presentation, target.slideIndex, target.nativeSlideId).Delete();
                    undoCount++;
                } else {
                    structuralShapes(presentation, target).shapes.forEach(function (shape) {
                        shape.Delete(); undoCount++;
                    });
                }
            });
            action.targets.forEach(function (target) {
                if (target.targetKind === 'slide') {
                    if (Identity.findPresentation && (function () {
                        try { Identity.requireSlide(presentation, null, target.nativeSlideId); return true; }
                        catch (_error) { return false; }
                    })()) throw new Error('wps_js_delete_slide_readback_mismatch');
                } else {
                    var slide = Identity.requireSlide(presentation, null, target.nativeSlideId);
                    (target.nativeShapeIds || []).forEach(function (id) {
                        if (Identity.findShapeById(slide, id)) throw new Error('wps_js_delete_shape_readback_mismatch');
                    });
                }
            });
            readback = { deleted: true, targetCount: action.targets.length };
        } else if (action.action === 'reorder_slide') {
            var slide = Identity.requireSlide(presentation, action.target.slideIndex, action.target.nativeSlideId);
            moveSlideTo(presentation, slide, Number(action.targetIndex));
            readback = { orderedNativeSlideIds: nativeSlideOrder(presentation),
                targetIndex: Number(slide.SlideIndex) };
        } else if (action.action === 'reorder_shapes') {
            var resolved = structuralShapes(presentation, action.target);
            var moving = {};
            resolved.nativeShapeIds.forEach(function (id) { moving[String(id)] = true; });
            var selected = action.baselineNativeShapeIds.filter(function (id) { return moving[String(id)]; });
            var remaining = action.baselineNativeShapeIds.filter(function (id) { return !moving[String(id)]; });
            var targetIndex = Number(action.targetIndex);
            if (targetIndex < 1 || targetIndex > remaining.length + 1) {
                throw new Error('wps_js_shape_target_index_invalid');
            }
            var expected = remaining.slice(0, targetIndex - 1).concat(selected,
                remaining.slice(targetIndex - 1));
            setShapeOrder(resolved.slide, expected);
            if (!equalOrder(expected, nativeShapeOrder(resolved.slide))) {
                throw new Error('wps_js_shape_reorder_readback_mismatch');
            }
            readback = { nativeSlideId: Number(action.target.nativeSlideId),
                orderedNativeShapeIds: expected, targetIndex: targetIndex };
        } else if (action.action === 'set_presentation_properties') {
            presentation.PageSetup.SlideWidth = Number(action.pageSize.width);
            presentation.PageSetup.SlideHeight = Number(action.pageSize.height);
            readback = { pageSize: { width: Number(presentation.PageSetup.SlideWidth),
                height: Number(presentation.PageSetup.SlideHeight) } };
            if (Math.abs(readback.pageSize.width - Number(action.pageSize.width)) > 0.01 ||
                Math.abs(readback.pageSize.height - Number(action.pageSize.height)) > 0.01) {
                throw new Error('wps_js_page_size_readback_mismatch');
            }
        } else {
            var targetSlide = Identity.requireSlide(presentation, action.target.slideIndex,
                action.target.nativeSlideId);
            if (action.hidden !== undefined) targetSlide.SlideShowTransition.Hidden = Boolean(action.hidden);
            if (action.background) {
                if (action.background.mode === 'follow_master') targetSlide.FollowMasterBackground = true;
                else if (action.background.mode === 'solid') {
                    targetSlide.FollowMasterBackground = false;
                    targetSlide.Background.Fill.Solid();
                    var hex = String(action.background.color).slice(1);
                    targetSlide.Background.Fill.ForeColor.RGB = parseInt(hex.slice(0, 2), 16) |
                        (parseInt(hex.slice(2, 4), 16) << 8) | (parseInt(hex.slice(4, 6), 16) << 16);
                } else throw new Error('wps_js_slide_background_mode_invalid');
            }
            readback = { nativeSlideId: Number(Identity.slideId(targetSlide)),
                hidden: Identity.nativeBoolean(targetSlide.SlideShowTransition.Hidden) === true,
                background: { followMasterBackground:
                    Identity.nativeBoolean(targetSlide.FollowMasterBackground) === true,
                    fillColor: value(function () { return targetSlide.Background.Fill.ForeColor.RGB; }) } };
        }
        return { readback: readback, undoCount: undoCount };
    }

    function undo(count) {
        for (var index = 0; index < count; index++) Application.CommandBars.ExecuteMso('Undo');
    }

    function executeStructuralPlan(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var before = ''; var state = null; var wrote = false; var applied = null;
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            preflightStructural(presentation, params.action);
            before = Capture.presentationScene(presentation).fingerprint;
            state = structuralState(presentation);
            Identity.assertWritable(presentation);
            wrote = true;
            applied = applyStructural(presentation, params.action);
            if (params.testControl && params.testControl.failAfterWrite) {
                throw new Error('scene_structural_injected_failure_after_write');
            }
            return Result.success({ transactional: true, wroteToWps: true, rolledBack: false,
                rollbackVerified: false, action: params.action.action,
                presentationFingerprintBefore: before,
                presentationFingerprintAfter: Capture.presentationScene(presentation).fingerprint,
                readback: applied.readback, rollbackIssues: [] });
        } catch (error) {
            var issues = [];
            if (wrote && presentation && state) {
                try { if (applied && applied.undoCount) undo(applied.undoCount); }
                catch (undoError) { issues.push({ code: 'structural_rollback_undo_failed',
                    message: Result.errorText(undoError) }); }
                issues = issues.concat(restoreStructuralState(presentation, state));
            }
            var after = presentation ? Capture.presentationScene(presentation).fingerprint : '';
            if (wrote && before && after !== before) issues.push({
                code: 'rollback_presentation_fingerprint_mismatch', expected: before, actual: after
            });
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: wrote, rolledBack: wrote,
                rollbackVerified: wrote && issues.length === 0,
                action: params.action && params.action.action,
                presentationFingerprintBefore: before, presentationFingerprintAfter: after,
                reason: Result.errorText(error), rollbackIssues: issues,
                readback: applied ? applied.readback : {}
            });
        }
    }

    function preflightMixed(presentation, steps) {
        if (!Array.isArray(steps) || !steps.length) throw new Error('PPT_SCENE_MIXED_PLAN_TOO_SMALL');
        var creationActions = [];
        var availableCreationRefs = {};
        var plannedSlideCount = Number(presentation.Slides.Count);
        steps.forEach(function (step, index) {
            if (step.stepKind === 'creation') {
                var actions = Array.isArray(step.actions) ? step.actions : [];
                plannedSlideCount = preflightCreation(presentation, actions, plannedSlideCount);
                creationActions = creationActions.concat(actions);
                actions.forEach(function (action) {
                    availableCreationRefs[String(action.operationId) + ':' + Number(action.resultIndex)] =
                        action.entityClass;
                });
            }
            else if (step.stepKind === 'structural') {
                if (step.action && step.action.action === 'delete_entities' && index !== steps.length - 1) {
                    throw new Error('mixed_delete_entities_must_be_final_operation');
                }
                preflightStructural(presentation, step.action);
            } else if (step.stepKind === 'creation_result_edit') {
                var reference = step.creationRef || {};
                var key = String(reference.operationId) + ':' + Number(reference.resultIndex);
                if (availableCreationRefs[key] !== 'element') {
                    throw new Error('scene_creation_ref_result_unavailable');
                }
                if (!Array.isArray(step.adapterOperations) || !step.adapterOperations.length) {
                    throw new Error('wps_js_creation_result_edit_operations_required');
                }
                step.adapterOperations.forEach(function (operation) {
                    Operations.assertOperationSupported(operation);
                });
            } else {
                throw new Error('wps_js_mixed_step_kind_invalid');
            }
        });
        assertNoChartSemanticData(creationActions);
        Identity.assertWritable(presentation);
    }

    function creationRefReceipt(receipts, reference) {
        var matches = receipts.filter(function (receipt) {
            return String(receipt.operationId) === String(reference.operationId) &&
                Number(receipt.resultIndex) === Number(reference.resultIndex);
        });
        if (matches.length !== 1 || matches[0].entityClass !== 'element') {
            throw new Error('scene_creation_ref_result_unavailable');
        }
        return matches[0];
    }

    function executeCreationResultEdit(presentation, step, receipts) {
        var receipt = creationRefReceipt(receipts, step.creationRef || {});
        var slide = Identity.requireSlide(presentation, receipt.slideIndex, receipt.nativeSlideId);
        var found = Identity.findShapeById(slide, receipt.nativeShapeId);
        if (!found || String(found.shape.Name) !== String(receipt.name)) {
            throw new Error('scene_creation_ref_created_object_missing');
        }
        var changed = [];
        (step.adapterOperations || []).forEach(function (operation, index) {
            var bound = Object.assign({}, operation, {
                nativeShapeId: receipt.nativeShapeId,
                expectedShapeName: receipt.name,
                operationIndex: index
            });
            var preflight = Operations.preflightOperation(slide, bound);
            Identity.assertWritable(presentation);
            changed.push(Operations.applyOperation(slide, bound, preflight));
        });
        found = Identity.findShapeById(slide, receipt.nativeShapeId);
        return { changed: changed,
            readback: Capture.captureShape(found.shape, presentation, Number(slide.SlideIndex),
                found.shapeIndex, true, []),
            nativeSlideId: Number(receipt.nativeSlideId), nativeShapeId: Number(receipt.nativeShapeId) };
    }

    async function executeMixedPlanDefault(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var before = ''; var state = null; var structuralWrote = false;
        var wrote = false; var receipts = []; var readbacks = []; var undoCount = 0;
        var childRollbackIssues = [];
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            before = Capture.presentationScene(presentation).fingerprint;
            preflightMixed(presentation, params.steps);
            if (params.steps.some(function (step) { return step.stepKind === 'structural'; })) {
                state = structuralState(presentation);
            }
            for (var index = 0; index < params.steps.length; index++) {
                var step = params.steps[index];
                var control = params.testControl || {};
                if (Number(control.failBeforeStepIndex) === index) {
                    throw new Error('scene_mixed_injected_failure_before_step:' + index);
                }
                if (step.stepKind === 'creation') {
                    var created = executeCreationPlan({ actions: step.actions },
                        Identity.runtimeLocator(presentation));
                    if (!created.success) {
                        if (created.data && created.data.wroteToWps === true) {
                            wrote = true;
                            childRollbackIssues = (created.data.rollbackIssues || []).concat([
                                { code: 'mixed_creation_step_rollback_unverified', stepIndex: index }
                            ]);
                        }
                        throw new Error(created.error);
                    }
                    wrote = true;
                    receipts = receipts.concat(created.data.receipts || []);
                    readbacks.push({ stepIndex: index, operationId: String(step.operationId),
                        stepKind: step.stepKind, creationCount: (created.data.receipts || []).length });
                } else if (step.stepKind === 'creation_result_edit') {
                    var edit = executeCreationResultEdit(presentation, step, receipts);
                    wrote = true;
                    readbacks.push({ stepIndex: index, operationId: String(step.operationId),
                        stepKind: step.stepKind, changed: edit.changed, readback: edit.readback,
                        nativeSlideId: edit.nativeSlideId, nativeShapeId: edit.nativeShapeId });
                } else {
                    preflightStructural(presentation, step.action);
                    Identity.assertWritable(presentation);
                    structuralWrote = true;
                    wrote = true;
                    var structural = applyStructural(presentation, step.action);
                    undoCount += structural.undoCount;
                    readbacks.push({ stepIndex: index, operationId: String(step.operationId),
                        stepKind: step.stepKind, readback: structural.readback });
                }
                if (Number(control.failAfterStepIndex) === index) {
                    throw new Error('scene_mixed_injected_failure_after_step:' + index);
                }
            }
            return Result.success({ transactional: true, wroteToWps: wrote, rolledBack: false,
                rollbackVerified: false, presentationFingerprintBefore: before,
                presentationFingerprintAfter: Capture.presentationScene(presentation).fingerprint,
                creationReceipts: receipts, stepReadbacks: readbacks, rollbackIssues: [] });
        } catch (error) {
            var issues = childRollbackIssues.slice();
            if (wrote && presentation) {
                try { if (undoCount) undo(undoCount); }
                catch (undoError) { issues.push({ code: 'mixed_rollback_delete_undo_failed',
                    message: Result.errorText(undoError), undoCount: undoCount }); }
                var restored = await Operations.restoreSnapshot(presentation, {}, receipts);
                issues = issues.concat(restored.rollbackIssues || []);
                if (structuralWrote) issues = issues.concat(restoreStructuralState(presentation, state));
            }
            var after = presentation ? Capture.presentationScene(presentation).fingerprint : '';
            if (wrote && before && after !== before) issues.push({
                code: 'mixed_rollback_presentation_fingerprint_mismatch', expected: before, actual: after
            });
            if (params.testControl && params.testControl.forceRollbackUnverified) {
                issues.push({ code: 'test_injected_rollback_verification_failure' });
            }
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: wrote, rolledBack: wrote,
                rollbackVerified: wrote && issues.length === 0,
                presentationFingerprintBefore: before, presentationFingerprintAfter: after,
                reason: Result.errorText(error), creationReceipts: receipts,
                stepReadbacks: readbacks, rollbackIssues: issues
            });
        }
    }

    async function executeMixedCreationPlanPageByPage(params, expectedPresentationRef) {
        params = params || {};
        var presentation = null; var before = '';
        try {
            presentation = Identity.requirePresentation(expectedPresentationRef || params.presentationId);
            before = Capture.presentationScene(presentation).fingerprint;
            if (params.requiredPageDisplayContractVersion !== 1) {
                throw new Error('wps_js_page_display_contract_invalid');
            }
            preflightMixed(presentation, params.steps);
            if (params.steps.some(function (step) { return step.stepKind !== 'creation'; })) {
                throw new Error('page_by_page_requires_creation_only');
            }
            var actions = [];
            params.steps.forEach(function (step) {
                actions = actions.concat(step.actions || []);
            });
            var created = await executeCreationPlanPageByPage({
                actions: actions,
                displayMode: 'page_by_page',
                requiredPageDisplayContractVersion: 1,
                testControl: params.testControl && {
                    failBeforeResultIndex: params.testControl.failBeforeResultIndex
                }
            }, Identity.runtimeLocator(presentation));
            if (!created.success) {
                return Result.failure(created.error, created.error, {
                    transactional: true,
                    wroteToWps: created.data && created.data.wroteToWps === true,
                    rolledBack: created.data && created.data.rolledBack === true,
                    rollbackVerified: created.data && created.data.rollbackVerified === true,
                    presentationFingerprintBefore: created.data &&
                        created.data.presentationFingerprintBefore || before,
                    presentationFingerprintAfter: created.data &&
                        created.data.presentationFingerprintAfter,
                    reason: created.data && created.data.reason || created.error,
                    creationReceipts: created.data && created.data.receipts || [],
                    stepReadbacks: [],
                    rollbackIssues: created.data && created.data.rollbackIssues || [],
                    pageDisplayEvidence: created.data && created.data.pageDisplayEvidence || []
                });
            }
            var receipts = created.data.receipts || [];
            var readbacks = params.steps.map(function (step, index) {
                return { stepIndex: index, operationId: String(step.operationId),
                    stepKind: step.stepKind, creationCount: receipts.filter(function (receipt) {
                        return String(receipt.operationId) === String(step.operationId);
                    }).length };
            });
            return Result.success({ transactional: true, wroteToWps: true, rolledBack: false,
                rollbackVerified: false,
                presentationFingerprintBefore: created.data.presentationFingerprintBefore,
                presentationFingerprintAfter: created.data.presentationFingerprintAfter,
                creationReceipts: receipts, stepReadbacks: readbacks, rollbackIssues: [],
                pageDisplayEvidence: created.data.pageDisplayEvidence || [] });
        } catch (error) {
            return Result.failure(errorCode(error), Result.errorText(error), {
                transactional: true, wroteToWps: false, rolledBack: false,
                rollbackVerified: false, presentationFingerprintBefore: before,
                presentationFingerprintAfter: before, reason: Result.errorText(error),
                creationReceipts: [], stepReadbacks: [], rollbackIssues: [],
                pageDisplayEvidence: []
            });
        }
    }

    function executeMixedPlan(params, expectedPresentationRef) {
        if (params && params.displayMode === 'page_by_page') {
            return executeMixedCreationPlanPageByPage(params, expectedPresentationRef);
        }
        return executeMixedPlanDefault(params, expectedPresentationRef);
    }

    return {
        executeCreationPlan: executeCreationPlan,
        rollbackCreationCommit: rollbackCreationCommit,
        executeStructuralPlan: executeStructuralPlan,
        executeMixedPlan: executeMixedPlan,
        assertNoChartSemanticData: assertNoChartSemanticData
    };
})();


/*
 * Input: Build-generated loopback config and server challenge/command responses
 * Output: Authenticated delivery, deduplicated results and terminal limit rejection
 * Pos: Phase 3 WPS JS Addin transport client
 */

var WpsJsBridgeTransport = (function () {
    var config = null;
    var sessionToken = null;
    var sessionId = null;
    var generation = 0;
    var appInstanceId = null;
    var polling = false;
    var pollSequence = 0;
    var heartbeatTimer = null;
    var completed = {};
    var inflight = {};
    var recoverResults = {};
    var status = 'stopped';

    function rightRotate(value, amount) {
        return (value >>> amount) | (value << (32 - amount));
    }

    function sha256(ascii) {
        var mathPow = Math.pow;
        var maxWord = mathPow(2, 32);
        var lengthProperty = 'length';
        var i;
        var j;
        var result = '';
        var words = [];
        var asciiBitLength = ascii[lengthProperty] * 8;
        var hash = sha256.h = sha256.h || [];
        var k = sha256.k = sha256.k || [];
        var primeCounter = k[lengthProperty];
        var isComposite = {};
        for (var candidate = 2; primeCounter < 64; candidate++) {
            if (!isComposite[candidate]) {
                for (i = 0; i < 313; i += candidate) isComposite[i] = candidate;
                hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
                k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
            }
        }
        ascii += '\x80';
        while (ascii[lengthProperty] % 64 - 56) ascii += '\x00';
        for (i = 0; i < ascii[lengthProperty]; i++) {
            j = ascii.charCodeAt(i);
            if (j >> 8) throw new Error('wps_js_bridge_hmac_non_ascii_input');
            words[i >> 2] |= j << ((3 - i) % 4) * 8;
        }
        words[words[lengthProperty]] = ((asciiBitLength / maxWord) | 0);
        words[words[lengthProperty]] = (asciiBitLength);
        for (j = 0; j < words[lengthProperty];) {
            var w = words.slice(j, j += 16);
            var oldHash = hash.slice(0);
            for (i = 0; i < 64; i++) {
                var w15 = w[i - 15];
                var w2 = w[i - 2];
                var a = hash[0];
                var e = hash[4];
                var temp1 = hash[7] +
                    (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
                    ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] +
                    (w[i] = i < 16 ? w[i] : (
                        w[i - 16] +
                        (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
                        w[i - 7] +
                        (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
                    ) | 0);
                var temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) +
                    ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
                hash = [(temp1 + temp2) | 0].concat(hash);
                hash[4] = (hash[4] + temp1) | 0;
                hash.pop();
            }
            for (i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
        }
        for (i = 0; i < 8; i++) {
            for (j = 3; j + 1; j--) {
                var byte = (hash[i] >> (j * 8)) & 255;
                result += (byte < 16 ? '0' : '') + byte.toString(16);
            }
        }
        return result;
    }

    function hexToAscii(hex) {
        var output = '';
        for (var index = 0; index < hex.length; index += 2) {
            output += String.fromCharCode(parseInt(hex.slice(index, index + 2), 16));
        }
        return output;
    }

    function hmacSha256(key, message) {
        if (key.length > 64) key = hexToAscii(sha256(key));
        while (key.length < 64) key += '\x00';
        var outer = '';
        var inner = '';
        for (var index = 0; index < 64; index++) {
            var code = key.charCodeAt(index);
            outer += String.fromCharCode(code ^ 0x5c);
            inner += String.fromCharCode(code ^ 0x36);
        }
        return sha256(outer + hexToAscii(sha256(inner + message)));
    }

    function request(method, path, body, callback, timeoutMs) {
        var requestGeneration = generation;
        var xhr = new XMLHttpRequest();
        xhr.open(method, config.serverUrl + path, true);
        xhr.timeout = timeoutMs || 15000;
        if (sessionToken) xhr.setRequestHeader('Authorization', 'Bearer ' + sessionToken);
        if (body !== undefined && body !== null) xhr.setRequestHeader('Content-Type', 'application/json');
        if (path === '/v1/results') xhr.setRequestHeader('X-WPS-Request-Id', body.requestId);
        xhr.onload = function () {
            if (requestGeneration !== generation) return;
            var parsed = null;
            try { parsed = xhr.responseText ? JSON.parse(xhr.responseText) : null; } catch (_error) {}
            callback(null, xhr.status, parsed);
        };
        xhr.onerror = function () { if (requestGeneration === generation) callback(new Error('js_bridge_loopback_request_failed')); };
        xhr.ontimeout = function () { if (requestGeneration === generation) callback(new Error('js_bridge_loopback_request_timeout')); };
        xhr.send(body === undefined || body === null ? null : JSON.stringify(body));
    }

    function postResult(envelope) {
        if (!sessionId) return;
        if (envelope.sessionId !== sessionId) {
            if (recoverResults[envelope.requestId] !== envelope.sessionId) return;
            envelope = Object.assign({}, envelope, {
                sessionId: sessionId, recoverySessionId: envelope.sessionId
            });
        }
        request('POST', '/v1/results', envelope, function (error, responseStatus, payload) {
            if (responseStatus === 401 || responseStatus === 409 || responseStatus === 410) {
                delete inflight[envelope.requestId];
                return;
            }
            if (!error && (responseStatus === 400 || responseStatus === 413) &&
                payload && payload.error &&
                /^js_bridge_payload_(too_large|too_deep|too_many_entries)$/.test(payload.error.code)) {
                delete inflight[envelope.requestId];
                return;
            }
            if (error || responseStatus !== 200) {
                setTimeout(function () { postResult(envelope); }, 500);
                return;
            }
            delete inflight[envelope.requestId];
        });
    }

    function resultEnvelope(command, result) {
        return {
            protocolVersion: 1,
            requestId: command.requestId,
            dispatchState: 'completed',
            success: Boolean(result && result.success),
            appInstanceId: command.expectedAppInstanceId,
            sessionId: command.sessionId,
            presentationRef: command.expectedPresentationRef,
            result: result,
            error: result && result.error ? result.error : null
        };
    }

    function processCommand(command, execute) {
        if (!command || command.protocolVersion !== 1 ||
            command.expectedAppInstanceId !== appInstanceId || command.sessionId !== sessionId) return;
        var now = new Date().getTime();
        for (var requestId in completed) {
            if (completed.hasOwnProperty(requestId) && completed[requestId].expiresAt <= now) {
                delete completed[requestId];
            }
        }
        var cached = completed[command.requestId];
        if (cached) {
            postResult(cached.envelope);
            return;
        }
        if (inflight[command.requestId]) return;
        inflight[command.requestId] = true;
        request('POST', '/v1/acks', {
            requestId: command.requestId,
            dispatchState: 'acknowledged'
        }, function (ackError, ackStatus) {
            if (ackError || ackStatus !== 200) {
                delete inflight[command.requestId];
                return;
            }
            request('POST', '/v1/acks', {
                requestId: command.requestId,
                dispatchState: 'dispatched'
            }, function (dispatchError, dispatchStatus) {
                if (dispatchError || dispatchStatus !== 200) {
                    delete inflight[command.requestId];
                    return;
                }
                var outcome;
                try { outcome = execute(command); }
                catch (error) {
                    outcome = WpsJsBridgeResult.failure(
                        'wps_js_action_failed', WpsJsBridgeResult.errorText(error)
                    );
                }
                Promise.resolve(outcome).then(function (result) {
                    var envelope = resultEnvelope(command, result);
                    completed[command.requestId] = {
                        envelope: envelope,
                        expiresAt: new Date().getTime() + Number(config.resultCacheTtlMs || 120000)
                    };
                    postResult(envelope);
                }, function (error) {
                    var envelope = resultEnvelope(command, WpsJsBridgeResult.failure(
                        'wps_js_action_failed', WpsJsBridgeResult.errorText(error)
                    ));
                    completed[command.requestId] = {
                        envelope: envelope,
                        expiresAt: new Date().getTime() + Number(config.resultCacheTtlMs || 120000)
                    };
                    postResult(envelope);
                });
            });
        });
    }

    function poll(execute) {
        if (!polling) return;
        var pollGeneration = generation;
        // Distinct URLs prevent WPS's shared browser from serializing pending
        // GETs for the same cache key across authenticated Addin instances.
        var pollPath = '/v1/commands?instance=' + encodeURIComponent(appInstanceId) +
            '&poll=' + (++pollSequence);
        request('GET', pollPath, null, function (error, responseStatus, payload) {
            if (!error && responseStatus === 200 && payload) processCommand(payload, execute);
            if (responseStatus === 410) {
                reset();
                status = 'retired';
                return;
            }
            if (responseStatus === 401) {
                reset();
                var resetGeneration = generation;
                setTimeout(function () {
                    if (generation === resetGeneration && status === 'disconnected') register(execute);
                }, 500);
                return;
            }
            if (!error && (responseStatus === 200 || responseStatus === 204)) {
                // Network callbacks keep hidden Addins responsive without a
                // chain of timers that WPS's browser can throttle in background.
                if (pollGeneration === generation) poll(execute);
            } else {
                setTimeout(function () {
                    if (pollGeneration === generation) poll(execute);
                }, 500);
            }
        }, Number(config.pollTimeoutMs || 20000) + 5000);
    }

    function heartbeat() {
        request('POST', '/v1/heartbeat', {}, function (error, responseStatus) {
            if (error || responseStatus !== 200) status = 'degraded';
        });
    }

    function reset() {
        generation += 1;
        polling = false;
        sessionToken = null;
        sessionId = null;
        inflight = {};
        recoverResults = {};
        if (heartbeatTimer) clearInterval(heartbeatTimer);
        heartbeatTimer = null;
        status = 'disconnected';
    }

    function register(execute) {
        var registrationGeneration = generation;
        function retry() {
            setTimeout(function () {
                if (registrationGeneration === generation && status === 'registering') register(execute);
            }, 500);
        }
        status = 'registering';
        request('POST', '/v1/challenge', { appInstanceId: appInstanceId },
            function (challengeError, challengeStatus, challenge) {
                if (challengeError || challengeStatus !== 200 || !challenge) {
                    retry();
                    return;
                }
                var proof = hmacSha256(config.secret,
                    challenge.challengeId + ':' + challenge.nonce + ':' + appInstanceId);
                var metadata = {
                    protocolVersion: 1,
                    routingVersion: 1,
                    platform: config.platform,
                    wpsVersion: String(WpsJsBridgeIdentity.safeRead(function () {
                        return Application.Version;
                    }, 'unknown')),
                    addinVersion: config.addinVersion,
                    sourceSha256: config.sourceSha256,
                    appType: 'wpp',
                    appInstanceId: appInstanceId,
                    capabilities: config.capabilities,
                    capabilityReport: config.capabilityReport,
                    capabilityHash: config.capabilityHash
                };
                request('POST', '/v1/register', {
                    challengeId: challenge.challengeId,
                    proof: proof,
                    metadata: metadata
                }, function (registerError, registerStatus, response) {
                    if (registerStatus === 410) { reset(); status = 'retired'; return; }
                    if (registerError || registerStatus !== 200 || !response) {
                        retry();
                        return;
                    }
                    sessionToken = response.sessionToken;
                    sessionId = response.sessionId;
                    (response.recoverResults || []).forEach(function (pending) {
                        recoverResults[pending.requestId] = pending.sessionId;
                        var cached = completed[pending.requestId];
                        if (!cached || cached.envelope.sessionId !== pending.sessionId) return;
                        postResult(cached.envelope);
                    });
                    config.pollTimeoutMs = response.pollTimeoutMs;
                    config.resultCacheTtlMs = response.resultCacheTtlMs;
                    polling = true;
                    status = 'connected';
                    heartbeatTimer = setInterval(heartbeat,
                        Math.max(1000, Math.floor(Number(response.heartbeatTimeoutMs) / 3)));
                    poll(execute);
                });
            });
    }

    function start(runtimeConfig, execute) {
        if (polling || status === 'registering') return;
        config = runtimeConfig;
        if (!appInstanceId || status === 'retired') {
            appInstanceId = 'wpp-' + new Date().getTime() + '-' + Math.random().toString(16).slice(2);
            if (WpsJsBridgeIdentity.bindInstance) WpsJsBridgeIdentity.bindInstance(appInstanceId);
        }
        register(execute);
    }

    function disconnect() {
        if (!sessionToken) return reset();
        request('POST', '/v1/disconnect', {}, function () { reset(); });
    }

    return {
        start: start,
        disconnect: disconnect,
        status: function () { return status; },
        instanceId: function () { return appInstanceId; },
        hmacSha256: hmacSha256
    };
})();


/*
 * Input: WPS Addin lifecycle and authenticated native command envelopes
 * Output: The closed native Presentation action set supported by the JS executor
 * Pos: Phase 3 Addin dispatcher; no user prompt or Scene orchestration logic
 */

var WpsJsBridgeRuntime = (function () {
    function execute(command) {
        var params = command.params || {};
        if (command.action === 'ping') {
            return WpsJsBridgeResult.success({
                connected: true,
                appType: 'wpp',
                application: {
                    name: WpsJsBridgeIdentity.safeRead(function () { return Application.Name; }, null),
                    version: WpsJsBridgeIdentity.safeRead(function () { return Application.Version; }, null)
                }
            });
        }
        if (command.action === 'getCurrentPptContext') {
            return WpsJsBridgeCapture.getCurrentPptContext(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'readSlides') {
            return WpsJsBridgeCapture.readSlides(params, command.expectedPresentationRef);
        }
        if (command.action === 'readPresentationScene') {
            return WpsJsBridgeCapture.readPresentationScene(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'readPptSceneTargets') {
            return WpsJsBridgeCapture.readTargets(params, command.expectedPresentationRef);
        }
        if (command.action === 'managePptPresentation') {
            return WpsJsBridgeLifecycle.execute(params, command.expectedPresentationRef);
        }
        if (command.action === 'editSlideBatch') {
            return WpsJsBridgeOperations.editSlideBatch(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'duplicatePptObject') {
            return WpsJsBridgeOperations.duplicateObject(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'duplicatePptComponent') {
            return WpsJsBridgeOperations.duplicateComponent(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'normalizePptComponentGrid') {
            return WpsJsBridgeOperations.normalizeComponentGrid(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'restorePptMutationSnapshot') {
            return WpsJsBridgeOperations.restoreMutationSnapshot(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'recoverPptMutationSnapshot') {
            return WpsJsBridgeOperations.restoreMutationSnapshot(
                Object.assign({}, params, { recoveryMode: 'verify_or_restore' }), command.expectedPresentationRef
            );
        }
        if (command.action === 'executePptSceneCreationPlan') {
            return WpsJsBridgePlans.executeCreationPlan(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'rollbackPptSceneCreationCommit') {
            return WpsJsBridgePlans.rollbackCreationCommit(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'executePptSceneMixedPlan') {
            return WpsJsBridgePlans.executeMixedPlan(
                params, command.expectedPresentationRef
            );
        }
        if (command.action === 'executePptSceneStructuralPlan') {
            return WpsJsBridgePlans.executeStructuralPlan(
                params, command.expectedPresentationRef
            );
        }
        return WpsJsBridgeResult.failure('wps_js_phase3_action_not_supported');
    }

    function start() {
        if (typeof WpsJsBridgeBuildConfig !== 'object' || !WpsJsBridgeBuildConfig.secret) {
            throw new Error('wps_js_bridge_build_config_missing');
        }
        WpsJsBridgeTransport.start(WpsJsBridgeBuildConfig, execute);
    }

    return { start: start, status: WpsJsBridgeTransport.status };
})();

function OnAddinLoad(ribbonUI) {
    try { Application.ribbonUI = ribbonUI; } catch (_error) {}
    WpsJsBridgeRuntime.start();
    return true;
}
function OnBridgeStatus() {
    alert('OpenDesk WPS JS Bridge: ' + WpsJsBridgeRuntime.status());
    return true;
}
function OnBridgeWake() {
    WpsJsBridgeRuntime.start();
    return { appInstanceId: WpsJsBridgeTransport.instanceId() };
}
