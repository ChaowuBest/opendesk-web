const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_GATEWAY_CONTRACT_PATH = path.join(__dirname, 'ppt-scene-v2-gateway-tools.json');
const GATEWAY_MODE = 'scene-v2';

function stringList(value, label) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== 'string' || !item.trim())) {
    throw new Error(`${label} must be an array of non-empty tool names`);
  }
  return value.map((item) => item.trim());
}

function loadGatewayContract(contractPath = DEFAULT_GATEWAY_CONTRACT_PATH, readFileSync = fs.readFileSync) {
  const parsed = JSON.parse(readFileSync(contractPath, 'utf8'));
  if (!parsed || parsed.mode !== GATEWAY_MODE) {
    throw new Error(`Invalid Scene v2 Gateway contract mode in ${contractPath}`);
  }
  if (!parsed.visibleToolGroups || typeof parsed.visibleToolGroups !== 'object' || Array.isArray(parsed.visibleToolGroups)) {
    throw new Error(`visibleToolGroups is required in ${contractPath}`);
  }
  if (Object.prototype.hasOwnProperty.call(parsed, 'internalOnlyTools') ||
      Object.prototype.hasOwnProperty.call(parsed, 'highRiskGrantOnlyTools')) {
    throw new Error('Scene v2 Gateway does not support legacy hidden or grant-only tool categories');
  }

  const visibleToolGroups = {};
  const visibleTools = [];
  for (const [groupName, value] of Object.entries(parsed.visibleToolGroups)) {
    const tools = stringList(value, `visibleToolGroups.${groupName}`);
    visibleToolGroups[groupName] = tools;
    visibleTools.push(...tools);
  }
  const duplicates = visibleTools.filter((name, index) => visibleTools.indexOf(name) !== index);
  if (duplicates.length > 0) {
    throw new Error(`Duplicate model-visible Gateway tools: ${[...new Set(duplicates)].join(', ')}`);
  }

  const names = parsed.publicToolNames;
  if (!names || typeof names !== 'object' || Array.isArray(names) ||
      Object.keys(names).length !== visibleTools.length ||
      visibleTools.some((name) => !Object.prototype.hasOwnProperty.call(names, name))) {
    throw new Error('publicToolNames must map exactly the visible Gateway tools');
  }
  const aliases = Object.values(names);
  if (aliases.some((name) => typeof name !== 'string' || !/^[a-z][a-z0-9_]*$/.test(name) || visibleTools.includes(name)) ||
      new Set(aliases).size !== aliases.length) {
    throw new Error('publicToolNames must contain unique identifiers distinct from canonical names');
  }

  return {
    ...parsed,
    contractPath,
    visibleToolGroups,
    visibleTools,
  };
}

function buildToolVisibilityPolicy(env = process.env, options = {}) {
  const mode = String(env.OPENDESK_WPS_TOOL_EXPOSURE_MODE || GATEWAY_MODE).trim().toLowerCase();
  if (mode !== GATEWAY_MODE) {
    throw new Error(`Unsupported OPENDESK_WPS_TOOL_EXPOSURE_MODE: ${mode}`);
  }
  const contractPath = env.OPENDESK_WPS_GATEWAY_CONTRACT_PATH || options.defaultContractPath ||
    DEFAULT_GATEWAY_CONTRACT_PATH;
  const contract = loadGatewayContract(contractPath, options.readFileSync);
  const publicToNative = new Map();
  const descriptionNames = new Map();
  for (const [native, alias] of Object.entries(contract.publicToolNames)) {
    publicToNative.set(alias, native);
    descriptionNames.set(native, alias);
    descriptionNames.set(native.replace(/^wps_ppt_/, ''), alias);
  }
  return {
    mode,
    allowedTools: new Set(contract.visibleTools),
    contract,
    publicToNative,
    descriptionNames,
  };
}

function isToolVisible(policy, toolName) {
  return Boolean(policy && policy.allowedTools && policy.allowedTools.has(toolName));
}

function resolveNativeToolName(policy, name) {
  if (typeof name !== 'string') return undefined;
  return policy.publicToNative.get(name) || (isToolVisible(policy, name) ? name : undefined);
}

function publicDescription(value, policy) {
  return typeof value === 'string'
    ? value.replace(/[A-Za-z0-9_]+/g, (token) => policy.descriptionNames.get(token) || token)
    : value;
}

function publicSchema(schema, policy) {
  if (!schema || typeof schema !== 'object' || Array.isArray(schema)) return schema;
  const result = { ...schema };
  if (typeof schema.description === 'string') result.description = publicDescription(schema.description, policy);
  // Traverse Schema positions only; defaults, examples and enum values are user data.
  for (const key of ['properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas']) {
    if (schema[key] && typeof schema[key] === 'object') {
      result[key] = Object.fromEntries(Object.entries(schema[key]).map(([name, child]) => [name, publicSchema(child, policy)]));
    }
  }
  for (const key of ['allOf', 'anyOf', 'oneOf', 'prefixItems']) {
    if (Array.isArray(schema[key])) result[key] = schema[key].map((child) => publicSchema(child, policy));
  }
  for (const key of ['items', 'additionalItems', 'additionalProperties', 'unevaluatedItems',
    'unevaluatedProperties', 'contains', 'propertyNames', 'not', 'if', 'then', 'else']) {
    if (Object.prototype.hasOwnProperty.call(schema, key)) {
      result[key] = Array.isArray(schema[key])
        ? schema[key].map((child) => publicSchema(child, policy)) : publicSchema(schema[key], policy);
    }
  }
  return result;
}

function modelVisibleTool(tool, policy = buildToolVisibilityPolicy({})) {
  const native = resolveNativeToolName(policy, tool.name);
  if (!native) throw new Error(`Unknown Gateway tool: ${tool.name}`);
  let projected = { ...tool };
  if (native === 'wps_ppt_manage_presentations' && Array.isArray(tool.inputSchema?.oneOf)) {
    // Keep the action union inside an object so Zod's roundtrip preserves the root type.
    projected.description = `${tool.description}\nPut the lifecycle action and its fields inside exactly one request object.`;
    projected.inputSchema = {
      type: 'object', properties: { request: tool.inputSchema }, required: ['request'], additionalProperties: false,
    };
  }
  projected.name = policy.contract.publicToolNames[native];
  if (typeof projected.description === 'string') projected.description = publicDescription(projected.description, policy);
  for (const key of ['inputSchema', 'outputSchema']) {
    if (projected[key]) projected[key] = publicSchema(projected[key], policy);
  }
  return projected;
}

function nativeToolArguments(toolName, args) {
  if (toolName !== 'wps_ppt_manage_presentations') return args;
  if (!args || typeof args !== 'object' || Array.isArray(args) ||
      Object.keys(args).length !== 1 || !Object.prototype.hasOwnProperty.call(args, 'request') ||
      !args.request || typeof args.request !== 'object' || Array.isArray(args.request)) {
    throw new Error('manage_presentations requires exactly one request object containing action and its fields');
  }
  return args.request;
}

module.exports = {
  DEFAULT_GATEWAY_CONTRACT_PATH,
  GATEWAY_MODE,
  buildToolVisibilityPolicy,
  isToolVisible,
  loadGatewayContract,
  modelVisibleTool,
  nativeToolArguments,
  resolveNativeToolName,
};
