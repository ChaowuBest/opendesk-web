const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_GATEWAY_CONTRACT_PATH = path.join(__dirname, 'ppt-scene-v2-gateway-tools.json');
const GATEWAY_MODE = 'scene-v2';

function stringList(value, label) {
  if (!Array.isArray(value) || value.some((item) => typeof item !== 'string' || !item.trim())) {
    throw new Error(`${label} must be an array of non-empty tool names`);
  }
  return value.map((item) => item.trim());
}

function loadGatewayContract(contractPath = DEFAULT_GATEWAY_CONTRACT_PATH, readFileSync = fs.readFileSync) {
  const parsed = JSON.parse(readFileSync(contractPath, 'utf8'));
  if (!parsed || parsed.mode !== GATEWAY_MODE) {
    throw new Error(`Invalid Scene v2 Gateway contract mode in ${contractPath}`);
  }
  if (!parsed.visibleToolGroups || typeof parsed.visibleToolGroups !== 'object' || Array.isArray(parsed.visibleToolGroups)) {
    throw new Error(`visibleToolGroups is required in ${contractPath}`);
  }
  if (Object.prototype.hasOwnProperty.call(parsed, 'internalOnlyTools') ||
      Object.prototype.hasOwnProperty.call(parsed, 'highRiskGrantOnlyTools')) {
    throw new Error('Scene v2 Gateway does not support legacy hidden or grant-only tool categories');
  }

  const visibleToolGroups = {};
  const visibleTools = [];
  for (const [groupName, value] of Object.entries(parsed.visibleToolGroups)) {
    const tools = stringList(value, `visibleToolGroups.${groupName}`);
    visibleToolGroups[groupName] = tools;
    visibleTools.push(...tools);
  }
  const duplicates = visibleTools.filter((name, index) => visibleTools.indexOf(name) !== index);
  if (duplicates.length > 0) {
    throw new Error(`Duplicate model-visible Gateway tools: ${[...new Set(duplicates)].join(', ')}`);
  }

  return {
    ...parsed,
    contractPath,
    visibleToolGroups,
    visibleTools,
  };
}

function buildToolVisibilityPolicy(env = process.env, options = {}) {
  const mode = String(env.OPENDESK_WPS_TOOL_EXPOSURE_MODE || GATEWAY_MODE).trim().toLowerCase();
  if (mode !== GATEWAY_MODE) {
    throw new Error(`Unsupported OPENDESK_WPS_TOOL_EXPOSURE_MODE: ${mode}`);
  }
  const contractPath = env.OPENDESK_WPS_GATEWAY_CONTRACT_PATH || options.defaultContractPath ||
    DEFAULT_GATEWAY_CONTRACT_PATH;
  const contract = loadGatewayContract(contractPath, options.readFileSync);
  return {
    mode,
    allowedTools: new Set(contract.visibleTools),
    contract,
  };
}

function isToolVisible(policy, toolName) {
  return Boolean(policy && policy.allowedTools && policy.allowedTools.has(toolName));
}

function modelVisibleTool(tool) {
  if (tool.name !== 'wps_ppt_manage_presentations' || !Array.isArray(tool.inputSchema?.oneOf)) return tool;
  // Keep the action union inside an object so Zod's roundtrip preserves the root type.
  return {
    ...tool,
    description: `${tool.description}\nPut the lifecycle action and its fields inside exactly one request object.`,
    inputSchema: {
      type: 'object',
      properties: { request: tool.inputSchema },
      required: ['request'],
      additionalProperties: false,
    },
  };
}

function nativeToolArguments(toolName, args) {
  if (toolName !== 'wps_ppt_manage_presentations') return args;
  if (!args || typeof args !== 'object' || Array.isArray(args) ||
      Object.keys(args).length !== 1 || !Object.prototype.hasOwnProperty.call(args, 'request') ||
      !args.request || typeof args.request !== 'object' || Array.isArray(args.request)) {
    throw new Error('manage_presentations requires exactly one request object containing action and its fields');
  }
  return args.request;
}

module.exports = {
  DEFAULT_GATEWAY_CONTRACT_PATH,
  GATEWAY_MODE,
  buildToolVisibilityPolicy,
  isToolVisible,
  loadGatewayContract,
  modelVisibleTool,
  nativeToolArguments,
};
