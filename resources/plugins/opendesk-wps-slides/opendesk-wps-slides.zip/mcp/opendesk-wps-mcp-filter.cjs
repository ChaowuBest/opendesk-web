#!/usr/bin/env node
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// integrations/opendesk-wps-assistant-config/mcp/scene-v2-gateway.js
var require_scene_v2_gateway = __commonJS({
  "integrations/opendesk-wps-assistant-config/mcp/scene-v2-gateway.js"(exports2, module2) {
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var DEFAULT_GATEWAY_CONTRACT_PATH = path2.join(__dirname, "ppt-scene-v2-gateway-tools.json");
    var GATEWAY_MODE = "scene-v2";
    function stringList(value, label) {
      if (!Array.isArray(value) || value.some((item) => typeof item !== "string" || !item.trim())) {
        throw new Error(`${label} must be an array of non-empty tool names`);
      }
      return value.map((item) => item.trim());
    }
    function loadGatewayContract(contractPath = DEFAULT_GATEWAY_CONTRACT_PATH, readFileSync = fs2.readFileSync) {
      const parsed = JSON.parse(readFileSync(contractPath, "utf8"));
      if (!parsed || parsed.mode !== GATEWAY_MODE) {
        throw new Error(`Invalid Scene v2 Gateway contract mode in ${contractPath}`);
      }
      if (!parsed.visibleToolGroups || typeof parsed.visibleToolGroups !== "object" || Array.isArray(parsed.visibleToolGroups)) {
        throw new Error(`visibleToolGroups is required in ${contractPath}`);
      }
      if (Object.prototype.hasOwnProperty.call(parsed, "internalOnlyTools") || Object.prototype.hasOwnProperty.call(parsed, "highRiskGrantOnlyTools")) {
        throw new Error("Scene v2 Gateway does not support legacy hidden or grant-only tool categories");
      }
      const visibleToolGroups = {};
      const visibleTools = [];
      for (const [groupName, value] of Object.entries(parsed.visibleToolGroups)) {
        const tools = stringList(value, `visibleToolGroups.${groupName}`);
        visibleToolGroups[groupName] = tools;
        visibleTools.push(...tools);
      }
      const duplicates = visibleTools.filter((name, index) => visibleTools.indexOf(name) !== index);
      if (duplicates.length > 0) {
        throw new Error(`Duplicate model-visible Gateway tools: ${[...new Set(duplicates)].join(", ")}`);
      }
      return {
        ...parsed,
        contractPath,
        visibleToolGroups,
        visibleTools
      };
    }
    function buildToolVisibilityPolicy2(env = process.env, options = {}) {
      const mode = String(env.OPENDESK_WPS_TOOL_EXPOSURE_MODE || GATEWAY_MODE).trim().toLowerCase();
      if (mode !== GATEWAY_MODE) {
        throw new Error(`Unsupported OPENDESK_WPS_TOOL_EXPOSURE_MODE: ${mode}`);
      }
      const contractPath = env.OPENDESK_WPS_GATEWAY_CONTRACT_PATH || options.defaultContractPath || DEFAULT_GATEWAY_CONTRACT_PATH;
      const contract = loadGatewayContract(contractPath, options.readFileSync);
      return {
        mode,
        allowedTools: new Set(contract.visibleTools),
        contract
      };
    }
    function isToolVisible2(policy, toolName) {
      return Boolean(policy && policy.allowedTools && policy.allowedTools.has(toolName));
    }
    function modelVisibleTool2(tool) {
      if (tool.name !== "wps_ppt_manage_presentations" || !Array.isArray(tool.inputSchema?.oneOf)) return tool;
      return {
        ...tool,
        description: `${tool.description}
Put the lifecycle action and its fields inside exactly one request object.`,
        inputSchema: {
          type: "object",
          properties: { request: tool.inputSchema },
          required: ["request"],
          additionalProperties: false
        }
      };
    }
    function nativeToolArguments2(toolName, args) {
      if (toolName !== "wps_ppt_manage_presentations") return args;
      if (!args || typeof args !== "object" || Array.isArray(args) || Object.keys(args).length !== 1 || !Object.prototype.hasOwnProperty.call(args, "request") || !args.request || typeof args.request !== "object" || Array.isArray(args.request)) {
        throw new Error("manage_presentations requires exactly one request object containing action and its fields");
      }
      return args.request;
    }
    module2.exports = {
      DEFAULT_GATEWAY_CONTRACT_PATH,
      GATEWAY_MODE,
      buildToolVisibilityPolicy: buildToolVisibilityPolicy2,
      isToolVisible: isToolVisible2,
      loadGatewayContract,
      modelVisibleTool: modelVisibleTool2,
      nativeToolArguments: nativeToolArguments2
    };
  }
});

// integrations/opendesk-wps-assistant-config/mcp/opendesk-wps-mcp-filter.js
var { spawn } = require("node:child_process");
var fs = require("node:fs");
var path = require("node:path");
var {
  buildToolVisibilityPolicy,
  isToolVisible,
  modelVisibleTool,
  nativeToolArguments
} = require_scene_v2_gateway();
var BUILTIN_RUNTIME_MODE = "builtin-plugin-v1";
var builtinRuntime = process.env.OPENDESK_WPS_RUNTIME_MODE === BUILTIN_RUNTIME_MODE;
if (builtinRuntime) {
  const required = [
    "OPENDESK_WPS_MCP_COMMAND",
    "OPENDESK_WPS_MCP_SERVER_PATH",
    "OPENDESK_WPS_MCP_SERVER_CWD",
    "OPENDESK_WPS_GATEWAY_CONTRACT_PATH",
    "OPENDESK_WPS_TOOL_EXPOSURE_MODE",
    "WPS_COM_SCRIPT_PATH",
    "WPS_PPT_SCENE_DIR",
    "WPS_PPT_SCENE_RESOURCE_DIR",
    "WPS_PPT_ARTIFACT_DIR",
    "WPS_ASSET_DIR",
    "WPS_PPT_LIFECYCLE_AUTH_DIR"
  ];
  const missing = required.filter((name) => !String(process.env[name] || "").trim());
  const absolutePaths = required.filter((name) => name.endsWith("_PATH") || name.endsWith("_DIR") || name.endsWith("_CWD") || name === "OPENDESK_WPS_MCP_COMMAND").filter((name) => !path.isAbsolute(String(process.env[name] || "")));
  const requiredFiles = [
    "OPENDESK_WPS_MCP_COMMAND",
    "OPENDESK_WPS_MCP_SERVER_PATH",
    "OPENDESK_WPS_GATEWAY_CONTRACT_PATH",
    "WPS_COM_SCRIPT_PATH"
  ];
  const missingFiles = requiredFiles.filter((name) => {
    const value = String(process.env[name] || "");
    return value && !fs.existsSync(value);
  });
  const requiredDirectories = [
    "OPENDESK_WPS_MCP_SERVER_CWD",
    "WPS_PPT_SCENE_DIR",
    "WPS_PPT_SCENE_RESOURCE_DIR",
    "WPS_PPT_ARTIFACT_DIR",
    "WPS_ASSET_DIR",
    "WPS_PPT_LIFECYCLE_AUTH_DIR"
  ];
  const missingDirectories = requiredDirectories.filter((name) => {
    const value = String(process.env[name] || "");
    return value && (!fs.existsSync(value) || !fs.statSync(value).isDirectory());
  });
  if (missing.length || absolutePaths.length || missingFiles.length || missingDirectories.length) {
    process.stderr.write(`[opendesk-wps-mcp-filter] invalid builtin runtime environment: ${JSON.stringify({
      missing,
      absolutePaths,
      missingFiles,
      missingDirectories
    })}
`);
    process.exit(2);
  }
}
var REPOSITORY_ROOT = path.resolve(__dirname, "..", "..", "..");
var DEFAULT_SERVER_PATH = path.join(REPOSITORY_ROOT, "wps-office-mcp", "dist", "index.js");
var DEFAULT_SERVER_CWD = REPOSITORY_ROOT;
var visibilityPolicy;
try {
  visibilityPolicy = buildToolVisibilityPolicy(process.env);
} catch (error) {
  process.stderr.write(`[opendesk-wps-mcp-filter] invalid tool exposure policy: ${error.message}
`);
  process.exit(2);
}
var serverCommand = process.env.OPENDESK_WPS_MCP_COMMAND || "node";
var serverPath = process.env.OPENDESK_WPS_MCP_SERVER_PATH || DEFAULT_SERVER_PATH;
var serverCwd = process.env.OPENDESK_WPS_MCP_SERVER_CWD || DEFAULT_SERVER_CWD;
var sceneRoot = process.env.WPS_PPT_SCENE_DIR || path.join(REPOSITORY_ROOT, "assets", "wps-codex", "_ppt-scenes");
var sceneResourceRoot = process.env.WPS_PPT_SCENE_RESOURCE_DIR || path.join(REPOSITORY_ROOT, "assets", "wps-codex", "_scene-resource-refs");
var environmentEvidencePath = process.env.WPS_TEST_ENV_EVIDENCE_PATH || "";
if (environmentEvidencePath) {
  try {
    fs.writeFileSync(environmentEvidencePath, JSON.stringify({
      layer: "opendesk-wps-mcp-filter",
      forceTransport: process.env.WPS_TEST_FORCE_TRANSPORT_BEFORE_DISPATCH || null,
      disableFallback: process.env.WPS_TEST_DISABLE_PARAMS_FILE_FALLBACK || null,
      pid: process.pid,
      parentPid: process.ppid,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }, null, 2), "utf8");
  } catch (error) {
    process.stderr.write(`[opendesk-wps-mcp-filter] environment evidence failed: ${error.message}
`);
  }
}
function writeMessage(message) {
  process.stdout.write(`${JSON.stringify(message)}
`);
}
function toolBlockedMessage(toolName) {
  return `OpenDesk WPS MCP wrapper blocked tool "${toolName}" because it is outside the exact Scene v2 Slides contract.`;
}
function isAllowedTool(toolName) {
  return isToolVisible(visibilityPolicy, toolName);
}
var child = spawn(serverCommand, [serverPath], {
  cwd: serverCwd,
  env: {
    ...process.env,
    WPS_PPT_SCENE_DIR: sceneRoot,
    WPS_PPT_SCENE_RESOURCE_DIR: sceneResourceRoot
  },
  stdio: ["pipe", "pipe", "pipe"],
  windowsHide: true
});
child.stderr.on("data", (chunk) => {
  process.stderr.write(chunk);
});
child.on("error", (error) => {
  process.stderr.write(`[opendesk-wps-mcp-filter] failed to start child MCP server: ${error.message}
`);
});
child.on("exit", (code, signal) => {
  process.stderr.write(`[opendesk-wps-mcp-filter] child MCP server exited code=${code} signal=${signal || ""}
`);
  process.exit(code ?? 1);
});
var pendingToolsList = /* @__PURE__ */ new Set();
var childBuffer = "";
var stdinBuffer = "";
function idKey(id) {
  return typeof id === "undefined" ? void 0 : String(id);
}
function forwardToChild(message) {
  child.stdin.write(`${JSON.stringify(message)}
`);
}
function handleClientMessage(message) {
  if (message && message.method === "tools/list" && Object.prototype.hasOwnProperty.call(message, "id")) {
    pendingToolsList.add(idKey(message.id));
    forwardToChild(message);
    return;
  }
  if (message && message.method === "tools/call" && Object.prototype.hasOwnProperty.call(message, "id")) {
    const toolName = message.params && message.params.name;
    if (typeof toolName === "string" && !isAllowedTool(toolName)) {
      writeMessage({
        jsonrpc: "2.0",
        id: message.id,
        error: {
          code: -32001,
          message: toolBlockedMessage(toolName)
        }
      });
      return;
    }
    if (toolName === "wps_ppt_manage_presentations") {
      try {
        message = {
          ...message,
          params: { ...message.params, arguments: nativeToolArguments(toolName, message.params.arguments) }
        };
      } catch (error) {
        writeMessage({ jsonrpc: "2.0", id: message.id, error: { code: -32602, message: error.message } });
        return;
      }
    }
  }
  forwardToChild(message);
}
function handleServerMessage(message) {
  const key = idKey(message && message.id);
  if (key && pendingToolsList.has(key)) {
    pendingToolsList.delete(key);
    const tools = message.result && Array.isArray(message.result.tools) ? message.result.tools : void 0;
    if (tools) {
      message.result.tools = tools.filter((tool) => tool && isAllowedTool(tool.name)).map(modelVisibleTool);
    }
  }
  writeMessage(message);
}
function processLines(buffer, onLine) {
  let newlineIndex;
  while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
    const line = buffer.slice(0, newlineIndex).replace(/\r$/, "");
    buffer = buffer.slice(newlineIndex + 1);
    if (!line.trim()) continue;
    try {
      onLine(JSON.parse(line));
    } catch (error) {
      process.stderr.write(`[opendesk-wps-mcp-filter] invalid JSON-RPC line: ${error.message}
`);
    }
  }
  return buffer;
}
process.stdin.on("data", (chunk) => {
  stdinBuffer += chunk.toString("utf8");
  stdinBuffer = processLines(stdinBuffer, handleClientMessage);
});
child.stdout.on("data", (chunk) => {
  childBuffer += chunk.toString("utf8");
  childBuffer = processLines(childBuffer, handleServerMessage);
});
process.stdin.on("end", () => {
  child.stdin.end();
});
process.on("SIGINT", () => child.kill("SIGINT"));
process.on("SIGTERM", () => child.kill("SIGTERM"));
